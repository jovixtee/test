﻿using FFL.FileTransfer.Models;
using Microsoft.AspNetCore.Mvc;
using NLog;
using FileTransferService = FFL.FileTransfer.Services.FileTransferService;
using ILogger = NLog.ILogger;

namespace FFL.FileTransfer.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class FileTransferController : ControllerBase
    {
        private readonly ILogger logger;
        private readonly TransferFileInfo transferInfo;
        private readonly FileTransferService transferService;
        public FileTransferController(TransferFileInfo transferInfo, FileTransferService _transferService)
        {
            transferService = _transferService;
            logger = LogManager.GetLogger("FileTransferService");
            this.transferInfo = transferInfo;
            string folderPath = transferInfo.FileTransferService.FFLPSubscribeFolder.Trim();
            string CARSfolderPath = transferInfo.FileTransferService.CARSFolder.Trim();
            try
            {
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                if(!Directory.Exists(CARSfolderPath))
                {
                    Directory.CreateDirectory(CARSfolderPath);
                }
                if(!Directory.Exists(folderPath + "\\" + "DailySync"))
                {
                    Directory.CreateDirectory(folderPath + "\\" + "DailySync");
                }
                if(!Directory.Exists(folderPath + "\\" + "Archive"))
                {
                    Directory.CreateDirectory(folderPath + "\\" + "Archive");
                }
                if(!Directory.Exists(folderPath + "\\" + "ReturnFiles"))
                {
                    Directory.CreateDirectory(folderPath + "\\" + "ReturnFiles");
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, $"The FileTransfer service start failed due to creating folder failed.");
            }
        }

        [HttpGet("Getfile")]
        public async Task<IActionResult> GetFile(string type)
        {
            try
            {
                logger.Info("Start to GetFile.");
                (var stream, var fileName) =  await transferService.GetFileStream(transferInfo, type, Response);
                return base.File(stream, "text/plain", fileName);
            }
            catch(Exception ex)
            {
                logger.Error("An error ocurred when GetFile, exception:{0}", ex);
                throw;
            }
            finally
            {
                logger.Info("GetFile Finished.");
            }
        }

        [HttpPost("SaveFile")]
        public async void SaveFile([FromForm] IFormFile file, [FromForm] string type)
        {
            await transferService.SaveFile(file, type, transferInfo);
        }

        [HttpPost("DeleteFile")]
        public void DeleteFile(string type)
        {
            transferService.DeleteFile(transferInfo, type);
        }

        [HttpPost("ReturnFile")]
        public async Task ReturnFile([FromForm] IFormFile file, [FromForm] string type, [FromForm] string fileName)
        {
            await transferService.ReturnFile(file, type, transferInfo, fileName);
        }

        [HttpPost("WriteExceptionFile")]
        public async Task WriteExceptionFile([FromForm] IFormFile file)
        {
            await transferService.WriteExceptionFile(file, transferInfo);
        }
    }
}

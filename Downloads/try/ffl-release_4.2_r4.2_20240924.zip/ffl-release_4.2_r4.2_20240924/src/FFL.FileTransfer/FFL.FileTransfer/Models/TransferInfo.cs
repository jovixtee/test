﻿namespace FFL.FileTransfer.Models
{

    public class TransferFileInfo
    {
        public FileTransferService FileTransferService { get; set; }
    }
    public class FileTransferService
    {
        public string Host { get; set; }
        public string FFLPSubscribeFolder { get; set; }
        public string FileName { get; set; }
        public string CARSFolder { get; set; }
    }
}

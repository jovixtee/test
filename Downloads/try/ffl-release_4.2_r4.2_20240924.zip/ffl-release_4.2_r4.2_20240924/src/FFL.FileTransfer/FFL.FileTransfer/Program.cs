using NLog.Web;
using NLog;
using ILogger = NLog.ILogger;
using FFL.FileTransfer.Models;
using FFL.FileTransfer.Services;
using FileTransferService = FFL.FileTransfer.Services.FileTransferService;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.ClearProviders();
builder.Logging.AddNLog("NLog.config");
builder.Logging.AddNLogWeb();
ILogger logger = LogManager.GetLogger("FileTransferService");
try
{

    var environment = builder.Environment.EnvironmentName;

    logger.Info($"env: {environment}");

    var configuration = new ConfigurationBuilder()
        .SetBasePath(AppContext.BaseDirectory)
        .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
        .AddJsonFile($"appsettings.{environment}.json", optional: true, reloadOnChange: true)
        .Build();

    builder.Services.AddControllers();
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();
    builder.Services.AddWindowsService();
    builder.Services.AddSingleton<TransferFileInfo>(provider =>
    {
        var result = configuration.Get<TransferFileInfo>();

        return result;
    });
    builder.Services.AddSingleton<FileTransferService, FileTransferService>();

    builder.WebHost.UseUrls(configuration["FileTransferService:Host"]);

    var app = builder.Build();

    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }
    //app.UseHttpsRedirection();

    app.UseAuthorization();

    app.MapControllers();

    app.Map("/healthz", appconfig =>
    {
        appconfig.Run(async context =>
        {
            await context.Response.WriteAsync("Ok. Version:1.0.0");
        });
    });

    app.Run();
}
catch (Exception ex)
{
    logger.Fatal(ex, "Initialization failed");
}
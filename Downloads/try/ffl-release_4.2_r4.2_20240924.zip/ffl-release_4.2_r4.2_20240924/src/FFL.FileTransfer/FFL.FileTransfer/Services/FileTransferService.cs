﻿using FFL.FileTransfer.Models;
using Microsoft.AspNetCore.Mvc;
using NLog;
using System.IO;
using System.Text;
using ILogger = NLog.ILogger;

namespace FFL.FileTransfer.Services
{
    public class FileTransferService
    {
        private readonly ILogger logger;
        private readonly TransferFileInfo transferInfo;

        public FileTransferService(TransferFileInfo transferInfo)
        {
            logger = LogManager.GetLogger("FileTransferService");
            this.transferInfo = transferInfo;
        }


        public async Task<(Stream, string)> GetFileStream(TransferFileInfo info, string type, HttpResponse response)
        {
            try
            {
                var path = GetFilePath(info, type);
                var results = path.Split('\\');
                var fileName = results.LastOrDefault();
                logger.Info("Start to GetFileStream");
                if (File.Exists(path))
                {
                    Stream stream = new FileStream(path, FileMode.Open);
                    return (stream, fileName);
                }
                return (null, string.Empty);
            }
            catch(Exception ex)
            {
                logger.Error("An error ocurred when GetFileStream, ex: {0}", ex);
                throw;
            }
            finally
            {
                logger.Info("GetFileStream Finished.");
            }
        }

        public void DeleteFile(TransferFileInfo info, string type)
        {
            if(type.Equals("sync") || type.Equals("death"))
            {
                var path = GetFilePath(info, type);
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
        }

        public async Task SaveFile(IFormFile file, string type, TransferFileInfo transferFileInfo)
        {
            try
            {
                logger.Info("SaveFile start.");
                var filePath = string.Empty;
                if (type.Equals("sync", StringComparison.OrdinalIgnoreCase) || type.Equals("death", StringComparison.OrdinalIgnoreCase))
                {
                    filePath = (transferFileInfo.FileTransferService.FFLPSubscribeFolder + "\\" + file.FileName);
                }
                if(type.Equals("CARS", StringComparison.OrdinalIgnoreCase))
                {
                    filePath = (transferFileInfo.FileTransferService.CARSFolder + "\\" + file.FileName);
                }
                if (!string.IsNullOrEmpty(filePath))
                {
                    using (var stream = file.OpenReadStream())
                    {
                        using (var fileStream = File.Create(filePath))
                        {
                            await stream.CopyToAsync(fileStream);
                        }
                    }
                }  
                logger.Info("SaveFile finished.");
            }
            catch(Exception ex)
            {
                logger.Error("An error ocurred when SaveFile, ex: {0}", ex);
                throw;
            }
        }

        public async Task ReturnFile(IFormFile file, string type, TransferFileInfo transferFileInfo, string fileName)
        {
            try
            {
                logger.Info("Start to return file.");
                #region Write e-file
                var archiveFolderPath = transferFileInfo.FileTransferService.FFLPSubscribeFolder + "\\Archive";
                CheckAndCreateFolder(archiveFolderPath);
                var syncFolderPath = archiveFolderPath + "\\Sync";
                CheckAndCreateFolder(syncFolderPath);
                var deathFolderPath = archiveFolderPath + "\\Death";
                CheckAndCreateFolder(deathFolderPath);
                var folderPath = string.Empty;
                //fileName = type == "sync" ? "FFLP_ACK_" + DateTime.Now.ToString("yyyyMMdd") + ".txt" : "ZSF017OD_ACK_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                folderPath = transferFileInfo.FileTransferService.FFLPSubscribeFolder + "\\" + "ReturnFiles";
                var files = Directory.GetFiles(transferFileInfo.FileTransferService.FFLPSubscribeFolder + "\\DailySync");
                var recordFileName = type == "sync" ? files.Where(x => x.Contains("FFLP")).FirstOrDefault() : files.Where(x => x.Contains("ZSF017OD")).FirstOrDefault();
                if(recordFileName == null)
                {
                    logger.Error("File not exist.");
                    return;
                }
                var fileNameStr = recordFileName.Split("\\");
                var originalFileName = string.Empty;
                if (fileNameStr.Length > 0)
                {
                    originalFileName = fileNameStr.LastOrDefault();
                }
                CheckAndCreateFolder(folderPath);
                if (File.Exists(folderPath + "\\" + fileName))
                {
                    File.Delete(folderPath + "\\" + fileName);
                }
                using (var filestream = File.Create(folderPath + "\\" + fileName))
                {
                    file.OpenReadStream().CopyTo(filestream);
                }
                #endregion
                MoveAndUpdateFolderFile(recordFileName, type == "sync" ? syncFolderPath : deathFolderPath, originalFileName);
                logger.Info("Return file finished.");
            }
            catch (Exception ex)
            {
                logger.Error("An error ocurred when ReturnFile, ex: {0}", ex);
                throw;
            }
        }

        public async Task WriteExceptionFile(IFormFile file, TransferFileInfo transferFileInfo)
        {
            try
            {

                var archiveFolderPath = transferFileInfo.FileTransferService.FFLPSubscribeFolder + "\\Archive";
                var exceptionFolderPath = archiveFolderPath + "\\ExceptionRecords";
                var filePath = exceptionFolderPath + file.Name;
                using (var stream = file.OpenReadStream())
                {
                    using (var fileStream = File.Create(filePath))
                    {
                        await stream.CopyToAsync(fileStream);
                    }
                }
            }
            catch(Exception ex)
            {
                logger.Error("An error ocurred when WriteExceptionFile, ex: {0}", ex);
                throw;
            }
        }

        private string GetFilePath(TransferFileInfo info, string type)
        {
            string path = string.Empty;
            var files = Directory.GetFiles(info.FileTransferService.FFLPSubscribeFolder + "\\DailySync");
            foreach (var file in files)
            {
                if (file.Contains("FFLP", StringComparison.OrdinalIgnoreCase) && type.Equals("sync"))
                {
                    path = file;
                    break;
                }
                if (file.Contains("ZSF017OD", StringComparison.OrdinalIgnoreCase) && type.Equals("death"))
                {
                    path = file;
                    break;
                }
            }
            return path;
        }

        private void MoveAndUpdateFolderFile(string sourcePath, string desFolderPath, string originFileName)
        {
            try
            {
                var desPath = desFolderPath + "\\" + originFileName;
                DirectoryInfo info = new DirectoryInfo(desFolderPath);
                var filePath = GetAvaliableDesFilePath(desFolderPath, originFileName);
                File.Move(sourcePath, filePath);
                DeleteUnnecessaryFile(desFolderPath, info);
            }
            catch(Exception ex)
            {
                logger.Error("An error ocurred when MoveAndUpdateFolderFile, ex: {0}", ex);
                throw;
            }
        }

        private void DeleteUnnecessaryFile(string path, DirectoryInfo info)
        {
            try
            {

                if (Directory.GetFiles(path).Count() > 10)
                {
                    var fileInfos = info.GetFiles();
                    var deleteFilePath = fileInfos.OrderBy(x => x.CreationTime).Select(y => y.FullName).FirstOrDefault();
                    File.Delete(deleteFilePath);
                }
            }
            catch(Exception ex)
            {
                logger.Error("An error ocurred when DeleteUnnecessaryFile, ex:{0}", ex);
                throw;
            }
        }


        private void CheckAndCreateFolder(string path)
        {
            if (!File.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        private string GetAvaliableDesFilePath(string folderPath, string fileName)
        {
            try
            {

                var path = folderPath + "\\" + fileName;
                int count = 1;
                while (true)
                {
                    if (File.Exists(path))
                    {
                        var fileNameSplitStr = fileName.Split('.');
                        var name = fileNameSplitStr.FirstOrDefault();
                        var extension = fileNameSplitStr.LastOrDefault();
                        path = folderPath + "\\" + name + "_" + count + "." + extension;
                        count++;
                    }
                    else
                    {
                        break;
                    }
                }
                return path;
            }
            catch(Exception ex)
            {
                logger.Error("An error ocurred when CheckFileExists, ex: {0}", ex);
                throw;
            }
        }
    }
    
}

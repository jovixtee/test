﻿using FFL.FileScanService.Models;
using NLog;
using System;
using ILogger = NLog.ILogger;

namespace FFL.FileScanService.Services
{
    public class WindowsService : BackgroundService
    {
        private readonly ILogger logger;
        private Timer timer;
        private readonly ServiceInfo serviceInfo;

        public WindowsService(ServiceInfo serviceInfo)
        {
            logger = LogManager.GetLogger("WindowsService");
            this.serviceInfo = serviceInfo;
            timer = GetTimer();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.Delay(10000);
            }
        }

        public override async Task StartAsync(CancellationToken cancellationToken)
        {
            logger.Info("Service started");
            await base.StartAsync(cancellationToken);
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            timer.Change(Timeout.Infinite, Timeout.Infinite);
            timer.Dispose();
            logger.Info("Service stopped");
            await base.StopAsync(cancellationToken);
        }

        private void DeleteExpiredFiles(object? folderPath)
        {
            logger.Info($"The service starts deleting expired files");
            DirectoryInfo directory = new DirectoryInfo((string)folderPath);

            if (directory.Exists)
            {
                var files = GetAllFilesInDirectory(directory);

                try
                {
                    foreach (FileInfo file in files)
                    {
                        TimeSpan fileAge = DateTime.UtcNow - file.LastWriteTimeUtc;

                        if (fileAge > TimeSpan.FromSeconds(serviceInfo.RetentionService.RetentionTime))
                        {
                            file.Delete();
                            logger.Info($"This file {file.Name} was deleted by the windows service.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    logger.Error(ex, "Unkown Exception occurred when deleted file by the windows service.");
                }
            }
        }

        private List<FileInfo> GetAllFilesInDirectory(DirectoryInfo directory)
        {
            var result = new List<FileInfo>();

            var files = directory.GetFiles();
            result.AddRange(files);

            foreach (var subDic in directory.GetDirectories())
            {
                var subDicFiles = GetAllFilesInDirectory(subDic);
                result.AddRange(subDicFiles);
            }

            return result;
        }

        private Timer GetTimer()
        {
            TimerCallback callback = DeleteExpiredFiles;
            return new Timer(callback, serviceInfo.ScanService.FolderPath, TimeSpan.Zero, TimeSpan.FromSeconds(serviceInfo.RetentionService.Interval));
        }
    }
}

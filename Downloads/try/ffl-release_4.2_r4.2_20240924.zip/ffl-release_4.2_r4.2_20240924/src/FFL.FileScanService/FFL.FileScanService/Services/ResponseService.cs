﻿using FFL.FileScanService.Models;
using Newtonsoft.Json;

namespace FFL.FileScanService.Services
{
    public class ResponseService
    {
        public static string JsonConvertScanResponse(ScanResponse scanResponse)
        {
            return JsonConvert.SerializeObject(scanResponse);
        }
    }
}

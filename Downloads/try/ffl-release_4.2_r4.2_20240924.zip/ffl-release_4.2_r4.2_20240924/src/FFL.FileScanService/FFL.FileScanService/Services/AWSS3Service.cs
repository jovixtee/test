﻿using Amazon.S3;
using Amazon.S3.Model;
using FFL.FileScanService.Models;
using Microsoft.Extensions.Options;
using NLog;
using System.IO;

namespace FFL.FileScanService.Services
{
    public class AWSS3Service
    {
        private readonly NLog.ILogger logger;
        private AmazonS3Client awsS3Client { get; set; }

        public AWSS3Service(AWSS3Config awsS3Config, string serviceUrl, string region) 
        {
            logger = LogManager.GetLogger("ScanService");
            var config = new AmazonS3Config
            {
                ServiceURL = serviceUrl,
                ForcePathStyle = true,
            };
            if (awsS3Config != null && !string.IsNullOrEmpty(awsS3Config.AccessKeyId) && !string.IsNullOrEmpty(awsS3Config.SecretAccessKey))
            {
                var amazonS3Client = new AmazonS3Client(
                        awsS3Config.AccessKeyId,
                        awsS3Config.SecretAccessKey,
                        config);
                awsS3Client = amazonS3Client;
            }
            else
            {
                config.AuthenticationRegion = region;
                awsS3Client = new AmazonS3Client(config);
            }
        }

        public async Task<bool> UploadFile(Guid correlationId, string bucketName, string entity, string recordId, string fileName, Stream file)
        {
            try
            {
                var putRequest = new PutObjectRequest
                {
                    BucketName = bucketName,
                    Key = $"{entity}/{recordId}/{fileName}",
                    InputStream = file,
                };
                PutObjectResponse response = await awsS3Client.PutObjectAsync(putRequest);

                logger.Info($"{correlationId} | Upload File to S3 | {bucketName}/{entity}/{recordId}/{fileName}, Http status code:{response.HttpStatusCode}");

                return response.HttpStatusCode == System.Net.HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                logger.Error(ex, $"{correlationId} | Upload File to S3 | {bucketName}/{entity}/{recordId}/{fileName}, Exception occurred");
                return false;
            }
        }

        public async Task DeleteFolder(Guid correlationId, string bucketName, string entity, string recordId)
        {
            try
            {
                var deleteObjRequest = new DeleteObjectRequest
                {
                    BucketName = bucketName,
                    Key = $"{entity}/{recordId}/"
                };
                DeleteObjectResponse response = await awsS3Client.DeleteObjectAsync(deleteObjRequest);

                logger.Info($"{correlationId} | Delete Folder from S3 | {bucketName}/{entity}/{recordId}, Http status code:{response.HttpStatusCode}");
            }
            catch (Exception ex )
            {
                logger.Error(ex, $"{correlationId} | Delete Folder from S3 | {bucketName}/{entity}/{recordId}, Exception occurred");
            }
        }
    }
}

﻿using Amazon.S3.Model;
using Amazon.S3;
using Amazon.SecretsManager.Model.Internal.MarshallTransformations;
using FFL.FileScanService.Models;
using FFL.FileScanService.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NLog;
using StackExchange.Redis;
using System.IO;
using System.Security.Cryptography;
using ILogger = NLog.ILogger;
using System.Collections.Concurrent;
using static Amazon.S3.Util.S3EventNotification;
using System.Text;
using System.Net.NetworkInformation;

namespace FFL.FileScanService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FileController : ControllerBase
    {
        private readonly ILogger logger;
        private readonly ServiceInfo serviceInfo;

        public FileController(ServiceInfo serviceInfo)
        {
            logger = LogManager.GetLogger("ScanService");
            this.serviceInfo = serviceInfo;
            string scanPath = serviceInfo.ScanService.FolderPath.Trim();
            try
            {
                if (!Directory.Exists(scanPath))
                {
                    Directory.CreateDirectory(scanPath);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, $"The scan service start failed due to creating scan folder failed.");
            }
        }
        [HttpPost("scan")]
        public async Task<string> Scan([FromForm] ApmInfo apmInfo)
        {
            if (string.IsNullOrEmpty(apmInfo.NeedUploadS3) || string.Equals(apmInfo.NeedUploadS3, "true", StringComparison.OrdinalIgnoreCase))
            {
                logger.Info($"Begin scaning the file, the file will upload to S3");
                return await ScanWithUploadS3(apmInfo);
            }
            else
            {
                logger.Info($"Begin scaning the file, the file will not upload to S3");
                return await ScanOnly(apmInfo);
            }
        }
        public async Task<string> ScanWithUploadS3(ApmInfo apmInfo)
        {
            if (apmInfo.CorrelationId == Guid.Empty)
            {
                logger.Warn($"{apmInfo.CorrelationId} | NULL | The correlationId is empty, the scan proccess is terminated.");
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.OtherError });
            }

            if (string.IsNullOrEmpty(apmInfo.ServiceURL) || string.IsNullOrEmpty(apmInfo.AuthenticationRegion))
            {
                logger.Warn($"{apmInfo.CorrelationId} | NULL | The ServiceURL or AuthenticationRegion is empty, the scan proccess is terminated.");
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.OtherError });
            }

            if (string.IsNullOrEmpty(apmInfo.AccessPoint) || string.IsNullOrEmpty(apmInfo.Entity) || apmInfo.RecordId == Guid.Empty)
            {
                logger.Warn($"{apmInfo.CorrelationId} | NULL | The accessPoint or entity or recordId is empty, the scan proccess is terminated.");
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.OtherError });
            }

            if (apmInfo.File == null || string.IsNullOrEmpty(apmInfo.FileName))
            {
                logger.Warn($"{apmInfo.CorrelationId} | NULL | The file or fileName is empty, the scan proccess is terminated.");
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.OtherError });
            }

            var folderPath = Path.Combine(Path.Combine(serviceInfo.ScanService.FolderPath, apmInfo.Entity), apmInfo.CorrelationId.ToString());
            try
            {
                (var fileName, var filePath) = await SaveFile(apmInfo.CorrelationId, apmInfo.File, folderPath);

                var scanResult = ScanFile(apmInfo.CorrelationId, fileName, filePath);

                if (scanResult == false)
                {
                    logger.Error($"{apmInfo.CorrelationId} | Scan File | Scan files failed.");
                    return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.Unsafe });
                }
                logger.Info($"{apmInfo.CorrelationId} | Scan File | Begin upload the file to S3.");
                var awsS3Client = new AWSS3Service(serviceInfo.AWSS3Config, apmInfo.ServiceURL, apmInfo.AuthenticationRegion);
                var uploadResult = await awsS3Client.UploadFile(apmInfo.CorrelationId, apmInfo.AccessPoint, apmInfo.Entity, apmInfo.RecordId.ToString(), apmInfo.FileName, apmInfo.File.OpenReadStream());

                if (uploadResult == false)
                {
                    logger.Error($"{apmInfo.CorrelationId} | Upload File | Upload files failed.");
                    await awsS3Client.DeleteFolder(apmInfo.CorrelationId, apmInfo.AccessPoint, apmInfo.Entity, apmInfo.RecordId.ToString());
                    return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.UploadS3Failed });
                }
                logger.Info($"{apmInfo.CorrelationId} | Scan File | End upload the file to S3.");
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.Success });
            }
            catch (Exception ex)
            {
                logger.Error(ex, $"{apmInfo.CorrelationId} | {apmInfo.RecordId} | {ex.Message}");
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.OtherError, });
            }
            finally
            {
                DeleteDirectory(apmInfo.CorrelationId, folderPath);
            }
        }
        private async Task<string> ScanOnly(ApmInfo apmInfo)
        {
            if (apmInfo.CorrelationId == Guid.Empty)
            {
                logger.Warn($"{apmInfo.CorrelationId} | NULL | The correlationId is empty, the scan proccess is terminated.");
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.OtherError });
            }

            if (apmInfo.File == null || string.IsNullOrEmpty(apmInfo.FileName))
            {
                logger.Warn($"{apmInfo.CorrelationId} | NULL | The file or fileName is empty, the scan proccess is terminated.");
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.OtherError });
            }

            var folderPath = Path.Combine(Path.Combine(serviceInfo.ScanService.FolderPath, "PostalCodeImport"), apmInfo.CorrelationId.ToString());
            try
            {
                (var fileName, var filePath) = await SaveFile(apmInfo.CorrelationId, apmInfo.File, folderPath);

                var scanResult = ScanFile(apmInfo.CorrelationId, fileName, filePath);

                if (scanResult == false)
                {
                    logger.Error($"{apmInfo.CorrelationId} | Scan File | Scan files failed.");
                    return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.Unsafe });
                }
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.Success });
            }
            catch (Exception ex)
            {
                logger.Error(ex, $"{apmInfo.CorrelationId} | Scan File | {ex.Message}");
                return ResponseService.JsonConvertScanResponse(new ScanResponse { ScanResult = ScanResultType.OtherError, });
            }
            finally
            {
                DeleteDirectory(apmInfo.CorrelationId, folderPath);
            }
        }
        private void DeleteDirectory(Guid correlationId, string folderPath)
        {
            if (Directory.Exists(folderPath))
            {
                try
                {
                    Directory.Delete(folderPath, true);
                    logger.Info($"{correlationId} | {folderPath} | Deleted.");
                }
                catch (Exception ex)
                {
                    logger.Error(ex, $"{correlationId} | {folderPath} | An error occurred while deleting the directory.");
                }
            }
        }

        private async Task<(string, string)> SaveFile(Guid correlationId, IFormFile file, string folderPath)
        {
            if (Directory.Exists(folderPath) == false)
                Directory.CreateDirectory(folderPath);

            var fileName = $"{DateTimeOffset.Now:yyyyMMddHHmmssfff}_" + file.FileName;
            var filePath = Path.Combine(folderPath, fileName);

            logger.Info($"{correlationId} | {fileName} | Start saving the file.");
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }
            logger.Info($"{correlationId} | {fileName} | Saving file completed.");

            return (fileName, filePath);
        }

        private void ScanFile(object? scanState)
        {
            var scanInfo = (ScanInfo)scanState;
            scanInfo.ScanCount++;

            if (System.IO.File.Exists(scanInfo.FilePath))
            {
                logger.Info($"{scanInfo.CorrelationId} | {scanInfo.FileName} | Scan count: {scanInfo.ScanCount}, scan result: file exist");
            }
            else
            {
                logger.Info($"{scanInfo.CorrelationId} | {scanInfo.FileName} | Scan count: {scanInfo.ScanCount}, scan result: file not exist");
                scanInfo.IsRunning = false;
                return;
            }

            if (DateTime.UtcNow - scanInfo.StartTime >= scanInfo.MaxDuration)
            {
                scanInfo.ScanResult = true;
                scanInfo.IsRunning = false;
            }
        }

        private bool ScanFile(Guid correlationId, string fileName, string filePath)
        {
            var scanInfo = new ScanInfo()
            {
                CorrelationId = correlationId,
                MaxDuration = TimeSpan.FromSeconds(serviceInfo.ScanService.TotalTime),
                IsRunning = true,
                ScanResult = false,
                StartTime = DateTime.UtcNow,
                FileName = fileName,
                FilePath = filePath
            };
            TimerCallback callback = ScanFile;
            var timer = new Timer(callback, scanInfo, TimeSpan.Zero, TimeSpan.FromSeconds(serviceInfo.ScanService.Interval));
            while (scanInfo.IsRunning)
            {
                System.Threading.Thread.Sleep(10);
            }
            timer.Dispose();

            return scanInfo.ScanResult;
        }

        //private async Task<bool> UploadFile(AWSS3Service awsS3Client, Guid correlationId, IFormFile file, string entity, Guid recordId)
        //{
        //    var awsResult = await awsS3Client.UploadFile(correlationId, serviceInfo.AWSS3Config.AccessPoint, entity, recordId.ToString(), file.FileName, file.OpenReadStream());

        //    return awsResult;
        //}
    }
}

﻿namespace FFL.FileScanService.Models
{
    public class ApmInfo
    {
        public Guid CorrelationId { get; set; }
        public string ServiceURL { get; set; }
        public string AccessPoint { get; set; }
        public string AuthenticationRegion { get; set; }
        public string Entity { get; set; }
        public Guid RecordId { get; set; }
        public IFormFile File { get; set; }
        public string FileName { get; set; }
        public string NeedUploadS3 { get; set; }
    }
}

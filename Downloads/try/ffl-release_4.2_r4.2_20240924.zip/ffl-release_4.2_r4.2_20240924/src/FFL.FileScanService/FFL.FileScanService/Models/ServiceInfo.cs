﻿namespace FFL.FileScanService.Models
{
    public class ServiceInfo
    {
        public ScanService ScanService {get; set;}
        public RetentionService RetentionService { get; set; }
        public AWSS3Config AWSS3Config { get; set;}
    }

    public class ScanService
    {
        public string Host { get; set; }
        public int Interval { get; set; }
        public int TotalTime { get; set; }
        public string FolderPath { get; set; }
    }

    public class RetentionService
    {
        public int RetentionTime { get; set; }
        public int Interval { get; set; }
    }

    public class AWSS3Config
    {
        //public string ServiceURL { get; set; }
        public string AccessKeyId { get; set; }
        public string SecretAccessKey { get; set; }
        //public string AccessPoint { get; set; }
        //public string RegionEndpoint { get; set; }
    }
}

﻿namespace FFL.FileScanService.Models
{
    public class ScanInfo
    {
        public string FilePath { get; set; }
        public int ScanCount { get; set; }
        public DateTime StartTime { get; set; }
        public TimeSpan MaxDuration { get; set; }
        public Guid CorrelationId { get; set; }
        public string FileName { get; set; }
        public bool IsRunning { get; set; }
        public bool ScanResult { get; set; }
    }
}

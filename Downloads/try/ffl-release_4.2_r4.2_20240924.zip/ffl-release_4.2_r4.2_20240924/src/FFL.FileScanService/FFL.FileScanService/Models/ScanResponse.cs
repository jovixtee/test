﻿namespace FFL.FileScanService.Models
{
    public class ScanResponse
    {
        public ScanResultType ScanResult { get; set; }
    }

    public enum ScanResultType
    {
        OtherError = 0,
        Success = 1,
        Unsafe = 2,
        UploadS3Failed = 3,
    }
}

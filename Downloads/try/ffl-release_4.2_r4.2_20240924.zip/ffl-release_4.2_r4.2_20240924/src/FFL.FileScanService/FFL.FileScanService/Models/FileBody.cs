﻿namespace FFL.FileScanService.Models
{
    public class FileBody
    {
        public Guid CorrelationId { get; set; } = Guid.Empty;
        public string FileName { get; set; }
    }
}

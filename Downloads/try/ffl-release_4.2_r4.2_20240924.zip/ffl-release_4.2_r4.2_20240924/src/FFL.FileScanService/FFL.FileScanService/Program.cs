using Amazon.S3;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using FFL.FileScanService.Models;
using FFL.FileScanService.Services;
using FFL.FileScanService;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NLog;
using NLog.Web;
using StackExchange.Redis;
using ILogger = NLog.ILogger;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.ClearProviders();
builder.Logging.AddNLog("NLog.config");
builder.Logging.AddNLogWeb();
ILogger logger = LogManager.GetLogger("WindowsService");
try
{

    var environment = builder.Environment.EnvironmentName;

    logger.Info($"env: {environment}");

    var configuration = new ConfigurationBuilder()
        .SetBasePath(AppContext.BaseDirectory)
        .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
        .AddJsonFile($"appsettings.{environment}.json", optional: true, reloadOnChange: true)
        .Build();

    builder.Services.AddControllers();
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();
    builder.Services.AddHostedService<WindowsService>();
    builder.Services.AddWindowsService();

    //builder.Services.AddSingleton<IAmazonSecretsManager>(provider =>
    //{
    //    return new AmazonSecretsManagerClient(Amazon.RegionEndpoint.APSoutheast1);
    //});

    builder.Services.AddSingleton<ServiceInfo>(provider =>
    {
        var result = configuration.Get<ServiceInfo>();
        //if (result != null && result.AWSS3Config != null && string.IsNullOrEmpty(result.AWSS3Config.AccessPoint))
        //{
        //    var secretsManager = provider.GetRequiredService<IAmazonSecretsManager>();
        //    var secretResponse = secretsManager.GetSecretValueAsync(new GetSecretValueRequest
        //    {
        //        SecretId = configuration["AwsSecretManager:SecretId"]
        //    });
        //    var secretJson = secretResponse.Result.SecretString;
        //    var secretResult = JsonConvert.DeserializeObject<AwsSecretManagerResult>(secretJson);
        //    result.AWSS3Config.AccessPoint = secretResult?.AccessPoint;
        //}

        return result;
    });

    builder.WebHost.UseUrls(configuration["ScanService:Host"]);

    var app = builder.Build();

    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }

    app.UseAuthorization();

    app.MapControllers();

    app.Map("/healthz", appconfig =>
    {
        appconfig.Run(async context =>
        {
            await context.Response.WriteAsync("Ok. Version:1.0.0");
        });
    });

    app.Run();
}
catch (Exception ex)
{
    logger.Fatal(ex, "Initialization failed");
}

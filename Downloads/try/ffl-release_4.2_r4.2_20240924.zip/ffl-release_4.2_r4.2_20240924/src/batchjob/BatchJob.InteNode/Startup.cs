/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using ApiManagement.Node;
using ApiManagement.Node.Audit;
using ApiManagement.Node.BackendRequestor;
using ApiManagement.Node.Dbp;
using ApiManagement.Node.Dbp.Auth;
using ApiManagement.Node.Job;
using ApiManagement.Node.Quartz.Job;
using ApiManagement.NodeInterface;
using ApiManagement.NodeInterface.Constant;
using ApiManagement.NodeInterface.Model;
using Framework.CommonUtility.IO;
using Framework.ContainerRuntime;
using Framework.ContainerRuntime.IO;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using NLog.Extensions.Logging;
using Quartz;
using Quartz.Impl;
using Quartz.Spi;
using System;
using System.Collections.Generic;

namespace BatchJob.InteNode
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            ApiManagement.Node.Startup.CenterMiddleware = new CenterMiddleware();
            ApiManagement.Node.Startup.Requesters = new Dictionary<string, IBackendRequester>();
            ApiManagement.Node.Startup.Requesters.Add(PipelineKeyDefine.HttpEngine, new HttpRequester(configuration));
            ApiManagement.Node.Startup.RateLimit = new Dictionary<string, List<RateLimitEntry>>();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLogging(loggingBuilder =>
            {
                // configure Logging with NLog
                loggingBuilder.ClearProviders();
                loggingBuilder.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Information);
                loggingBuilder.AddNLog("nlog.config");
            });
            
            services.AddControllers();
            services.AddSingleton<CenterMiddleware>();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "ApiManagement.Node", Version = "v1" });
            });
            // Add our job
            services.AddSingleton<IJobFactory, SingletonJobFactory>();
            services.AddSingleton<ISchedulerFactory, StdSchedulerFactory>();
            services.AddSingleton<NodeRegisterJob>();
            services.AddSingleton<RequestHistoryJob>();
            services.AddSingleton<DbpConfigJob>();

            services.AddInterceptor(Configuration);
            services.Configure<BatchJobSettings>(Configuration.GetSection("BatchJobSettings"));
            services.Configure<PlatformSettings>(Configuration.GetSection("PlatformSettings"));
            services.AddSingleton<IDbpClient, DbpClient>();
            services.AddSingleton<IPlatformAuthProvider, PlatformAuthProvider>();
            services.AddSingleton<IHttpClientWrapper, HttpClientWrapper>();
            services.AddSingleton<IAuditor, DefaultAuditor>();
            services.AddSingleton<IAuditWriterFactory, CSVAuditWriterFactory>();
            services.AddSingleton<IAuditTransfer, AuditTransferDbp>();
            services.AddJob();
            services.AddHostedService<QuartzHostedService>();
            services.AddSingleton<IZipUtil, ZipUtil>();
            services.AddSingleton<ITemporaryFolderUtil, TemporaryFolderUtil>();
            services.Configure<KestrelServerOptions>(x => x.AllowSynchronousIO = true);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseMiddleware<HealthMiddleware>();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "ApiManagement.Node v1"));
            }
            ServiceLocator.Instance = app.ApplicationServices;
            app.UseRouting();

            app.UseMiddleware<AuditMiddleware>();
            app.Use(ApiManagement.Node.Startup.CenterMiddleware.MiddlewareAction);
        }
    }
}
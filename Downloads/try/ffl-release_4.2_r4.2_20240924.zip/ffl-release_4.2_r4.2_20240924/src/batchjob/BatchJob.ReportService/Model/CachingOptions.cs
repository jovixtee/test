﻿namespace BatchJob.ReportService.Model
{
    public class CachingOptions
    {
        public int CacheDurationMinutes { get; set; } = 60;
        public CacheServiceType CacheType { get; set; } = CacheServiceType.Memory;
        public RedisCachingOptions RedisCacheOptions { get; set; }
        public int CapchaCookieDurationMinutes { get; set; } = 5;
        public string CacheKeyPrefix { get; set; } = string.Empty;
    }

    public class RedisCachingOptions
    {
        public string RedisConnection { get; set; }
        public string RedisInstance { get; set; }
    }

    public enum CacheServiceType
    {
        Memory = 0,
        Redis = 1,
        RedisMemoryHybird = 2
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using static BatchJob.ReportService.Model.SSRSEnum;

namespace BatchJob.ReportService.Model
{
    public class ReportConfiguration
    {
        public string SiteZone { get; set; }
        public string ServiceUrl { get; set; }
        public string UserName { get; set; }
        public string Domain { get; set; }
        public string SecurityWord { get; set; }
        public string FolderName { get;set; }
        public int TimeoutSeconds { get; set; }
        public int MaxDataSize { get; set; }
    }

    public class DataSourceInfo
    {
        public string Name { get; set; }
        public string Connection { get; set; }
        public string TrackName { get; set; }
        public string TrackConnection { get; set; }
        public string AuditName { get; set; }
        public string AuditConnection { get; set; }
        public string UserName { get; set; }
        public string SecurityWord { get; set; }
    }

    public class ExportMessage
    {
        public ExportStatus Status { get; set; }
        public string Message { get; set; }
    }
}

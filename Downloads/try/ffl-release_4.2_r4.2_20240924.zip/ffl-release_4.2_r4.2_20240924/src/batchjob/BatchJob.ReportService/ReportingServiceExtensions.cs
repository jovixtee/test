﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.ReportService.Common.Interfaces;
using BatchJob.ReportService.Common;
using BatchJob.ReportService.Services.Interfaces;
using BatchJob.ReportService.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using BatchJob.ReportService.Model;
using BatchJob.ReportService.Cache;

namespace BatchJob.ReportService
{
    public static class ReportingServiceExtensions
    {
        public static void AddReportingService(this IServiceCollection services, IConfiguration Configuration)
        {
            services.AddScoped<IReportingService, ReportingService>();
            services.AddSingleton<IReportServiceClient, ReportServiceClient>();
            var cacheOptions = new CachingOptions();
            Configuration.GetSection("CachingOptions").Bind(cacheOptions);
            if (cacheOptions.CacheType == CacheServiceType.Redis)
            {
                services.AddStackExchangeRedisCache(options =>
                {
                    options.Configuration = cacheOptions.RedisCacheOptions.RedisConnection;
                    options.InstanceName = cacheOptions.RedisCacheOptions.RedisInstance;
                });
                services.AddSingleton<ICacheService, RedisCacheService>();
            }
            else
            {
                services.AddMemoryCache();
                services.AddSingleton<ICacheService, MemoryCacheService>();
            }
        }
    }
}

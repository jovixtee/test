﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.ReportService.Common.Interfaces;
using BatchJob.ReportService.Model;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SSRSService2010;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Security;
using System.Threading;
using System.Threading.Tasks;
using Task = System.Threading.Tasks.Task;

namespace BatchJob.ReportService.UploadRdls
{
    public class UploadRdlFiles : BackgroundService
    {
        private readonly ILogger<UploadRdlFiles> _logger;
        public DataSourceInfo DSConfig { get; set; }
        public ReportConfiguration ReportConfig { get; set; }

        public UploadRdlFiles(ILogger<UploadRdlFiles> logger,
            IReportServiceClient serviceClient,
            IOptions<ReportConfiguration> reportConfig,
            IOptions<DataSourceInfo> dsConfig)
        {
            _logger = logger;
            DSConfig = dsConfig.Value;
            ReportConfig = reportConfig.Value;
            _logger.LogInformation("start to init config");
            _client = serviceClient.CreateSSRSClient();
        }
        private readonly bool isSkip = false;
        private readonly ReportingService2010SoapClient _client;

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                if (_client != null)
                {
                    await CreateDataSourceAndRdls(ReportConfig.SiteZone);
                }
                await base.StopAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"An error occurred whiling execute background service. Exception: {ex}");
            }
        }

        public async Task CreateDataSourceAndRdls(string siteZone)
        {
            string path = new FileInfo(Assembly.GetExecutingAssembly().Location).Directory!.ToString();
            path = Path.Combine(path, "rdls", siteZone);
            if (Directory.Exists(path))
            {
                foreach (string subFolder in Directory.GetDirectories(path))
                {
                    DirectoryInfo dir = new DirectoryInfo(subFolder);
                    _logger.LogInformation($"rdls folder path: {dir.FullName}");
                    var (name, connection) = GetDataSourceInfo(dir.Name);
                    if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(connection))
                    {
                        _logger.LogWarning($"Cannot find datasource info. Name: {dir.Name}");
                        continue;
                    }
                    await UploadRdls(dir, name, connection);
                }
            }
        }

        private (string, string) GetDataSourceInfo(string name)
        {
            switch (name)
            {
                case "APMDataSource":
                    return (DSConfig.Name, DSConfig.Connection);
                case "AuditDataSource":
                    return (DSConfig.AuditName, DSConfig.AuditConnection);
                case "TrackDataSource":
                    return (DSConfig.TrackName, DSConfig.TrackConnection);
                default:
                    return (null, null);
            }
        }

        public async Task<bool> UploadRdls(DirectoryInfo dir, string datasourceName, string connection)
        {
            var folderPath = await CreateFolder(ReportConfig.FolderName);

            var dsPath = await CreateDataSource(datasourceName, connection, DSConfig.UserName, DSConfig.SecurityWord);

            var ds = new DataSource() { Name = dir.Name, Item = new DataSourceReference { Reference = dsPath } };

            var rdlFiles = from e in Directory.GetFiles(dir.FullName, "*.rdl", SearchOption.TopDirectoryOnly)
                           orderby e
                           select e;
            foreach (var rdlFile in rdlFiles)
            {
                var name = Path.GetFileNameWithoutExtension(rdlFile);
                var content = File.ReadAllBytes(rdlFile);

                await CreateReport(name, content, folderPath, new DataSource[] { ds });
            }

            return true;
        }

        public async Task<string> CreateFolder(string name)
        {
            _logger.LogInformation("start to create folder");
            var searchOptions = new Property[0];
            var searchConditions = new SearchCondition[2];
            searchConditions[0] = new SearchCondition { Name = "Name", Values = new string[] { name }, Condition = ConditionEnum.Equals, ConditionSpecified = true };
            searchConditions[1] = new SearchCondition { Name = "Type", Values = new string[] { "Folder" }, Condition = ConditionEnum.Equals, ConditionSpecified = true };

            var header = new TrustedUserHeader();
            var folders = await _client.FindItemsAsync(header, "/", BooleanOperatorEnum.And, searchOptions, searchConditions);

            if (folders.Items.Length == 0)
            {
                Property[] folderProps = new Property[] { new Property { Name = "Description", Value = "Report Folder" } };
                var newFolderResult = await _client.CreateFolderAsync(header, name, "/", folderProps);
                return newFolderResult.ItemInfo.Path;
            }
            else
            {
                return folders.Items.First().Path;
            }
        }

        public async Task<string> CreateDataSource(string name, string dbString, string dbUser, string dbSecurityWord)
        {
            _logger.LogInformation("start to create datasource");
            var searchOptions = new Property[0];
            var searchConditions = new SearchCondition[2];
            searchConditions[0] = new SearchCondition { Name = "Name", Values = new string[] { name }, Condition = ConditionEnum.Equals, ConditionSpecified = true };
            searchConditions[1] = new SearchCondition { Name = "Type", Values = new string[] { "DataSource" }, Condition = ConditionEnum.Equals, ConditionSpecified = true };

            var header = new TrustedUserHeader();
            var datasources = await _client.FindItemsAsync(header, "/", BooleanOperatorEnum.And, searchOptions, searchConditions);
            if (datasources.Items.Length > 0)
            {
                var first = datasources.Items.First();
                await _client.DeleteItemAsync(header, first.Path);
            }

            DataSourceDefinition definition = new DataSourceDefinition()
            {
                ConnectString = dbString,
                Enabled = true,
                Extension = "SQL",
                CredentialRetrieval = CredentialRetrievalEnum.Store,
                UserName = dbUser,
                Password = dbSecurityWord,
                WindowsCredentials = false
            };

            Property[] properties = new Property[] { new Property { Name = "Description", Value = "Report Data Source" } };
            var dsResult = await _client.CreateDataSourceAsync(header, name, "/", true, definition, properties);
            return dsResult.ItemInfo.Path;
        }

        private async Task CreateReport(string name, byte[] content, string folderPath, DataSource[] dataSources)
        {
            _logger.LogInformation($"start to create report {name}");
            var searchOptions = new Property[0];
            var searchConditions = new SearchCondition[2];
            searchConditions[0] = new SearchCondition { Name = "Name", Values = new string[] { name }, Condition = ConditionEnum.Equals, ConditionSpecified = true };
            searchConditions[1] = new SearchCondition { Name = "Type", Values = new string[] { "Report" }, Condition = ConditionEnum.Equals, ConditionSpecified = true };

            var header = new TrustedUserHeader();
            var reports = await _client.FindItemsAsync(header, folderPath, BooleanOperatorEnum.And, searchOptions, searchConditions);
            if (reports.Items.Length > 0)
            {
                var first = reports.Items.First();
                await _client.DeleteItemAsync(header, first.Path);
            }

            var request = new CreateCatalogItemRequest()
            {
                TrustedUserHeader = header,
                Definition = content,
                ItemType = "Report",
                Name = name,
                Overwrite = true,
                Parent = folderPath,
                Properties = new Property[] { new Property { Name = "Description", Value = name } }
            };

            var newReportResult = await _client.CreateCatalogItemAsync(request);
            if (newReportResult != null)
            {
                await _client.SetItemDataSourcesAsync(header, newReportResult.ItemInfo.Path, dataSources);
            }
        }
    }
}

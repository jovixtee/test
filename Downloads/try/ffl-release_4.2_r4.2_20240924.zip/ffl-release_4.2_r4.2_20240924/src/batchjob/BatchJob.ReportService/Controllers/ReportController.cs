﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.ReportService.Model;
using BatchJob.ReportService.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SSRSService2010;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BatchJob.ReportService.Controllers
{
    [ApiController]
    [Authorize]
    public class ReportController : ControllerBase
    {
        private readonly ILogger<ReportController> logger;
        private readonly IReportingService ReportingService;
        public ReportController(IReportingService service, ILogger<ReportController> logger)
        {
            ReportingService = service;
            this.logger = logger;
        }

        [HttpPost("ListChildren")]
        public async Task<List<CatalogItem>> ListChildren(string path)
        {
            return await ReportingService.ListReport(path);
        }

        [HttpPost("ExportReport")]
        public async Task<IActionResult> ExportReport(SSRSModel.RenderModel renderModel)
        {
            var (buffer, fileName) = await ReportingService.Export(renderModel);
            return File(buffer, "application/octet-stream", fileName);
        }

        [HttpPost("BeginExport")]
        public async Task<string> BeginExport(SSRSModel.RenderModel renderModel)
        {
            return ReportingService.BeginExport(renderModel);
        }

        [HttpGet("CheckStatus")]
        public async Task<ExportMessage> CheckStatus(string uniqueWord)
        {
            return await ReportingService.CheckStatus(uniqueWord);
        }

        [HttpGet("TryGetExportFile")]
        public async Task<IActionResult> TryGetExportFile(string uniqueWord)
        {
            var (buffer, fileName) = await ReportingService.TryGetExportFile(uniqueWord);
            return File(buffer, "application/octet-stream", fileName);
        }

        [HttpGet("Test")]
        public async Task<List<CatalogItem>> Test()
        {
            logger.LogInformation("ReportService test start...");
            return await ReportingService.ListReport("/");
        }
    }
}

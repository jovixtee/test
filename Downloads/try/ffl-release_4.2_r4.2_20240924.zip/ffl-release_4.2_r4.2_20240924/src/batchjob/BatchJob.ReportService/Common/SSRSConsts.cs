﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
namespace BatchJob.ReportService.Common
{
    internal class SSRSConsts
    {
        internal const string EXECUTORURL = "/ReportExecution2005.asmx";
        internal const string REPORTSERVICEURL = "/ReportService2010.asmx";
        internal const string SiteZoneIntranet = "Intranet";
        internal const string SiteZoneInternet = "Internet";

        internal static class DeviceInfoSetting
        {
            internal static readonly string XlsDeviceInfo =
                "<DeviceInfo>" +
                "  <SimplePageHeaders>True</SimplePageHeaders>" +
                "</DeviceInfo>";

            internal static readonly string CSVDeviceInfo =
                "<DeviceInfo>" +
                "  <NoHeader>True</NoHeader>" +
                "  <FieldDelimiter xml:space='preserve'>\t</FieldDelimiter>" +
                "  <Encoding>Unicode</Encoding>" +
                "  <SuppressLineBreaks>true</SuppressLineBreaks>" +
                "</DeviceInfo>";

            internal static readonly string TifDeviceInfo =
                "<DeviceInfo>" +
                "  <OutputFormat>{0}</OutputFormat>" +
                "  <PageWidth>21cm</PageWidth>" +
                "  <PageHeight>29.70cm</PageHeight>" +
                "  <MarginTop>0cm</MarginTop>" +
                "  <MarginLeft>0cm</MarginLeft>" +
                "  <MarginRight>0cm</MarginRight>" +
                "  <MarginBottom>0cm</MarginBottom>" +
                "</DeviceInfo>";

            internal static readonly string PdfDeviceInfo =
                    "<DeviceInfo>" +
                    "  <OutputFormat>PDF</OutputFormat>" +
                    "  <PageWidth>21cm</PageWidth>" +
                    "  <PageHeight>29.70cm</PageHeight>" +
                    "  <MarginTop>0cm</MarginTop>" +
                    "  <MarginLeft>0cm</MarginLeft>" +
                    "  <MarginRight>0cm</MarginRight>" +
                    "  <MarginBottom>0cm</MarginBottom>" +
                    "</DeviceInfo>";

            internal static readonly string JPGDeviceInfo =
                "<DeviceInfo>" +
                    "  <OutputFormat>{0}</OutputFormat>" +
                    "  <PageWidth>21cm</PageWidth>" +
                    "  <PageHeight>29.70cm</PageHeight>" +
                    "  <MarginTop>0cm</MarginTop>" +
                    "  <MarginLeft>0cm</MarginLeft>" +
                    "  <MarginRight>0cm</MarginRight>" +
                    "  <MarginBottom>0cm</MarginBottom>" +
                    "</DeviceInfo>";
        }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.ReportService.Common.Interfaces;
using BatchJob.ReportService.Model;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SSRSExecutorService;
using SSRSService2010;
using System;
using System.IdentityModel.Selectors;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Security;

namespace BatchJob.ReportService.Common
{
    public class ReportServiceClient : IReportServiceClient
    {
        private readonly ILogger<ReportServiceClient> logger;
        private const string SSRSExecutorServiceEndpoint = "/ReportExecution2005.asmx";
        private const string SSRSServiceEndpoint = "/ReportService2010.asmx";

        public ReportConfiguration ReportConfig { get; set; }
        public ReportServiceClient(
            ILogger<ReportServiceClient> logger,
            IOptions<ReportConfiguration> config)
        {
            this.ReportConfig = config.Value;
            this.logger = logger;
        }

        public ReportingService2010SoapClient CreateSSRSClient()
        {
            if (string.IsNullOrEmpty(ReportConfig.ServiceUrl))
            {
                return null;
            }
            BasicHttpBinding rsBinding = new BasicHttpBinding();
            rsBinding.Security.Mode = BasicHttpSecurityMode.Transport;
            rsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Ntlm;
            rsBinding.MaxReceivedMessageSize = ReportConfig.MaxDataSize * 1024 * 1204;
            rsBinding.SendTimeout = new TimeSpan((long)10000 * 1000 * ReportConfig.TimeoutSeconds);
            SSRSService2010.TrustedUserHeader trustedUserHeader = new SSRSService2010.TrustedUserHeader();
            EndpointAddress rsEndpointAddress = new EndpointAddress(ReportConfig.ServiceUrl.TrimEnd('/') + SSRSServiceEndpoint);
            ReportingService2010SoapClient client = new ReportingService2010SoapClient(rsBinding, rsEndpointAddress);
            System.Net.ServicePointManager.ServerCertificateValidationCallback =
                    (se, cert, chain, sslerror) =>
                    {
                        return CheckSSLCertificate(se, cert, chain, sslerror);
                    };
            client.ClientCredentials.ServiceCertificate.SslCertificateAuthentication =
                    new X509ServiceCertificateAuthentication()
                    {
                        CertificateValidationMode = X509CertificateValidationMode.Custom,
                        RevocationMode = X509RevocationMode.Offline,
                        CustomCertificateValidator = new Validator(logger)
                    };
            client.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
            client.ClientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential(ReportConfig.UserName, ReportConfig.SecurityWord, ReportConfig.Domain);
            return client;
        }

        public ReportExecutionServiceSoapClient CreateExecutorClient()
        {
            if (string.IsNullOrEmpty(ReportConfig.ServiceUrl))
            {
                return null;
            }
            BasicHttpBinding rsBinding = new BasicHttpBinding();
            rsBinding.Security.Mode = BasicHttpSecurityMode.Transport;
            rsBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Ntlm;
            rsBinding.MaxReceivedMessageSize = ReportConfig.MaxDataSize * 1024 * 1204;
            rsBinding.SendTimeout = new TimeSpan((long)10000 * 1000 * ReportConfig.TimeoutSeconds);
            SSRSExecutorService.TrustedUserHeader trustedUserHeader = new SSRSExecutorService.TrustedUserHeader();
            EndpointAddress rsEndpointAddress = new EndpointAddress(ReportConfig.ServiceUrl.TrimEnd('/') + SSRSExecutorServiceEndpoint);
            ReportExecutionServiceSoapClient client = new ReportExecutionServiceSoapClient(rsBinding, rsEndpointAddress);
            System.Net.ServicePointManager.ServerCertificateValidationCallback =
                    (se, cert, chain, sslerror) =>
                    {
                        return CheckSSLCertificate(se, cert, chain, sslerror);
                    };
            client.ClientCredentials.ServiceCertificate.SslCertificateAuthentication =
                    new X509ServiceCertificateAuthentication()
                    {
                        CertificateValidationMode = X509CertificateValidationMode.Custom,
                        RevocationMode = X509RevocationMode.Offline,
                        CustomCertificateValidator = new Validator(logger)
                    };
            client.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
            client.ClientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential(ReportConfig.UserName, ReportConfig.SecurityWord, ReportConfig.Domain);
            return client;
        }

        private bool CheckSSLCertificate(object se, X509Certificate cert, X509Chain chain, SslPolicyErrors sslerror)
        {
            var validate = se != null;
            if (!validate)
            {
                logger.LogWarning("Check certificate failed.");
            }
            return validate;
        }

        class Validator : X509CertificateValidator
        {
            private readonly ILogger logger;
            public Validator(ILogger logger)
            {
                this.logger = logger;
            }

            public override void Validate(X509Certificate2 certificate)
            {
                logger.LogInformation("Start to validate certificate.");
                if (certificate == null)
                {
                    logger.LogInformation("There is not certificate.");
                    throw new ArgumentNullException("certificate");
                }
                logger.LogInformation("Validation finished.");
            }
        }
    }
}

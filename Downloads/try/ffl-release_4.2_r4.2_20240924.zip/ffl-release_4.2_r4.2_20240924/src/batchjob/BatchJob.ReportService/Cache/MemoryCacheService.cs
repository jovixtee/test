﻿using BatchJob.ReportService.Model;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using System.Threading.Tasks;
using System;

namespace BatchJob.ReportService.Cache
{
    public class MemoryCacheService : ICacheService
    {
        public MemoryCacheService(
             IOptions<CachingOptions> cachingOptions,
             IMemoryCache cache
            )
        {
            this.cachingOptions = cachingOptions.Value;
            _cache = cache;
        }

        protected IMemoryCache _cache;
        private CachingOptions cachingOptions;

        public T Get<T>(string key) where T : class
        {
            object cached;
            if (_cache.TryGetValue(cachingOptions.CacheKeyPrefix + key, out cached))
            {
                return cached as T;
            }

            return null;
        }

        public T GetOnce<T>(string key) where T : class
        {
            var result = this.Get<T>(key);
            if (result != null)
            {
                this.Remove(key);
            }
            return result;
        }

        public void Remove(string key)
        {
            object cached;
            if (_cache.TryGetValue(cachingOptions.CacheKeyPrefix + key, out cached))
            {
                _cache.Remove(cachingOptions.CacheKeyPrefix + key);
            }
        }

        public void Set(string key, object value)
        {
            Set(key, value, cachingOptions.CacheDurationMinutes);
        }

        public void Set(string key, object value, int duration)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            Set(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(duration),
                Priority = CacheItemPriority.Low
            });
        }

        public void SetShort(string key, object value, int duration)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            Set(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromSeconds(duration),
                Priority = CacheItemPriority.Low
            });
        }

        public void Set(string key, object value, MemoryCacheEntryOptions cacheOptions)
        {
            object cached;
            if (_cache.TryGetValue(cachingOptions.CacheKeyPrefix + key, out cached))
            {
                _cache.Remove(cachingOptions.CacheKeyPrefix + key);
            }

            _cache.Set(cachingOptions.CacheKeyPrefix + key, value, cacheOptions);
        }

        public void Set(string key, object value, DistributedCacheEntryOptions cacheOptions)
        {
            throw new NotImplementedException("Please checked the DI in startup, you have add a memory cache service. Don't use distributed cache method.");
        }

        public CacheServiceType GetCacheServiceType()
        {
            return CacheServiceType.Memory;
        }

        public async Task SetAsync(string key, object value)
        {
            await SetAsync(key, value, cachingOptions.CacheDurationMinutes);
        }

        public async Task SetAsync(string key, object value, int duration)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            await SetAsync(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(duration),
                Priority = CacheItemPriority.Low
            });
        }

        public async Task SetShortAsync(string key, object value, int duration)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            await SetAsync(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromSeconds(duration),
                Priority = CacheItemPriority.Low
            });
        }

        public async Task SetAsync(string key, object value, MemoryCacheEntryOptions cacheOptions)
        {
            object cached;
            if (_cache.TryGetValue(cachingOptions.CacheKeyPrefix + key, out cached))
            {
                _cache.Remove(cachingOptions.CacheKeyPrefix + key);
            }
            _cache.Set(cachingOptions.CacheKeyPrefix + key, value, cacheOptions);
            await Task.FromResult(true);
        }

        public Task SetAsync(string key, object value, DistributedCacheEntryOptions cacheOptions)
        {
            throw new NotImplementedException("Please checked the DI in startup, you have add a memory cache service. Don't use distributed cache method.");
        }

        public async Task RemoveAsync(string key)
        {
            object cached;
            if (_cache.TryGetValue(cachingOptions.CacheKeyPrefix + key, out cached))
            {
                _cache.Remove(cachingOptions.CacheKeyPrefix + key);
            }
            await Task.FromResult(true);
        }

        public async Task<T> GetAsync<T>(string key) where T : class
        {
            object cached;
            if (_cache.TryGetValue(cachingOptions.CacheKeyPrefix + key, out cached))
            {
                return await Task.FromResult<T>(cached as T);
            }

            return null;
        }

        public async Task<T> GetOnceAsync<T>(string key) where T : class
        {
            var result = await this.GetAsync<T>(key);
            if (result != null)
            {
                await this.RemoveAsync(key);
            }
            return result;
        }

        #region Prefix
        public T Get<T>(string key, string prefix) where T : class
        {
            object cached;
            if (_cache.TryGetValue(prefix + key, out cached))
            {
                return cached as T;
            }

            return null;
        }

        public T GetOnce<T>(string key, string prefix) where T : class
        {
            var result = this.Get<T>(key, prefix);
            if (result != null)
            {
                this.Remove(key, prefix);
            }
            return result;
        }

        public void Remove(string key, string prefix)
        {
            object cached;
            if (_cache.TryGetValue(prefix + key, out cached))
            {
                _cache.Remove(prefix + key);
            }
        }

        public void Set(string key, object value, string prefix)
        {
            Set(key, value, cachingOptions.CacheDurationMinutes, prefix);
        }

        public void Set(string key, object value, int duration, string prefix)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            Set(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(duration),
                Priority = CacheItemPriority.Low
            }, prefix);
        }

        public void SetShort(string key, object value, int duration, string prefix)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            Set(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromSeconds(duration),
                Priority = CacheItemPriority.Low
            }, prefix);
        }

        public void Set(string key, object value, MemoryCacheEntryOptions cacheOptions, string prefix)
        {
            object cached;
            if (_cache.TryGetValue(prefix + key, out cached))
            {
                _cache.Remove(prefix + key);
            }

            _cache.Set(prefix + key, value, cacheOptions);
        }

        public void Set(string key, object value, DistributedCacheEntryOptions cacheOptions, string prefix)
        {
            throw new NotImplementedException("Please checked the DI in startup, you have add a memory cache service. Don't use distributed cache method.");
        }

        public async Task SetAsync(string key, object value, string prefix)
        {
            await SetAsync(key, value, cachingOptions.CacheDurationMinutes, prefix);
        }

        public async Task SetAsync(string key, object value, int duration, string prefix)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            await SetAsync(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(duration),
                Priority = CacheItemPriority.Low
            }, prefix);
        }

        public async Task SetShortAsync(string key, object value, int duration, string prefix)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            await SetAsync(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromSeconds(duration),
                Priority = CacheItemPriority.Low
            }, prefix);
        }

        public async Task SetAsync(string key, object value, MemoryCacheEntryOptions cacheOptions, string prefix)
        {
            object cached;
            if (_cache.TryGetValue(prefix + key, out cached))
            {
                _cache.Remove(prefix + key);
            }
            _cache.Set(prefix + key, value, cacheOptions);
            await Task.FromResult(true);
        }

        public Task SetAsync(string key, object value, DistributedCacheEntryOptions cacheOptions, string prefix)
        {
            throw new NotImplementedException("Please checked the DI in startup, you have add a memory cache service. Don't use distributed cache method.");
        }

        public async Task RemoveAsync(string key, string prefix)
        {
            object cached;
            if (_cache.TryGetValue(prefix + key, out cached))
            {
                _cache.Remove(prefix + key);
            }
            await Task.FromResult(true);
        }

        public async Task<T> GetAsync<T>(string key, string prefix) where T : class
        {
            object cached;
            if (_cache.TryGetValue(prefix + key, out cached))
            {
                return await Task.FromResult<T>(cached as T);
            }

            return null;
        }

        public async Task<T> GetOnceAsync<T>(string key, string prefix) where T : class
        {
            var result = await this.GetAsync<T>(key, prefix);
            if (result != null)
            {
                await this.RemoveAsync(key, prefix);
            }
            return result;
        }
        #endregion
    }
}

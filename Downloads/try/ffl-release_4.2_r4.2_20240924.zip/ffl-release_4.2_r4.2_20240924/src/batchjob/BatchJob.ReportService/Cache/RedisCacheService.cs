﻿using BatchJob.ReportService.Model;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace BatchJob.ReportService.Cache
{
    public class RedisCacheService : ICacheService
    {
        public RedisCacheService(
            IOptions<CachingOptions> cachingOptions,
            IDistributedCache cache,
            ILogger<RedisCacheService> logger)
        {
            this.cachingOptions = cachingOptions.Value;
            _cache = cache;
            log = logger;
        }

        protected IDistributedCache _cache;
        private CachingOptions cachingOptions;
        private ILogger log;

        public T Get<T>(string key) where T : class
        {
            byte[] cached = null;
            try
            {
                cached = _cache.Get(cachingOptions.CacheKeyPrefix + key);
            }
            catch (Exception ex)
            {
                log.LogError("Get cache from redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", cachingOptions.CacheKeyPrefix + key, ex.ToString());
                cached = null;
            }

            if (cached == null)
            {
                return null;
            }
            var cachedStr = System.Text.Encoding.UTF8.GetString(cached);
            if (typeof(T) == typeof(string))
            {
                return cachedStr as T;
            }

            return JsonConvert.DeserializeObject<T>(cachedStr);
        }

        public T GetOnce<T>(string key) where T : class
        {
            var result = this.Get<T>(key);
            if (result != null)
            {
                this.Remove(key);
            }
            return result;
        }

        public void Remove(string key)
        {
            try
            {
                _cache.Remove(cachingOptions.CacheKeyPrefix + key);
            }
            catch (Exception ex)
            {
                log.LogError("Remove cache from redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", cachingOptions.CacheKeyPrefix + key, ex.ToString());
            }

        }

        public void Set(string key, object value)
        {
            Set(key, value, cachingOptions.CacheDurationMinutes);
        }

        public void Set(string key, object value, int duration)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            Set(key, value, new DistributedCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(duration)
            });
        }

        public void SetShort(string key, object value, int duration)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            Set(key, value, new DistributedCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromSeconds(duration)
            });
        }

        public void Set(string key, object value, DistributedCacheEntryOptions cacheOptions)
        {
            string toCache;
            if (value is string)
            {
                toCache = (string)value;
            }
            else
            {
                toCache = JsonConvert.SerializeObject(value, new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
            }

            try
            {
                _cache.Set(cachingOptions.CacheKeyPrefix + key, System.Text.Encoding.UTF8.GetBytes(toCache), cacheOptions);
            }
            catch (Exception ex)
            {
                log.LogError("Set cache in redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", cachingOptions.CacheKeyPrefix + key, ex.ToString());
            }
        }

        public void Set(string key, object value, MemoryCacheEntryOptions cacheOptions)
        {
            log.LogError("Please checked the DI in startup, you have add a redis cache service. Don't use memory cache method.");
            throw new NotImplementedException("Please checked the DI in startup, you have add a redis cache service. Don't use memory cache method.");
        }

        public CacheServiceType GetCacheServiceType()
        {
            return CacheServiceType.Redis;
        }

        //async
        public async Task<T> GetAsync<T>(string key) where T : class
        {
            byte[] cached = null;
            try
            {
                cached = await _cache.GetAsync(cachingOptions.CacheKeyPrefix + key);
            }
            catch (Exception ex)
            {
                log.LogError("Get cache from redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", cachingOptions.CacheKeyPrefix + key, ex.ToString());
                cached = null;
            }

            if (cached == null)
            {
                return null;
            }
            var cachedStr = System.Text.Encoding.UTF8.GetString(cached);
            if (typeof(T) == typeof(string))
            {
                return cachedStr as T;
            }

            return JsonConvert.DeserializeObject<T>(cachedStr);
        }

        public async Task<T> GetOnceAsync<T>(string key) where T : class
        {
            var result = await this.GetAsync<T>(key);
            if (result != null)
            {
                await this.RemoveAsync(key);
            }
            return result;
        }

        public async Task RemoveAsync(string key)
        {
            try
            {
                await _cache.RemoveAsync(cachingOptions.CacheKeyPrefix + key);
            }
            catch (Exception ex)
            {
                log.LogError("Remove cache from redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", cachingOptions.CacheKeyPrefix + key, ex.ToString());
            }

        }

        public async Task SetAsync(string key, object value)
        {
            await SetAsync(key, value, cachingOptions.CacheDurationMinutes);
        }

        public async Task SetAsync(string key, object value, int duration)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            await SetAsync(key, value, new DistributedCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(duration)
            });
        }

        public async Task SetShortAsync(string key, object value, int duration)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            await SetAsync(key, value, new DistributedCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromSeconds(duration)
            });
        }

        public async Task SetAsync(string key, object value, DistributedCacheEntryOptions cacheOptions)
        {
            string toCache;
            if (value is string)
            {
                toCache = (string)value;
            }
            else
            {
                toCache = JsonConvert.SerializeObject(value, new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
            }

            try
            {
                await _cache.SetAsync(cachingOptions.CacheKeyPrefix + key, System.Text.Encoding.UTF8.GetBytes(toCache), cacheOptions);
            }
            catch (Exception ex)
            {
                log.LogError("Set cache in redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", cachingOptions.CacheKeyPrefix + key, ex.ToString());
            }
        }

        public Task SetAsync(string key, object value, MemoryCacheEntryOptions cacheOptions)
        {
            log.LogError("Please checked the DI in startup, you have add a redis cache service. Don't use memory cache method.");
            throw new NotImplementedException("Please checked the DI in startup, you have add a redis cache service. Don't use memory cache method.");
        }

        #region Prefix
        public T Get<T>(string key, string prefix) where T : class
        {
            byte[] cached = null;
            try
            {
                cached = _cache.Get(prefix + key);
            }
            catch (Exception ex)
            {
                log.LogError("Get cache from redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", prefix + key, ex.ToString());
                cached = null;
            }

            if (cached == null)
            {
                return null;
            }
            var cachedStr = System.Text.Encoding.UTF8.GetString(cached);
            if (typeof(T) == typeof(string))
            {
                return cachedStr as T;
            }

            return JsonConvert.DeserializeObject<T>(cachedStr);
        }

        public T GetOnce<T>(string key, string prefix) where T : class
        {
            var result = this.Get<T>(key, prefix);
            if (result != null)
            {
                this.Remove(key, prefix);
            }
            return result;
        }

        public void Remove(string key, string prefix)
        {
            try
            {
                _cache.Remove(prefix + key);
            }
            catch (Exception ex)
            {
                log.LogError("Remove cache from redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", prefix + key, ex.ToString());
            }

        }

        public void Set(string key, object value, string prefix)
        {
            Set(key, value, cachingOptions.CacheDurationMinutes, prefix);
        }

        public void Set(string key, object value, int duration, string prefix)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            Set(key, value, new DistributedCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(duration)
            }, prefix);
        }

        public void SetShort(string key, object value, int duration, string prefix)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            Set(key, value, new DistributedCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromSeconds(duration)
            }, prefix);
        }

        public void Set(string key, object value, DistributedCacheEntryOptions cacheOptions, string prefix)
        {
            string toCache;
            if (value is string)
            {
                toCache = (string)value;
            }
            else
            {
                toCache = JsonConvert.SerializeObject(value, new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
            }

            try
            {
                _cache.Set(prefix + key, System.Text.Encoding.UTF8.GetBytes(toCache), cacheOptions);
            }
            catch (Exception ex)
            {
                log.LogError("Set cache in redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", prefix + key, ex.ToString());
            }
        }

        public void Set(string key, object value, MemoryCacheEntryOptions cacheOptions, string prefix)
        {
            log.LogError("Please checked the DI in startup, you have add a redis cache service. Don't use memory cache method.");
            throw new NotImplementedException("Please checked the DI in startup, you have add a redis cache service. Don't use memory cache method.");
        }

        //async
        public async Task<T> GetAsync<T>(string key, string prefix) where T : class
        {
            byte[] cached = null;
            try
            {
                cached = await _cache.GetAsync(prefix + key);
            }
            catch (Exception ex)
            {
                log.LogError("Get cache from redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", prefix + key, ex.ToString());
                cached = null;
            }

            if (cached == null)
            {
                return null;
            }
            var cachedStr = System.Text.Encoding.UTF8.GetString(cached);
            if (typeof(T) == typeof(string))
            {
                return cachedStr as T;
            }

            return JsonConvert.DeserializeObject<T>(cachedStr);
        }

        public async Task<T> GetOnceAsync<T>(string key, string prefix) where T : class
        {
            var result = await this.GetAsync<T>(key, prefix);
            if (result != null)
            {
                await this.RemoveAsync(key, prefix);
            }
            return result;
        }

        public async Task RemoveAsync(string key, string prefix)
        {
            try
            {
                await _cache.RemoveAsync(prefix + key);
            }
            catch (Exception ex)
            {
                log.LogError("Remove cache from redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", prefix + key, ex.ToString());
            }

        }

        public async Task SetAsync(string key, object value, string prefix)
        {
            await SetAsync(key, value, cachingOptions.CacheDurationMinutes, prefix);
        }

        public async Task SetAsync(string key, object value, int duration, string prefix)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            await SetAsync(key, value, new DistributedCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromMinutes(duration)
            }, prefix);
        }

        public async Task SetShortAsync(string key, object value, int duration, string prefix)
        {
            duration = duration <= 0 ? cachingOptions.CacheDurationMinutes : duration;
            await SetAsync(key, value, new DistributedCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromSeconds(duration)
            }, prefix);
        }

        public async Task SetAsync(string key, object value, DistributedCacheEntryOptions cacheOptions, string prefix)
        {
            string toCache;
            if (value is string)
            {
                toCache = (string)value;
            }
            else
            {
                toCache = JsonConvert.SerializeObject(value, new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
            }

            try
            {
                await _cache.SetAsync(prefix + key, System.Text.Encoding.UTF8.GetBytes(toCache), cacheOptions);
            }
            catch (Exception ex)
            {
                log.LogError("Set cache in redis cache with key \"{cacheKey}\" failed. Error details: \"{errorDetails}\".", prefix + key, ex.ToString());
            }
        }

        public Task SetAsync(string key, object value, MemoryCacheEntryOptions cacheOptions, string prefix)
        {
            log.LogError("Please checked the DI in startup, you have add a redis cache service. Don't use memory cache method.");
            throw new NotImplementedException("Please checked the DI in startup, you have add a redis cache service. Don't use memory cache method.");
        }
        #endregion
    }
}

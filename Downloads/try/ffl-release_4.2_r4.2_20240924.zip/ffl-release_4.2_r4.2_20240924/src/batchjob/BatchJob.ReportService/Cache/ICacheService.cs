﻿using BatchJob.ReportService.Model;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using System.Threading.Tasks;

namespace BatchJob.ReportService.Cache
{
    public interface ICacheService
    {
        void Set(string key, object value);

        //duration is minutes
        void Set(string key, object value, int duration);

        //duration is seconds
        void SetShort(string key, object value, int duration);

        void Set(string key, object value, MemoryCacheEntryOptions cacheOptions);

        void Set(string key, object value, DistributedCacheEntryOptions cacheOptions);

        void Remove(string key);

        T Get<T>(string key) where T : class;

        T GetOnce<T>(string key) where T : class;

        Task SetAsync(string key, object value);

        //duration is minutes
        Task SetAsync(string key, object value, int duration);

        //duration is seconds
        Task SetShortAsync(string key, object value, int duration);

        Task SetAsync(string key, object value, MemoryCacheEntryOptions cacheOptions);

        Task SetAsync(string key, object value, DistributedCacheEntryOptions cacheOptions);

        Task RemoveAsync(string key);

        Task<T> GetAsync<T>(string key) where T : class;

        Task<T> GetOnceAsync<T>(string key) where T : class;

        CacheServiceType GetCacheServiceType();

        #region Prefix
        void Set(string key, object value, string prefix);

        //duration is minutes
        void Set(string key, object value, int duration, string prefix);

        //duration is seconds
        void SetShort(string key, object value, int duration, string prefix);

        void Set(string key, object value, MemoryCacheEntryOptions cacheOptions, string prefix);

        void Set(string key, object value, DistributedCacheEntryOptions cacheOptions, string prefix);

        void Remove(string key, string prefix);

        T Get<T>(string key, string prefix) where T : class;

        T GetOnce<T>(string key, string prefix) where T : class;

        //async
        Task SetAsync(string key, object value, string prefix);

        //duration is minutes
        Task SetAsync(string key, object value, int duration, string prefix);

        //duration is seconds
        Task SetShortAsync(string key, object value, int duration, string prefix);

        Task SetAsync(string key, object value, MemoryCacheEntryOptions cacheOptions, string prefix);

        Task SetAsync(string key, object value, DistributedCacheEntryOptions cacheOptions, string prefix);

        Task RemoveAsync(string key, string prefix);

        Task<T> GetAsync<T>(string key, string prefix) where T : class;

        Task<T> GetOnceAsync<T>(string key, string prefix) where T : class;
        #endregion
    }
}

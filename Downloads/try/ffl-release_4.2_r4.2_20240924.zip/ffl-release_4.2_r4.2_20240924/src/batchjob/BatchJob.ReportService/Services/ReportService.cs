﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.ReportService.Services.Interfaces;
using System.ServiceModel;
using System.Threading.Tasks;
using System.Linq;
using SSRSExecutorService;
using ExecutorTrustedUserHeader = SSRSExecutorService.TrustedUserHeader;
using ExecutorParameterValue = SSRSExecutorService.ParameterValue;
using SSRSService2010;
using SSRSTrustedUserHeader = SSRSService2010.TrustedUserHeader;
using BatchJob.ReportService.Common.Interfaces;
using BatchJob.ReportService.Model;
using System.Collections.Generic;
using BatchJob.ReportService.Common;
using Microsoft.Extensions.Logging;
using System;
using Microsoft.Extensions.Caching.Memory;
using ThreadTask = System.Threading.Tasks.Task;
using Microsoft.Extensions.Options;
using System.Text;
using BatchJob.ReportService.Cache;
using static BatchJob.ReportService.Model.SSRSEnum;

namespace BatchJob.ReportService.Services
{
    public class ReportingService : IReportingService
    {
        private readonly ILogger<ReportingService> logger;
        private readonly IReportServiceClient ServiceClient;
        private readonly ICacheService Cache;

        private const string CacheMessagePrefix = "Message";
        private const string CacheFilePrefix = "File";

        public ReportConfiguration ReportConfig { get; set; }

        public ReportingService(IReportServiceClient client, ICacheService cache, IOptions<ReportConfiguration> config, ILogger<ReportingService> logger)
        {
            this.ServiceClient = client;
            this.Cache = cache;
            this.ReportConfig = config.Value;
            this.logger = logger;
        }

        public async Task<List<CatalogItem>> ListReport(string path)
        {
            var client = ServiceClient.CreateSSRSClient();
            if (client == null)
            {
                return null;
            }
            SSRSTrustedUserHeader header = new SSRSTrustedUserHeader();
            var items = await client.ListChildrenAsync(header, path, false);
            return items.CatalogItems.ToList();
        }

        public async Task<(byte[], string)> Export(SSRSModel.RenderModel renderModel)
        {
            try
            {
                return await ExportInternal(renderModel);
            }
            catch (Exception ex)
            {
                logger.LogError($"An error occurred while exporting report. Exception: {ex}");
                return (new byte[0], string.Empty);
            }
        }

        public async Task<(byte[], string)> ExportInternal(SSRSModel.RenderModel renderModel)
        {
            logger.LogInformation($"Start to export report. Parameters: {GenerateParametersLog(renderModel)}");
            var client = ServiceClient.CreateExecutorClient();
            if (client == null)
            {
                return (new byte[0], string.Empty);
            }
            var trustHeader = new ExecutorTrustedUserHeader();
            var loadResponse = await client.LoadReportAsync(trustHeader, renderModel.ReportPath, null);
            var executionHeader = loadResponse.ExecutionHeader;
            var param = new List<ExecutorParameterValue>();
            if (renderModel.Parameters != null)
            {
                foreach (var parameter in renderModel.Parameters)
                {
                    param.Add(new ExecutorParameterValue() { Name = parameter.Key, Value = parameter.Value });
                }
            }
            await client.SetExecutionParametersAsync(executionHeader, trustHeader, param.ToArray(), "en-us");

            var render = new RenderRequest();
            render.Format = renderModel.ReportFormat.ToAttributeString();
            render.ExecutionHeader = executionHeader;
            render.TrustedUserHeader = trustHeader;
            var response = await client.RenderAsync(render);

            var fileName = renderModel.ReportPath.Substring(renderModel.ReportPath.LastIndexOf("/") + 1) + GetFileExtension(renderModel.ReportFormat);
            logger.LogInformation($"Export report finished.");
            return (response.Result, fileName);
        }

        private string GetFileExtension(SSRSEnum.ReportFormat format)
        {
            switch (format)
            {
                case SSRSEnum.ReportFormat.PDF:
                    return ".pdf";
                case SSRSEnum.ReportFormat.WORD:
                    return ".docx";
                case SSRSEnum.ReportFormat.EXCEL:
                    return ".xlsx";
                case SSRSEnum.ReportFormat.CSV:
                    return ".csv";
                case SSRSEnum.ReportFormat.XML:
                    return ".xml";
                case SSRSEnum.ReportFormat.XHTML:
                    return ".xhtml";
                case SSRSEnum.ReportFormat.JPG:
                    return ".jpg";
                case SSRSEnum.ReportFormat.JPEG:
                    return ".jpeg";
                default:
                    return "";
            }
        }

        private string GenerateParametersLog(SSRSModel.RenderModel renderModel)
        {
            if (renderModel == null)
            {
                return "Render model is null";
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine($"ReportPath: {renderModel.ReportPath}");
            builder.AppendLine($"ReportFormat: {renderModel.ReportFormat.ToAttributeString()}");
            if (renderModel.Parameters == null)
            {
                builder.AppendLine("Parameter is null");
                return builder.ToString();
            }

            foreach (var param in renderModel.Parameters)
            {
                builder.AppendLine($"Parameters: Name: {param.Key}, Value: {(param.Value == null ? "NULL" : param.Value)}");
            }
            return builder.ToString();
        }

        public string BeginExport(SSRSModel.RenderModel renderModel)
        {
            var uniqueWord = DateTime.Now.Ticks.ToString();
            var fileCacheKey = GetCacheKey(CacheDataType.File, uniqueWord);
            var messageCacheKey = GetCacheKey(CacheDataType.Message, uniqueWord);
            _ = ThreadTask.Run(async () =>
            {
                try
                {
                    logger.LogInformation($"Begin export report. UniqueWord: {uniqueWord}, ReportPath: {renderModel.ReportPath}, Type: {renderModel.ReportFormat}");
                    var (fileData, filenName) = await ExportInternal(renderModel);
                    logger.LogInformation($"Export report finished. UniqueWord: {uniqueWord}, FileName: {filenName}, Size: {fileData.Length}");
                    await Cache.SetAsync(messageCacheKey, new ExportMessage { Status = SSRSEnum.ExportStatus.Finished, Message = filenName }, ReportConfig.TimeoutSeconds);
                    await Cache.SetAsync(fileCacheKey, fileData, ReportConfig.TimeoutSeconds);
                }
                catch (Exception ex)
                {
                    logger.LogError($"An error occurred while exporting report. Exception: {ex}");
                    Cache.Set(messageCacheKey, new ExportMessage { Status = SSRSEnum.ExportStatus.Failed, Message = ex.Message }, 60 * 10);
                }
            });
            return uniqueWord;
        }

        public async Task<ExportMessage> CheckStatus(string uniqueWord)
        {
            var messageCacheKey = GetCacheKey(CacheDataType.Message, uniqueWord);
            var message = await Cache.GetAsync<ExportMessage>(messageCacheKey);
            if (message != null)
            {
                logger.LogInformation($"Get export message from cache. UniqueWord: {uniqueWord}, Status: {message?.Status}, Message length: {message?.Message.Length}");
                return message;
            }
            else
            {
                logger.LogInformation($"Export is inprogress. UniqueWord: {uniqueWord}");
                return new ExportMessage()
                {
                    Status = SSRSEnum.ExportStatus.Inprogress,
                    Message = string.Empty,
                };
            }
        }

        public async Task<(byte[], string)> TryGetExportFile(string uniqueWord)
        {
            var fileCacheKey = GetCacheKey(CacheDataType.File, uniqueWord);
            var messageCacheKey = GetCacheKey(CacheDataType.Message, uniqueWord);
            var fileData = await Cache.GetAsync<byte[]>(fileCacheKey);
            if (fileData != null)
            {
                var message = await Cache.GetAsync<ExportMessage>(messageCacheKey);
                if (message != null)
                {
                    await Cache.RemoveAsync(messageCacheKey);
                    await Cache.RemoveAsync(fileCacheKey);
                }
                return (fileData, message?.Message);
            }
            logger.LogInformation($"Cannot find exported file. UniqueWord: {uniqueWord}");
            return (new byte[0], string.Empty);
        }

        private string GetCacheKey(CacheDataType type, string uniqueWord)
        {
            switch (type)
            {
                case CacheDataType.Message:
                    return $"{CacheMessagePrefix}_{uniqueWord}";
                case CacheDataType.File:
                    return $"{CacheFilePrefix}_{uniqueWord}";
                default:
                    return "";
            }
        }
    }
}

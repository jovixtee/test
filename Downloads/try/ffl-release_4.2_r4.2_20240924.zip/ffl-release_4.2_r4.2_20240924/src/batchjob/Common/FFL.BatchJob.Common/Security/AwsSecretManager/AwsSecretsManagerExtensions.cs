﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Amazon.SecretsManager.Extensions.Caching;
using Microsoft.Extensions.Configuration;

namespace FFL.BatchJob.Common.Security.AwsSecretManager
{
    public static class AwsSecretsManagerExtensions
    {
        public static void AddAmazonSecretsManager(this IConfigurationBuilder configurationBuilder,
                        string region,
                        string[] secretNames,
                        string awsAccessKeyId = null,
                        string awsSecretAccessKey = null,
                        string awsWebIdentityTokenFilePath = null,
                        string awsRoleArn = null,
                        string awsRoleSessionName = null,
                        string versionStage = SecretCacheConfiguration.DEFAULT_VERSION_STAGE,
                        bool useSecretCache = true,
                        uint cacheItemTTL = SecretCacheConfiguration.DEFAULT_CACHE_ITEM_TTL,
                        PeriodicWatcher periodicWatcher = null)
        {
            foreach (var secretName in secretNames)
            {
                var configurationSource =
                        new AwsSecretsManagerConfigurationSource(region, secretName, awsAccessKeyId, awsSecretAccessKey, awsWebIdentityTokenFilePath, awsRoleArn, awsRoleSessionName, versionStage, useSecretCache, cacheItemTTL, periodicWatcher);

                configurationBuilder.Add(configurationSource);
            }
        }
    }
}

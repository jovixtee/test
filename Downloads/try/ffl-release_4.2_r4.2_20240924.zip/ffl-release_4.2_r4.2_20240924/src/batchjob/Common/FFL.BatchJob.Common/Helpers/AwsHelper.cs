﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Amazon.Runtime;
using Amazon.SecurityToken;
using Amazon.SecurityToken.Model;
using System;
using System.IO;
using System.Threading.Tasks;

namespace FFL.BatchJob.Common.Helpers
{
    public class AwsHelper
    {
        public static async Task<SessionAWSCredentials> GetSessionAWSCredentialsAsync(string webIdentityTokenFile, string roleArn, string roleSessionName = "AwsRoleSession")
        {
            //https://aws.amazon.com/blogs/developer/web-identity-federation-using-the-aws-sdk-for-net/
            if (string.IsNullOrEmpty(webIdentityTokenFile))
            {
                throw new ArgumentNullException("webIdentityTokenFile cannot be empty");
            }
            else if (string.IsNullOrEmpty(roleArn))
            {
                throw new ArgumentNullException("roleArn cannot be empty");
            }
            string accessToken = File.ReadAllText(webIdentityTokenFile);
            if (string.IsNullOrEmpty(accessToken))
            {
                throw new Exception("GetSessionAWSCredentialsAsync-accessToken cannot be empty");
            }
            var stsClient = new AmazonSecurityTokenServiceClient(new AnonymousAWSCredentials());
            // Assume the role using the token provided by AWS_WEB_IDENTITY_TOKEN_FILE.
            var assumeRoleResult = await stsClient.AssumeRoleWithWebIdentityAsync(new AssumeRoleWithWebIdentityRequest
            {
                WebIdentityToken = accessToken,
                //ProviderId = "graph.facebook.com",
                RoleArn = roleArn,
                RoleSessionName = string.IsNullOrEmpty(roleSessionName) ? "AwsRoleSession" : roleSessionName
                //DurationSeconds = 3600
            });
            if (assumeRoleResult?.Credentials != null)
            {
                var credentials = assumeRoleResult.Credentials;
                SessionAWSCredentials sessionCreds = new SessionAWSCredentials(credentials.AccessKeyId, credentials.SecretAccessKey, credentials.SessionToken);

                return sessionCreds;
            }
            else
            {
                throw new Exception("GetSessionAWSCredentialsAsync-credentials cannot be empty.");
            }
        }
    }
}

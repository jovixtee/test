﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FFL.BatchJob.Common.Options
{
    public class SecurityOptions
    {
        public bool UseCaptcha { get; set; } = true;
        public bool UseAzureKeyVault { get; set; } = false;
        public CaptchaOptions CaptchaOptions { set; get; }
        public AzureKeyVaultOptions AzureKeyVaultOptions { get; set; }
        public AwsSecretManagerOptions AwsSecretManagerOptions { get; set; }
        public AwsSystemManagerOptions AwsSystemManagerOptions { get; set; }
    }

    public class CaptchaOptions
    {
        public string GatewayUrl { set; get; }
    }

    public class AzureKeyVaultOptions
    {
        public string KeyVaultName { get; set; }
        public string KeyNameFormat { get; set; } = "{0}";
        public string KeyType { get; set; } = "RSA";
        public int? KeySize { get; set; } = 2048;
        public string Algorithm { get; set; } = "RSA-OAEP";
        public string KeyIdentifier { get; set; }
        public string ClientId { get; set; }
        public string ClientSercet { get; set; }

        public bool NeedDataProtector { get; set; } = true;
    }

    public class AwsSecretManagerOptions
    {
        public bool UseSecretCache { get; set; } = true;
        public string SecretName { get; set; }
        public string Region { get; set; }
        public string AccessKey { get; set; }
        public string SecretKey { get; set; }
        public uint CacheItemTTL { get; set; } = 60 * 60 * 1000;
        public string VersionStage { get; set; } = "AWSCURRENT";
    }

    public class AwsSystemManagerOptions
    {
        public string Path { get; set; }
        public string Region { get; set; }
        public string AccessKey { get; set; }
        public string SecretKey { get; set; }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Amazon;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Extensions.Caching;
using Amazon.SecretsManager.Model;
using FFL.BatchJob.Common.Helpers;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace FFL.BatchJob.Common.Security.AwsSecretManager
{
    public class AwsSecretsManagerConfigurationProvider : ConfigurationProvider
    {
        private readonly bool _useSecretCache;
        private readonly string _region;
        private readonly string _secretName;
        private readonly string _awsAccessKeyId;
        private readonly string _awsSecretAccessWord;
        private readonly string _awsWebIdentityToken;
        private readonly string _awsRoleArn;
        private readonly string _awsRoleSessionName;
        private readonly string _versionStage;
        private readonly uint _cacheItemTTL;

        public AwsSecretsManagerConfigurationProvider(string region, string secretName, string awsAccessKeyId, string awsSecretAccessKey, string awsWebIdentityTokenFilePath, string awsRoleArn, string awsRoleSessionName, string versionStage, bool useSecretCache, uint cacheItemTTL, PeriodicWatcher watcher = null)
        {
            _useSecretCache = useSecretCache;
            _region = region;
            _secretName = secretName;
            _awsAccessKeyId = awsAccessKeyId;
            _awsSecretAccessWord = awsSecretAccessKey;
            _awsWebIdentityToken = awsWebIdentityTokenFilePath;
            _awsRoleArn = awsRoleArn;
            _awsRoleSessionName = awsRoleSessionName;

            _versionStage = versionStage;
            _cacheItemTTL = cacheItemTTL;

            //if (watcher != null)
            //{
            //    //_changeTokenRegistration =
            //    ChangeToken.OnChange(() => watcher.Watch(), Load);
            //}
        }

        public override void Load()
        {
            if (_useSecretCache)
            {
                var secret = GetCacheSecret();

                Data = JsonConvert.DeserializeObject<Dictionary<string, string>>(secret);
            }
            else
            {
                var secret = GetSecret();

                Data = JsonConvert.DeserializeObject<Dictionary<string, string>>(secret);
            }
        }

        private string GetCacheSecret()
        {
            using (var client =
            string.IsNullOrEmpty(_awsAccessKeyId) && string.IsNullOrEmpty(_awsSecretAccessWord) ? new AmazonSecretsManagerClient(AwsHelper.GetSessionAWSCredentialsAsync(_awsWebIdentityToken, _awsRoleArn, _awsRoleSessionName).Result, RegionEndpoint.GetBySystemName(_region)) : new AmazonSecretsManagerClient(_awsAccessKeyId, _awsSecretAccessWord, RegionEndpoint.GetBySystemName(_region)))
            {
                string secretString = string.Empty;
                SecretCacheConfiguration config = new SecretCacheConfiguration()
                {
                    CacheItemTTL = _cacheItemTTL,
                    VersionStage = _versionStage

                };
                using (var cache = new SecretsManagerCache(client, config))
                {
                    secretString = cache.GetSecretString(_secretName).Result;
                    if (string.IsNullOrWhiteSpace(secretString))
                    {
                        var bytes = cache.GetSecretBinary(_secretName).Result;
                        if (bytes != null)
                        {
                            var token = BitConverter.ToString(bytes);
                            secretString = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(token));

                            //using (var reader = new StreamReader(new MemoryStream(bytes)))
                            //{
                            //    secretString = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(reader.ReadToEnd()));
                            //}
                        }
                    }
                }

                return secretString;
            }
        }

        private string GetSecret()
        {
            var request = new GetSecretValueRequest
            {
                SecretId = _secretName,
                VersionStage = _versionStage // VersionStage defaults to AWSCURRENT if unspecified.

            };
            using (var client =
            string.IsNullOrEmpty(_awsAccessKeyId) && string.IsNullOrEmpty(_awsSecretAccessWord) ? new AmazonSecretsManagerClient(AwsHelper.GetSessionAWSCredentialsAsync(_awsWebIdentityToken, _awsRoleArn, _awsRoleSessionName).Result, RegionEndpoint.GetBySystemName(_region)) : new AmazonSecretsManagerClient(_awsAccessKeyId, _awsSecretAccessWord, RegionEndpoint.GetBySystemName(_region)))
            {
                string secretString = string.Empty;
                var response = client.GetSecretValueAsync(request).Result;

                if (response.SecretString != null)
                {
                    secretString = response.SecretString;
                }
                else
                {
                    var token = BitConverter.ToString(response.SecretBinary.ToArray());
                    secretString = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(token));

                    //using (var reader = new StreamReader(response.SecretBinary))
                    //{
                    //    secretString = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(reader.ReadToEnd()));
                    //}
                }

                return secretString;
            }
        }
    }
}

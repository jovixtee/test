﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.CAMService.Filter;
using BatchJob.CAMService.Models.CamRequestModels;
using BatchJob.CAMService.Models.CamResponseModels;
using BatchJob.CAMService.Services;
using BatchJob.CAMService.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BatchJob.CAMService.Controller
{
    [TypeFilter(typeof(GlobalAuthorizeFilter), Order = 1)]
    [TypeFilter(typeof(GlobalExceptionFilter), Order = 2)]
    [TypeFilter(typeof(ValidateActionFilterAttribute), Order = 3)]
    [ApiController]
    [Route("api/groups")]
    public class CamGroupApiController : ControllerBase
    {
        //private readonly ILogger<UsersController> _logger;

        private readonly ICamGroupService Client;

        public CamGroupApiController(ICamGroupService client)
        {
            Client = client;
        }

        [HttpPost("info")]
        public async Task<GroupInfo> GetGroupInfo(GroupInfoModel model)
        {
            //_logger.LogInformation("start GetUserInfo");
            return await Client.GetGroupInfo(model);
            //_logger.LogInformation("GetUserInfo successfully");
        }

        [HttpPost("findbycriteria")]
        public async Task<GroupInfoList> FindbyCriteria(FindGroupInfoModel model)
        {
            //_logger.LogInformation("start Findbycriteria");
            return await Client.FindbyCriteria(model);
            //_logger.LogInformation("Findbycriteria successfully");
        }

        [HttpPost("update")]
        public async Task<IActionResult> UpdateGroupInfo(UpdateGroupInfoModel model)
        {
            //_logger.LogInformation("start UpdateGroupInfo ");
            await Client.UpdateGroupInfo(model);
            //_logger.LogInformation("UpdateGroupInfo successfully");
            return NoContent();
        }

        [HttpPost("remove")]
        public async Task<IActionResult> RemoveGroupInfo(GroupInfoModel model)
        {
            //_logger.LogInformation("start RemoveUserInfo ");
            await Client.RemoveGroupInfo(model);
            //_logger.LogInformation("RemoveUserInfo successfully");
            return NoContent();
        }
    }
}

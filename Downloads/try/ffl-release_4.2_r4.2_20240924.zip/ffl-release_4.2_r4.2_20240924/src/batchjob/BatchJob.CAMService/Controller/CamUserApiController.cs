﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.CAMService.Filter;
using BatchJob.CAMService.Models.CamRequestModels;
using BatchJob.CAMService.Models.CamResponseModels;
using BatchJob.CAMService.Services;
using BatchJob.CAMService.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace BatchJob.CAMService.Controller
{
    [TypeFilter(typeof(GlobalAuthorizeFilter), Order = 1)]
    [TypeFilter(typeof(GlobalExceptionFilter), Order = 2)]
    [TypeFilter(typeof(ValidateActionFilterAttribute), Order = 3)]
    [ApiController]
    [Route("api/users")]
    public class CamUserApiController : ControllerBase
    {
        //private readonly ILogger<UsersController> _logger;

        private readonly ICamUserService UsersService;

        public CamUserApiController(ICamUserService usersService)
        {
            UsersService = usersService;
        }

        [HttpPost("info")]
        public async Task<UserInfo> GetUserInfo(UserInfoModel model)
        {
            //_logger.LogInformation("start Info");
            return await UsersService.GetUserInfo(model);
            //_logger.LogInformation("GetUserInfo successfully");
        }

        [HttpPost("findbycriteria")]
        public async Task<UserInfoList> FindUsersByCriteria(FindUserInfoModel model)
        {
            //_logger.LogInformation("start findbycriteria");
            return await UsersService.FindUsersByCriteria(model);
            //_logger.LogInformation("findbycriteria successfully");
        }

        [HttpPost("update")]
        public async Task<UserInfo> UpdateUserInfo(UpdateUserInfoModel model)
        {
            //_logger.LogInformation("start UpdateUserInfo");
            return await UsersService.UpdateUserInfo(model);
            //_logger.LogInformation("UpdateUserInfo successfully");
        }

        [HttpPost("remove")]
        public async Task<IActionResult> RemoveUserInfo([NotNull] UserInfoModel model)
        {
            //_logger.LogInformation("start RemoveUserInfo");
            await UsersService.RemoveUserInfo(model);
            //_logger.LogInformation("RemoveUserInfo successfully");
            return NoContent();
        }
    }
}

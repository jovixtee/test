﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.CAMService.Models.CamResponseModels;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System;
using BatchJob.CAMService.Models.ApmResponseModels;
using System.Security.AccessControl;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace BatchJob.CAMService.Utils
{
    public static class CamConverter
    {
        private const string eq = "eq";
        private const string like = "like";
        private const string co = "co";
        private const string userResourceType = "User";
        private const string groupResourceType = "Role";
        private const string userType = "AgencyUser";
        private const string emailType = "work";

        public static GroupInfo ConvertToGroupInfo(GroupViewModel group)
        {
            if (group == null) return null;
            var members = new List<Members>();
            if (group.MembersValue != null && group.MembersValue.Any())
            {
                foreach (var item in group.MembersValue)
                {
                    members.Add(new Members
                    {
                        Value = item,
                        MembersRef = "",
                        Type = userResourceType
                    });
                }
            }
            GroupInfo groupInfo = new GroupInfo
            {
                Id = group.GroupId,
                ExternalId = group.ExternalId,
                Meta = new Meta
                {
                    ResourceType = groupResourceType,
                    Created = group.CreatedOn,
                    LastModified = group.ModifiedOn
                },
                DisplayName = group.GroupName,
                Members = members,
                CamGroup = new CamGroup
                {
                    GroupAccessRightInfo = ""
                }
            };
            return groupInfo;
        }
        public static UserInfo ConvertToUserInfo(UserViewModel user)
        {
            if (user == null) return null;
            var userGroups = new List<Groups>();
            foreach (var item in user.userGroups)
            {
                userGroups.Add(new Groups { Display = item.RoleName, Value = item.RoleId, GroupsRef = "" });
            }
            UserInfo userInfo = new UserInfo
            {
                Id = user.UserId,
                ExternalId = user.ExternalId,
                Meta = new Meta
                {
                    ResourceType = userResourceType,
                    Created = user.CreatedOn,
                    LastModified = user.ModifiedOn
                },
                UserName = user.UserName,
                DisplayName = user.DisplayName,
                Name = new Name
                {
                    Formatted = user.DisplayName,
                    FamilyName = user.FirstName,
                    GivenName = user.LastName,
                },
                Active = user.Status == Status.Active,
                Emails = new List<Email>
                {
                    new Email
                    {
                        Value = user.Email,
                        Primary = true,
                        Type = emailType
                    }
                },
                ProfileUrl = "",
                Title = "",
                UserType = userType,
                Groups = userGroups,
                EnterpriseUser = new EnterpriseUser
                {
                    Organization = "MSF"
                },
                ExtendedUser = new ExtendedUser
                {
                    LastLogin = user.LastLoginDate,
                    IsPrivileged = user.Status == Status.Active,
                }
            };
            return userInfo;
        }
        //public static FilterInfo TableFilter(string filter)
        //{
        //    if (string.IsNullOrEmpty(filter))
        //    {
        //        return new FilterInfo();
        //        //throw new ArgumentException($"'{nameof(filter)}' cannot be null or empty.", nameof(filter));
        //    }
        //    FilterInfo result = new FilterInfo { FilterOperator = FilterLogicalOperator.And };
        //    string column = filter[..filter.IndexOf(" ")];
        //    column = ColumnMapping(column);
        //    var condition = new FilterConditionInfo { ColumnName = column, ColumnType = typeof(string) };
        //    string operators = filter[(filter.IndexOf(" ") + 1)..];
        //    if (operators.ToLower().StartsWith(eq))
        //    {
        //        condition.Operator = FilterConditionOperator.Equal;
        //    }
        //    else if (operators.ToLower().StartsWith(like) || operators.ToLower().StartsWith(co))
        //    {
        //        condition.Operator = FilterConditionOperator.Contains;
        //    }
        //    condition.Values = new List<object> { operators[(operators.IndexOf("\'") + 1)..].TrimStart('\'').TrimEnd('\'') };
        //    result.FilterConditionColl = new List<FilterConditionInfo> { condition };
        //    return result;
        //}
        public static string ColumnMapping(string name,bool isOnlyGroup = false)
        {
            string column = name;
            if (string.IsNullOrEmpty(name))
            {
                return column;
            }
            if (column.ToLower().Equals("groupname"))
            {
                column = "rolename";
            }
            else if (column.ToLower().Equals("groupid"))
            {
                if (isOnlyGroup)
                {
                    column = "id";
                }
                else
                {
                    column = "roleid";
                }
            }
            else if (column.ToLower().Equals("userid"))
            {
                column = "username";
            }
            return column;
        }
    }
}
/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APM.SDK;
using BatchJob.CAMService.Models;
using BatchJob.CAMService.Services;
using BatchJob.CAMService.Services.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Builder.Extensions;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;

namespace BatchJob.CAMService
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLogging(loggingBuilder =>
            {
                // configure Logging with NLog
                loggingBuilder.ClearProviders();
                loggingBuilder.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Information);
                loggingBuilder.AddNLog("nlog.config");

            });
            services.Configure<CamOptions>(Configuration.GetSection("CamOptions"));
            services.Configure<CamAuthentication>(Configuration.GetSection("CamAuthentication"));
            services.Configure<CamAPMOption>(Configuration.GetSection("CamAPMOption"));
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<ICamGroupService, CamGroupService>();
            services.AddScoped<ICamUserService, CamUserService>();
            services.AddControllers().AddNewtonsoftJson();
            services.AddSingleton(Configuration);
            services.AddSwaggerGen(s =>
            {
                s.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "Reporting Service API", Version = "v1" });
            });

            services.AddAPMSDK();
            /*
            services.AddAuthentication()
              .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
              {
                  //options.Authority = Configuration.GetSection("Authentication:APMAuthority").Value;
                  //options.TokenValidationParameters = new TokenValidationParameters
                  //{
                  //    ValidateAudience = false
                  //};
                  if (bool.TryParse(Configuration.GetSection("Authentication:RequireHttpsMetadata").Value, out bool requireHttps))
                  {
                      options.RequireHttpsMetadata = requireHttps;
                  }
                  var issuersStr = Configuration.GetSection("Authentication:Issuers").Value;
                  if (!string.IsNullOrEmpty(issuersStr))
                  {
                      options.TokenValidationParameters.ValidIssuers = issuersStr.Split(",");
                  }
              });
            */
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            string basePath = Configuration.GetValue("CamServiceBasePath", "");
            if (!env.IsProduction())
            {
                if (string.IsNullOrEmpty(basePath))
                {
                    app.UseSwagger(c =>
                    {
                        c.RouteTemplate = "/swagger/{documentName}/swagger.json";
                    });
                    app.UseSwaggerUI(s =>
                    {
                        s.RoutePrefix = "swagger";
                        s.SwaggerEndpoint("/swagger/v1/swagger.json", "API V1");
                    });
                }
                else
                {
                    app.UseSwagger(c =>
                    {
                        c.RouteTemplate = $"/{basePath}/swagger/{{documentName}}/swagger.json";
                    });
                    app.UseSwaggerUI(s =>
                    {
                        s.RoutePrefix = basePath;
                        s.SwaggerEndpoint($"/{basePath}/swagger/v1/swagger.json", "API V1");
                    });
                }
            }
            var healthz = string.IsNullOrEmpty(basePath) ? "/healthz" : $"/{basePath}/healthz";
            app.Map(healthz, appconfig =>
            {
                appconfig.Run(async context =>
                {
                    await context.Response.WriteAsync($"Ok. Package Version: {Configuration.GetValue("PackageImage_Version", "None")}");
                });
            });
            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BatchJob.CAMService.Models.CamRequestModels
{
    public class UserInfoModel
    {
        public string userId { get; set; }
    }

    public class FindUserInfoModel
    {
        public string filter { get; set; }

        public int? startIndex { get; set; } = 1;

        public int? itemsPerPage { get; set; } = 10;

        public string ascOrderBy { get; set; }
        public string descOrderBy { get; set; }
    }

    public class UpdateUserInfoModel
    {
        public string[] schemas { get; set; }

        public string userId { get; set; }

        public List<Operations> Operations { get; set; }
    }
}

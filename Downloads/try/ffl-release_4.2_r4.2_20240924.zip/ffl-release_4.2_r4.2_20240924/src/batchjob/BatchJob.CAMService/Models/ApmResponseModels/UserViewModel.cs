﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System;
using System.Collections.Generic;
using System.Linq;

namespace BatchJob.CAMService.Models.ApmResponseModels
{
    public enum Status
    {
        Active,
        Inactive,
    }
    public class UserViewModel
    {
        public string UserId { get; set; }
        public string ExternalId { get; set; }
        public string CreatedOn { get; set; } = "";
        public string ModifiedOn { get; set; } = "";
        public string UserName { get; set; }
        public string DisplayName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Status Status { get; set; }
        public string Email { get; set; }
        public List<UserGroup> userGroups { get; set; }
        public string LastLoginDate { get; set; } = "";
    }
    public class UserGroup
    {
        public Guid RoleId { get; set; }
        public string RoleName { get; set; }
    }
}

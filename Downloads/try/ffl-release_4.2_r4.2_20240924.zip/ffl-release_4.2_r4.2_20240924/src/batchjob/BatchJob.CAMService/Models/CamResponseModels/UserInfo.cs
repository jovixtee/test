﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Newtonsoft.Json;
using System.Collections.Generic;
using System;

namespace BatchJob.CAMService.Models.CamResponseModels
{
    public class UserInfo
    {
        [JsonProperty("schemas")]
        public string[] Schemas { get; set; } = new string[3] { "urn:ietf:params:scim:schemas:core:2.0:User", "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User", "urn:ietf:params:scim:schemas:extension:cam:2.0:User" };

        [JsonProperty("id")]
        public string Id { get; set; } = "";

        [JsonProperty("externalId")]
        public string ExternalId { get; set; }

        [JsonProperty("meta")]
        public Meta Meta { get; set; }

        [JsonProperty("userName")]
        public string UserName { get; set; } = "";

        [JsonProperty("displayName")]
        public string DisplayName { get; set; } = "";

        [JsonProperty("name")]
        public Name Name { get; set; }

        [JsonProperty("active")]
        public bool Active { get; set; }

        [JsonProperty("emails")]
        public List<Email> Emails { get; set; }

        [JsonProperty("profileUrl")]
        public string ProfileUrl { get; set; } = "";

        [JsonProperty("title")]
        public string Title { get; set; } = "";

        [JsonProperty("userType")]
        public string UserType { get; set; }

        [JsonProperty("groups")]
        public List<Groups> Groups { get; set; }

        [JsonProperty("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User")]
        public EnterpriseUser EnterpriseUser { get; set; }

        [JsonProperty("urn:ietf:params:scim:schemas:extension:cam:2.0:User")]
        public ExtendedUser ExtendedUser { get; set; }

        [JsonIgnore]
        public string systemId { get; set; }
    }

    public enum UserType
    {
        AgencyUser, Temp, Intern, Vendor, Other
    }

    public class Meta
    {
        [JsonProperty("resourceType")]
        public string ResourceType { get; set; } = "";

        [JsonProperty("created")]
        public string Created { get; set; } = "";

        [JsonProperty("lastModified")]
        public string LastModified { get; set; } = "";
    }

    public class Name
    {
        [JsonProperty("formatted")]
        public string Formatted { get; set; } = "";

        [JsonProperty("familyName")]
        public string FamilyName { get; set; } = "";

        [JsonProperty("givenName")]
        public string GivenName { get; set; } = "";
    }

    public class Email
    {
        [JsonProperty("value")]
        public string Value { get; set; } = "";

        [JsonProperty("type")]
        public string Type { get; set; } = "";

        [JsonProperty("primary")]
        public bool Primary { get; set; }
    }

    public class Groups
    {
        [JsonProperty("value")]
        public Guid Value { get; set; }

        [JsonProperty("$ref")]
        public string GroupsRef { get; set; } = "";

        [JsonProperty("display")]
        public string Display { get; set; } = "";
    }

    public class EnterpriseUser
    {
        [JsonProperty("organization")]
        public string Organization { get; set; } = "";

        [JsonProperty("division")]
        public string Division { get; set; } = "";

        [JsonProperty("department")]
        public string Department { get; set; } = "";

        [JsonProperty("manager")]
        public Manager Manager { get; set; }
        public EnterpriseUser()
        {
            Manager= new Manager();
        }
    }

    public class Manager
    {
        [JsonProperty("value")]
        public string Value { get; set; } = "";

        [JsonProperty("$ref")]
        public string ManagerRef { get; set; } = "";

        [JsonProperty("displayName")]
        public string DisplayName { get; set; } = "";
    }

    public class ExtendedUser
    {
        [JsonProperty("lastLogin")]
        public string LastLogin { get; set; } = "";

        [JsonProperty("lastPasswordChanged")]
        public string LastPasswordChanged { get; set; } = "";

        [JsonProperty("isPrivileged")]
        public bool IsPrivileged { get; set; }
    }
}

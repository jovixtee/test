﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace BatchJob.CAMService.Models.CamResponseModels
{
    public class GroupInfo
    {
        [JsonProperty("schemas")]
        public string[] Schemas { get; set; } = new string[2] { "urn:ietf:params:scim:schemas:core:2.0:Group", "urn:ietf:params:scim:schemas:extension:cam:2.0:Group" };

        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("externalId")]
        public Guid ExternalId { get; set; }

        [JsonProperty("meta")]
        public Meta Meta { get; set; }

        [JsonProperty("displayName")]
        public string DisplayName { get; set; } = "";

        [JsonProperty("members")]
        public List<Members> Members { get; set; }

        [JsonProperty("urn:ietf:params:scim:schemas:extension:cam:2.0:Group")]
        public CamGroup CamGroup { get; set; }
    }

    public class Members
    {
        [JsonProperty("value")]
        public string Value { get; set; } = "";

        [JsonProperty("$ref")]
        public string MembersRef { get; set; } = "";

        [JsonProperty("type")]
        public string Type { get; set; } = "";
    }

    public class CamGroup
    {
        [JsonProperty("groupAccessRightInfo")]
        public string GroupAccessRightInfo { get; set; } = "";
    }
}

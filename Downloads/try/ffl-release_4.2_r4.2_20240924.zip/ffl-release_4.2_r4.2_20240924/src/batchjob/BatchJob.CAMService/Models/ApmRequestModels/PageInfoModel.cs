﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BatchJob.CAMService.Models.ApmResponseModels;
namespace BatchJob.CAMService.Models.ApmRequestModels
{
    public class RetrievalParam
    {
        public string FilterConfig { get; set; }
        public int? CurrentPage { get; set; } = 1;
        public int? PageSize { get; set; } = 10;
        public string AscOrderBy { get; set; }
        public string DescOrderBy { get; set; }
        public int? StartIndex { get; set; }
    }
    public class QueryUserResult
    {
        public int TotalItemsCount { get; set; }
        public int StartIndex { get; set; }
        public int ItemsPerPage { get; set; }
        public List<UserViewModel> Resources;
    }
    public class QueryGroupResult
    {
        public int TotalItemsCount { get; set; }
        public int StartIndex { get; set; }
        public int ItemsPerPage { get; set; }
        public List<GroupViewModel> Resources;
    }
}

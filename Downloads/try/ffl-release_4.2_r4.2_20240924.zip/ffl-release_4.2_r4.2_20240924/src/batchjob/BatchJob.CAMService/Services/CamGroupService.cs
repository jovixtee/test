﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.CAMService.Models.CamRequestModels;
using BatchJob.CAMService.Models.CamResponseModels;
using BatchJob.CAMService.Services.Interfaces;
using BatchJob.CAMService.Utils;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System;
using APM.SDK;
using BatchJob.CAMService.Models;
using Microsoft.Extensions.Options;
using APM.SDK.Messages;
using System.Net.Http;
using Newtonsoft.Json;
using System.Linq;
using IdentityModel.Client;
using BatchJob.CAMService.Models.ApmRequestModels;
using BatchJob.CAMService.Models.ApmResponseModels;
using Microsoft.AspNetCore.Builder.Extensions;
using Microsoft.AspNetCore.Mvc;
using APM.SDK.Services;

namespace BatchJob.CAMService.Services
{
    public class CamGroupService : ICamGroupService
    {
        public CamGroupService(
            ILogger<CamUserService> logger,
            IOptions<CamAuthentication> options,
            ICamUserService usersService,            
            IOptions<CamAPMOption> apmOptions
        )
        {
            _log = logger;
            _identityOption = options.Value;
            _apmOptions = apmOptions.Value;
            _usersService = usersService;
                       
            _client = new APMClient2(new APMSettings()
            {
                ServiceEndpoint = _apmOptions.Endpoint.TrimEnd('/') + "/api/v1/CamsApi/",
                AuthEndpoint = _identityOption.APMAuthority,
                ClientId = _identityOption.ClientId,
                Secret = _identityOption.ClientSecret
            });
        }
        private readonly APMClient2 _client;
        private readonly ILogger<CamUserService> _log;
        private readonly CamAuthentication _identityOption;
        private readonly ICamUserService _usersService;
        private readonly CamAPMOption _apmOptions;
        public async Task<GroupInfo> GetGroupInfo(GroupInfoModel model)
        {
            _log.LogInformation(CamsLogInformation.SetInformation("start GetGroupById"));
            if (!string.IsNullOrWhiteSpace(model.groupId) && !Guid.TryParse(model.groupId,out _))
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: Group Id does not conform to the guid format."));
                throw new ValidationModelException(401, "Group Id does not conform to the guid format.");
            }
            if (string.IsNullOrEmpty(model.groupId))
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: Group Id is null"));
                throw new ValidationModelException(500, "Group Id is null");
            }
            if (!Guid.TryParse(model.groupId, out Guid groupId))
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: Incorrect parameter groupId"));
                throw new ValidationModelException(500, "Incorrect parameter groupId");
            }
            var response = new APMResponse();
            try
            {
                response = await _client.ExecuteAsync<APMRequest, APMResponse>(new APMRequest()
                {
                    Method = HttpMethod.Get,
                    RequestPath = $"groupinforetrieval?groupId={model.groupId}"
                });
            }
            catch (Exception ex)
            {
                _log.LogError(CamsLogInformation.SetInformation("batch_job_cam_access_error:" + ex));
                throw new ValidationModelException(500, "Internal Server Error");
            }
            var result = response.Content.ReadAsStringAsync().Result;
            if (string.IsNullOrEmpty(result))
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: Group was not found"));
                throw new ValidationModelException(404, "Group was not found");
            }
            var group = new GroupInfo();
            try
            {
                group = CamConverter.ConvertToGroupInfo(JsonConvert.DeserializeObject<GroupViewModel>(result));
            }
            catch (Exception ex)
            {
                _log.LogError(CamsLogInformation.SetInformation("batch_job_cam_access_error:" + ex));
                throw new ValidationModelException(500, "Internal Server Error");
            }
            _log.LogInformation("end GetGroupById");
            return group;
        }

        public async Task<GroupInfoList> FindbyCriteria(FindGroupInfoModel model)
        {
            _log.LogInformation(CamsLogInformation.SetInformation("start FindbyCriteria"));
            if (model.startIndex == null || model.startIndex < 0)
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: startIndex is a positive integer greater than 0 is required"));
                throw new ValidationModelException(500, "startIndex is a positive integer greater than 0 is required");
            }
            if (model.itemsPerPage == null || model.itemsPerPage < 0)
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: itemsPerPage is a positive integer greater than 0 is required"));
                throw new ValidationModelException(500, "itemsPerPage is a positive integer greater than 0 is required");
            }
            try
            {
                GroupInfoList groupInfoList = new GroupInfoList() { Resources = new List<GroupInfo>() };
                RetrievalParam pageInfoModel = new RetrievalParam()
                {
                    FilterConfig = model.filter,
                    StartIndex = model.startIndex ?? 1,
                    PageSize = model.itemsPerPage ?? 10,
                    AscOrderBy = CamConverter.ColumnMapping(model.ascOrderBy,true),
                    DescOrderBy = CamConverter.ColumnMapping(model.descOrderBy,true),
                };
                var response = await _client.ExecuteAsync<APMRequest, APMResponse>(new APMRequest()
                {
                    Method = HttpMethod.Post,
                    RequestPath = $"grouplistretrieval?FilterConfig={JsonConvert.SerializeObject(pageInfoModel.FilterConfig)}&CurrentPage={pageInfoModel.CurrentPage}&PageSize={pageInfoModel.PageSize}&AscOrderBy={pageInfoModel.AscOrderBy}&DescOrderBy={pageInfoModel.DescOrderBy}",
                    InputParameters = pageInfoModel
                });
                var result = await response.Content.ReadAsStringAsync();
                var groupsResult = JsonConvert.DeserializeObject<QueryGroupResult>(result);
                if (groupsResult.TotalItemsCount == 0)
                {
                    throw new ValidationModelException(404, "Group was not found");
                }
                if (groupsResult.Resources != null && groupsResult.Resources.Any())
                {
                    foreach (var group in groupsResult.Resources)
                    {
                        groupInfoList.Resources.Add(CamConverter.ConvertToGroupInfo(group));
                    }
                }
                groupInfoList.TotalResults = groupsResult.TotalItemsCount;
                _log.LogInformation(CamsLogInformation.SetInformation("groupInfoList TotalResults:{0}"), groupInfoList.TotalResults);
                groupInfoList.StartIndex = groupsResult.StartIndex;
                groupInfoList.ItemsPerPage = groupsResult.ItemsPerPage;
                _log.LogInformation(CamsLogInformation.SetInformation("end FindbyCriteria"));
                return groupInfoList;
            }
            catch (Exception ex)
            {
                if (ex.Message.Equals("Group was not found"))
                {
                    throw new ValidationModelException(404, ex.Message);
                }
                _log.LogError(CamsLogInformation.SetInformation("batch_job_cam_access_error:" + ex));
                throw new ValidationModelException(500, "Internal Server Error");
            }
        }

        public async Task UpdateGroupInfo(UpdateGroupInfoModel model)
        {
            _log.LogInformation("start UpdateGroupInfo");
            if (!string.IsNullOrWhiteSpace(model.groupId) && !Guid.TryParse(model.groupId, out _))
            {
                _log.LogInformation("batch_job_cam_access_error: Group Id does not conform to the guid format.");
                throw new ValidationModelException(401, "Group Id does not conform to the guid format.");
            }
            if (model == null || !model.Operations.Any())
            {
                _log.LogInformation("batch_job_cam_access_error:Info or operations is null");
                throw new ValidationModelException(500, "Info or operations is null");
            }
            if (string.IsNullOrEmpty(model.groupId))
            {
                _log.LogInformation("batch_job_cam_access_error:Group Id is null");
                throw new ValidationModelException(500, "Group Id is null");
            }
            var Operation = model.Operations.FirstOrDefault();
            if (string.IsNullOrEmpty(Operation!.Op))
            {
                _log.LogInformation("batch_job_cam_access_error:Op is null");
                throw new ValidationModelException(500, "Op is null");
            }
            if (string.IsNullOrEmpty(Operation!.Path))
            {
                _log.LogInformation("batch_job_cam_access_error: Path is null");
                throw new ValidationModelException(500, "Path is null");
            }
            if (string.IsNullOrEmpty(Operation!.Value.ToString()))
            {
                _log.LogInformation("batch_job_cam_access_error: Value is null");
                throw new ValidationModelException(500, "Value is null");
            }
            var existGroup = await GetGroupInfo(new GroupInfoModel { groupId = model.groupId });
            if (existGroup == null)
            {
                _log.LogInformation("batch_job_cam_access_error: Group was not found");
                throw new ValidationModelException(404, "Group was not found");
            }
            var user = await _usersService.GetUserInfo(new UserInfoModel { userId = Operation.Value.ToString() });
            if (user == null)
            {
                _log.LogInformation("batch_job_cam_access_error: Team member validate failed.");
                throw new ValidationModelException(404, "Team member was not found");
            }
            int status = 0;
            if (Operation.Op == "Add")
            {
                if (!user.Active)
                {
                    _log.LogInformation("batch_job_cam_access_error: Add Failed,User was not Actived or Deleted");
                    throw new ValidationModelException(500, "Add Failed,User was not Actived or Deleted");
                }
                status = 0;
            }
            else if (Operation.Op == "Remove")
            {
                status = 1;
            }
            else
            {
                throw new ValidationModelException(500, "Incorrect parameter op");
            }
            string result = "";
            try
            {
                var response = await _client.ExecuteAsync<APMRequest, APMResponse>(new APMRequest()
                {
                    Method = HttpMethod.Post,
                    RequestPath = $"groupmembershipoperate?groupId={model.groupId}&operate={status}&userName={Operation.Value}"
                });
                result = await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                _log.LogError("batch_job_cam_access_error:" + ex);
                throw new ValidationModelException(500, "Internal Server Error");
            }
            int resultEnum = Convert.ToInt32(result.ToString());
            if ((ResultStatus)resultEnum == ResultStatus.UserExist)
            {
                _log.LogInformation("batch_job_cam_access_error: Add Failed,User already exists in the current group");
                throw new ValidationModelException(500, "Add Failed,User already exists in the current group");

            }
            else if ((ResultStatus)resultEnum == ResultStatus.UserNotExist)
            {
                _log.LogInformation("batch_job_cam_access_error: Remove Failed,User does not exist in the current group");
                throw new ValidationModelException(500, "Remove Failed,User does not exist in the current group");
            }
            _log.LogInformation("end UpdateGroupInfo");
        }

        public async Task RemoveGroupInfo(GroupInfoModel model)
        {
            _log.LogInformation("start RemoveGroupById");
            if (!string.IsNullOrWhiteSpace(model.groupId) && !Guid.TryParse(model.groupId, out _))
            {
                _log.LogInformation("batch_job_cam_access_error: Group Id does not conform to the guid format.");
                throw new ValidationModelException(401, "Group Id does not conform to the guid format.");
            }
            if (string.IsNullOrEmpty(model.groupId))
            {
                throw new ValidationModelException(500, "Group Id is null");
            }
            var existGroup = await GetGroupInfo(new GroupInfoModel { groupId = model.groupId });
            if (existGroup == null)
            {
                _log.LogInformation("batch_job_cam_access_error: Group was not found");
                throw new ValidationModelException(404, "Group was not found");
            }
            try
            {
                var response = await _client.ExecuteAsync<APMRequest, APMResponse>(new APMRequest()
                {
                    Method = HttpMethod.Post,
                    RequestPath = $"groupremoval?groupId={model.groupId}",
                    InputParameters = model.groupId
                });
                var result = response.Content.ReadAsStringAsync().Result;
                _log.LogInformation("end RemoveGroupById");
            }
            catch (Exception ex)
            {
                _log.LogError("batch_job_cam_access_error:" + ex);
                throw new ValidationModelException(500, "Internal Server Error");
            }
        }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.CAMService.Models.CamRequestModels;
using BatchJob.CAMService.Models.CamResponseModels;
using BatchJob.CAMService.Services.Interfaces;
using BatchJob.CAMService.Utils;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Microsoft.Extensions.Options;
using APM.SDK;
using BatchJob.CAMService.Models;
using Exception = System.Exception;
using APM.SDK.Messages;
using Newtonsoft.Json;
using System.Net.Http;
using System.Linq;
using BatchJob.CAMService.Models.ApmRequestModels;
using BatchJob.CAMService.Models.ApmResponseModels;
using APM.SDK.DataContract.CaseDocument;
using Microsoft.AspNetCore.Builder.Extensions;
using Newtonsoft.Json.Linq;
using APM.SDK.Services;

namespace BatchJob.CAMService.Services
{
    public class CamUserService : ICamUserService
    {
        public CamUserService(
            ILogger<CamUserService> logger,
            IOptions<CamAuthentication> options,           
            IOptions<CamAPMOption> apmOptions
        )
        {
            _log = logger;
            _apmOptions = apmOptions.Value;
            _identityOption = options.Value;
                        
            _client = new APMClient2(new APMSettings()
            {
                ServiceEndpoint = _apmOptions.Endpoint.TrimEnd('/') + "/api/v1/CamsApi/",
                AuthEndpoint = _identityOption.APMAuthority,
                ClientId = _identityOption.ClientId,
                Secret = _identityOption.ClientSecret
            });
        }
        private readonly APMClient2 _client;
        private readonly ILogger _log;
        private readonly CamAuthentication _identityOption;
        private readonly CamAPMOption _apmOptions;

        public async Task<UserInfo> GetUserInfo(UserInfoModel model)
        {
            _log.LogInformation(CamsLogInformation.SetInformation("start GetUserById"));
            if (string.IsNullOrEmpty(model.userId))
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: User Id validate failed"));
                throw new ValidationModelException(500, "User Id is null");
            }
            var response = new APMResponse();
            try
            {
                response = await _client.ExecuteAsync<APMRequest, APMResponse>(new APMRequest()
                {
                    Method = HttpMethod.Get,
                    RequestPath = $"UserAccountRetrieval?userId={model.userId}"
                });
            }
            catch (Exception ex)
            {
                _log.LogError(CamsLogInformation.SetInformation("batch_job_cam_access_error:" + ex));
                throw new ValidationModelException(500, "Internal Server Error");
            }
            var result = await response.Content.ReadAsStringAsync();
            if (string.IsNullOrEmpty(result))
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: user validate failed"));
                throw new ValidationModelException(404, "User was not found");
            }
            var user = new UserInfo();
            try
            {
                user = CamConverter.ConvertToUserInfo(JsonConvert.DeserializeObject<UserViewModel>(result));
            }catch (Exception ex)
            {
                _log.LogError(CamsLogInformation.SetInformation("batch_job_cam_access_error:" + ex));
                throw new ValidationModelException(500, "Internal Server Error");
            }
            _log.LogInformation(CamsLogInformation.SetInformation("end GetUserById"));
            return user;

        }

        public async Task<UserInfoList> FindUsersByCriteria(FindUserInfoModel model)
        {
            _log.LogInformation(CamsLogInformation.SetInformation("start FindUsersByCriteria"));
            if (model.startIndex == null || model.startIndex < 0)
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: startIndex is a positive integer greater than 0 is required"));
                throw new ValidationModelException(500, "startIndex is a positive integer greater than 0 is required");
            }
            if (model.itemsPerPage == null || model.itemsPerPage < 0)
            {
                _log.LogInformation(CamsLogInformation.SetInformation("batch_job_cam_access_error: itemsPerPage is a positive integer greater than 0 is required"));
                throw new ValidationModelException(500, "itemsPerPage is a positive integer greater than 0 is required");
            }
            try
            {
                UserInfoList userInfoList = new UserInfoList() { Resources = new List<UserInfo>() };
                RetrievalParam pageInfoModel = new RetrievalParam()
                {
                    FilterConfig = model.filter,
                    StartIndex = model.startIndex,
                    PageSize = model.itemsPerPage,
                    AscOrderBy = CamConverter.ColumnMapping(model.ascOrderBy),
                    DescOrderBy = CamConverter.ColumnMapping(model.descOrderBy),
                };
                var response = await _client.ExecuteAsync<APMRequest, APMResponse>(new APMRequest()
                {
                    Method = HttpMethod.Post,
                    RequestPath = $"userlistretrieval",
                    InputParameters = pageInfoModel
                });
                //?FilterConfig={JsonConvert.SerializeObject(pageInfoModel.FilterConfig)}&CurrentPage={pageInfoModel.CurrentPage}&PageSize={pageInfoModel.PageSize}&AscOrderBy={pageInfoModel.AscOrderBy}&DescOrderBy={pageInfoModel.DescOrderBy}
                var result = await response.Content.ReadAsStringAsync();
                var usersResult = JsonConvert.DeserializeObject<QueryUserResult>(result);
                if (usersResult.Resources != null && usersResult.Resources.Any())
                {
                    foreach (var user in usersResult.Resources)
                    {
                        userInfoList.Resources.Add(CamConverter.ConvertToUserInfo(user));
                    }
                }
                userInfoList.TotalResults = usersResult.TotalItemsCount;
                _log.LogInformation(CamsLogInformation.SetInformation($"userInfoList TotalResults:{userInfoList.TotalResults}"));
                userInfoList.StartIndex = usersResult.StartIndex;
                userInfoList.ItemsPerPage = usersResult.ItemsPerPage;
                _log.LogInformation(CamsLogInformation.SetInformation("end FindUsersByCriteria"));
                return userInfoList;
            }
            catch (Exception ex)
            {
                _log.LogError(CamsLogInformation.SetInformation("batch_job_cam_access_error:" + ex));
                throw new ValidationModelException(500, "Internal Server Error");
            }
        }

        public async Task<UserInfo> UpdateUserInfo(UpdateUserInfoModel model)
        {

            _log.LogInformation("start UpdateUserInfo");
            if (model == null || !model.Operations.Any())
            {
                _log.LogInformation("batch_job_cam_access_error:Info or operations is null");
                throw new ValidationModelException(500, "Info or operations is null");
            }
            var Operation = model.Operations.First();
            if (string.IsNullOrEmpty(Operation.Op))
            {
                _log.LogInformation("batch_job_cam_access_error: Op is null");
                throw new ValidationModelException(500, "Op is null");
            }
            if (string.IsNullOrEmpty(Operation.Path))
            {
                _log.LogInformation("batch_job_cam_access_error: Path is null");
                throw new ValidationModelException(500, "Path is null");
            }
            if (string.IsNullOrEmpty(model.userId))
            {
                _log.LogInformation("batch_job_cam_access_error: User Id is null");
                throw new ValidationModelException(500, "User Id is null");
            }
            if (Operation.Value == null || string.IsNullOrEmpty(Operation.Value.ToString()))
            {
                _log.LogInformation("batch_job_cam_access_error: Value Id is null");
                throw new ValidationModelException(500, "Value is null");
            }
            var userExist = await GetUserInfo(new UserInfoModel { userId = model.userId });
            if (userExist == null)
            {
                _log.LogInformation("batch_job_cam_access_error: User validate failed");
                throw new ValidationModelException(404, "User was not found");
            }
            string val = Operation.Value.ToString();
            int status = 0;
            try
            {
                if (Convert.ToBoolean(Operation.Value))
                {
                    status = 0;
                }
                else
                {
                    status = 1;
                }
            }
            catch (Exception ex)
            {
                _log.LogError("batch_job_cam_access_error:" + ex);
                throw new ValidationModelException(500, "Value must be true or false");
            }
           
            var userResponse = new APMResponse();
            try
            {
                userResponse = await _client.ExecuteAsync<APMRequest, APMResponse>(new APMRequest()
                {
                    Method = HttpMethod.Post,
                    RequestPath = $"setuseraccountstatus?userId={model.userId}&status={status}",
                    InputParameters = model.userId
                });

            }
            catch (Exception ex)
            {
                _log.LogError("batch_job_cam_access_error:" + ex);
                throw new ValidationModelException(500, "Internal Server Error");
            }

            var result = await userResponse.Content.ReadAsStringAsync();
            _log.LogInformation("end UpdateUserInfo");
            if (string.IsNullOrEmpty(result))
            {
                _log.LogInformation("batch_job_cam_access_error: user validate failed");
                throw new ValidationModelException(404, "User was not found");
            }
            var user = new UserInfo();
            try
            {
                user = CamConverter.ConvertToUserInfo(JsonConvert.DeserializeObject<UserViewModel>(result));
            }
            catch (Exception ex)
            {
                _log.LogError("batch_job_cam_access_error:" + ex);
                throw new ValidationModelException(500, "Internal Server Error");
            }
            return user;
        }


        public async Task RemoveUserInfo(UserInfoModel model)
        {
            _log.LogInformation("start RemoveUserById");
            if (string.IsNullOrEmpty(model.userId))
            {
                throw new ValidationModelException(500, "User Id is null");
            }
            var userExist = await GetUserInfo(model);
            if (userExist == null)
            {
                _log.LogInformation("batch_job_cam_access_error: User validate failed");
                throw new ValidationModelException(404, "User was not found");
            }
            try
            {
                var response = await _client.ExecuteAsync<APMRequest, APMResponse>(new APMRequest()
                {
                    Method = HttpMethod.Post,
                    RequestPath = $"useraccountremoval?userId={model.userId}",
                    InputParameters = model.userId
                });
                var result = response.Content.ReadAsStringAsync().Result;
                _log.LogInformation("end RemoveUserById");
            }
            catch (Exception ex)
            {
                _log.LogError("batch_job_cam_access_error:" + ex);
                throw new ValidationModelException(500, "Internal Server Error");
            }
        }
    }
}
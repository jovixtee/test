﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.CAMService.Models.CamResponseModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Text.RegularExpressions;

namespace BatchJob.CAMService.Filter
{
    public class GlobalExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            if (!context.ExceptionHandled)
            {
                var validationModelException = context.Exception as ValidationModelException;
                ErrorResult result = new ErrorResult()
                {
                    schemas = new string[] { "urn:ietf:params:scim:api:messages:2.0:Error" }
                };
                if (validationModelException == null)
                {
                    result.status = "500";
                    result.detail = "Internal Server Error";
                }
                else
                {
                    result.status = validationModelException.ErrorCode == 404 ? $"{validationModelException.ErrorCode}" : validationModelException.ErrorCode + "";
                    result.detail = validationModelException.Message;
                }
                //LoggerHelper._.Error($"batch_job_cam_access_error:{result.detail}");
                context.Result = new JsonResult(result);
                string status = Regex.Replace(result.status, @"[^0-9]+", "",RegexOptions.None, TimeSpan.FromMilliseconds(100));
                context.HttpContext.Response.StatusCode = int.Parse(status);
                context.ExceptionHandled = true;
            }
        }
    }
}

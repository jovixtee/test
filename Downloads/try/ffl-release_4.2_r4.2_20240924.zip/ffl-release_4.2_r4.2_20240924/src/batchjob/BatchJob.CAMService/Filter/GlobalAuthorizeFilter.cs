﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.CAMService.Models;
using BatchJob.CAMService.Models.CamResponseModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace BatchJob.CAMService.Filter
{
    public class GlobalAuthorizeFilter : IAuthorizationFilter
    {
        private CamOptions Configuration { get; set; }
        private readonly ILogger<GlobalAuthorizeFilter> Logger;

        public GlobalAuthorizeFilter(ILogger<GlobalAuthorizeFilter> logger, IOptions<CamOptions> configuration)
        {
            this.Logger = logger;
            Configuration = configuration.Value;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var verifyNonce = CheckNonce(context);
            if (verifyNonce != null)
            {
                OverwriteReponse(context, verifyNonce);
                return;
            }
            var verifyTimeStamp = CheckTimeStamp(context);
            if (verifyTimeStamp != null)
            {
                OverwriteReponse(context, verifyTimeStamp);
                return;
            }
            var verifyAccount = CheckAccountAndAuthorizationHeader(context);
            if (verifyAccount != null)
            {
                OverwriteReponse(context, verifyAccount);
            }
        }

        private static void OverwriteReponse(AuthorizationFilterContext context, ErrorResult result)
        {
            context.Result = new JsonResult(result);
            context.HttpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
        }

        private ErrorResult CheckAccountAndAuthorizationHeader(AuthorizationFilterContext context)
        {
            Func<string, byte[]> _ = (s) => { return Encoding.UTF8.GetBytes(s); };
            Func<string, ErrorResult> SetUnauthorizedCode = (content) =>
            {
                //LoggerHelper._.Error("batch_job_cam_validation_error:" + content);
                return new ErrorResult()
                {
                    status = "401",
                    schemas = new string[] { "urn:ietf:params:scim:api:messages:2.0:Error" },
                    detail = content
                };
            };
            string acctID = Configuration.AccountID;
            string secretWord = Configuration.VerificationCode;
            string acctIDq = context.HttpContext.Request.Query["accountid"].ToString();
            if (string.IsNullOrEmpty(acctIDq) || acctIDq != acctID)
            {
                return SetUnauthorizedCode("Unauthorised Request: Invalid account");
            }
            string combinedString = "";
            if (string.IsNullOrEmpty(Configuration.RequestUrl))
            {
                string httpMethod = context.HttpContext.Request.Method.ToUpper();
                string protocol = context.HttpContext.Request.IsHttps ? "https" : "http";
                string hostName = context.HttpContext.Request.Host.Value.ToLower();
                string url = context.HttpContext.Request.Path.ToString();
                string queryStringSorted = context.HttpContext.Request.Query.OrderBy(x => x.Key).Select(x => $"{x.Key}={x.Value}").Aggregate((x, y) => $"{x}&{y}").ToLower();
                combinedString = $"{protocol}://{hostName}{url}?{queryStringSorted}";
                combinedString = $"{httpMethod}&{combinedString.ToLower()}";
            }
            else
            {
                Uri uri = null;
                try
                {
                    string path = context.HttpContext.Request.Path.ToString();
                    var lastTwoWords = path.Split(@"/").Reverse().Take(2).Reverse();
                    path = string.Join(@"/", lastTwoWords);
                    string requestUrl = $"{Configuration.RequestUrl.TrimEnd('/')}/{path}";
                    uri = new Uri(requestUrl);
                }
                catch (Exception e)
                {
                    //LoggerHelper._.Error($"batch_job_cam_validation_error:{e.Message}");
                    return SetUnauthorizedCode("Unauthorised Request: Invalid authorisation header");
                }
                string httpMethod = context.HttpContext.Request.Method.ToUpper();
                string protocol = uri.Scheme;
                string hostName = uri.Authority.ToLower();
                string url = uri.LocalPath;
                string queryStringSorted = context.HttpContext.Request.Query.OrderBy(x => x.Key).Select(x => $"{x.Key}={x.Value}").Aggregate((x, y) => $"{x}&{y}").ToLower();
                combinedString = $"{protocol}://{hostName}{url}?{queryStringSorted}";
                combinedString = $"{httpMethod}&{combinedString.ToLower()}";
            }
            string authString = Convert.ToBase64String(new HMACSHA256(_(secretWord)).ComputeHash(_(combinedString)));
            var authHeader = GetAuthorizationHeader(context);
            if (authHeader != authString)
            {
                return SetUnauthorizedCode("Unauthorised Request: Invalid authorisation header");
            }
            return null;
        }

        private static string GetAuthorizationHeader(AuthorizationFilterContext context)
        {
            var token = context.HttpContext.Request.Headers["Authorization"].ToString();
            return token.Replace("Bearer ", "");
        }

        private static ErrorResult CheckNonce(AuthorizationFilterContext context)
        {
            string nonce = context.HttpContext.Request.Query["nonce"].ToString();
            if (string.IsNullOrEmpty(nonce))
            {
                //LoggerHelper._.Error("batch_job_cam_validation_error:Invalid nonce");
                return new ErrorResult()
                {
                    status = "401",
                    schemas = new string[] { "urn:ietf:params:scim:api:messages:2.0:Error" },
                    detail = "Unauthorised Request: Invalid nonce"
                };
            }
            try
            {
                _ = UInt32.Parse(nonce);
            }
            catch (Exception e)
            {
                //LoggerHelper._.Error($"CheckNonce:{e.Message}");
                //LoggerHelper._.Error($"batch_job_cam_validation_error:Invalid nonce");
                return new ErrorResult()
                {
                    status = "401",
                    schemas = new string[] { "urn:ietf:params:scim:api:messages:2.0:Error" },
                    detail = "Unauthorised Request: Invalid nonce"
                };
            }
            return null;
        }

        private ErrorResult CheckTimeStamp(AuthorizationFilterContext context)
        {
            string reqdtq = context.HttpContext.Request.Query["ts"].ToString();
            string gracePeriod = Configuration.RequestExpiry + "";
            if (!string.IsNullOrEmpty(reqdtq))
            {
                try
                {
                    long gracePeriodl = long.Parse(gracePeriod);
                    long lreqDt = long.Parse(reqdtq);
                    DateTime reqDateTime = new DateTime(1970, 1, 1).AddMilliseconds(lreqDt);
                    var totalSeconds = DateTime.UtcNow.Subtract(reqDateTime).TotalSeconds;
                    //LoggerHelper._.Error($"diff totalSeconds:{totalSeconds}");
                    if (totalSeconds <= gracePeriodl)
                    {
                        return null;
                    }
                }
                catch (System.Exception ex) when (ex is FormatException)
                {
                    Logger.LogError("CheckTimeStamp Exception:{ex.ToString()}", ex.ToString());
                }
            }
            //LoggerHelper._.Error("batch_job_cam_validation_error:Invalid time stamp");
            return new ErrorResult()
            {
                status = "401",
                schemas = new string[] { "urn:ietf:params:scim:api:messages:2.0:Error" },
                detail = "Unauthorised Request: Invalid time stamp"
            };
        }
    }
}

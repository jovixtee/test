﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using APM.SDK;
using APM.SDK.Services;
using CleanUp.JobHandler;
using ConnectionAdapterService.Interface;
using DataPipeline.JobHandler;
using Framework.ContainerRuntime;
using Framework.ContainerRuntime.Authentication;
using Framework.ContainerRuntime.SecretManagers;
using Framework.MarsDatabase;
using HolidaySetting.Interface;
using JobExecutor.Domain;
using JobExecutor.Interface.Logger;
using JobManager.Domain;
using JobManager.Interface;
using MarsRpc.Http.Client;
using MarsRpc.Http.Client.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using NotificationService.Interface;
using Replicator.Interface;
using System;
using System.IO;
using System.Net.Sockets;
using System.Threading.Tasks;
using TaskManager.Interface;
using Transfer.Interface;
using Transfer.JobHandler;

namespace BatchJob.JobExe
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            //EnsureJobPruningHandler();
            services.Configure<SecretManager>(Configuration.GetSection("SecretManager"));
            services.AddLogging(loggingBuilder =>
            {
                // configure Logging with NLog
                loggingBuilder.ClearProviders();
                loggingBuilder.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Information);
                loggingBuilder.AddNLog("nlog.config");
            });

            services.AddSingleton(Configuration);
            services.AddSingleton(typeof(IJobLoggerFactoryCreator), typeof(JobLoggerFactoryCreator));

            #region RPC

            services.AddMarsRpcHttpClient();
            services.AddEntityFrameworkSqlServer();

            services.AddMarsDatabaseFrameworks(Configuration.GetSection("DBSettings"));
            services.AddMarsRuntime(Configuration.GetSection("Runtime"));

            #endregion RPC

            //overwrite endpoint provider
            services.AddSingleton<IRpcHttpCookieProvider, JobExecutorRpcHttpCookieProvider>();

            services.AddImportedService<IJobManagerService>();
            services.AddImportedService<ITaskManagerService>();
            services.AddImportedService<ITransferService>();
            services.AddImportedService<IConnectionAdapterService>();
            services.AddImportedService<IHolidaySettingService>();
            services.AddImportedService<INotificationService>();
            services.AddImportedService<IReplicatorsService>();

            #region Rebus Configuration

            services.AddJobExecutorFactory(Configuration);
            services.AddTransient(typeof(TransferJobHandler));
            services.AddTransient(typeof(CleanUpJobHandler));
            services.AddTransient(typeof(DataPipelineJobHandler));
            services.AddJobExecutorMarsEventRebus<JobExecutorEventHandler>(Configuration.GetSection("ServiceBusSetting"));

            services.AddAuthentication(option =>
            {
                option.DefaultAuthenticateScheme = AuthenticationDefaults.CookieAuthenticationScheme;
                option.DefaultScheme = AuthenticationDefaults.CookieAuthenticationScheme;
            });

            services.AddCors(build => build.AddPolicy(RuntimeConstants.CORS_POLICY_NAME, builder =>
            {
                var origins = this.Configuration.GetSection("Cors:AllowedOrigins").Value.Split(';');
                builder.WithOrigins(origins)
                .AllowAnyHeader()
                .AllowAnyMethod()
                .AllowCredentials();
            }));
            services.Configure<KestrelServerOptions>(x => x.AllowSynchronousIO = true);

            #endregion Rebus Configuration

            services.AddAPMSDK();
            services.AddAPMClientFunc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory factory)
        {
            string basePath = Configuration.GetValue("JobExeBasePath", "");
            app.UseMarsRuntime("mars.jobexe");
            app.RegisterJobLogFactory(factory);
            app.StartMarsEventRebus();
            var healthz = string.IsNullOrEmpty(basePath) ? "/healthz" : $"/{basePath}/healthz";
            app.Map(healthz, appconfig =>
            {
                appconfig.Run(async context =>
                {
                    await context.Response.WriteAsync($"Ok. Package Version: {Configuration.GetValue("PackageImage_Version", "None")}");
                });
            });
            var jobServerHealthz = string.IsNullOrEmpty(basePath) ? "/jobserverhealthz" : $"/{basePath}/jobserverhealthz";
            app.Map(jobServerHealthz, appconfig =>
            {
                appconfig.Run(async context =>
                {
                    var jobServer = Configuration.GetValue("Runtime:GatewayEndpoint", "");
                    if (string.IsNullOrEmpty(jobServer))
                    {
                        await context.Response.WriteAsync($"Job server is null. Package Version: {Configuration.GetValue("PackageImage_Version", "None")}");
                    }
                    else
                    {
                        bool serverOnline = await ServerOnline(jobServer);
                        string status = serverOnline ? "online" : "offline";
                        await context.Response.WriteAsync($"Job server {jobServer} is {status}. Package Version: {Configuration.GetValue("PackageImage_Version", "None")}");
                    }
                });
            });
            //app.Map("/availablespace", appconfig =>
            //{
            //    appconfig.Run(async context =>
            //    {
            //        string driveInfoString = default;
            //        DriveInfo[] driveInfos = DriveInfo.GetDrives();
            //        if (driveInfos != null)
            //        {
            //            StringBuilder builder = new StringBuilder();
            //            foreach (var item in driveInfos)
            //            {
            //                if (item.DriveType == DriveType.Fixed)
            //                {
            //                    string infoString = $"Name: {item.Name}, DriveType: {item.DriveType}, DriveFormat: {item.DriveFormat} RootDirectory: {item.RootDirectory?.FullName}, AvailableFreeSpace: {item.AvailableFreeSpace}, TotalFreeSpace: {item.TotalFreeSpace}, TotalSize: {item.TotalSize}";
            //                    builder.Append(infoString);
            //                }
            //            }
            //            driveInfoString = builder.ToString();
            //        }
            //        await context.Response.WriteAsync($"Drive infos: {driveInfoString}");
            //    });
            //});

            Aspose.Email.License license = new Aspose.Email.License();
            license.SetLicense("Aspose.Total.NET.lic");
        }

        private async Task<bool> ServerOnline(string serverUrl)
        {
            bool serviceOnline;
            using (TcpClient tcpClient = new TcpClient())
            {
                try
                {
                    Uri uri = new(serverUrl);
                    await tcpClient.ConnectAsync(uri.Host, uri.Port);
                    serviceOnline = true;     // Service is online. No exception thrown.
                }
                catch (Exception ex)
                {
                    serviceOnline = false;    // Exception was thrown. Service is offline
                    Console.WriteLine($"Failed to connect to job server: {ex}");
                }
            }
            return serviceOnline;
        }

        private void EnsureJobPruningHandler()
        {
            try
            {
                string fileName = "CleanUpJobHandler.dll";
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);
                if (File.Exists(filePath))
                {
                    string[] directories = Configuration.GetSection("JobHandlerDirectories").Get<string[]>();
                    foreach (var dir in directories)
                    {
                        string handlerFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, dir);
                        if (Directory.Exists(handlerFolder))
                        {
                            try
                            {
                                File.Copy(filePath, Path.Combine(handlerFolder, fileName));
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Failed to copy CleanUpJobHandler to handler folder: {ex}");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to execute EnsureJobPruningHandler: {ex}");
            }
        }
    }

}
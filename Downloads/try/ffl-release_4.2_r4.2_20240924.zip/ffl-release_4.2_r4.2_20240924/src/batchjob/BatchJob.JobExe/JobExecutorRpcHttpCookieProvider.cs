﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using AccountManagerService.Interface.EnumObject;
using Authentication.Interface;
using Framework.CommonUtility.Identity;
using Framework.ContainerRuntime.Authentication;
using Framework.MarsDatabase.Model.Tenancy;
using MarsRpc.Http.Client.Services;
using Microsoft.AspNetCore.Authentication;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace BatchJob.JobExe
{
    public class JobExecutorRpcHttpCookieProvider : IRpcHttpCookieProvider
    {
        public JobExecutorRpcHttpCookieProvider(ITenancyIdentityProvider identityProvider)
        {
        }

        public Dictionary<string, string> GetCookie()
        {
            var dic = new Dictionary<string, string>();
            var (tokenKey, tokenValue) = GetAccessToken();
            dic.Add(tokenKey, tokenValue);

            return dic;
        }

        public (string, string) GetAccessToken()
        {
            TenantUser tenantUser = new TenantUser { Username = "System", UserRole = (int)UserRoleEnum.Owner, DisplayName = "System" };

            var identity = new ClaimsPrincipal(new ClaimsIdentity(GetClaim(tenantUser, new Dictionary<int, int>()), AuthenticationDefaults.CookieAuthenticationScheme, "Name", "Role"));
            var ticket = new AuthenticationTicket(identity, new AuthenticationProperties(), AuthenticationConstants.AuthenticationScheme);
            var tokenStr = new MarsJwtDataFormat().Protect(ticket);
            return (AuthenticationConstants.TokenKey, tokenStr);
        }

        private Claim[] GetClaim(TenantUser user, Dictionary<int, int> privileges)
        {
            return new Claim[]
            {
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Iat, new DateTimeOffset(DateTime.Now).ToUniversalTime().ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64),
                new Claim(AuthenticationConstants.ClaimKey_Name, user.DisplayName),
                new Claim("Role", user.UserRole.ToString()),
                new Claim("Privileges", JsonConvert.SerializeObject(privileges)),
                new Claim(AuthenticationConstants.ClaimKey_TenantId, Guid.Empty.ToString()),
            };
        }
    }
}
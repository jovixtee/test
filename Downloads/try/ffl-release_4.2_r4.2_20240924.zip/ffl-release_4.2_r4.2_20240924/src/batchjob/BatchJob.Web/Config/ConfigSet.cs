﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Text;

namespace BatchJob.Web.Config
{
    public interface IConfigSet
    {
        void setEnvConfig();

        void ReplaceIndex();

        void ReplaceAssetManifest();
    }

    public class ConfigSet : IConfigSet
    {
        private readonly EnvConfig EnvConfig;
        private readonly IConfiguration Configuration;

        public ConfigSet(IOptions<EnvConfig> envConfig, IConfiguration configuration)
        {
            EnvConfig = envConfig.Value;
            Configuration = configuration;
        }

        public void ReplaceAssetManifest()
        {
            var baseAddress = AppDomain.CurrentDomain.BaseDirectory;
            var path = Path.Combine(baseAddress, "Spa");
            var filePath = Path.Combine(path, "asset-manifest.json");
            if (!File.Exists(filePath))
            {
                return;
            }
            var url = Configuration.GetValue<string>("ApiRootPath");
            var content = File.ReadAllText(filePath);
            content = content.Replace("/_BatchJob_Replace_Text_", url);
            File.WriteAllText(filePath, content);
        }

        public void ReplaceIndex()
        {
            var baseAddress = AppDomain.CurrentDomain.BaseDirectory;
            var path = Path.Combine(baseAddress, "Spa");
            var filePath = Path.Combine(path, "index.html");
            if (!File.Exists(filePath))
            {
                return;
            }
            var url = Configuration.GetValue<string>("ApiRootPath");
            var content = File.ReadAllText(filePath);
            content = content.Replace("/_BatchJob_Replace_Text_", url);
            File.WriteAllText(filePath, content);
        }

        public void setEnvConfig()
        {
            if (EnvConfig == null || string.IsNullOrEmpty(EnvConfig.API_URL))
            {
                return;
            }
            var baseAddress = AppDomain.CurrentDomain.BaseDirectory;
            var path = Path.Combine(baseAddress, "Spa");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            var filePath = Path.Combine(path, "env-config.js");
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
            using (var fileStream = new FileStream(filePath, FileMode.CreateNew))
            {
                var content = JsonConvert.SerializeObject(EnvConfig);
                byte[] data = Encoding.ASCII.GetBytes($"window.ave = {content}");
                fileStream.Write(data, 0, data.Length);
            }
        }
    }
}
import { getItem, setItem } from "./localstorageutil";
import {StorageKeys} from "../common/contracts/WebConstants";
import { UserSummaryObject } from '../accountmanager/AccountManagerContract';


const hasPermission = function (objectCode: number, accessRight: number): boolean {
    let summary = getUserSummary();
    if (summary) {
        return summary.UserRole === 1 || summary.Privileges?.findIndex((p: { ObjectCode: number; AccessRight: number; }) => p.ObjectCode === objectCode && (p.AccessRight & accessRight) > 0) > -1;
    }

    return false;
};

const storeUserSummary = function (data: UserSummaryObject) {
    setItem(StorageKeys.userPrivileges, data);
}

const getUserSummary = function () {
    let summary = getItem(StorageKeys.userPrivileges)
    return summary;
}

const UserSummaryStorageKey = StorageKeys.userPrivileges;

export { storeUserSummary, getUserSummary, hasPermission,  UserSummaryStorageKey };
import React, { FC, useEffect, useState } from 'react';
import { Layout, Breadcrumb } from 'antd';
import { useLocation } from 'react-router-dom';
import HeaderBar from './HeaderBar';
import { ExclamationCircleOutlined, MailOutlined } from '@ant-design/icons';
import { menus, findItmes, MenuItemDto } from "./menu";
const { Header } = Layout;

interface IHeaderToolProps {
    onAboutClick: () => void;
}
const HeaderTool: FC<IHeaderToolProps> = (props) => {
    const [navigation, setNavigation] = useState({ icon: <MailOutlined />, items: new Array<MenuItemDto>() });
    const local = useLocation();
    useEffect(() => {
        const pathname = local.pathname;
        let items = findItmes(menus, pathname);
        if (items) {
            items = items.reverse();
            let nav = { items: items, icon: items[items.length - 1]?.icon };
            setNavigation(nav);
        }
    }, [local.pathname]);


    return (
        <>
            <Header className="site-layout-background" style={{ padding: 0, display: 'flex', alignItems: 'center', background: '#FFFFFF', justifyContent: 'space-between' }}>
                <div className="breadcrumb" style={{ display: 'flex', alignItems: 'center' }}>
                    {navigation.icon}
                    <Breadcrumb style={{ marginLeft: '8px' }}>
                        {navigation.items.map(i => {
                            return (
                                <Breadcrumb.Item key={i.key} >
                                    <span>{i.title}</span>
                                </Breadcrumb.Item>)
                        })}
                    </Breadcrumb>
                </div>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <ExclamationCircleOutlined style={{ fontSize: '20px', marginRight: '26px' }} onClick={props.onAboutClick}/>
                    <div className="user-cental">
                        <HeaderBar />
                    </div>
                </div>
            </Header>
        </>
    )

}
export default HeaderTool
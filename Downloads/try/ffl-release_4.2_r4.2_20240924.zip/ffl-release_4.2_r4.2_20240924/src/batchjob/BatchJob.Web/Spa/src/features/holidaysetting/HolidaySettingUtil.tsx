import { Holiday, ScheduleMonth } from './HolidaySettingContract';

const convertVM = (holiday: Holiday): HolidayVM => {
    let datestr = '';
    let dateType = '';
    switch (holiday.Type) {
        case 0:
            datestr = holiday.Dates!.map(m => `${m.Month}-${m.Day}-${m.Year}`).join(";");
            dateType = "Once";
            break;
        case 1:
            dateType = "Monthly";
            datestr = holiday.Holidays!.map(m => `From day ${m.CurrentStartDay} to day ${m.CurrentEndDay}`).join(";");
            break;
        case 2:
            dateType = "Yearly";
            const dateSuffix = (date: string) => date === '1' ? 'st' : date === '2' ? 'nd' : date === '3' ? 'rd' : 'th';
            datestr = holiday.Holidays!.map(m => `From ${ScheduleMonth[m.CurrentStartMonth as any]} ${m.CurrentStartDay}${dateSuffix(m.CurrentStartDay as any)}`
                + ` to ${ScheduleMonth[m.CurrentEndMonth as any]} ${m.CurrentEndDay}${dateSuffix(m.CurrentEndDay as any)}`).join(";");
            break;
    }

    return { TypeStr: dateType, DateStr: datestr, ...holiday };
}

const HolidaySettingUtil = {
    ConvertVM: convertVM
};

interface HolidayVM extends Holiday {
    TypeStr: string;
    DateStr: string;
}

export default HolidaySettingUtil;
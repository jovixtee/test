﻿import React, { useState } from 'react';
import { Drawer, Form, Button, Input, Select, Checkbox } from 'antd';
import apiservice from '../../utils/fetchutil';
import { HolidayProfileBase, Workday, } from './HolidaySettingContract'
import { FormInstance } from 'antd/lib/form';

const formData: HolidayProfileBase = {}
const { Option } = Select;
const weekDays = new Array<any>();

if (weekDays.length === 0) {
    for (let d in Workday) {
        if (parseInt(d)) {
            weekDays.push({ value: parseInt(d), label: Workday[d] });
        }
    }
}

class DrawerForm extends React.Component<any, any> {
    formRef = React.createRef<FormInstance>();
    constructor(props: any) {
        super(props);
        this.state = {
            visible: false,
            authenticationType: '',
            createModal: {
                title: "create profile",
                visible: false,
                weeks: ['1']
            },
            formData: formData
        }
    }

    onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };

    onClose = () => {
        this.closeNewEvent();
    };

    closeNewEvent = () => {
        this.props.closeDrawerEvent();
    };

    onWeeksChange = (checkedValue: any): void => {
        console.log(checkedValue);
    }

    onTimeZoneChange = (value: any, option: any) => void {
    };

    getTimeZoneInfo = () => {
        let typeList = [];
        for (var value in this.props.timeZone) {
            let item: any = value;
            if (!isNaN(item)) {
                typeList.push(<Select.Option value={this.props.timeZone[item].TimeZoneId} key={item}>
                    {this.props.timeZone[item].TimeZoneId}</Select.Option>);
            }
        }
        return typeList;
    };

    apiService = apiservice();
    onFinish = (viewModel: any) => {
        let workdayValue = 0;
        for (let index = 0; index < viewModel.workdays.length; index++) {
            workdayValue = parseInt(viewModel.workdays[index]) + workdayValue;
        }
        let model: HolidayProfileBase = {
            OrganizationName: viewModel.organizationName,
            Workdays: workdayValue,
            TimeZoneInfoId: viewModel.timeZone,
            ProfileId: this.props.id
        }
        this.saveFormData(model);
    }
    saveFormData = (model: HolidayProfileBase) => {
        if (this.props.formData.Profile) {
            this.apiService.post("/IHolidaySettingService/UpdateProfile", { profile: model }).then(
                (result: HolidayProfileBase) => {
                    console.log('Success', result);
                    this.onClose();
                }
            ).catch((e) => {
            })
        }
        else {
            this.apiService.post("/IHolidaySettingService/SaveProfile", { profile: model }).then(
                (result: HolidayProfileBase) => {
                    console.log('Success', result);
                    this.onClose();
                }
            ).catch((e) => {
                console.log(e);
            })
        }
    }
    onSubmitForm = () => {
        this.formRef.current?.submit();
    }

    render() {
        return (
            <>
                <Drawer
                    title="Create a new account"
                    width={720}
                    onClose={this.onClose}
                    visible={this.props.visible}
                    footer={
                        <div style={{ textAlign: 'right', }}>
                            <Button type="primary" onClick={this.onSubmitForm} >
                                Save
                            </Button>
                            <Button onClick={this.onClose} style={{ marginLeft: '10px' }}>
                                Cancel
                            </Button>
                        </div>
                    }
                >
                    <Form name="basic"
                        onFinish={this.onFinish}
                        ref={this.formRef}
                        layout="vertical"
                        onFinishFailed={this.onFinishFailed}
                        style={{ marginTop: '20px' }}
                        initialValues={{
                            "organizationName": this.props.formData?.Profile?.OrganizationName,
                            "timeZone": this.props.timeZone?.TimeZoneId
                        }}>
                        <Form.Item
                            name="organizationName" label="Profile Name" rules={[{ required: true, message: 'Enter a profile name.' }]}>
                            <Input defaultValue={this.props.formData.profileName} placeholder="Profile Name" />
                        </Form.Item>
                        <Form.Item
                            name="workdays" label="Workday" initialValue={[1, 2, 4, 8, 16, 32, 64]}>
                            <Checkbox.Group
                                options={weekDays}
                            ></Checkbox.Group>
                        </Form.Item>
                        <Form.Item
                            name="timeZone" label="Time Zone" rules={[{ required: true }]}>
                            <Select placeholder="Time Zone"
                                defaultValue={this.props.defaultTime.TimeZoneId}>
                                {this.getTimeZoneInfo()}
                            </Select>
                        </Form.Item>
                    </Form>
                </Drawer>
            </>
        );
    }
}

export default DrawerForm;


import React from 'react';
import { Route, Switch } from 'react-router-dom';
import TaskManagerMain from './TaskManagerMain';
import './taskmanager.css';
import PathConfig from '../../common/PathConfig';


const TaskLayout = () => {
    return (
        <div>
            <Switch>
                {/* <Route path='/taskmanager/create' component={TaskCreate} /> */}
                <Route path={PathConfig.addPrefix('/')} component={TaskManagerMain} />
            </Switch>
        </div>
    );
};
export default TaskLayout; 
import React, { FC, useEffect, useState } from 'react';
import { Drawer, Form, Input, Button, Select, Spin } from 'antd';
import { VoidCallBackFunction, ISelectOption } from './BackendAPIContracts';
import { GetVersionById, GetSelects, CreateVersion } from './BackendAPIApiService';
import { StatusMap, VersionDto, VersionStatusType } from '../../common/contracts/ModelContracts';

interface IVersionFom {
    VersionName?: string;
    APIControl?: string;
    Authentication?: string;
    Status?: VersionStatusType
}

interface IManageVersionDrawerProps {
    visibile: boolean;
    cancelClick: VoidCallBackFunction;
    isEdit: boolean;
    apiId: string;
    versionId: string;
    getTableData: VoidFunction;
}

const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 12 },
};
const { Option } = Select;
const ManageVersionDrawer: FC<IManageVersionDrawerProps> = (props) => {
    const [selectAPIControlData, setSelectAPIControlData] = useState<ISelectOption[]>([]);
    const [selectAuthenticationData, setSelectAuthenticationData] = useState<ISelectOption[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [buttonLoading, setButtonLoading] = useState<boolean>(false);
    const [versionId, setVersionId] = useState<string>("");

    const [form] = Form.useForm();
    useEffect(() => {
        (async () => {
            if (props.visibile && props.apiId) {
                setLoading(true);
                try {
                    if (props.versionId) {
                        await requestGetSelects();
                        await requestGetVersionById();
                    } else {
                        await requestGetSelects();
                    }
                } catch (e) {
                    setLoading(false);
                }
            }
            setLoading(false);
        })();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.visibile, props.versionId, props.apiId]);

    const requestGetVersionById = (): Promise<any> => {
        return new Promise((resolve, reject) => {
            GetVersionById(props.versionId)
                .then(res => {
                    console.log(res)
                    if (res) {
                        res.Id && setVersionId(res.Id);
                        form.setFieldsValue({
                            VersionName: res.Endpoint,
                            APIControl: res.ControlPolicyID,
                            Authentication: res.AuthenticationID,
                            Status: res.Status
                        });
                    }
                    resolve(true)
                })
                .catch(err => {
                    reject(err)
                })

        })

    }
    const requestGetSelects = (): Promise<any> => {
        return new Promise((resolve, reject) => {
            GetSelects(["Atuh", "ControlPolicy"])
                .then(res => {
                    setSelectAPIControlData(res.controlPolicy);
                    setSelectAuthenticationData(res.auth);
                    resolve(true);
                })
                .catch(err => {
                    reject(err)
                })
        })
    }

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };
    const onFinish = (values: IVersionFom) => {
        setLoading(true);
        setButtonLoading(true);
        let requestObject = new VersionDto();
        requestObject.ControlPolicyID = values.APIControl;
        requestObject.Endpoint = values.VersionName;
        requestObject.AuthenticationID = values.Authentication;
        requestObject.Status = values.Status;
        requestObject.BackendID = props.apiId;
        // props.cancelClick();
        if (props.isEdit) {
            requestObject.Id = versionId;
        }
        CreateVersion(requestObject)
            .then(res => {
                setLoading(false);
                setButtonLoading(false);
                closeDrawer();
                props.getTableData();
            })
            .catch(err => {
                setLoading(false);
                setButtonLoading(false);
            })
    }
    const closeDrawer = (): void => {
        form.resetFields();
        props.cancelClick()
    }


    return <Drawer
        visible={props.visibile}
        width={720}
        destroyOnClose
        forceRender
        onClose={closeDrawer}
        title={props.isEdit ? "Edit Version" : "Create a new Version"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" style={{ marginRight: 8 }} onClick={() => form.submit()} disabled={!buttonLoading && loading} loading={buttonLoading}>Save</Button>
                <Button onClick={closeDrawer} >Cancel</Button>
            </div>
        }
    >
        <Spin spinning={loading}>
            <Form {...layout} form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '20px' }}>
                <Form.Item label="Version Name" name="VersionName" rules={[{ required: true, message: 'Please input version name!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="APIControl" name="APIControl" rules={[{ required: false, message: 'Please input APIControl!' }]}>
                    <Select style={{ minWidth: 120 }}>
                        {
                            selectAPIControlData.map((optionItem) => <Option value={optionItem.key} key={optionItem.key}>{optionItem.value}</Option>)
                        }
                    </Select>
                </Form.Item>
                <Form.Item label="Authentication" name="Authentication" rules={[{ required: false, message: 'Please input authentication!' }]}>
                    <Select style={{ minWidth: 120 }}>
                        {
                            selectAuthenticationData.map((optionItem) => <Option value={optionItem.key} key={optionItem.key}>{optionItem.value}</Option>)
                        }
                    </Select>
                </Form.Item>
                <Form.Item label="Status" name="Status" initialValue={VersionStatusType.Active}>
                    <Select style={{ minWidth: 120 }}>
                        {
                            Array.from(StatusMap).map(([key, value]) => <Option value={value} key={value}>{key}</Option>)
                        }
                    </Select>
                </Form.Item>
            </Form>
        </Spin>

    </Drawer>




}
export default ManageVersionDrawer
import apiservice from '../../utils/fetchutil';
import { APIsMenuDto, MethodMenuDto, MethodContentDto, NodeItemDto, VersionComboBoxDto, APIDto,VersionSettingDto,VersionDataDto,OperationDto,ViewOperationDto,ImportVersionDto, FromType} from '../../common/contracts/ModelContracts';
const serve = apiservice();

export const GetAllApis = (name: string): Promise<APIsMenuDto[]> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetAllApis", { "name": name }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetOperations = (VersionID: string, Path: string): Promise<MethodMenuDto[]> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetOperations", { "VersionID": VersionID, "Path": Path }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const GetMethodContent = (MethodId: string): Promise<MethodContentDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetMethodContent", { "MethodId": MethodId }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetAllNode = (): Promise<NodeItemDto[]> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetAllNode").then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetVersionComboBoxData = (): Promise<VersionComboBoxDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetVersionComboBoxData").then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateApi = (detail: APIDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateApi", { "dto": detail }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetApiById = (id: string): Promise<APIDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetApiById", { "id": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateVersionSetting = (detail: VersionSettingDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateVersionSetting", { "dto": detail }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}


export const GetVersionSetting = (id: string): Promise<VersionDataDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetVersionSetting", { "versionId": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetRequestUrl = (versionId: string): Promise<string> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetRequestUrl", { "versionId": versionId }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const SaveOperation = (dto: OperationDto): Promise<string> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/SaveOperation", { "dto": dto }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetOperation = (id: string): Promise<ViewOperationDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetOperation", { "methodId": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}


export const DeleteVersion = (id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteVersion", { "id": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}


export const DeleteMethod = (id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteMethod", { "id": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CloneVerison = (id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CloneVerison", { "id": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}


export const CloneOperation = (id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CloneOperation", { "id": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const ImportOpenAPIByFile = (file: any): Promise<OperationDto[]> => {
    const fd = new FormData();
    fd.set('arg', JSON.stringify({ _streamLength: file.size, importArguments: { FileName: file.name } }));
    fd.set('file', file);
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/ImportOpenAPIByFile", fd).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const ImportOpenAPIByHttp = (address: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/ImportOpenAPIByHttp", {"address":address}).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const ImportSwagger = (dto: ImportVersionDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/ImportSwagger", {"dto":dto}).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetPolicyComboBoxData = (): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetPolicyComboBoxData").then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetItemComboBoxData = (fromType: FromType): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetItemComboBoxData", {"fromType":fromType}).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}







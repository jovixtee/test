import React, { useState } from 'react';
import {Modal, message } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import UserForm from './UserForm';
import UserEditForm from './UserEditForm';
import { UserPagedQuery, QueryUserDetail, DeleteUser, CreateAccount, UpdateUser,UpdateUsersStatus,CheckAdminUser, userPermissionCostants } from './UserApiServe';
import { ProfileReadDrawer } from './ProfileReadDrawer';

import { hasPermission } from '../../utils/permissionutil';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import AmpCommonTable, { IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { convertTicksToFormatDate } from '../../utils/dateconvert';

const { confirm } = Modal;
const User = () => {
    const [selectedRecords, setSelectedRecords] = useState<any>();
    const [refresh, setRefresh] = useState(1);

    const [visible, setVisible] = useState<boolean>(false);
    const [editVisible, setEditVisible] = useState<boolean>(false);
    const [EditFormData, setEditFormData] = useState<any>({});
    const [showReadonlyDrawer, setShowReadonlyDrawer] = useState(false);
    const [readonlyProfile, setReadonlyProfile] = useState<any>({});

    const columns = [
        {
            title: 'Display Name',
            dataIndex: 'DisplayName',
            key: 'DisplayName',
            sorter: true,
            ellipsis: true,
            width: '12%',
            render: (text: any, record: any) => <a type="link" onClick={() => viewProfile(record)}>{text}</a>
        }, {
            title: 'User Name',
            dataIndex: 'Username',
            key: 'Username',
            ellipsis: true,
            width: '13%',
        },
        {
            title: 'Status',
            dataIndex: 'Status',
            key: 'Status',
            ellipsis: true,
            width: '12%',
            render: (text: number) => {
                return <span>{text === 2 ? 'Deactive' : text === 1 ? 'Active' : text}</span>
            }
        }, {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
            width: '13%',
        }, {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            sorter: true,
            width: '13%',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
            width: '13%'
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            width: '25%',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }];

    let addSourceBtn = () => {
        setVisible(true);
    }

    let editSourceBtn = async () => {
        let result = await QueryUserDetail({ UserId: selectedRecords[0].UserId })
        setEditFormData({ ...result.Result });
        setEditVisible(true)
    }

    let deleteSourceBtn = () => {
        confirm({
            title: 'Warning',
            icon: <ExclamationCircleOutlined />,
            content: 'You are about to delete the selected items. Are you sure you want to proceed?',
            async onOk() {
                await DeleteUser({
                    UserId: selectedRecords[0].UserId
                }).then((result) => {
                    if (result.Type === 0) {
                        message.success('The user was deleted successfully!');
                        setRefresh(refresh + 1);
                    } else {
                        message.warning(result.Message);
                    }
                }).catch((error) => {
                    console.log(error);
                })
            },
            onCancel() {
                console.log('Cancel');
            },
        })
    }

    const activeBtn = async () => {
        // let params = {
        //     userDetail: {
        //         User: {
        //             UserId: selectedRecords[0].UserId,
        //             Status: 1
        //         }
        //     }
        // }
        var user = selectedRecords?.map((item: { UserId: any; }) => ({
            User:{
                UserId: item.UserId,
                Status: 1
            }
        }));
        let params = {users:user};
        let result = await UpdateUsersStatus(params)
        if (result.Type === 0) {
            message.success('The user is successfully activated!')
            setRefresh(refresh + 1);
        } else {
            message.warning(result.Message)
        }
    }
    const deaciveBtn = async () => {
        // let params = {
        //     userDetail: {
        //         User: {
        //             UserId: selectedRecords[0].UserId,
        //             Status: 2
        //         }
        //     }
        // }
        var user = selectedRecords?.map((item: { UserId: any; }) => ({
            User:{
                UserId: item.UserId,
                Status: 2
            }
        }));
        let params = {users:user};
        let checkAdminResult = await CheckAdminUser(params)
        if(checkAdminResult){
            message.success('The administrator user cannot be disabled.');
            return;
        }
        let result = await UpdateUsersStatus(params)
        if (result.Type === 0) {
            message.success('User deactivated successfully!')
            setRefresh(refresh + 1);
        } else {
            message.warning(result.Message)
        }
    }

    const buttons: Array<IAmpTableButton> = [{
        Text: "Create",
        Primary: true,
        Icon: <PlusOutlined />,
        OnClick: addSourceBtn,
        EnableMode: 'always',
        HasPermission: hasPermission(userPermissionCostants.ObjectCode, userPermissionCostants.Create)
    }, {
        Text: "Edit",
        Icon: <EditOutlined />,
        OnClick: editSourceBtn,
        EnableMode: 'single',
        HasPermission: hasPermission(userPermissionCostants.ObjectCode, userPermissionCostants.Update)
    }, {
        Text: "Delete",
        Icon: <DeleteOutlined />,
        OnClick: deleteSourceBtn,
        EnableMode: 'single',
        HasPermission: hasPermission(userPermissionCostants.ObjectCode, userPermissionCostants.Delete)
    }, {
        Text: "Activate",
        Icon: <DeleteOutlined />,
        OnClick: activeBtn,
        EnableMode: 'multiple',
        HasPermission: hasPermission(userPermissionCostants.ObjectCode, userPermissionCostants.Update)
    }, {
        Text: "Deactivate",
        Icon: <DeleteOutlined />,
        OnClick: deaciveBtn,
        EnableMode: 'multiple',
        HasPermission: hasPermission(userPermissionCostants.ObjectCode, userPermissionCostants.Update)
    }];

    const viewProfile = async (record: any) => {
        let result = await QueryUserDetail({ UserId: record.UserId })
        setReadonlyProfile(result.Result);
        console.log(result.Result);
        setShowReadonlyDrawer(true);
    }

    const getEditFormData = async (data: any) => {
        console.log(data)
        let Roles = []
        if (data.PermissionLevels) {
            Roles = data.PermissionLevels.map((value: string) => {
                return {
                    RoleId: value
                }
            })
        }
        let params = {
            userDetail: {
                User: {
                    UserId: data.User.UserId,
                    IdentityId: data.User.IdentityId,
                    Description: data.Description,
                    DisplayName: data.DisplayName,
                    Username: data.Username,
                    Password: data.confirm,
                    UserRole: data.UserRole,
                    Email: data.Email,
                },
                Roles: Roles
            }
        }
        let result = await UpdateUser(params)
        if (result.Type === 0) {
            message.success('Update User Succeed!')
            setEditVisible(false)
            setRefresh(refresh+1);
        } else {
            message.warning(result.Message)
        }
    }

    const onFinish = (data: any) => {
        getEditFormData(data)
        onCloseFun();
    }

    const onCloseFun = () => {
        setVisible(false);
        setEditVisible(false);
    }

    const getAddFormData = async (data: any) => {
        console.log(data)
        let Roles = []
        if (data.PermissionLevels) {
            Roles = data.PermissionLevels.map((value: string) => {
                return {
                    RoleId: value
                }
            })
        }
        let obj = {
            accountObject: {
                DisplayName: data.DisplayName,
                Username: data.Username,
                Password: data.Password,
                Description: data.Description,
                Roles: Roles,
                UserRole: data.UserRole,
                Email: data.Email,
                Authentication: Number(data.Authentication)
            }
        }
        let result = await CreateAccount(obj)
        if (result.Type === 0) {
            message.success('Create Account Succeed!')
            setVisible(false)
            setRefresh(refresh+1);
        } else {
            message.warning(result.Message)
        }
    }

    const ApiPagerQuery = async (exp: PagerExpression) => {
        let obj = {
            expression: { ...exp }
        }
        let result = await UserPagedQuery(obj);
        let data =  result!.Result!.Result.map((e:any)=>{
            let item = {...e};
            if(item.TenantId !== null && item.UserRole === 1){
                item.disabled = true;
            }else{
                item.disabled = false;
            }
            return item;
        })
        return { total: result!.Result!.TotalNumber, records: data };
    }

    return (
        <>
            <AmpCommonTable
                Type="checkbox"
                RowKey="UserId"
                Columns={columns}
                PagerQuery={ApiPagerQuery}
                OnSelectedChanged={records => setSelectedRecords(records)}
                SearchKeys={["Name"]}
                Refresh={refresh}
                Buttons={buttons}
                EnableSearch />
            {visible && <UserForm visible={visible} onCloseFun={onCloseFun} onGetFormData={getAddFormData}></UserForm>}
            {editVisible && <UserEditForm EditFormData={EditFormData} onCloseFun={onCloseFun} visible={editVisible} onGetData={onFinish} ></UserEditForm>}
            <ProfileReadDrawer visible={showReadonlyDrawer} profileDto={readonlyProfile} onClose={() => setShowReadonlyDrawer(false)} />
        </>
    );
};
export default User;
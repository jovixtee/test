import { Modal, Transfer, Cascader, Row, Col, Button, Tag, Spin } from 'antd';
import { TransferItem } from 'antd/lib/transfer';
import React, { FC, useEffect, useState } from 'react';
import useCascader from "./useCascader";
import { MethodTypeEnum } from './FrontendAPIContracts';
import { GetMethodByBackendIDFrontendIDVersionID, ImportMethod } from './FrontendAPIApiService';


interface IImportAPIModelProps {
    visible: boolean;
    getTableData: VoidFunction;
    onCancel: VoidFunction;
    apiId: string;
    versionId: string;
}



interface IMethodItem {
    key: string;
    value: string;
    MethodName?: string;
}


const ImportAPIModel: FC<IImportAPIModelProps> = (props) => {

    const [methodData, setMethodData] = useState<any>([]);
    const [wantImportKeys, setWantImportKeys] = useState<any>([]);
    // const [{ cascaderVaule, cascaderOptions, cascaderLoadData, cascaderOnChange }, setVersionId] = useCascader();
    const [{ cascaderVaule, cascaderOptions, cascaderLoadData, cascaderOnChange }] = useCascader();
    const [loading, setLoading] = useState<boolean>(false);
    const [buttonLoading, setButtonLoading] = useState<boolean>(false);
    useEffect(() => {



    }, [])


    const onTransferChange = (itemKeys: any): void => {

        setWantImportKeys(itemKeys);
    }
    const onSerachMethodClick = (): void => {

        if (cascaderVaule) {
            setLoading(true);
            GetMethodByBackendIDFrontendIDVersionID(props.apiId, cascaderVaule[0] as string, cascaderVaule[1] as string)
                .then(res => {
                    const methodReqeustData = res.Method || [];
                    let methodDataList = methodReqeustData.map((item: IMethodItem) => {
                        return {
                            key: item.key,
                            title: item.value,
                            type: item.MethodName
                        }
                    })
                    setMethodData(methodDataList);
                    setWantImportKeys([]);
                    setLoading(false);
                })
                .catch(err => {
                    setLoading(false);
                })
        }


    }
    const filterOption = (inputValue: string, item: TransferItem): boolean => item.title ? item.title.indexOf(inputValue) > -1 : false

    const onClickOk = () => {
        showLoading(true)
        ImportMethod(props.versionId, wantImportKeys)
            .then(res => {
                showLoading(false);
                props.getTableData();
                closeModal();
            })
            .catch(err => {
                showLoading(false)
            })
    }

    const showLoading = (isShow: boolean): void => {
        setLoading(isShow)
        setButtonLoading(isShow)
    }
    const closeModal = (): void => {
        setMethodData([]);
        setWantImportKeys([]);
        props.onCancel();
    }

    return <Modal
        destroyOnClose
        visible={props.visible}
        onCancel={closeModal}
        title={"Import API Method"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" style={{ marginRight: 8 }} loading={buttonLoading} disabled={(!buttonLoading && loading) || (wantImportKeys.length === 0)} onClick={onClickOk}>Import</Button>
                <Button onClick={closeModal} >Cancel</Button>
            </div>
        }
    >

        <Row style={{ marginBottom: 20 }}>
            <Col span={16}>
                <div id="modal-Cascader"></div>
                <Cascader
                    style={{ width: "100%" }}
                    options={cascaderOptions}
                    loadData={cascaderLoadData}
                    onChange={cascaderOnChange}
                    getPopupContainer={()=>document.getElementById("modal-Cascader")!}
                    className={"ant-cascader-custom"} />

            </Col>
            <Col span={7} push={1}>
                <Button type="primary" disabled={!!!cascaderVaule} onClick={onSerachMethodClick}>Search Method</Button>
            </Col>
        </Row>

        <Spin spinning={loading}>
            <Transfer
                dataSource={methodData}
                showSearch
                oneWay
                titles={["Backend", "Frontend"]}
                filterOption={filterOption}
                listStyle={{
                    width: 210,
                    height: 320
                }}
                targetKeys={wantImportKeys}
                onChange={onTransferChange}
                render={item => item.title ? <React.Fragment><Tag color={"#87d068"} >{MethodTypeEnum[item.type]}</Tag>{item.title}</React.Fragment> : ""}
            />

        </Spin>




    </Modal>
}


export default ImportAPIModel
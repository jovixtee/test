import apiservice from "../utils/fetchutil";
const serve = apiservice();

 
export const validateCookie =(): Promise<boolean> => {
    return new Promise((resolve, reject) => {
        serve.get("/IPassportService/ValidateCookie").then(res=>resolve(res)).catch(res=> resolve(false));
    })
}

export const refreshCookie =(): Promise<boolean> => {
    return new Promise((resolve, reject) => {
        serve.get("/IPassportService/RefreshCookie").then(res=>resolve(res)).catch(res=> resolve(false));
    })
}


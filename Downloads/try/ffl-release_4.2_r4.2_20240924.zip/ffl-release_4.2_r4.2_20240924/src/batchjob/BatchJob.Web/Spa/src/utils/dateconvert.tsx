import moment from "moment";

const defaultTicks: number = 621355968000000000;

export function convertTicksToFormatDate(ticks: number, dateformat: string): string {
    if (ticks && dateformat) {
        let date: Date = new Date((ticks - defaultTicks) / 10000);
        return moment(date).format(dateformat);
    } else {
        return "";
    }
}

export function convertTicksToMoment(ticks: number): moment.Moment {
    let date: Date = new Date((ticks - defaultTicks) / 10000);
    return moment(date);
}

export function convertMomentToTicks(mmt: moment.Moment): number {
    return mmt.toDate().getTime() * 10000 + defaultTicks;
}

export function convertDateToTicks(date: Date): number {
    return date.getTime() * 10000 + defaultTicks;
}
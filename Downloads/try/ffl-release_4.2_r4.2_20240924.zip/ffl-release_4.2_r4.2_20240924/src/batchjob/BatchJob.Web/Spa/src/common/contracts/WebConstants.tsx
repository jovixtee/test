export const StorageKeys = {
    userPrivileges: "dbp.app.userprivileges",
}

export const CookieKeys = {
    marsToken:"mars_access_token",
}

export const DatetimeFormat = "YYYY-MM-DD HH:mm:ss";
import React, { useState, useEffect } from "react";

import { Table, Row, Col } from 'antd';
const AuthenticationTable = (props: any) => {
    const [selectedRowKeys, setSelectedRowKeys] = useState<any>([]);
    const columns = [
        {
            title: 'Authentication Name',
            dataIndex: 'AuthenticationName',
            key: 'AuthenticationName',
            sorter: true,
            width: '12%',
        }, {
            title: 'Description',
            dataIndex: 'Description',
            key: 'Description',
            width: '16%'
        }, {
            title: 'Authentication Type',
            dataIndex: 'AuthenticationType',
            key: 'AuthenticationType',
            width: '12%'
        }, {
            title: 'Status',
            dataIndex: 'Status',
            key: 'Status',
            width: '10%'
        }, {
            title: 'Created By',
            dataIndex: 'createdby',
            key: 'createdby',
            width: '12%'
        }, {
            title: 'Created Time',
            dataIndex: 'createdtime',
            key: 'createdtime',
            width: '13%'
        }, {
            title: 'Modified By',
            dataIndex: 'modifiedby',
            key: 'modifiedby',
            width: '12%'
        }, {
            title: 'Modified Time',
            dataIndex: 'modifiedtime',
            key: 'modifiedtime',
            width: '13%'
        }];
    const onChangeTable = (pagination: any, filters: any, sorter: any, extra: any) => {
        props.getTableChange(pagination, filters, sorter, extra)
    }
    const rowSelection = {
        selectedRowKeys,
        onChange: (selectedRowKeys: any, selectedRows: any) => {
            setSelectedRowKeys([...selectedRowKeys])
            props.func(selectedRows)
        },
    }
    useEffect(() => {
        if (props.selectLength === 0) {
            setSelectedRowKeys([])
        }
    }, [props.selectLength])
    return (
        <>
            <Table
                rowSelection={{ type: 'checkbox', ...rowSelection }}
                onChange={onChangeTable}
                columns={columns}
                dataSource={props.dataSource}
                rowKey='uuid'
                footer={() => { return <Row><Col span={6}>{`${props.selectLength} of ${props.dataSource.length} selected`}</Col></Row> }}
            >
            </Table>
        </>
    );
};

export default AuthenticationTable;
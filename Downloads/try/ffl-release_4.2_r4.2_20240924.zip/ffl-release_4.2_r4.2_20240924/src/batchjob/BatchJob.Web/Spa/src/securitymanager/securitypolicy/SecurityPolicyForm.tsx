import React from 'react';
import { Breadcrumb, Form, Button, Input, Tabs } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import './SecurityPolicy.css';
import { hasPermission } from '../../utils/permissionutil';
import {
    SecurityPermissionConstants
} from './SecurityPofileContract';

const { TextArea } = Input;
const { TabPane } = Tabs;

const formItemLayout = {
    labelCol: { span: 4 },
    wrapperCol: { span: 6 },
};

function callback(key: any) {
    console.log(key);
}

class Security extends React.Component<any, any>{
    private formRef = React.createRef<any>();
    constructor(props: any) {
        super(props);
        this.state = {
            formData: this.props.formData.Result,
        }
    }
    onFinish = () => {
    }
    onCreateClickTab1 = () => {
        this.props.updateDrawer("1")
    };
    // onCreateClickTab2 = () => {
    //     this.props.updateDrawer("2")
    // };
    onCreateClickTab3 = () => {
        this.props.updateDrawer("3")
    };
    render() {
        return (
            <div>
                <Breadcrumb style={{ marginBottom: 16 }}>
                    <Breadcrumb.Item>Security Manager</Breadcrumb.Item>
                </Breadcrumb>
                <Form
                    id="policyForm"
                    name="validate_other"
                    {...formItemLayout}
                    onFinish={this.onFinish}
                    ref={this.formRef}
                    initialValues={{
                        "Name": this.state.formData?.SymmetricKey?.Name,
                        "EncryptionKey": this.state.formData?.SymmetricKey?.EncryptionKey,
                        "MatchPassphrase": this.state.formData?.SymmetricKey?.MatchPassphrase,
                        //"Name1": this.state.formData?.KeyVaultConfig?.Name,
                        //"ClientId": this.state.formData?.KeyVaultConfig?.ClientId,
                        //"ClientSecret": this.state.formData?.KeyVaultConfig?.ClientSecret,
                        //"KeyIdentity": this.state.formData?.KeyVaultConfig?.KeyIdentity,
                        "Name2": this.state.formData?.AsymmetricKey?.Name,
                        "PrivateKey": this.state.formData?.AsymmetricKey?.PrivateKey,
                        "PublicKey": this.state.formData?.AsymmetricKey?.PublicKey,
                    }}
                >
                    <Tabs defaultActiveKey={this.props.selectedTab} onChange={callback}>
                        <TabPane tab="Symmetric Key" key="1">
                            <div>
                                <Button type="text" disabled={!hasPermission(SecurityPermissionConstants.ObjectCode, SecurityPermissionConstants.Update)} icon={<PlusOutlined twoToneColor="#eb2f96" />} onClick={this.onCreateClickTab1}>Update</Button>
                            </div>
                            <Form.Item
                                label="Name"
                                labelAlign="right"
                                name="Name"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                            <Form.Item
                                label="Encryption Key"
                                name="EncryptionKey"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"

                                />
                            </Form.Item>
                            <Form.Item
                                label="Match Passphrase"
                                labelAlign="right"
                                name="MatchPassphrase"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"

                                />
                            </Form.Item>
                        </TabPane>

                        {/* <TabPane tab="KeyVault Config" key="2">
                            <div>
                                <Button type="text" disabled={true} icon={<PlusOutlined twoToneColor="#eb2f96" />} onClick={this.onCreateClickTab2}>Update</Button>
                            </div>
                            <Form.Item
                                label="Name"
                                labelAlign="right"
                                name="Name1"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"

                                />
                            </Form.Item>
                            <Form.Item
                                label="Client Secret"
                                labelAlign="right"
                                name="ClientId"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                            <Form.Item
                                label="Client Secret"
                                labelAlign="right"
                                name="ClientSecret"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                            <Form.Item
                                label="Key Identity"
                                name="KeyIdentity"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                        </TabPane> */}
                        <TabPane tab="Asymmetric Key" key="3">
                            <div>
                                <Button type="text" disabled={!hasPermission(SecurityPermissionConstants.ObjectCode, SecurityPermissionConstants.Update)} icon={<PlusOutlined twoToneColor="#eb2f96" />} onClick={this.onCreateClickTab3}>Update</Button>
                            </div>
                            <Form.Item
                                label="Name"
                                labelAlign="right"
                                name="Name2"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                            <Form.Item
                                label="Public Key"
                                name="PublicKey"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <TextArea rows={2} placeholder="Please enter your description" />
                            </Form.Item>
                            <Form.Item
                                label="Private Key"
                                labelAlign="right"
                                name="PrivateKey"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <TextArea rows={6} placeholder="Please enter your description" />
                            </Form.Item>
                        </TabPane>
                    </Tabs>

                </Form>
            </div>
        )
    }
}

export default Security;


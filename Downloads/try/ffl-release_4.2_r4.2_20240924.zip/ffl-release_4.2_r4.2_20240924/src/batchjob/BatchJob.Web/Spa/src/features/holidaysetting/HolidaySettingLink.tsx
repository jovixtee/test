import React, { useEffect, useState } from 'react';
import { Drawer } from 'antd';
import { DeleteOutlined, EditOutlined, PlusOutlined, } from '@ant-design/icons';
import { Holiday, HolidayPermissionConstants, HolidaySettingProfile } from './HolidaySettingContract';
import { hasPermission } from '../../utils/permissionutil';
//import './HolidaySetting.css';
import HolidaySubDrawer from './HolidaySubDrawer';
import AmpCommonTable, { IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import HolidaySettingApi from './HolidaySettingApi'
import HolidaySettingUtil from "./HolidaySettingUtil";
import UINotrification from "../../common/UINotrification";
import moment from "moment";
interface IDrawerLinkFormProps {
    Profile: HolidaySettingProfile;
    Visible: boolean;
    OnClose: () => void;
}
const formatterTime = (val:any) => {
	return val ? moment(val).format('YYYY-MM-DD') : ''
}
const DrawerLinkForm = (props: IDrawerLinkFormProps) => {

    const [subDrawVisable, setSubDrawerVisable] = useState(false);
    const [selectedRecords, setSelectedRecords] = useState<Holiday[]>();
    const [currentHoliday, setCurrentHoliday] = useState<Holiday>({});
    const [refresh, setRefresh] = useState(1);

    useEffect(() => {
        refreshTable();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.Profile]);

    const columns = [
        {
            title: 'Holiday',
            dataIndex: 'Name',
            sorter: true,
        },
        {
            title: 'Description',
            dataIndex: 'Description',
        },
        {
            title: 'Schedule Type',
            dataIndex: 'TypeStr',
        },
        {
            title: 'Date',
            dataIndex: 'DateStr',
        }
    ];
    const refreshTable = () => {
        setRefresh(refresh + 1);
    }

    const createHoliday = () => {
        setCurrentHoliday({});
        setSubDrawerVisable(true);
    }

    const editHoliday = () => {
        setCurrentHoliday(selectedRecords![0]);
        setSubDrawerVisable(true);
    }

    const deleteHoliday = async () => {
        UINotrification.confirm(
            "You are about to delete the selected holidays. Are you sure you want to proceed?",
            "Confirm Deletion",
            async () => {
                let ids:any = selectedRecords!.map(r => r.Id);
                const result = await HolidaySettingApi.DeleteHolidays(props.Profile!.ProfileId!,ids );
                if (result.HolidayOperationResult) {
                    UINotrification.success("The selected records were deleted successfully.");
                } else {
                    UINotrification.error("Failed to delete selected records.");
                }
                refreshTable();
            },
            () => {
                refreshTable();
            });
        
    }

    const closeSubDrawer = () => {
        setSubDrawerVisable(false);
        refreshTable();
    }

    const buttons: IAmpTableButton[] = [{
        Text: "Create",
        Primary: true,
        Icon: <PlusOutlined />,
        OnClick: createHoliday,
        EnableMode: 'always',
        HasPermission: hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Create)
    }, {
        Text: "Edit",
        Icon: <EditOutlined />,
        OnClick: editHoliday,
        EnableMode: 'single',
        HasPermission: hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Create)
    }, {
        Text: "Delete",
        Icon: <DeleteOutlined />,
        OnClick: deleteHoliday,
        EnableMode: 'multiple',
        HasPermission: hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Delete)
    }];

    const ApiPagerQueryJob = async (exp: PagerExpression) => {
        const result = await HolidaySettingApi.QueryAllHolidaysByProfileId(props.Profile!.ProfileId!);
        const vms = result!.Holidays!.map(h => HolidaySettingUtil.ConvertVM(h));
        return { total: vms.length, records: vms };
    }

    return (
        <>
            <Drawer title="Holidays" width={720} closable={true} visible={props.Visible} onClose={props.OnClose}>
                <AmpCommonTable RowKey="Id" Type="checkbox" Refresh={refresh} Columns={columns} Buttons={buttons} PagerQuery={ApiPagerQueryJob} OnSelectedChanged={rs => setSelectedRecords(rs as Holiday[])} />
                <HolidaySubDrawer Visible={subDrawVisable} Holiday={currentHoliday} OnClose={closeSubDrawer} ProfileId={props.Profile!.ProfileId!} />
            </Drawer>
        </>
    );
}
export default DrawerLinkForm;


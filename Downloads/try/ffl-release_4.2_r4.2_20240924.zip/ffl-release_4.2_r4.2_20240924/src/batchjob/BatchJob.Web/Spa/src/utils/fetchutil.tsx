import qs from "qs";
import * as LSUtil from './localstorageutil';
import { UserSummaryStorageKey } from './permissionutil';
import ApiConfig from '../common/AveConfig';
import PathConfig from '../common/PathConfig';
import UINotification from '../common/UINotrification';
 
interface IOption {
    headers?: any;
    mode?: "no-cors" | "cors" | "same-origin";
    cache?: "default" | "no-cache" | "reload" | "force-cache" | "only-if-cached";
    credentials?: "include" | "same-origin" | "omit";
    accept?: 'application/json' | 'text/xml' | '*/*';
}
interface IService {
    post: (url: string, data?: any, options?: IOption) => Promise<any>;
    get: (url: string, data?: any, options?: IOption) => Promise<any>;
    hostUrl: string;
}


function request(url: string, data?: any, options = {}, isGet = true) {
    let init: any = {
        method: isGet ? "GET" : "POST",
        // headers: {
        //     "Content-Type": "application/json",
        // },
        // cookie set
        //   - include
        //   - same-origin
        //   - omit
        mode: "cors",
        credentials: "include",
        accept: 'application/json'
    }

    if (data instanceof FormData) {
        init.body = data;
    } else {
        init.headers = { "Content-Type": "application/json" };
    }

    Object.assign(init, options);
    if (isGet && data) {
        let searchStr = "";
        if (data instanceof Object) {
            for (let i in data) {
                if (searchStr === "") {

                    searchStr += (i + "=" + data[i]);
                } else {
                    searchStr += ("&" + i + "=" + data[i]);
                }
            }
        }
        if (url.indexOf("?") === -1) {
            url = url + "?" + searchStr;
        } else {
            url = url + "&" + searchStr;
        }
    }


   
  
     
    /**
     * add token
     */
    // const token = localStorage.getItem("token");
    // token && (init.headers.Authorization = token);
    /**
     * POST
     */
    if (!isGet && data) {
        if (!init.headers) {

        }
        else if (init.headers["Content-Type"] === "application/x-www-form-urlencoded") {
            init.body = qs.stringify(data);
        }
        else if (init.headers["Content-Type"] === "application/json") {
            init.body = JSON.stringify(data);
        }
    }


    let promise = fetch(url, init).then(checkStatus).catch((rason: any) => {
        console.error("an error has occurred. Detail:", rason);
        return Promise.reject(rason);
    });


    
    if (init.accept === 'application/json') {
        promise = promise.then(buildResult);
    }

    return promise;
}
function checkStatus(response: Response) {
    return new Promise((resolve, reject) => {
        switch (response.status) {
            case 200: resolve(response); break;
            case 401:
                UINotification.error("Session has been expired, redirecting to login page." , () => {
                    LSUtil.removeItem('LoginInfo');
                    LSUtil.removeItem(UserSummaryStorageKey)
                    window.location.href = PathConfig.addPrefix('/login?ReturnUrl=' + encodeURIComponent(window.location.pathname + window.location.search));
                });
                reject();
                break;
            case 403:
                UINotification.error("You don't have enough permission, please contact administrator for help.");
                reject();
                break;
            case 404:
                UINotification.error("Resources you are requesting is not found.");
                reject();
                break;
            case 400:
            case 500:
                response.json().then(e => {
                    let error = parseJSON(e.Message);
                    if(error){
                        UINotification.error(error.Message);
                        return;
                    }
                    UINotification.error(e.Message);
                });
                reject();
                break;
            default:
                response.text().then(e => UINotification.error(e));
                reject();
        }
        return response;
    });
}

function parseJSON(str:any) {
    if (typeof str == 'string') {
        try {
            var obj=JSON.parse(str);
            return obj;
        } catch(e) {
            return null;
        }
    }
    console.log('It is not a string!')
}　

function buildResult(response: any) {
    return new Promise((resolve, reject) => {
        response.text().then((body: any) => {
            resolve(body.length ? JSON.parse(body) : null);
        }).catch((err: any) => {
            reject(err);
        });
    });
}


function apiservice(): IService {
    //let s = apiConfig().dbpRequestUrl();
    //let hostUrl = process.env.REACT_APP_DBP_API_URL;
    const service: IService = {
        post: (url: string, data?: any, options?: IOption) => {
            return initConfig().then(()=>{
                return request(ApiConfig.API_URL() + url, data, options, false);
            }).catch(e=>{
                UINotification.error(e);
                return Promise.reject(e)}
            );
        },
        get: (url: string, data?: any, options?: IOption) => {
            return initConfig().then(()=>{
                return request(ApiConfig.API_URL() + url, data, options, true);
            }).catch(e=>Promise.reject(e));
        },
        hostUrl: ApiConfig.API_URL()
    }
    return service;
}

function initConfig() {
    if (ApiConfig.LOCAL()) {
        return Promise.resolve();
    } else if (ApiConfig.API_URL()) {
        return Promise.resolve();
    } else {
        return fetch('/api/ReadConfig/GetConfig')
            .then(buildResult)
            .then((res) => {
                LSUtil.setItem('env-config', res);
                console.log("env-config:" + JSON.stringify(res))
                return Promise.resolve();
            })
            .catch((e) => Promise.reject('Not loaded into the configuration file, please refresh and reload'));
    }
}

export default apiservice;

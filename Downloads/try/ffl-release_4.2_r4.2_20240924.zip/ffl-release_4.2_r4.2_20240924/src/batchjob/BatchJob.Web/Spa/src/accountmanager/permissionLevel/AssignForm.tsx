import React, { useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { Select } from 'antd';
import { QueryUserAll } from './permissionLevelApiServe';
const { Option } = Select;



const AssignForm = (props: any, ref: any) => {
    const [user, setUser] = useState<string[]>([]);
    const [userArr, setUserArr] = useState<any>([]);
    useImperativeHandle(ref, () => ({
        onNextAssign: () => {
            let selectUsers: any = []
            user.forEach((userID: string) => {
                userArr.forEach((item: any) => {
                    if (item.UserId === userID) {
                        selectUsers.push(item)
                    }
                })
            })
            props.EditFormData.Users = [...selectUsers]
            props.onAssignFormData(user)
        }
    }));

    useEffect(() => {
        getInitRole();
    },[])
    const getInitRole = async () => {
        let result = await QueryUserAll()
        if (result.Result) {
            setUserArr(result.Result)
        }
        let users = props.EditFormData.Users.map((item: any) => {
            return item.UserId
        })
        setUser(users)
    }
    const onChange = (value: string[]) => {
        setUser(value)
    }
    return (
        <>
            <div style={{ color: 'rgba(0, 0, 0, 0.85)', fontWeight: 500, fontSize: '16px',paddingBottom:'20px' }}>Select Users:</div>
            <Select
                style={{ width: '50%' }}
                onChange={onChange}
                mode="multiple"
                placeholder="select user"
                value={user}

            >
                {
                    userArr.map((item: any) => {
                        return <Option key={item.UserId} value={item.UserId}>{item.DisplayName}</Option>
                    })
                }
            </Select>
        </>

    )
}
export default forwardRef(AssignForm);
import React, { FC } from "react";
import { PlusOutlined } from '@ant-design/icons';
import "./APIsContent.css";
interface IBlankAPIContentProps {
    hidden: boolean;
}

const BlankAPIContent: FC<IBlankAPIContentProps> = (props) => {

    return (
        <>
            <div className="blank-content" hidden={props.hidden}>
                <div className="main">
                    <h2> Click "{<PlusOutlined/>}" icon to create a new API.</h2>
                </div>
            </div>
        </>
            );

}

            export default BlankAPIContent;

import apiservice from '../../utils/fetchutil';
const serve = apiservice()
export const RolePagedQuery = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/RolePagedQuery", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const DeleteRole = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/DeleteRole", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const DeleteRoles = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/DeleteRoles", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const UpdateRole = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/UpdateRole", params).then((result) => {
            resolve(result)
        }).catch(error => {

            reject(error)
        })

    })
}
export const CreateRole = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/CreateRole", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const AddCheckDisplayName = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/AddCheckDisplayName", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const EditCheckDisplayName = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/EditCheckDisplayName", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const QueryRoleAll = (): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/QueryRoleAll").then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const QueryUserAll = (): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/QueryUserAll").then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const QueryPrivilegeAll = (): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/QueryPrivilegeAll").then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const QueryRoleDetail = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/QueryRoleDetail",params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}

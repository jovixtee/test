import { Space, Table, Input, Form,Select } from 'antd';
import React, { FC, useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { ColumnsType } from "antd/lib/table";
import { EditOutlined, DeleteOutlined, CheckOutlined, CloseOutlined } from '@ant-design/icons';
import { EditTableData, EntityAttributes, FieldMappings, IEditTableRef } from '../ReplicatorContract';


interface IEditItem {
  TargetAttribute?: string ;
  TargetDataType?: string;
  SourceAttribute?: string;
  SourceDataType?: string
}

interface IEditTableProps {
    sourceAttributes?:EntityAttributes[];
    targetAttributes?:EntityAttributes[];
    dataSource: FieldMappings[];
    ref?: any;
}

const FieldMappingsTable: FC<IEditTableProps> = forwardRef((props, ref) => {
    const [dataSource, setDatasource] = useState<EditTableData[]>(new Array<EditTableData>())
    const [addData, setAddData] = useState<FieldMappings[]>(new Array<FieldMappings>());
    const [deleteData, setDeleteData] = useState<FieldMappings[]>(new Array<FieldMappings>());
    const [updateData, setUpdateData] = useState<FieldMappings[]>(new Array<FieldMappings>());
    const [editingData, setEditingData] = useState<EditTableData>(new EditTableData());
    const [form] = Form.useForm();

    useEffect(() => {
        const propsdata = props!.dataSource!.map(item => {
            return { ...item, IsEdit: false, IsNewData: false }
        })
        handleAddData(propsdata!);
    }, [props.dataSource])

    const handleAddData = (newDataSource: EditTableData[]): void => {
        const newTableData = new EditTableData();
        newTableData.Id = new Date().getTime().toString();
        newTableData.IsEdit = true;
        newTableData.IsNewData = true;
        form.setFieldsValue({
            TargetAttribute: newTableData.TargetAttribute,
            TargetDataType: newTableData.TargetDataType,
            SourceAttribute: newTableData.SourceAttribute,
            SourceDataType:newTableData.SourceDataType,
        })
        //newDataSource.push(newTableData);
        newDataSource.unshift(newTableData);
        setDatasource(newDataSource)
        setEditingData(newTableData)
    }

    const onFailed = (values: any): void => {
        console.log('onFailed:', values);
    };

    const onFinish = (values: IEditItem): void => {
        console.log('onFinish:', values);
        let newDataSource = [...dataSource];
        let data = handleOnFinish(values, newDataSource);
        form.resetFields();
        handleAddData(data);
    }

    const handleOnFinish = (record: IEditItem, newDataSource: EditTableData[]) => {
        let IsNew: boolean = false;
        let data = newDataSource.find(item => item.Id === editingData.Id);
        if (data) {
            data.IsEdit = false;
            data.TargetAttribute = record.TargetAttribute;
            data.TargetDataType = record.TargetDataType;
            data.SourceAttribute = record.SourceAttribute;
            data.SourceDataType = record.SourceDataType;

            IsNew = data.IsNewData;


            if (IsNew) {
                let newAddArray = [...addData]
                let newDataItem = newAddArray.find(item => item.Id === editingData.Id);
                if (newDataItem) {
                    newDataItem.TargetAttribute = record.TargetAttribute;
                    newDataItem.TargetDataType = record.TargetDataType;
                    newDataItem.SourceAttribute = record.SourceAttribute;
                    newDataItem.SourceDataType = record.SourceDataType;
                } else {
                    newAddArray.unshift(data)
                }
                setAddData(newAddArray);
            } else {
                let newUpdateData = [...updateData]
                let newDataItem = newUpdateData.find(item => item.Id === editingData.Id);
                if (newDataItem) {
                    newDataItem.TargetAttribute = record.TargetAttribute;
                    newDataItem.TargetDataType = record.TargetDataType;
                    newDataItem.SourceAttribute = record.SourceAttribute;
                    newDataItem.SourceDataType = record.SourceDataType;
                } else {
                    newUpdateData.unshift(data)
                }
                setUpdateData(newUpdateData);
            }
        }
        return newDataSource;
    }

    const onCancelItemClick = (record: EditTableData): void => {
        let newDataSource = [...dataSource];
        let editItem = newDataSource.find(item => item.Id === record.Id);
        if (editItem) {
            let isNewData = editItem.IsNewData;
            if (isNewData) {
                newDataSource = dataSource.filter(item => item.Id !== record.Id);
                setDatasource(newDataSource);
            } else {
                editItem.TargetAttribute = record.TargetAttribute;
                editItem.TargetDataType = record.TargetDataType;
                editItem.SourceAttribute = record.SourceAttribute;
                editItem.SourceDataType = record.SourceDataType;
                editItem.IsEdit = false;
                setDatasource(newDataSource);
            }
        }
        handleAddData(newDataSource);
    }


    const onEntitySourceChanged = (record: string): void => {
        let attributes = props.sourceAttributes?.find(e=>e.AttributesName = record);
        form.setFieldsValue({
            SourceDataType:attributes?.AttributesType
        })
    }
    const onEntityTargetChanged = (record: string): void => {
        let attributes = props.targetAttributes?.find(e=>e.AttributesName = record);
        form.setFieldsValue({
            TargetDataType:attributes?.AttributesType
        })
    }

    const onDeleteItemClick = (record: EditTableData): void => {
        if (record.IsNewData) {
            let newAddData = addData.filter(item => item.Id !== record.Id);
            let newDataSource = dataSource.filter(item => item.Id !== record.Id);
            setAddData(newAddData)
            setDatasource(newDataSource);
        } else {
            let newDeleteData = [...deleteData];
            let newDataSource = dataSource.filter(item => item.Id !== record.Id);
            newDeleteData.push(record)
            setDeleteData(newDeleteData);
            setDatasource(newDataSource);
        }
    }

    const onEditItemClick = (record: EditTableData): void => {
        let newDataSource = [...dataSource];

        if (editingData.TargetAttribute && editingData.SourceAttribute) {
            let data = editingData as IEditItem;
            newDataSource = handleOnFinish(data, newDataSource);
        } else {
            newDataSource.shift();
        }
        let recordData = newDataSource.find(item => item.Id === record.Id);
        if (recordData) {
            recordData.IsEdit = true;
            form.setFieldsValue({
                TargetAttribute: recordData.TargetAttribute,
                TargetDataType: recordData.TargetDataType,
                SourceAttribute: recordData.SourceAttribute,
                SourceDataType:recordData.SourceDataType,
            })
            setEditingData(recordData);
            setDatasource(newDataSource);
        }
    }


    const tableColumn: ColumnsType<EditTableData> = [
        {
            title: "Target Attribute",
            dataIndex: "TargetAttribute",
            width:"35%",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="TargetAttribute" rules={[{ required: true, message: 'Target Attribute is required' }]}>
                            <Select placeholder="Select One" 
                                showSearch
                                onChange={onEntityTargetChanged}  
                                filterOption={(input:any, option:any) =>
                                    option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }>
                               
                                {props!.targetAttributes!.map((item) => (
                                    <Select.Option key={item.AttributesName} value={item.AttributesName as string} label={item.AttributesName}>
                                        {item.AttributesName}
                                    </Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                        :
                        <span>{record.TargetAttribute}</span>
                }
            </React.Fragment>
        },
        {
            title: "Target DataType",
            dataIndex: "TargetDataType",
            render: (_: any, record) => <React.Fragment>
                {
                      record.IsEdit ?

                      <Form.Item name="TargetDataType" rules={[{ required: true, message: 'Target DataType is required' }]}>
                            <Input placeholder={"Parameter name"} />
                      </Form.Item>
                      :
                       <span>{record.TargetDataType}</span>
                }
            </React.Fragment>
        },
        {
            title: "Source Attribute",
            dataIndex: "SourceAttribute",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                    <Form.Item name="SourceAttribute" rules={[{ required: true, message: 'Source Attribute is required' }]}>
                    <Select placeholder="Select One" 
                        showSearch
                        onChange={onEntitySourceChanged}  
                        filterOption={(input:any, option:any) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }>
                        {props!.sourceAttributes!.map((item) => (
                            <Select.Option key={item.AttributesName} value={item.AttributesName as string} label={item.AttributesName}>
                                {item.AttributesName}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                        :
                        <div style={{ wordWrap: 'break-word', wordBreak: 'break-word' }}>{record.SourceAttribute}</div>
                }
            </React.Fragment>
        },
        {
            title: "Source DataType",
            dataIndex: "SourceDataType",
            render: (_: any, record) => <React.Fragment>
                {
                       record.IsEdit ?

                       <Form.Item name="SourceDataType" rules={[{ required: true, message: 'Source DataType is required' }]}>
                           <Input/>
                       </Form.Item>
                       :
                    <span>{record.SourceDataType}</span>
                }
            </React.Fragment>
        },
        {
            title: "Action",
            dataIndex: "Action",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Space>
                            <CheckOutlined onClick={() => form.submit()} />
                            <CloseOutlined onClick={() => onCancelItemClick(record)} />
                        </Space>
                        :
                        <Space>
                            <EditOutlined onClick={() => onEditItemClick(record)} />
                            <DeleteOutlined onClick={() => onDeleteItemClick(record)} />
                        </Space>
                }
            </React.Fragment>
        }
    ]

    useImperativeHandle(ref, (): IEditTableRef => ({
        getTableResult: () => {
            return {
                addData,
                updateData,
                deleteData
            }
        }
    }));


    return <React.Fragment>
        <Form form={form} onFinish={onFinish} onFinishFailed={onFailed}  >
            <Table
                rowKey={(record) => record.Id!}
                columns={tableColumn}
                dataSource={dataSource}
                pagination={false}
            />
        </Form>
    </React.Fragment>
}
)
export default FieldMappingsTable





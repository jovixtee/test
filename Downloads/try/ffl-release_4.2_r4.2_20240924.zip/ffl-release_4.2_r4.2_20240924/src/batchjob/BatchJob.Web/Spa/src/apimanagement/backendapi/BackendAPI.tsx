import React, { FC, useState, useEffect } from "react";
import { Breadcrumb, Row, Col, Space, Table, Input, Button } from "antd";
import { ColumnsType } from "antd/lib/table";
import { IPaginationC,  QueryBackendPager } from "./BackendAPIContracts";
import {BackendDetailsDto,TypeMap,VersionDetailsDto} from "../../common/contracts/ModelContracts";
import VersionTable from './VersionTable';
import ManageAPIDrawer from './ManageAPIDrawer';
import ManageVersionDrawer from './ManageVersionDrawer';
import ManageAPIParameterTypeDrawer from './ManageAPIParameterTypeDrawer';
import { FundViewOutlined, PlusOutlined } from '@ant-design/icons';
import { PagerQueryBackend, DeleteBackend, DeleteVersion } from './BackendAPIApiService';
import "./backendAPI.css";



const Search = Input.Search;
const BackendAPI: FC = () => {

    const [dataSource, setDataSource] = useState<BackendDetailsDto[]>(new Array<BackendDetailsDto>());
    const [currentPageData, setCurrentPageData] = useState<IPaginationC>({ currentPage: 1, currentPageSize: 10, total: 0 });
    const [isEditMode, setIsEditMode] = useState<boolean>(false);
    const [manageAPIDrawerVisible, setManageAPIDrawerVisible] = useState<boolean>(false);
    const [isEditVersionMode, setIsEditVersionMode] = useState<boolean>(false);
    const [manageVersionDrawerVisible, setManageVersionDrawerVisible] = useState<boolean>(false);
    const [versionDrawerApiId, setVersionDrawerApiId] = useState<string>("");
    const [versionDrawerVersionId, setVersionDrawerVersionId] = useState<string>("");
    const [apiDrawerDefaultData, setApiDrawerDefaultData] = useState<BackendDetailsDto>(new BackendDetailsDto());
    const [manageAPIParameterTypeDrawerVisible, setManageAPIParameterTypeDrawerVisible] = useState<boolean>(false);
    const [manageParameterTypeId, setManageParameterTypeId] = useState<string>("");
    const [loading, setLoading] = useState<boolean>(false);
    const [searchText, setSearchText] = useState<string>("");



    const tableColumn: ColumnsType<BackendDetailsDto> = [
        {
            title: 'Name',
            dataIndex: 'Name',
        },
        {
            title: 'Protocol',
            dataIndex: 'Protocol',
            render: (_: any, record) => Array.from(TypeMap).find(([key, value]) => value === record.Protocol)?.[0]
        },
        {
            title: 'Description',
            dataIndex: 'Description',
        },
        {
            title: 'Action',
            dataIndex: 'Action',
            render: (text, record) => <Space size="middle">
                <Button type="link" onClick={() => { onEditAPIClick(record) }}>Edit</Button>
                <Button type="link" onClick={() => { onAddVersionClick(record.Id,) }}>Add Version</Button>
                <Button type="link" onClick={() => { onManageMethodParameterClick(record.Id) }}>Manage Method Parameter Type</Button>
                <Button type="link" onClick={() => { onDeleteAPIClick(record.Id) }}>Delete</Button>
            </Space>
        }
    ]

    useEffect(() => {
        requestPagerQueryBackend(1, searchText)
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const requestPagerQueryBackend = (jumpPage: number, searchText: string) => {
        setLoading(true);
        PagerQueryBackend({
            "pager": new QueryBackendPager(currentPageData.currentPageSize, jumpPage, searchText)
        }).then(res => {
            setCurrentPageData({ ...currentPageData, currentPage: jumpPage, total: res.TotalNumber });
            console.log(res)
            if (res.Result) {
                setDataSource(res.Result);
            }
            setLoading(false)
        }).catch(err => {
            setLoading(false)
        })
    }

    const onSearch = (value: string): void => {

        setSearchText(value);
        requestPagerQueryBackend(1, value);
    }

    const onManageMethodParameterClick = (apiId: string): void => {
        setManageParameterTypeId(apiId);
        setManageAPIParameterTypeDrawerVisible(true)
    }

    const closeManageAPIParameterTypeDrawer = (): void => {
        setManageAPIParameterTypeDrawerVisible(false)
        setManageParameterTypeId("");
    }

    const tablePageChange = (page: number, pageSize?: number | undefined): void => {
        requestPagerQueryBackend(page, searchText);
    }


    const onImportAPIClick = (): void => {


    }
    const onDeleteAPIClick = (Id: string): void => {
        setLoading(true);
        DeleteBackend(Id)
            .then(res => {
                requestPagerQueryBackend(1, searchText);
            })
            .catch(err => {
                setLoading(false);
            })

    }
    const onCreateAPIClick = (): void => {
        setIsEditMode(false);
        setApiDrawerDefaultData(new BackendDetailsDto())
        setManageAPIDrawerVisible(true);
    }
    const closeManageAPIDrawer = (): void => {
        setApiDrawerDefaultData(new BackendDetailsDto())
        setManageAPIDrawerVisible(false);

    }

    const onEditAPIClick = (record: BackendDetailsDto): void => {
        setIsEditMode(true);
        setApiDrawerDefaultData(record);
        setManageAPIDrawerVisible(true);

    }

    const onAddVersionClick = (apiId: string): void => {
        setIsEditVersionMode(false);
        setVersionDrawerApiId(apiId);
        setVersionDrawerVersionId("");
        setManageVersionDrawerVisible(true);


    }
    const onEditVersionClick = (apiId: string, versionRecord: VersionDetailsDto): void => {
        setIsEditVersionMode(true);
        setVersionDrawerVersionId(versionRecord.Id)
        setVersionDrawerApiId(apiId);
        setManageVersionDrawerVisible(true);

    }

    const closeManageVersionDrawer = (): void => {
        setManageVersionDrawerVisible(false);
        setVersionDrawerApiId("");
        setVersionDrawerVersionId("");
    }
    const onDeleteVersion = (apiId: string, versionRecord: VersionDetailsDto) => {
        if (versionRecord.Id) {
            setLoading(true);
            DeleteVersion(versionRecord.Id)
                .then(res => {
                    requestPagerQueryBackend(1, searchText)
                })
                .catch(err => {
                    setLoading(false);
                })
        }
    }


    return <React.Fragment>

        <Breadcrumb>
            <Breadcrumb.Item>Backend API</Breadcrumb.Item>
        </Breadcrumb>
        <Row style={{ margin: '16px 0' }}>
            <Col span={18}>
                <Space size='small'>
                    <Button type="text" onClick={onCreateAPIClick}><PlusOutlined />Create</Button>
                    <Button type='text' icon={<FundViewOutlined />} onClick={onImportAPIClick}> Import</Button>
                </Space>
            </Col>
            <Col span={6}>
                <Search placeholder="input search text" allowClear onSearch={onSearch} style={{ width: 200, float: 'right' }} />
            </Col>
        </Row>

        <Table
            loading={loading}
            rowKey={record => record.Id}
            dataSource={dataSource}
            columns={tableColumn}
            expandable={{
                rowExpandable: (record) => (record.versions && record.versions.length > 0) ? true : false,
                expandedRowRender: (record) => <VersionTable
                    versionData={record.versions}
                    apiId={record.Id}
                    versionEdit={(versionRecord: VersionDetailsDto) => { onEditVersionClick(record.Id, versionRecord) }}
                    versionDelete={(versionRecord: VersionDetailsDto) => { onDeleteVersion(record.Id, versionRecord) }}
                />
            }}
            pagination={{
                defaultPageSize: 10,
                defaultCurrent: 1,
                total: currentPageData.total,
                pageSize: currentPageData.currentPageSize,
                onChange: tablePageChange,
                current: currentPageData.currentPage
            }}
        />

        <ManageAPIDrawer
            visibile={manageAPIDrawerVisible}
            cancelClick={closeManageAPIDrawer}
            isEdit={isEditMode}
            defaultData={apiDrawerDefaultData}
            getTableData={() => { requestPagerQueryBackend(1, searchText) }}
        />
        <ManageVersionDrawer
            visibile={manageVersionDrawerVisible}
            cancelClick={closeManageVersionDrawer}
            isEdit={isEditVersionMode}
            apiId={versionDrawerApiId}
            versionId={versionDrawerVersionId}
            getTableData={() => { requestPagerQueryBackend(1, searchText) }}
        />
        <ManageAPIParameterTypeDrawer
            cancelClick={closeManageAPIParameterTypeDrawer}
            visibile={manageAPIParameterTypeDrawerVisible}
            apiId={manageParameterTypeId}
        />

    </React.Fragment>
}

export default BackendAPI
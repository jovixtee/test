import { Drawer, Form, Input, Button, Select, Spin } from 'antd';
import React, { FC, useEffect, useState } from 'react';
import { ControlPolicyDto } from '../../common/contracts/ModelContracts';
import { CreateControlPolicy, GetControlPolicyById } from './ControlPolicyApiService'
import TaskRepository from '../../features/taskmanager/TaskRepository';

const { TextArea } = Input;
interface IControlPolicyDrawerProps {
    visible: boolean;
    closeDrawer: () => void;
    refresh: (searchText:string) => void;
    policyId: string;
}

const { Option } = Select;

 
const ControlPolicyDrawer: FC<IControlPolicyDrawerProps> = (props) => {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState<boolean>(false);
    const notificationProfiles = TaskRepository.getInstance().NotificationProfiles;

    useEffect(() => {
        if (props.policyId && props.policyId.length > 0) {
            handleGetControlPolicyById(props.policyId);
        }
            // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.visible,props.policyId]);



    const handleGetControlPolicyById = (id: string) => {
        setLoading(true);
        GetControlPolicyById(id).then(res => {
            form.setFieldsValue({
                Name: res?.Name,
                Notification: res?.Notification,
                Description: res?.Description
            })
        }).finally(() => setLoading(false));


    }

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };
    const onFinish = (values: ControlPolicyDto) => {
        setLoading(true);
        let requestObject = new ControlPolicyDto();
        requestObject.Name = values.Name;
        requestObject.Notification = values.Notification;
        requestObject.Description = values.Description;
        if (props.policyId && props.policyId.length > 0) {
            requestObject.Id = props.policyId;
        }
        CreateControlPolicy(requestObject).then(res => {
            props.closeDrawer();
            props.refresh("");
            form.resetFields();
        }).finally(() => setLoading(false));
    }


    const closeDrawer = ()=>{
        form.resetFields();
        props.closeDrawer();
    }

    return <Drawer
        visible={props.visible}
        width={720}
        destroyOnClose
        forceRender
        onClose={closeDrawer}
        title={(props.policyId && props.policyId.length > 0) ? "Edit ControlPolicy" : "Create a new ControlPolicy"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" style={{ marginRight: 8 }} onClick={() => form.submit()}>Save</Button>
                <Button onClick={closeDrawer} >Cancel</Button>
            </div>
        }
    >
        <Spin spinning={loading}>
            <Form layout="vertical" form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '20px' }}>
                <Form.Item label="Name" name="Name" rules={[{ required: true, message: 'Please input path!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Notification" name="Notification" >
                    <Select>
                        {notificationProfiles?.map(item => <Option key={item.Id} value={item.Id as string}> {item.Name} </Option>)}
                    </Select>
                </Form.Item>
                <Form.Item label="Description" name="Description" >
                    <TextArea rows={2} placeholder="" />
                </Form.Item>
            </Form>
        </Spin>
    </Drawer>
}
export default ControlPolicyDrawer
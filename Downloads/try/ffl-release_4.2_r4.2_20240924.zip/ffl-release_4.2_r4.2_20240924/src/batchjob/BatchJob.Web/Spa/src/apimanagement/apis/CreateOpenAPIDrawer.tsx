import React, { FC, useEffect, useState } from 'react';
import { Form, Button, Input, Select, Radio, Upload, Spin, Drawer, message, Row, Col } from 'antd';
import { GetAllNode, ImportOpenAPIByFile, ImportSwagger, ImportOpenAPIByHttp } from './APIsService';
import { NodeItemDto, ImportVersionDto, OperationDto } from '../../common/contracts/ModelContracts';
import { InboxOutlined } from '@ant-design/icons';
import { UploadFile } from 'antd/lib/upload/interface'
const { Dragger } = Upload;


interface ICreateOpenAPIDrawerProps {
    openVisible: boolean;
    closeDrawer: () => void;
    onRefresh: () => void;
}
const { Option } = Select;
const { TextArea } = Input;

const CreateOpenAPIDrawer: FC<ICreateOpenAPIDrawerProps> = (props) => {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState<boolean>(false);
    const [node, setNode] = useState<NodeItemDto[]>([]);
    const [nodeUrl, setNodeUrl] = useState<string>("");
    const [operations, setOperations] = useState<OperationDto[]>([]);
    const [fileList,setFileList] = useState<any[]>([]);

    const options = [
        { label: 'HTTP', value: 0, disabled: true },
        { label: "HTTPS", value: 1 },
        { label: 'Both', value: 2, disabled: true },
    ];

    useEffect(() => {
        handleGetAllNode();
    }, [])


    const handleGetAllNode = () => {
        setLoading(true);
        GetAllNode().then(res => {
            setNode(res);
        }).finally(() => setLoading(false));
    }


    const handleImportSwagger = (detail: ImportVersionDto) => {
        setLoading(true);
        ImportSwagger(detail).then(res => {
            form.resetFields();
            setOperations([]);
            props.onRefresh();
            message.success("Create Success");
            closeDrawer();
        }).finally(() => setLoading(false));
    }

    const handleNodeChange = (value: string, option: any) => {
        let nodeUrl = option.length > 0 ? option[0].nodeUrl : ""
        setNodeUrl(nodeUrl);
        let endpoint = form.getFieldValue("Endpoint");
        let baseUrl = nodeUrl + (endpoint ? endpoint : "");
        form.setFieldsValue({
            BaseUrl: baseUrl
        });
    };

    const handleUrlSuffixChange = (e: any) => {
        let endpoint = e.target.value;
        endpoint = endpoint.startsWith("/") ? endpoint : "/" + endpoint;
        var baseUrl = nodeUrl + endpoint;
        form.setFieldsValue({
            BaseUrl: baseUrl,
            Endpoint: endpoint
        });
    };


    const onFinish = (values: any) => {
        if (operations && operations.length === 0) {
            message.error("Not found import method ");
            return;
        }
        let setting = new ImportVersionDto();
        setting.DisplayName = values.DisplayName;
        setting.Identifier = values.Identifier;
        setting.Description = values.Description;
        setting.Endpoint = values.Endpoint;
        setting.ControlPolicyId = values.ControlPolicyId;
        setting.FrontendAuthId = values.FrontendAuthId;
        setting.BackendAuthId = values.BackendAuthId;
        setting.BaseAddress = values.BaseUrl;
        setting.ServiceAddress = values.ServiceAddress;
        setting.NodeID = values.NodeID;
        setting.operations = operations;
        handleImportSwagger(setting);

    }

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };

    const closeDrawer = (): void => {
        form.resetFields();
        props.closeDrawer();
    }

    const beforeUpload = (file: any, FileList: UploadFile[]) => {
        const isJSON = file.type === 'application/json';
        if (!isJSON) {
            message.error('You can only upload json file!');
            return false;
        }

        const isLt4M = file.size / 1024 / 1024 > 4;
        if (isLt4M) {
            message.error('file must smaller than 4MB!');
            return false;
        }
        
        setLoading(true);
        ImportOpenAPIByFile(file).then(res => {
            setOperations(res);
            let fileName = [{"name":file.name}];
            setFileList(fileName);
        }).catch(e=>{
            setFileList([]);
        }).finally(() => setLoading(false));
        return true;
    }
    const onRemove = (file: any) => {
        setFileList([]);
    };

    const importOpenAPIByHttp = (e: any): void => {
        let url = e.target.value;
        if (CheckUrl(url)) {
            ImportOpenAPIByHttp(url).then(res => {
                //message.success("Impprt method Success");
                setOperations(res);
            }).finally(() => setLoading(false));
        } else {
            message.error("Please enter the correct URL");
        }
    }

    const CheckUrl = (url: string): boolean => {
        let regex = /^(https?:\/\/)/;
        return regex.test(url);
    }

    return (
        <Drawer
            visible={props.openVisible}
            width={720}
            destroyOnClose
            forceRender
            onClose={closeDrawer}
            title={"Create a openAPI"}
            footer={
                <div style={{ textAlign: 'right' }}>
                    <Button type="primary" style={{ marginRight: 8 }} disabled={loading} loading={loading} onClick={() => form.submit()}>Save</Button>
                    <Button onClick={closeDrawer} >Cancel</Button>
                </div>
            }>

            <Spin spinning={loading}>
                <Form form={form} layout="vertical" onFinish={onFinish} onFinishFailed={onFailed}>
                    <Form.Item label="OpenAPI specification" name="specification" rules={[{ type: "url", required: false, message: 'Please enter the correct URL' }]}>
                        <Row>
                            <Col span={23}><Input onBlur={importOpenAPIByHttp} /> </Col>
                            <Col span={1}><span style={{paddingLeft:"5px"}} >or</span></Col>
                        </Row>
                    </Form.Item>
                    <Form.Item>
                        <Dragger beforeUpload={beforeUpload} multiple={false} onRemove={onRemove} fileList={fileList} accept="application/json" maxCount={1}>
                            <p className="ant-upload-drag-icon">
                                <InboxOutlined />
                            </p>
                            <p className="ant-upload-text">Click or drag file to this area to upload</p>
                            <p className="ant-upload-hint">(maximmum size 4 MiB)</p>
                        </Dragger>
                    </Form.Item>

                    <Form.Item label="Display Name" name="DisplayName" rules={[{ required: true, message: 'Please input Display name!' }]}>
                        <Input />
                    </Form.Item>
                    <Form.Item label="Version identifier" name="Identifier" rules={[{ required: true, message: 'Please input Version identifier!' }]}>
                        <Input />
                    </Form.Item>
                    <Form.Item label="Description" name="Description" >
                        <TextArea rows={3} placeholder="" />
                    </Form.Item>
                    <Form.Item label="Web Service URL" name="ServiceAddress" rules={[{ required: true, message: 'Please input Display name!' }]}>
                        <Input />
                    </Form.Item>

                    <Form.Item hidden label="URL scheme" name="scheme" initialValue={1} rules={[{ required: true, message: 'Please input Display name!' }]}>
                        <Radio.Group options={options} />
                    </Form.Item>

                    <Form.Item label="Node" name="NodeID" rules={[{ required: true, message: 'Please Select Node!' }]}>
                        <Select onChange={handleNodeChange} mode="multiple">
                            {
                                node && node.map(item => <Option value={item.key} key={item.key} nodeUrl={item.NodeUrl}>{item.value}</Option>)
                            }
                        </Select>
                    </Form.Item>
                    <Form.Item label="API URL suffix" name="Endpoint" rules={[{ required: true, message: 'Please input Display name!' }]}>
                        <Input onChange={handleUrlSuffixChange} />
                    </Form.Item>
                    <Form.Item label="Base URL" name="BaseUrl" rules={[{ required: true, message: 'Please input Display Base URL!' }]}>
                        <Input disabled />
                    </Form.Item>
                </Form>
            </Spin>


        </Drawer>
    );
}
export default CreateOpenAPIDrawer
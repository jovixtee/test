import React, { useState } from 'react';
import { Layout,Button, Modal } from 'antd';
import SiderNav from './SiderNav';
import ContentMain from './ContentMain';
import HeaderTool from './HeaderTool';
import './index.css';
import AveConfig from '../../common/AveConfig';
import PathConfig from '../../common/PathConfig';
const { Sider, Content } = Layout;

const Index = () => {
    const [collapsed, setCollapsed] = useState(false);
    const [isShowAbout, setIsShowAbout] = useState(false);
    
    // const [navigation, setNavigation] = useState({
    //     icon: <MailOutlined />,
    //     items: [{ href: "", label: "Application Center" }, { href: "", label: "Application List" }]
    // });

    // const OnNavigationChanged = (navItem: any) => {
    //     setNavigation(navItem);
    // }
    
    const AboutModal = () =>{
        return (
            <>
                <Modal 
                    title="About"
                    mask={true}
                    centered
                    width={520}
                    onCancel={()=>setIsShowAbout(false)}
                    visible={isShowAbout} 
                    footer={null}>
                    <div style={{ height: '200px' }}>
                        <div style={{ display:"flex",justifyContent:"center",alignItems:"center",paddingTop:32}}>
                            <div style={{ display:"flex",justifyContent:"center",alignItems:"center",marginRight:10}} >
                                <img style={{height:'38px'}}  alt="" src={PathConfig.addPrefix('/logo.svg')} />
                            </div>
                            <div style={{font:"normal normal bold 21px/27px Comfortaa"}}>
                                <span>{AveConfig.LOGO()}</span>
                            </div>
                        </div>
                        <div style={{marginTop:'31px',font:'normal normal normal 20px/27px Segoe UI',textAlign:'center'}}><span>Version: {AveConfig.VERSION()}</span></div>
                    </div>
                </Modal>
            </>
        );
    }

    return (
        <div id='page' style={{ height: '100vh', display: 'flex' }}>
            <Layout>
                <Sider trigger={null} collapsible collapsed={collapsed} width={260} collapsedWidth={60}
                    style={{
                        overflow: 'hidden',
                        height: '100vh'
                    }}>
                    <div className="site-sider-header" onClick={() => setCollapsed(!collapsed)} >
                        <div className="site-sider-logo" style={{ background: `url('${PathConfig.addPrefix("/logo.svg")}') no-repeat padding-box` }} />
                        <div className="site-sider-logo-font" hidden={collapsed} style={{fontFamily:'comfortaa'}}>{AveConfig.LOGO()}</div>
                    </div>
                    {/* <SiderNav onNavChanged={OnNavigationChanged} /> */}
                    <SiderNav/>
                </Sider>
                <Layout className="site-layout" style={{ overflowY: "scroll" }}>
                    <HeaderTool onAboutClick={()=>setIsShowAbout(true)}/>
                    <Content style={{ minHeight: 280, margin: '32px', overflow: 'initial' }} >
                        <ContentMain ></ContentMain>
                    </Content>
                    <AboutModal/>
                </Layout>
            </Layout>
        </div>
    );
};

export default Index;
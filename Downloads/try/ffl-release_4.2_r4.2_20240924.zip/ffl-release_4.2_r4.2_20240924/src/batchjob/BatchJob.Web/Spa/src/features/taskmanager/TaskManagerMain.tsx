import React, { useEffect } from 'react';
import { Tabs } from 'antd';
import TaskTable from './TaskTable';
import TaskGroupTable from './TaskGroupTable';
import TaskRepository from './TaskRepository';

const TaskManagerMain = () => {
    useEffect(() => {
        TaskRepository.getInstance().LoadActionSettingsAsync();
        TaskRepository.getInstance().LoadHolidayProfileAsync();
        TaskRepository.getInstance().LoadNotificationProfilesAsync();
        TaskRepository.getInstance().GetJobQueueNames();
    }, []);

    return (
        <Tabs defaultActiveKey={"1"} >
            <Tabs.TabPane tab="Tasks" key="1">
                <TaskTable />
            </Tabs.TabPane>
            <Tabs.TabPane tab="Groups" key="2">
                <TaskGroupTable />
            </Tabs.TabPane>
        </Tabs>
    );
};
export default TaskManagerMain;
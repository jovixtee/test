import React from 'react';
import { Button, Descriptions, Drawer } from 'antd';
import { TaskGroupDto } from './TaskManagerContract';

interface IProfileEditDrawerProps {
    Dto: TaskGroupDto,
    visible: boolean,
    onClose: Function,

}
const TaskGroupReadDrawer = (props: IProfileEditDrawerProps) => {

    return (<Drawer visible={props.visible} width={720} onClose={(e) => props.onClose()}
        title={"View profile"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" onClick={(e) => props.onClose()} >Close</Button>
            </div>
        }>
        <Descriptions column={1} bordered>
            <Descriptions.Item label="Group Name">{props.Dto.Name}</Descriptions.Item>
            
        </Descriptions>
    </Drawer>)
}

export default TaskGroupReadDrawer;
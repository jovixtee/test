import React, { FC, useEffect, useState } from 'react';
import { Drawer, Form, Input, Button, Spin } from 'antd';
import { ParameterTypeDto } from '../../common/contracts/ModelContracts';

import { CreateParameterType } from './FrontendAPIApiService';

interface IAPIParameterTypeForm {
    TypeName?: string;
    TypeJson?: string;
}

interface IManageAPITypeFormDrawerProps {
    visibile: boolean;
    cancelClick: VoidFunction;
    isEdit: boolean;
    editTypeData: ParameterTypeDto;
    apiId: string;
    refreshData: VoidFunction;
}



const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 16 },

};
const ManageAPITypeFormDrawer: FC<IManageAPITypeFormDrawerProps> = (props) => {
    const [loading, setLoading] = useState<boolean>(false);
    const [form] = Form.useForm();
    useEffect(() => {

        if (props.isEdit) {
            if (props.editTypeData.Id) {
                form.setFieldsValue({
                    TypeName: props.editTypeData.Name,
                    TypeJson: props.editTypeData.ExtensionJSON
                });
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.editTypeData.Id]);

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };
    const onFinish = (values: IAPIParameterTypeForm) => {
        setLoading(true);
        let requestObject = new ParameterTypeDto();
        requestObject.Name = values.TypeName;
        requestObject.ExtensionJSON = values.TypeJson;
        requestObject.FrontendId = props.apiId;
        if (props.isEdit) {
            requestObject.Id = props.editTypeData.Id;
        }
        CreateParameterType(requestObject)
            .then(res => {
                closeDrawer();
                props.refreshData();
            })
            .catch(err => {
                setLoading(false);

            })
    }
    const closeDrawer = (): void => {
        setLoading(false);
        form.resetFields();
        props.cancelClick()
    }

    return <Drawer
        visible={props.visibile}
        width={720}
        destroyOnClose
        forceRender
        onClose={closeDrawer}
        title={props.isEdit ? "Edit API Parameter Type" : "Create a new API Parameter Type"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" style={{ marginRight: 8 }} loading={loading} onClick={() => form.submit()}>Save</Button>
                <Button onClick={closeDrawer} >Cancel</Button>
            </div>
        }
    >
        <Spin spinning={loading}>
            <Form {...layout} form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '20px' }}>
                <Form.Item label="Type Name" name="TypeName" rules={[{ required: true, message: 'Please input Type Name!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Type Json" name="TypeJson" rules={[{ required: true, message: 'Please input Type Json!' }]}>
                    <Input.TextArea rows={8} />
                </Form.Item>
            </Form>
        </Spin>
    </Drawer>
}
export default ManageAPITypeFormDrawer
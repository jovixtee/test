import apiservice from '../../utils/fetchutil';
import { ControlPolicyDto, ControlPolicyRuleDto } from "../../common/contracts/ModelContracts";
import { PagerResult } from '../../common/contracts/PagerContracts';
import { message } from 'antd';
const serve = apiservice();

export const request = (params: any): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("", params).then((result) => {
            res(result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const PagerQueryControlPolicy = (params: any): Promise<PagerResult<ControlPolicyDto>> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/PagerControlPolicy", params).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const DeleteControlPolicy = (Ids: string[]): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteControlPolicy", { "dto": Ids }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}


export const CreateControlPolicy = (detail: ControlPolicyDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateControlPolicy", { "dto": detail }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateControlPolicyRule = (detail: ControlPolicyRuleDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateControlPolicyRule", { "dto": detail }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            if (result.EventCode === 0) {
                message.success(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetControlPolicyById = (id: string): Promise<ControlPolicyDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetControlPolicyById", { "id": id }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetControlPolicyRuleById = (id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetControlPolicyRuleById", { "id": id }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const DeleteControlPolicyRuleById = (id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteControlPolicyRuleById", { "id": id }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetViewControlPolicy = (name: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetViewControlPolicy", { "name": name }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const SortControlRulePolicyRule = (dto: ControlPolicyRuleDto[]): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/SortControlRulePolicyRule", {"dto":dto}).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}





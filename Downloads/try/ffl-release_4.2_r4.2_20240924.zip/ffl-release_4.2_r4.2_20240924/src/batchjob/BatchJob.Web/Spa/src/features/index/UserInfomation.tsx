import React from 'react';
import { Form, Drawer } from 'antd';

const UserInformation = (props: any) => {
    const [form] = Form.useForm();
    
    return (
        <Drawer
            forceRender
            title="User Information"
            width={720}
            onClose={() => { props.onCloseFun() }}
            visible={true}
          
        >
            <Form
                form={form}
                
            >
                <Form.Item
                    name="DisplayName"
                    label="Display Name"

                >
                    <div>{props.EditFormData.DisplayName}</div>
                </Form.Item>
                <Form.Item
                    name="Description"
                    label="Description"
                >
                    <div>{props.EditFormData.Description}</div>
                </Form.Item>
                <Form.Item
                    name="Username"
                    label="User Name"

                >
                    <div>{props.EditFormData.Username}</div>
                </Form.Item>
                <Form.Item
                    name="Email"
                    label="Email"

                >
                    <div>{props.EditFormData.Email}</div>
                </Form.Item>

            </Form>
        </Drawer>

    )

}
export default UserInformation;
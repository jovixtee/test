import React, { FC, useState, useEffect } from "react";
import { Breadcrumb, Row, Col, Space, Table, Input, Button, Drawer, List, Checkbox, Typography, Alert } from "antd";
import { ColumnsType } from "antd/lib/table";
import { IPaginationC, QueryFrontendPager } from "./FrontendAPIContracts";
import { FrontendAPIDto, VersionDetailsDto, PublishNodeDto } from '../../common/contracts/ModelContracts';
import VersionTable from './VersionTable';
import ManageAPIDrawer from './ManageAPIDrawer';
import ManageVersionDrawer from './ManageVersionDrawer';
import { FundViewOutlined, PlusOutlined } from '@ant-design/icons';
import { NodeDetail } from '../../common/contracts/ModelContracts';
import ManageAPIParameterTypeDrawer from './ManageAPIParameterTypeDrawer';
import "./frontendAPI.css";
import { CheckboxValueType } from "antd/lib/checkbox/Group";
import { PagerQueryFrontend, DeleteVersion, DeleteFrontend, GetAllAvailableNodes, PublishNodeMethod } from "./FrontendAPIApiService";



const { Text } = Typography;
const { Search } = Input;
const FrontendAPI: FC = () => {

    const [dataSource, setDataSource] = useState<FrontendAPIDto[]>(new Array<FrontendAPIDto>());
    const [currentPageData, setCurrentPageData] = useState<IPaginationC>({ currentPage: 1, currentPageSize: 10, total: 0 });
    const [searchText, setSearchText] = useState<string>("");
    const [isEditMode, setIsEditMode] = useState<boolean>(false);
    const [manageAPIDrawerVisible, setManageAPIDrawerVisible] = useState<boolean>(false);
    const [isEditVersionMode, setIsEditVersionMode] = useState<boolean>(false);
    const [manageVersionDrawerVisible, setManageVersionDrawerVisible] = useState<boolean>(false);
    const [versionDrawerApiId, setVersionDrawerApiId] = useState<string>("");
    const [versionDrawerVersionId, setVersionDrawerVersionId] = useState<string>("");
    const [apiDrawerDefaultData, setApiDrawerDefaultData] = useState<FrontendAPIDto>(new FrontendAPIDto());
    const [puiblishAPIDrawerVisible, setPuiblishAPIDrawerVisible] = useState<boolean>(false);
    const [publishNodeList, setPublishNodeList] = useState<NodeDetail[]>(new Array<NodeDetail>());
    const [checkedNodeList, setCheckedNodeList] = useState<any[]>([]);
    const [manageAPIParameterTypeDrawerVisible, setManageAPIParameterTypeDrawerVisible] = useState<boolean>(false);
    const [manageParameterTypeId, setManageParameterTypeId] = useState<string>("");
    const [selectedFrontendAPI, setselectedFrontendAPI] = useState<string>("");

    const [tableLoading, setTableLoading] = useState<boolean>(true);

    const tableColumn: ColumnsType<FrontendAPIDto> = [
        {
            title: 'Name',
            dataIndex: 'Name',
        },
        {
            title: 'BaseAddress',
            dataIndex: 'BaseAddress',
        },
        {
            title: 'Description',
            dataIndex: 'Description',
        },
        {
            title: 'Action',
            dataIndex: 'Action',
            render: (text, record) => <Space size="middle">
                <Button type='link' onClick={() => { onEditAPIClick(record) }}>Edit</Button>
                <Button type='link' onClick={() => { onAddVersionClick(record.Id) }}>Add Version</Button>
                <Button type='link' onClick={() => { onPublishAPIClick(record.Id) }}>Publish</Button>
                <Button type='link' onClick={() => { onManageMethodParameterClick(record.Id) }}>Manage Method Parameter Type</Button>
                <Button type='link' onClick={() => { onDeleteAPIClick(record.Id) }}>Delete</Button>

            </Space>
        }
    ]

    useEffect(() => {
        requestPagerQueryFrontend(1, searchText);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])


    const requestPagerQueryFrontend = (jumpPage: number, searchText: string) => {
        setTableLoading(true);
        PagerQueryFrontend({
            "pager": new QueryFrontendPager(currentPageData.currentPageSize, jumpPage, searchText)
        }).then(res => {
            setCurrentPageData({ ...currentPageData, currentPage: jumpPage, total: res.TotalNumber });
            console.log(res)
            if (res.Result) {
                setDataSource(res.Result);
            }
            setTableLoading(false)
        }).catch(err => {
            setTableLoading(false)
        })
    }
    const onSearch = (value: string): void => {
        setSearchText(value);
        requestPagerQueryFrontend(1, value)
    }


    const tablePageChange = (page: number, pageSize?: number | undefined): void => {
        requestPagerQueryFrontend(page, searchText)

    }

    const onImportAPIClick = (): void => {


    }
    const onDeleteAPIClick = (Id: string): void => {
        setTableLoading(true);
        DeleteFrontend(Id)
            .then(res => {
                requestPagerQueryFrontend(1, searchText)
            })
            .catch(err => {
                setTableLoading(false);
            })

    }
    const onPublishAPIClick = (Id: string): void => {
        setTableLoading(true);
        setPuiblishAPIDrawerVisible(true);
        setselectedFrontendAPI(Id);
        GetAllAvailableNodes()
            .then(res => {
                let list = new Array<NodeDetail>();
                if (res) {
                    res.Result?.map(item => list.push(item));
                }
                setPublishNodeList(list);
                setTableLoading(false);
            })
            .catch(err => {
                setTableLoading(false);
            })

    }
    const closePublishAPIDrewerClick = (): void => {
        setPuiblishAPIDrawerVisible(false);
        setPublishNodeList(new Array<NodeDetail>());
        setCheckedNodeList([]);
    }
    const submitPublishResult = (): void => {
        console.log(checkedNodeList)
        let dto: PublishNodeDto = { FrontendId: selectedFrontendAPI, NodeId: checkedNodeList.join(',') };
        PublishNodeMethod(dto)
            .then(ret => {
                setPuiblishAPIDrawerVisible(false);
                setTableLoading(false);
            })
            .catch(err => {
                setTableLoading(false);
            })
    }
    const checkPublishNodeChange = (checkedValues: CheckboxValueType[]): void => {
        setCheckedNodeList(checkedValues);
    }

    const onCreateAPIClick = (): void => {
        setIsEditMode(false);
        setApiDrawerDefaultData(new FrontendAPIDto())
        setManageAPIDrawerVisible(true);
    }
    const closeManageAPIDrawer = (): void => {
        setApiDrawerDefaultData(new FrontendAPIDto())
        setManageAPIDrawerVisible(false);

    }

    const onEditAPIClick = (record: FrontendAPIDto): void => {
        setIsEditMode(true);
        setApiDrawerDefaultData(record);
        setManageAPIDrawerVisible(true);

    }

    const onAddVersionClick = (apiId: string): void => {
        setIsEditVersionMode(false);
        setVersionDrawerApiId(apiId);
        setVersionDrawerVersionId("");
        setManageVersionDrawerVisible(true);


    }
    const onEditVersionClick = (apiId: string, versionRecord: VersionDetailsDto): void => {
        //console.log(apiId,versionRecord)
        setIsEditVersionMode(true);
        setVersionDrawerVersionId(versionRecord.Id)
        setVersionDrawerApiId(apiId);
        setManageVersionDrawerVisible(true);

    }

    const closeManageVersionDrawer = (): void => {
        setManageVersionDrawerVisible(false);
        setVersionDrawerApiId("");
        setVersionDrawerVersionId("");
    }

    const onDeleteVersion = (apiId: string, versionRecord: VersionDetailsDto) => {
        if (versionRecord.Id) {
            setTableLoading(true);
            DeleteVersion(versionRecord.Id)
                .then(res => {
                    requestPagerQueryFrontend(1, searchText)
                })
                .catch(err => {
                    setTableLoading(false);
                })
        }
    }

    const onManageMethodParameterClick = (apiId: string): void => {
        setManageParameterTypeId(apiId);
        setManageAPIParameterTypeDrawerVisible(true)
    }

    const closeManageAPIParameterTypeDrawer = (): void => {
        setManageAPIParameterTypeDrawerVisible(false)
        setManageParameterTypeId("");
    }


    return <React.Fragment>

        <Breadcrumb>
            <Breadcrumb.Item>Frontend API</Breadcrumb.Item>
        </Breadcrumb>
        <Row style={{ margin: '16px 0' }}>
            <Col span={18}>
                <Space size='small'>
                    <Button type="text" onClick={onCreateAPIClick}><PlusOutlined />Create</Button>
                    <Button type='text' icon={<FundViewOutlined />} onClick={onImportAPIClick}> Import</Button>
                </Space>
            </Col>
            <Col span={6}>
                <Search placeholder="input search text" allowClear onSearch={onSearch} style={{ width: 200, float: 'right' }} />
            </Col>
        </Row>

        <Table
            rowKey={record => record.Id}
            dataSource={dataSource}
            columns={tableColumn}
            expandable={{
                rowExpandable: (record) => (record.Versions && record.Versions.length > 0) ? true : false,
                expandedRowRender: (record) => <VersionTable
                    versionData={record.Versions}
                    apiId={record.Id}
                    versionEdit={(versionRecord: VersionDetailsDto) => { onEditVersionClick(record.Id, versionRecord) }}
                    versionDelete={(versionRecord: VersionDetailsDto) => { onDeleteVersion(record.Id, versionRecord) }}

                />
            }}
            pagination={{
                defaultPageSize: 10,
                defaultCurrent: 1,
                total: currentPageData.total,
                pageSize: currentPageData.currentPageSize,
                onChange: tablePageChange,
                current: currentPageData.currentPage
            }}
            loading={tableLoading}
        />

        <ManageAPIDrawer
            visibile={manageAPIDrawerVisible}
            cancelClick={closeManageAPIDrawer}
            isEdit={isEditMode}
            defaultData={apiDrawerDefaultData}
            getTableData={() => { requestPagerQueryFrontend(1, searchText) }}
        />
        <ManageVersionDrawer
            visibile={manageVersionDrawerVisible}
            cancelClick={closeManageVersionDrawer}
            isEdit={isEditVersionMode}
            apiId={versionDrawerApiId}
            versionId={versionDrawerVersionId}
            getTableData={() => { requestPagerQueryFrontend(1, searchText) }}
        />
        <ManageAPIParameterTypeDrawer
            cancelClick={closeManageAPIParameterTypeDrawer}
            visibile={manageAPIParameterTypeDrawerVisible}
            apiId={manageParameterTypeId}
        />

        <Drawer
            visible={puiblishAPIDrawerVisible}
            destroyOnClose
            width={720}
            title={"Publish API"}
            onClose={closePublishAPIDrewerClick}
            footer={
                <div style={{ textAlign: 'right', }}>
                    <Button type="primary" style={{ marginRight: 8 }} onClick={submitPublishResult}>Save</Button>
                    <Button onClick={closePublishAPIDrewerClick} >Cancel</Button>
                </div>
            }
        >
            <div style={{ marginBottom: 20 }}>
                <Text strong>Please Select Publich Node:</Text>
            </div>

            {
                (checkedNodeList && checkedNodeList.length > 0) && <Alert message={`Select ${checkedNodeList.length} Items`} type="info" />
            }


            <Checkbox.Group style={{ width: '100%', marginTop: 10 }} onChange={checkPublishNodeChange}>
                <List

                    dataSource={publishNodeList}
                    renderItem={(item) => <List.Item
                        key={item.Id}
                    >
                        <Checkbox value={item.Id}>{item.Host}</Checkbox>
                    </List.Item>}
                ></List>
            </Checkbox.Group>
        </Drawer>

    </React.Fragment>
}

export default FrontendAPI
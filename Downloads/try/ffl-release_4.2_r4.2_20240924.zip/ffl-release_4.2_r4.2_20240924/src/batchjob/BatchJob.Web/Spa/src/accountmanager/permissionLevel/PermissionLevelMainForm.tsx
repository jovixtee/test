import React, { useEffect, useState, useRef } from 'react';
import { Button, Drawer, Steps } from 'antd';
import GeneralForm from './GeneralForm';
import PermissionLevel from './PermissionLeavelForm';
import AssignForm from './AssignForm';
const { Step } = Steps;

const PermissionLevelMainForm: React.FC<any> = (props: any) => {
    const childRef: any = useRef();
    const [current, setCurrent] = useState<number>(0);
    const nextIsSuccess = (isSuccessed: boolean, values?: any) => {
        if (isSuccessed) {
            setCurrent(1)
            props.onGeneralData(values)
        }
    }
    const steps = [
        {
            title: 'General',
            content: <GeneralForm ref={childRef} {...props} nextIsSuccess={nextIsSuccess} ></GeneralForm>,
        },
        {
            title: 'Assign admins',
            content: <AssignForm  {...props} ref={childRef} />,
        },
        {
            title: 'PermissionLevel',
            content: <PermissionLevel  {...props} ref={childRef} />,
        },
    ];
    let onSave = () => {
        childRef.current.onSubmit()
    }
    
    const onNext = () => {
        if (current === 0) {
            childRef.current.onNext()
        }
        if (current === 1) {
            childRef.current.onNextAssign()
            setCurrent(2);
        }
    }
    const onBack = () => {
        setCurrent(current - 1);
    }
    useEffect(() => {
        setCurrent(0)
    }, [props.visible])
    return (
        <Drawer
            forceRender
            title={props.text}
            width={720}
            onClose={() => { props.onCloseFun() }}
            visible={props.visible}
            bodyStyle={{ paddingBottom: 80 }}
            footer={
                <div
                    style={{
                        textAlign: 'right',
                    }}
                >
                    {current > 0 && (
                        <Button onClick={onBack} style={{ marginRight: 8 }}>Back</Button>
                    )}
                    {current < steps.length - 1 && (
                        <Button onClick={onNext} type="primary" style={{ marginRight: 8 }}>Next</Button>
                    )}
                    {current === steps.length - 1 && (
                        <Button onClick={onSave} type="primary" style={{ marginRight: 8 }}> Save</Button>
                    )}
                    <Button onClick={() => { props.onCloseFun() }} >Cancel</Button>
                </div>
            }
        >
        <div style={{display:'flex'}}>

            <Steps current={current} 
            direction="vertical"
            style={{height:'180px',width:'240px'}}
            >
                {steps.map(item => (
                    <Step key={item.title} title={item.title} />
                ))}
            </Steps>
      
            <div className="steps-content" style={{width:'472px'}}
            >{steps[current].content}</div>
        </div>
        </Drawer>

    )
}
export default PermissionLevelMainForm;
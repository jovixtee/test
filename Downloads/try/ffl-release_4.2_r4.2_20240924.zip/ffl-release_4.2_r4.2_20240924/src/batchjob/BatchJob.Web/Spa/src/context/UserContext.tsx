import { UserManager } from 'oidc-client';
import { APMOidcConfig } from '../login/OidcConfig';
import { UserSummaryObject } from '../accountmanager/AccountManagerContract';
import React from 'react';

const UserContext = React.createContext<UserSummaryObject | undefined>(undefined);

export const APMOidcUserManager = new UserManager(APMOidcConfig);
export default UserContext;
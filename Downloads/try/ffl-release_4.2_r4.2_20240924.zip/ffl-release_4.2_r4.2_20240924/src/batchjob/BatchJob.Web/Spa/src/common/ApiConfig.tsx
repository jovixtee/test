import * as LSUtil from '../utils/localstorageutil';

interface IApiConfig {
    requestUrl: () => string;
    prefix:()=>string;
}

// function apiConfig(): IApiConfig {
//     let w = (window as any);
//     const config: IApiConfig = {
//         aveConfig: w.ave,
//         dbpRequestUrl: () => {
//             return w.ave.DBP_URL;
//         }
//     }
//     return config;
// }
// export default apiConfig;



class ApiJsConfig implements IApiConfig {
    private w: any;

    constructor() {
        this.load();
   }
    
   private load =() =>  {
        let local = (window as any).ave.LOCAL;
       if(local){
           this.w = (window as any).ave;
       }else{
           this.w = LSUtil.getItem("env-config");
       }
       return this.w;
   }

    /**
     * import form /public/index.html
     * <script src="/public/env-config.js"></script> 
     * @returns api request URL
     * use fetchutil.tsx
     */
    public requestUrl() {
        return this.load()?.API_URL;
    }

    public prefix() {
        return this.load()?.PREFIX;
    }
}

const ApiConfig = new ApiJsConfig();
export default ApiConfig;


import React, { useEffect } from 'react';
import { Button, Input, Form, Drawer } from 'antd';

const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 16 },
};

const UserEditForm = (props: any) => {
    const [form] = Form.useForm();
    const onSubmit = () => {
        form.submit();
    }
    const onFinish = (values: any) => {
        props.onGetData(Object.assign(props.EditFormData, values))
    };

    // useEffect(() => {
    //     form.resetFields();
    // })

    return (
        <Drawer
            forceRender
            title="User Setting"
            width={720}
            onClose={() => { props.onCloseFun() }}
            visible={true}
            bodyStyle={{ paddingBottom: 80 }}
            footer={
                <div
                    style={{
                        textAlign: 'right',
                    }}
                >
                    <Button onClick={onSubmit} type="primary" style={{ marginRight: 8 }}> Submit</Button>
                    <Button onClick={() => { props.onCloseFun() }} >Cancel</Button>

                </div>
            }
        >
            <Form
                onFinish={onFinish}
                form={form}
                initialValues={props.EditFormData}
                {...layout}
            >
              
                <Form.Item
                    name="DisplayName"
                    label="Display Name"
                    rules={[{ required: true, message: 'Display Name is required!' }]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    name="Description"
                    label="Description"
                >
                    <Input.TextArea />
                </Form.Item>
                <Form.Item
                    name="Username"
                    label="User Name"
                    rules={[
                        {
                            required: true,
                            message: 'Please input your User Name',
                        },
                    ]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    name="Password"
                    label="Password"
                    rules={[
                        {
                            required: true,
                            message: 'Please input your password!',
                        }
                    ]}
                    hasFeedback
                >
                    <Input placeholder="Please enter password" autoComplete="new-password" type="password" />
                </Form.Item>
                <Form.Item
                    name="NewPassword"
                    label="New Password"
                    rules={[
                        {
                            required: true,
                            message: 'Please input your password!',
                        },
                        {min:8, message:"At least 8 bits."},
                        {
                            pattern:/^(?=.*\d)(?=.*[a-zA-Z])(?=.*[~!@#$%^&*])[\da-zA-Z~!@#$%^&*]{8,}$/,
                            message:"must contain two or more types:uppercase letters,lowercase letters,numbers,special characters"
                        }
                    ]}
                    hasFeedback
                >
                     <Input placeholder="Please enter password" autoComplete="new-password" type="password" />
                </Form.Item>
                <Form.Item
                    name="confirm"
                    label="Confirm Password"
                    dependencies={['NewPassword']}
                    hasFeedback
                    rules={[
                        {
                            required: true,
                            message: 'Please confirm your password!',
                        },
                        ({ getFieldValue }) => ({
                            validator(rule, value) {
                                if (!value || getFieldValue('NewPassword') === value) {
                                    return Promise.resolve();
                                }
                                return Promise.reject('The two passwords that you entered do not match!');
                            },
                        }),
                    ]}
                >
                     <Input placeholder="Please enter password" autoComplete="new-password" type="password" />
                </Form.Item>
            </Form>
        </Drawer>

    )

}
export default UserEditForm;
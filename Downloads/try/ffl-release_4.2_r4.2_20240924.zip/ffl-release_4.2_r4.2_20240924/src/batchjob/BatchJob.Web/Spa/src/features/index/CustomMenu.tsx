import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu } from 'antd';
import { MailOutlined } from '@ant-design/icons';
import PathConfig from '../../common/PathConfig';
import { menus,findUrl,findItmes } from "./menu";

const CustomMenu = ({ menus, onMenuChanged }: any) => {
    let loca = useLocation();

    const [openKeys, setOpenKeys] = useState<any>([]);
    const [selectedKeys, setSelecteKeys] = useState<any>();
    useEffect(() => {
        const pathname = loca.pathname;
        //debugger
        //var s =  findItmes(menus,pathname);
        
        //var d = s.map(e=>e.key);

        var keys = findUrl(menus,pathname);
        if (keys && keys.length) {
            if (keys.length === 1) {
                setSelecteKeys(keys);
                setOpenKeys([]);
            } else {
                setSelecteKeys([keys.shift()]);
                setOpenKeys(keys);
            }
        }
    }, [loca.pathname, menus]);

    const onOpenChange = (nopenKeys: any) => {
        if (nopenKeys.length === 0 || nopenKeys.length === 1) {
            setOpenKeys(nopenKeys);
            return;
        }
        const latestOpenKey = nopenKeys[nopenKeys.length - 1];
        if (latestOpenKey.includes(nopenKeys[0])) {
            setOpenKeys(nopenKeys);
        } else {
            setOpenKeys([latestOpenKey]);
        }
    };
    const renderSubMenu = ({ key, icon, title, subs }: any) => {
        let newPath = PathConfig.addPrefix(key);
        return (
            <Menu.SubMenu key={newPath} title={<span>{icon || <MailOutlined />}<span>{title}</span></span>}>
                {
                    subs && subs.map((item: any) => {
                        return item.subs && item.subs.length > 0 ? renderSubMenu(item) : renderMenuItem({ parent: { key, icon, title, subs }, ...item })
                    })
                }
            </Menu.SubMenu>
        )
    };
    const renderMenuItem = ({ key, icon, title, parent }: any) => {
        let newPath = PathConfig.addPrefix(key);
        return (
            <Menu.Item key={newPath}>
                <Link to={newPath}>
                    {icon || <MailOutlined />}
                    <span>{title}</span>
                </Link>
            </Menu.Item>
        )
    };

    const OnSelectionChanged = ({ key, icon, title, parent }: any) => {
        const navItems = [];
        if (parent) {
            navItems.push({ href: parent.key, label: parent.title });
        }
        navItems.push({ href: key, label: title });
        const nav = { icon: icon, items: navItems };
        onMenuChanged(nav);
    };

    return (
        <Menu
            onOpenChange={onOpenChange}
            onClick={({ key }) => setSelecteKeys([key])}
            openKeys={openKeys}
            selectedKeys={selectedKeys}
            theme='dark'
            mode='inline'
        >
            {
                menus && menus.map((item: any) => {
                    return item.subs && item.subs.length > 0 ? renderSubMenu(item) : renderMenuItem(item)
                })
            }
        </Menu>
    );
};

export default CustomMenu;
import { ProtocolType } from "../NotificationSetting/NotificationSettingContracts";

export const PermissionConstants = {
    ObjectCode: 102001,
    Read: 1,
    Create: 2,
    Update: 4,
    Delete: 8
};


 
 

export class Recipients {
    Id?:string;
    Name?:string;
    Description?:string;
    ConnectionType?:ProtocolType;
    Contact?:string[];
    CreatedOn?: number;
    CreatedBy?: string;
    ModifiedOn?: number;
    ModifiedBy?: string;
}

//import { CascaderOptionType, CascaderValueType } from 'antd/lib/cascader';
import { useEffect, useState } from 'react';
import { GetSelects, GetVersionByBackendID } from './FrontendAPIApiService';
import { IDictionary } from './FrontendAPIContracts';

interface CascaderInstance {
    cascaderVaule: any | undefined,
    cascaderOptions: any[],
    cascaderLoadData: (selectedOptions: any[] | undefined) => void
    cascaderOnChange: (value: any, selectedOptions: any, changeCallBack?: ChangeCallBackFunction) => void
}
interface ChangeCallBackFunction {
    (value: any): void
}

// const optionLists: CascaderOptionType[] = [
//     {
//         value: '1',
//         label: 'API 1',
//         isLeaf: false,
//     },
//     {
//         value: '2',
//         label: 'API 2',
//         isLeaf: false,
//     },
// ];


// function useCascader(): [CascaderInstance, React.Dispatch<React.SetStateAction<string>>] {
function useCascader(): [CascaderInstance] {

    const [value, setValue] = useState<any>();
    const [options, setOptions] = useState<any[]>([]);
    // const [versionId, setVersionId] = useState<string>("");

    useEffect(() => {
        requestGetSelects();
    }, [])

    const requestGetSelects = (): void => {
        GetSelects(["BackendAPI"])
            .then(res => {
                let tempData = res.BackendAPI;
                if (tempData) {
                    let optionList = tempData.map(item => {
                        return {
                            value: item.key,
                            label: item.value,
                            isLeaf: false,
                        }
                    })
                    setOptions(optionList)
                }
            })
            .catch(err => {
            })
    }

    const onChange = (value: any, selectedOptions: any, changeCallBack?: ChangeCallBackFunction) => {
        setValue(value);
        changeCallBack && changeCallBack(value);
    };

    const loadData = async (selectedOptions: any[] | undefined) => {
        if (!selectedOptions || selectedOptions.length === 0) return;
        const targetOption = selectedOptions[selectedOptions.length - 1];
        const apiId = targetOption.value as string;
        console.log(targetOption)
        targetOption.loading = true;
        targetOption.children = [];
        try {
            let reqeustResult = await GetVersionByBackendID(apiId);
            let versionDictionary: IDictionary[] = reqeustResult?.Version;
            if (versionDictionary) {
                let versionList = versionDictionary.map(item => {
                    return {
                        label: item.value,
                        value: item.key
                    }
                })
                targetOption.children = versionList
            }
        } catch (e) {

        }
        if (targetOption.children.length === 0) {
            targetOption.disabled = true;
        }else{
            targetOption.disabled = false;
        }

        targetOption.loading = false;

        setOptions([...options]);
    };
    return [
        {
            cascaderVaule: value,
            cascaderOptions: options,
            cascaderLoadData: loadData,
            cascaderOnChange: onChange
        }
        // setVersionId =
    ]
}



export default useCascader
export interface PagerResult<T> {
    TotalNumber?: number;
    Result?: Array<T>;
};
export class PagerExpression {
    PageSize?: number;
    JumpPage?: number;
    IsSort?: boolean;
    IsDesc?: boolean;
    SortBy?: string;
    CurrentPage?: number;
    SearchValue?: string;
    SearcheKeys?: Array<string>;
    Filters?: Array<FilterCondition>;
}
export class FilterCondition {
    ColumnName?: string;
    ColumnIndex?: string
    ColumnValues?: Array<string>;
}

export class ImportArguments {
    FileName?: string;
}
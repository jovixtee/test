import React, { useState, useEffect } from "react";
import { TimePicker, Space, DatePicker } from "antd";
import { convertTicksToMoment, convertDateToTicks } from "../utils/dateconvert";
interface IDateTimeProps {
    // datetime ticks Value
    defaultValue?: number;
    value?: number;
    // changed callBack return datetime ticks value
    // no select :-1
    onChange?: (times: number) => void;
    // date format string for result view default "YYYY-MM-DD"
    dateFormat?: string;
    // time format string for result view default "HH:mm:ss"
    timeFormat?: string;
}
function DateTimePicker(props: IDateTimeProps) {
    const dateFormat: string = props.dateFormat || "YYYY-MM-DD";
    const timeFormat: string = props.timeFormat || "HH:mm:ss";
    const [value, setValue] = useState(props.value || props.defaultValue);
    const [timeString, setTimeString] = useState("");
    const [dateString, setDateString] = useState("");
    useEffect(() => {
        let moment = convertTicksToMoment(props.value as number || props.defaultValue as number);
        setDateString(moment.format(dateFormat));
        setTimeString(moment.format(timeFormat))
        setValue(props.value || props.defaultValue);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.value, props.defaultValue]);
    function timeOnChange(time: any, timeString: string): void {
        setTimeString(timeString);
        getTimes(dateString, timeString);
    }
    function onDateChange(date: any, dateString: string): void {
        setDateString(dateString);
        getTimes(dateString, timeString);
    }
    function getTimes(dateString: any, timestring: string): void {
        if (props.onChange) {
            if (dateString && timestring) {
                const value = convertDateToTicks(new Date(dateString + " " + timestring));
                // props.value = value;
                props.onChange(value);
            } else {
                // props.value = -1;
                props.onChange(-1);
            }
        }
    }
    return (
        <Space>
            <DatePicker
                defaultValue={value && value !== -1 ? convertTicksToMoment(value) : undefined}
                format={dateFormat}
                onChange={onDateChange} />
            <TimePicker
                defaultValue={value && value !== -1 ? convertTicksToMoment(value) : undefined}
                format={timeFormat}
                onChange={timeOnChange} />
        </Space>
    );
}

export default DateTimePicker;
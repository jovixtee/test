import { Button, Input, Radio, Checkbox, Select, Form, Drawer, Descriptions } from 'antd';
import React, { FC, useEffect, useState } from "react";
interface IProfileReadDrawerProps {
    visible: boolean;
    onClose: () => void;
    dataSource: any[];
}

const ProfileReadDrawer: FC<IProfileReadDrawerProps> = (props) => {
    const [data, setData] = useState<any[]>();
    useEffect(() => {
        if (props.visible && props.dataSource) {
            setData(props.dataSource);
        }
    }, [props.visible]);

    

    const renderItem = (data: any[]) => {
        return (
            <>
                <Descriptions column={1} bordered>
                    {
                        data?.map((item: any) => {
                            let obj = null;
                            switch (item.type) {
                                case "text":
                                    obj = (<Descriptions.Item label={item.key}>{item.value}</Descriptions.Item>);
                                    break;
                                case "radio":
                                    obj = (
                                        <Descriptions.Item label={item.key}>
                                            <Radio.Group disabled options={item.data} defaultValue={item.value} />
                                        </Descriptions.Item>
                                    );
                                    break;
                                case "checkbox":

                                    obj = (
                                        <Descriptions.Item label={item.key}>
                                            <Checkbox.Group disabled options={item.data} defaultValue={item.value} />
                                        </Descriptions.Item>
                                    );
                                    break;
                            }
                            return obj;
                        })
                    }
                </Descriptions>
            </>
        );
    }

    return (<Drawer visible={props.visible} width={720} onClose={(e) => props.onClose()}
        title={"View profile"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" onClick={(e) => props.onClose()} >Close</Button>
            </div>
        }>
        {renderItem(data!)}
    </Drawer>)
};

export default ProfileReadDrawer;
import { throws } from "assert";
import * as LSUtil from "../utils/localstorageutil";

interface IPathConfig {
  addPrefix: (path: string) => string;
}

class PathJsConfig implements IPathConfig {
  private w: any;

  constructor() {
    this.load();
  }

  private load = () => {
    let local = (window as any).ave.LOCAL;
    if (local) {
      this.w = (window as any).ave;
    } else {
      this.w = LSUtil.getItem("env-config");
    }
    return this.w;
  };

  public addPrefix(path: string) {
    return this.load() ? this.load().PREFIX + path : path;
  }
}

const PathConfig = new PathJsConfig();
export default PathConfig;

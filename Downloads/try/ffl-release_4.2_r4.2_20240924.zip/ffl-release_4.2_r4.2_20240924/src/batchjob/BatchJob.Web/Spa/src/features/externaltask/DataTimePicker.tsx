import React, { useState, useEffect } from "react";
import moment from "moment";
import { TimePicker, Space, DatePicker } from "antd";

interface IDateTimeProps {
    value?: string;
    onChange?: (date: string, time: string) => void;
    dateFormat?: string;
    timeFormat?: string;
}
const DataTimePicker = (props: IDateTimeProps) => {
    const dateFormat = props.dateFormat || "YYYY/MM/DD";
    const timeFormat = props.timeFormat || "HH:mm:ss";
    const [value, setValue] = useState(props.value);
    const [timeString, setTimeString] = useState("");
    const [dateString, setDateString] = useState("");
    useEffect(() => {
        setValue(props.value || "");
    }, [props.value]);
    const timeOnChange = (time: any, timestring: string) => {
        setTimeString(time);
        props.onChange && props.onChange(dateString, timestring);
    };
    const onDateChange = (date: any, dateString: string) => {
        setDateString(dateString);
        props.onChange && props.onChange(dateString, timeString);
    };
    return (
        <Space>
            <DatePicker defaultValue={value ? moment(value, dateFormat) : undefined} onChange={onDateChange} />
            <TimePicker defaultValue={value ? moment(value, timeFormat) : undefined} onChange={timeOnChange} />
        </Space>
    );
};
export default DataTimePicker;
import { PagerResult, ImportArguments } from '../../common/contracts/PagerContracts';
import { AdapterType, ConnectionAdapterDto } from '../connections/ConnectionContract';

export enum SyncOption {
    None,
    OneWay,
    TwoWay
}

export enum Confliction {
    None,
    SourceAlwaysWin
}

export enum AuthenticationType {
    None,
    WindowsAuthentication,
    SQLAuthentication
}

export enum MappingDBStatus {
    Enabled,
    Disabled
}

export enum DataSyncEventCode {
    Access,
    Detail,
    Update,
    Delete,
    Create,
}
export class TransferActionDto {
    Id?: string;
    Name?: string;
    SourceType?: AdapterType;
    DestType?: AdapterType;
    DisplayName?: string;
    Arguments?: string;
    SchemaXml?: string;
}

export class DocumentDto {
    Id?: string;
    Name?: string;
    SourceType?: AdapterType;
    DestType?: AdapterType;
    DisplayName?: string;
    Arguments?: string;
    SchemaXml?: string;
}

export class TransferDatabaseDto {
    Id?: string;
    Name?: string;
    DataBaseServerAddress?: string;
    DataBaseName?: string;
    AuthType?: AuthenticationType;
    Status?: MappingDBStatus;
    Account?: string;
    Password?: string;
    CreatedBy?: string;
    CreatedOn?: number;
    ModifiedBy?: string;
    ModifiedOn?: number;
    Description?: string;
}

export class TransferProfileDto {
    Id?: string;
    Name?: string;
    SourceAdapterId?: string;
    SourceAdapterName?: string;
    DestinationAdapterId?: string;
    ActionId?: string;
    DestinationAdapterName?: string;
    MappingDBId?: string;
    MappingDBName?: string;
    DataSyncXml?: string;
    DataSyncXmlName?: string;
    ProfileXml?: string;
    CreatedBy?: string;
    CreatedOn?: number;
    ModifiedBy?: string;
    ModifiedOn?: number;
    Description?: string;
    SyncOption?: SyncOption;
    Confliction?: Confliction;
    DocumentServiceId?:string;
    DocumentServiceName?:string;
}

export enum ServiceResultType {
    Success = 0,
    Failed = 1,
    Error = 2,
    Exception = 3,
}

export class TransferServiceResult {
    Type?: ServiceResultType;
    Message?: string;
    MappingDatabases?: Array<ConnectionAdapterDto>;
    PageredTransferProfiles?: PagerResult<TransferProfileDto>;
    TransferProfile?: TransferProfileDto;
    TransferActions?: Array<TransferActionDto>;
    Adapters?: Array<ConnectionAdapterDto>;
    DocumentService?: Array<ConnectionAdapterDto>;
}

export class TransferImportArguments extends ImportArguments {
    ProfileDto?: TransferProfileDto;
}

export const TransferPermissions = {
    ObjectCode: 201001,
    Read: 1,
    Create: 2,
    Update: 4,
    Delete: 8
};

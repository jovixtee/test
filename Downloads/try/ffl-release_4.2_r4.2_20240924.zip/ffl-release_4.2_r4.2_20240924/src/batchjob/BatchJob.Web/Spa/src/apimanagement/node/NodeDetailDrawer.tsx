import React, { FC, useEffect, useState } from 'react';
import { Drawer, Col, Row, Typography, Badge, Collapse } from 'antd';
import { NodeDetail} from '../../common/contracts/ModelContracts';
import { StatusType } from './NodeContract';
interface INodeDetailDrawerProps {
    Nodedata?: NodeDetail;
    visibile?: boolean;
    cancelClick: VoidFunction;
}
const { Text } = Typography;
const { Panel } = Collapse;
const NodeDetailDrawer: FC<INodeDetailDrawerProps> = (props) => {

    const [nodeData, setNodeData] = useState<NodeDetail>(new NodeDetail());

    useEffect(() => {
        
        if (props.Nodedata) {
            setNodeData(props.Nodedata)            
        }

    }, [props.Nodedata])


    return <Drawer
        visible={props.visibile}
        width={720}
        destroyOnClose
        forceRender
        onClose={props.cancelClick}
        title={"View Node Detail"}
    >

        <Row style={{ marginBottom: 10 }}>
            <Col span={4}> <Text strong>Host: </Text></Col>
            <Col span={20}><div style={{ marginLeft: "47px" }}>{nodeData.Host}</div></Col>
        </Row>
        <Row style={{ marginBottom: 10 }}>
            <Col span={4}> <Text strong>Host Name: </Text></Col>
            <Col span={20}><div style={{ marginLeft: "47px" }}>{nodeData.HostName}</div></Col>
        </Row>
        <Row style={{ marginBottom: 10 }}>
            <Col span={4}> <Text strong>Status: </Text></Col>
            <Col span={20}><div style={{ marginLeft: "47px" }}> <Badge status={"success"} text={nodeData.Status?StatusType[nodeData.Status]:""} /></div></Col>
        </Row>
        <Row style={{ marginBottom: 10 }}>
            <Col span={4}> <Text strong>Schema: </Text></Col>
            <Col span={20}><div style={{ marginLeft: "47px" }}>{nodeData.Schema}</div></Col>
        </Row>
        <Row style={{ marginBottom: 10 }}>
            <Col span={4}> <Text strong>Port: </Text></Col>
            <Col span={20}><div style={{ marginLeft: "47px" }}>{nodeData.Port}</div></Col>
        </Row>
        <Row style={{ marginBottom: 10 }}>
            <Col span={4}> <Text strong>Frontend API: </Text></Col>
            <Col span={20}>
                {
                    (nodeData.Frontend && nodeData.Frontend.length > 0)
                        ?
                        <Collapse bordered={false}>
                            {nodeData.Frontend.map((item, index) => {                           
                                return  <Panel header={<Text strong>{item.Name}</Text>} key={index}>
                                <Row style={{ marginBottom: 5 }}>
                                    <Col span={6}> <Text strong>Name: </Text></Col>
                                    <Col span={18}><div style={{ marginLeft: 0 }}>{item.Name}</div></Col>
                                </Row>
                                <Row style={{ marginBottom: 5 }}>
                                    <Col span={6}> <Text strong>BaseAddress: </Text></Col>
                                    <Col span={18}><div style={{ marginLeft: 0 }}>{item.BaseAddress}</div></Col>
                                </Row>
                                <Row style={{ marginBottom: 5 }}>
                                    <Col span={6}> <Text strong>Version: </Text></Col>
                                    <Col span={18}>
                                        {
                                            (item.Versions && item.Versions.length > 0)
                                                ?
                                                <Collapse bordered={false}>
                                                    {item.Versions.map((versionItem, versionIndex) => <Panel header={versionItem.Endpoint} key={versionItem.Id}>
                                                        <Row style={{ marginBottom: 5 }}>
                                                            <Col span={8}> <Text strong>VersionName: </Text></Col>
                                                            <Col span={16}><div style={{ marginLeft: 0 }}>{versionItem.Endpoint}</div></Col>
                                                        </Row>
                                                        <Row style={{ marginBottom: 5 }}>
                                                            <Col span={8}> <Text strong>Status: </Text></Col>
                                                            <Col span={16}><div style={{ marginLeft: 0 }}>{versionItem.Status?StatusType[versionItem.Status]:''}</div></Col>
                                                        </Row>
                                                        <Row style={{ marginBottom: 5 }}>
                                                            <Col span={8}> <Text strong>APIControl: </Text></Col>
                                                            <Col span={16}><div style={{ marginLeft: 0 }}>{versionItem.ControlPolicy}</div></Col>
                                                        </Row>
                                                        <Row style={{ marginBottom: 5 }}>
                                                            <Col span={8}> <Text strong>Authentication: </Text></Col>
                                                            <Col span={16}><div style={{ marginLeft: 0 }}>{versionItem.Authentication}</div></Col>
                                                        </Row>

                                                    </Panel>)}
                                                </Collapse>
                                                : <div>Not have Version</div>
                                        }

                                    </Col>
                                </Row>
                            </Panel>
                            
                           })}
                        </Collapse>
                        : <div style={{ marginLeft: "47px" }}>Not have Frontend API</div>
                }

            </Col>
        </Row>

    </Drawer>
}

export default NodeDetailDrawer
import React, { useState } from 'react';
import { message, Modal } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import PermissionLevelMainForm from './PermissionLevelMainForm';
import { RolePagedQuery, DeleteRoles, CreateRole, UpdateRole } from './permissionLevelApiServe';
import { hasPermission } from '../../utils/permissionutil';
import { userPermissionCostants } from '../user/UserApiServe'
import { QueryRoleDetail } from './permissionLevelApiServe';
import { convertTicksToFormatDate } from '../../utils/dateconvert';
import AmpCommonTable, { IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { ProfileReadDrawer } from './ProfileReadDrawer';
import { PagerExpression } from '../../common/contracts/PagerContracts';

const { confirm } = Modal;

const PermissionLevel = () => {
    const [visible, setVisible] = useState<any>(false);
    const [EditFormData, setEditFormData] = useState<any>({});
    const [EditGeneralFormData, setEditGeneralFormData] = useState<any>({});
    const [editVisible, setEditVisible] = useState<boolean>(false);
    const [showReadonlyDrawer, setShowReadonlyDrawer] = useState(false);
    const [drawerText, setDrawerText] = useState<string>('');

    const [refresh, setRefresh] = useState(1);
    const [selectedRowKeys, setSelectedRowKeys] = useState<any>([]);

    const columns = [
        {
            title: 'Permission Level Name',
            dataIndex: 'Name',
            key: 'Name',
            sorter: true,
            width: '24%',
            ellipsis: true,
            render: (name: any, obj: any, index: any) => <a onClick={() => viewProfile(obj)}>{name}</a>,
        }, {
            title: 'Description',
            dataIndex: 'Description',
            key: 'Description',
            ellipsis: true,
            width: '12%'
        }, {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
            width: '13%'
        }, {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            sorter: true,
            width: '13%',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
            width: '13%'
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            width: '25%',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }];


    let AddGeneralFormData: any = {}
    let UserId: object[] = []

    let addSource = () => {
        setVisible(true)
        setDrawerText('Add Permission Level')
    }
    let editSourceBtn = async () => {
        let result = await QueryRoleDetail({ RoleId: selectedRowKeys[0].RoleId })
        setEditFormData({ ...result.Result });
        setEditVisible(true)
        setDrawerText('Edit Permission Level')
    }
    let deleteSourceBtn = () => {
        confirm({
            title: 'Warning',
            icon: <ExclamationCircleOutlined />,
            content: 'You are about to delete the selected items. Are you sure you want to proceed?',
            onOk() {
                deleteSource()
            },
            onCancel() {
            },
        })
    }
    let deleteSource = async () => {
        let data = selectedRowKeys.map((item: { RoleId: any; }) => {
            return item.RoleId
        })
        await DeleteRoles({ roleIds: data }).finally(() => {
            setRefresh(refresh + 1);
        });
    }

    const onCloseFun = () => {
        setVisible(false)
    }
    const onEditCloseFun = () => {
        setEditVisible(false)
    }

    const getAddAssignFormData = (userId: string[]) => {
        UserId = userId.map((value) => {
            return {
                UserId: value
            }
        })
    }

    const getAddGeneralFormData = (values: any) => {
        AddGeneralFormData = values
        console.log(values)
    }

    const getAddLevelFormData = async (values: any) => {
        console.log(values)
        setVisible(false)
        let Privileges = values.selectedRows.map((item: any) => {
            let AccessRight = 0
            item.checkedValues.forEach((right: number) => {
                AccessRight = AccessRight | right
            })
            return {
                PrivilegeId: item.PrivilegeId,
                AccessRight: AccessRight
            }
        })
        let params = {
            roleDetail: {
                Role: {
                    Name: AddGeneralFormData.Name,
                    Description: AddGeneralFormData.Description
                },
                Users: [...UserId],
                Privileges: [...Privileges]
            }
        }
        await CreateRole(params).then(res => {
            if (res.Type === 0) {
                message.success(res.Message);
            } else {
                message.error(res.Message);
            }
        }).finally(() => {
            setRefresh(refresh + 1);
        })

    };

    const getEditFormData = async (data: any) => {
        console.log(data)
        setEditVisible(false);
        let Privileges = data.selectedRows.map((item: any) => {
            let AccessRight = 0
            item.checkedValues.forEach((right: number) => {
                AccessRight = AccessRight | right
            })
            return {
                PrivilegeId: item.PrivilegeId,
                AccessRight: AccessRight
            }
        })
        console.log(Privileges)
        let params = {
            roleDetail: {
                Role: {
                    RoleId: data.Role.RoleId,
                    Name: data.Role.Name,
                    Description: data.Role.Description
                },
                Users: [...data.UserId],
                Privileges: [...Privileges]
            }
        }
        await UpdateRole(params).then(res => {
            if (res.Type === 0) {
                message.success(res.Message);
            } else {
                message.error(res.Message);
            }
        }).finally(() => {
            setRefresh(refresh + 1);
        });
    }

    const getEditAssignFormData = (userId: string[]) => {
        console.log(userId)
        UserId = userId.map((value) => {
            return {
                UserId: value
            }
        })
    }

    const getEditGeneralFormData = (values: any) => {
        setEditGeneralFormData(values)
        console.log(values)
    }

    const getEditLevelFormData = async (values: any) => {
        getEditFormData(Object.assign(values, EditGeneralFormData, { UserId: UserId }))
        setVisible(false)
    };

    const buttons: Array<IAmpTableButton> = [{
        Text: "Create",
        Primary: true,
        Icon: <PlusOutlined />,
        OnClick: addSource,
        EnableMode: 'always',
        HasPermission: hasPermission(userPermissionCostants.ObjectCode, userPermissionCostants.Create)
    }, {
        Text: "Edit",
        Icon: <EditOutlined />,
        OnClick: editSourceBtn,
        EnableMode: 'single',
        HasPermission: hasPermission(userPermissionCostants.ObjectCode, userPermissionCostants.Update)
    }, {
        Text: "Delete",
        Icon: <DeleteOutlined />,
        OnClick: deleteSourceBtn,
        EnableMode: 'multiple',
        HasPermission: hasPermission(userPermissionCostants.ObjectCode, userPermissionCostants.Delete)
    }];


    let viewProfile = async (obj: any) => {
        let result = await QueryRoleDetail({ RoleId: obj.RoleId })
        setEditFormData({ ...result.Result });
        setShowReadonlyDrawer(true);
    }


    const ApiPagerQuery = async (exp: PagerExpression) => {
        let param = { expression: { ...exp } }
        let result = await RolePagedQuery(param);
        return { total: result!.Result!.TotalNumber, records: result!.Result!.Result };
    }

    return (
        <div>

            <AmpCommonTable
                Type="checkbox"
                RowKey="RoleId"
                Columns={columns}
                PagerQuery={ApiPagerQuery}
                OnSelectedChanged={records => setSelectedRowKeys(records)}
                SearchKeys={["Name"]}
                Refresh={refresh}
                Buttons={buttons}
                EnableSearch />


            {visible &&
                <PermissionLevelMainForm
                    text={drawerText}
                    EditFormData={{ Privileges: [], Role: {}, Users: [] }}
                    onCloseFun={onCloseFun}
                    visible={visible}
                    onLevelFormData={getAddLevelFormData}
                    onGeneralData={getAddGeneralFormData}
                    onAssignFormData={getAddAssignFormData}
                />}

            {editVisible &&
                <PermissionLevelMainForm
                    text={drawerText}
                    EditFormData={EditFormData}
                    onCloseFun={onEditCloseFun}
                    visible={editVisible}
                    onLevelFormData={getEditLevelFormData}
                    onGeneralData={getEditGeneralFormData}
                    onAssignFormData={getEditAssignFormData}
                />}

            {showReadonlyDrawer &&
                <ProfileReadDrawer
                    visible={showReadonlyDrawer}
                    profileDto={EditFormData}
                    onClose={() => setShowReadonlyDrawer(false)} />}

        </div>
    );
};
export default PermissionLevel;
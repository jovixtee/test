import TaskManagerApiService from './TaskManagerApiService';
import { TaskActionSettingDto } from './TaskManagerContract';
import { HolidayProfileBase } from '../holidaysetting/HolidaySettingContract';

class TaskRepository {
    private constructor() { }
    private static instance: TaskRepository;
    public static getInstance(): TaskRepository {
        if (this.instance == null) {
            this.instance = new TaskRepository();
        }
        return TaskRepository.instance;
    }
    public ActionSettings?: TaskActionSettingDto[];
    public LoadActionSettingsAsync = () => {
        TaskManagerApiService.getInstance().GetAllActionSettings(result => {
            this.ActionSettings = result?.ActionSettings;
        })
    }
    public HolidayProfile?: HolidayProfileBase[];
    public LoadHolidayProfileAsync = () => {
        TaskManagerApiService.getInstance().LoadHolidayProfileAsync(result => {
            this.HolidayProfile = result?.Profiles as HolidayProfileBase[];
        })
    }
    public NotificationProfiles?: any[];
    public LoadNotificationProfilesAsync = () => {
        TaskManagerApiService.getInstance().LoadNotificationProfilesAsync(result => {
            this.NotificationProfiles = result?.Result;
        })
    }


    public QueueNames?: any[];
    public GetJobQueueNames = () => {
        TaskManagerApiService.getInstance().GetJobQueueNames(result => {
            this.QueueNames = result?.JobQueueNames.map((item:any)=>item.replace("MarsEvent_",""));
        })
    }

}

export default TaskRepository;
/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
import {ConfigEnv, defineConfig, UserConfig} from 'vite';
import react from '@vitejs/plugin-react';
import basicSsl from '@vitejs/plugin-basic-ssl';
import {resolve} from 'path';
import dns from 'dns';

dns.setDefaultResultOrder('verbatim');


// https://vitejs.dev/config/
export default ({mode}: ConfigEnv): UserConfig => {
    //const isDev = mode === 'development';
    //let baseUrl = '/ptlweb/';
    //if (isDev) {
    //    baseUrl = './';
    //}
    let baseUrl = './';
    return {
        base: baseUrl,
        server: {
            host: '10.1.72.24',
            port: 8010,
            https: false,
            proxy: {
                '/api': {
                    target: 'https://10.1.72.24:8443/',
                    changeOrigin: true,
                    secure: false,
                    ws: true
                }
            }
        },
        // plugins: [react(), basicSsl()],
        plugins: [react()],
        css: {
            preprocessorOptions: {
                less: {
                    math: 'always',
                    globalVars: {},
                    javascriptEnabled: true
                }
            }
        },
        resolve: {
            alias: {
                '@': resolve(__dirname, './src')
            }
        },
        build: {
            outDir: 'build',
        }
    }
}

import apiservice from '../../utils/fetchutil';
const serve = apiservice()
export const UserPagedQuery = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/UserPagedQuery", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const DeleteUser = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/DeleteUser", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const UpdateUser = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/UpdateUser", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const UpdateUserStatus = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/UpdateUserStatus", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}

export const UpdateUsersStatus = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/UpdateUsersStatus", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}

export const CreateAccount = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/CreateAccount", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const QueryRoleAll = (): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/QueryRoleAll").then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const QueryUserDetail = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/QueryUserDetail", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const userPermissionCostants = {
    ObjectCode: 101001,
    Read: 1,
    Create: 2,
    Update: 4,
    Delete: 8
}
export const CheckAdminUser = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/IAccountManagerService/CheckAdminUser", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
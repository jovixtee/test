import { Button, Drawer, Form, Input, Select, Collapse, Upload, Space, Table, message } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import * as ReplicatorContract from '../ReplicatorContract';
import { GetApiService } from '../ReplicatorApiService';
import { UploadOutlined, MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { UploadFile } from 'antd/lib/upload/interface';
import { ConnectionAdapterDto, AdapterType } from '../../features/connections/ConnectionContract';
import UINotrification from '../../common/UINotrification';
const { TextArea } = Input;
interface IDataPiplineProps {
  visible: boolean;
  onCancel: Function;
  refresh: Function;
  dataSource?: ReplicatorContract.ReplicatorPipline;
}

export const DataPiplineDrawer = (props: IDataPiplineProps) => {
  const [form] = Form.useForm();
  const [actions, setActions] = useState<Array<ReplicatorContract.ReplicatorActionsDto>>([]);
  const [adapters, setAdapters] = useState<Array<ConnectionAdapterDto>>([]);
  const [connManager, setConnManager] = useState<Array<ReplicatorContract.ConnManager>>([]);
  const [selectedAction, setSelectedAction] = useState<ReplicatorContract.ReplicatorActionsDto>({});
  const [fileList, setFileList] = useState<any[]>([]);
  const [uploadFile, setUploadFile] = useState<UploadFile>();
  const [connectionAdapterTemp, setConnectionAdapterTemp] = useState<any[]>([]);
  const [connectionInfo, setConnectionInfo] = useState({});
  const [sftpFolder, setSftpFolder] = useState('');
  const [tableVisable, setTableVisable] = useState<boolean>(true);

  const getConnectionName = (id: string): string => {
    return adapters.find((a) => a.Id === id)?.AdapterName ?? '';
  };

  useEffect(() => {
    GetApiService()
        .GetReplicatorResources()
        .then((result) => {
          if (result.Action) {
            setActions(result.Action!);
          }
          if (result.Adapters) {
            setAdapters(result.Adapters!);
          }
        });
  }, [props.visible]);

  useEffect(() => {
    if (props.visible && props.dataSource) {
      const data = props.dataSource;
      const files = [];
      if (data.ProfileJsonName) {
        files.push({ name: data.ProfileJsonName });
      }
      const action = actions.find((a) => a.Id === data.ActionId);
      onActionChanged(action?.Id);
      form.setFieldsValue({
        Name: data.Name,
        UniqueName: data.UniqueName,
        ActionId: data.ActionId,
        Description: data.Description,
        connManager: assemblyConnManager(data.ConnManager!),
        ProfileJSON: files
      });
    } else {
      setTableVisable(false);
      setSelectedAction({});
      form.resetFields();
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form, props.visible, props.dataSource, actions, fileList]);

  const assemblyConnManager = (connArray: any[]) => {
    return connArray.map((e: any) => {
      const conn: any = {};
      const key = e['AdapterTitle'];
      const val = e['AdapterId'];
      const folder = e['SftpFolder'];
      conn[key] = `${val}@${key}`;
      if (folder) {
        conn['SftpFolder'] = folder;
      }
      return conn;
    });
  };

  const beforeUpload = (file: any, FileList: UploadFile[]) => {
    const isLt4M = file.size / 1024 / 1024 < 4;
    if (!isLt4M) {
      setFileList([]);
      UINotrification.error('file must smaller than 4MB!');
      return false;
    } else {
      setUploadFile(file);
    }
    return true;
  };

  const normFile = (e: any) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };

  useEffect(() => {
    // Edit init
    if (props.visible && props.dataSource && selectedAction.Id === props.dataSource.ActionId) {
      const data = props.dataSource;
      let sftpFolder = '';
      const ConnectionTemp: any = [];
      const ConnectionInfoTemp: { [key: string]: any } = {};
      if (data.ConnManager && data.ConnManager!.length > 0) {
        data.ConnManager.sort((a, b) => Number(a.Index) - Number(b.Index));
      }
      data.ConnManager!.forEach((item, index) => {
        const num = connManager.filter((i) => {
          if (i.ConnectionName === item.AdapterTitle) return i;
        });
        const connectionItem = item;
        if (num.length > 0) {
          if (selectedAction.Id != data.ActionId) {
            connectionItem.AdapterName = undefined;
          } else {
            sftpFolder = item.SftpFolder!;
          }
          const sn = item.Index ? item.Index : (index + 1).toString();
          ConnectionTemp.push({
            SN: sn,
            ConnectionName: item.AdapterTitle || '',
            ConnectionInfo: [connectionItem] || [],
            Parameter: [item] || []
          });
          if (item.AdapterTitle) {
            ConnectionInfoTemp[item.AdapterTitle + '__' + sn] = item.AdapterId + '@' + item.AdapterTitle;
          }
          if (item.SftpFolder) {
            setSftpFolder(sftpFolder);
          }
        }
      });
      setConnectionInfo(ConnectionInfoTemp);
      setConnectionAdapterTemp(ConnectionTemp);
    }
    // Create init
    else {
      const ConnectionTemp: any = [];
      connManager.map((i, k) => {
        const connectionItem: any = [];
        adapters.map((item) => {
          if (i.ConnectionType === item.AdapterType) {
            if (i.ConnectionType === 2) {
              connectionItem.push({
                AdapterId: item.Id,
                AdapterName: undefined,
                AdapterTitle: i.ConnectionName,
                SftpFolder: ''
              });
            } else {
              connectionItem.push({
                AdapterId: item.Id,
                AdapterName: undefined,
                AdapterTitle: i.ConnectionName
              });
            }
          }
        });
        ConnectionTemp.push({
          SN: (k + 1).toString(),
          ConnectionName: i.ConnectionName || '',
          ConnectionInfo: [connectionItem[0]] || [],
          Parameter: [connectionItem[0]] || []
        });
      });
      // empty connection state
      setConnectionInfo({});
      setSftpFolder('');
      setConnectionAdapterTemp(ConnectionTemp);
    }
  }, [connManager, actions]);

  const onActionChanged = (value: any) => {
    if (value) {
      const item = actions.find((a) => a.Id === value);
      setSelectedAction(item ?? {});
      setConnManager(item!.ConnManager!);
      setTableVisable(true);
      //const src = adapters.filter(ad => ad.AdapterType === item?.SourceType);
      // setSrcAdapters(src ?? new Array<ConnectionAdapterDto>());

      //const dest = adapters.filter(ad => ad.AdapterType === item?.DestType);
      //setDestAdapters(dest ?? new Array<ConnectionAdapterDto>());
    }
  };

  const onFinish = async (values: any) => {
    const pipline = new ReplicatorContract.ReplicatorPipline();
    if (props.dataSource) {
      pipline.Id = props.dataSource.Id;
    }
    pipline.Name = values.Name;
    const reString = /^[a-zA-Z0-9_]{1,}$/;
    pipline.UniqueName = values.UniqueName;
    if (!values.UniqueName.match(reString)) {
      message.warning('Unique name contains special characters,please change it and retry.');
    } else {
      pipline.ActionId = values.ActionId;
      pipline.Description = values.Description;

      const connections: any = [];
      Object.keys(connectionInfo).forEach((key) => {
        const realKey = key.split('__')[0];
        if (realKey == 'SFTP') {
          connections.push({
            [key]: connectionInfo[key as keyof typeof connectionInfo],
            SftpFolder: sftpFolder
          });
        } else {
          connections.push({
            [key]: connectionInfo[key as keyof typeof connectionInfo]
          });
        }
      });
      pipline.ConnManager = assemblyAdapter(connections);
      GetApiService()
          .SaveReplicatorPipline(pipline, uploadFile)
          .then((res) => {
            if (res.Type === ReplicatorContract.ServiceResultType.Success) {
              UINotrification.success(
                  props?.dataSource ? 'Update replicator pipline success' : 'Create replicator pipline success'
              );
              props.onCancel();
              props.refresh();
            } else {
              UINotrification.error('Save failed');
            }
          });
    }
  };

  const assemblyAdapter = (connArray: any[]) => {
    return connArray.map((e: any) => {
      const conn = new ReplicatorContract.Adapter();
      const keys = Object.keys(e);
      keys.forEach((key) => {
        if (key !== 'SftpFolder') {
          const val: string = e[key];
          const data = val.split('@');
          conn.Index = key.split('__')[1];
          conn.AdapterId = data[0];
          conn.AdapterName = getConnectionName(data[0]);
          conn.AdapterTitle = data[1];
        } else {
          conn.SftpFolder = e[key];
        }
      });
      return conn;
    });
  };

  const handleChange = (info: any) => {
    let keyList = [...info.fileList];
    keyList = keyList.slice(-2);
    setFileList(keyList);
  };

  const onRemove = (file: any) => {
    setFileList([]);
    setUploadFile(undefined);
  };

  const onFinishFailed = (errorInfo: any) => { };

  const OnSelectedChanged = (value: any, id: string) => {
    setConnectionInfo((prevState) => {
      return { ...prevState, [id]: value };
    });
  };

  const OnInputChanged = (e: any, id: any) => {
    setSftpFolder(e.target.value);
  };

  const columns = [
    {
      title: 'SN',
      dataIndex: 'SN',
      key: 'SN',
      width: '10%'
    },
    {
      title: 'Connection Type',
      dataIndex: 'ConnectionName',
      key: 'ConnectionName',
      width: '20%'
    },
    {
      title: 'Connection Info',
      dataIndex: 'ConnectionInfo',
      width: '30%',
      render: (ConnectionInfo: any, index: any) => {
        if (!ConnectionInfo?.[0]) {
          return '';
        }
        const type = adapters.filter((ad) => ad.Id === ConnectionInfo[0]!.AdapterId).map((item) => item.AdapterType)[0];
        const infoKey = ConnectionInfo[0]!.AdapterTitle + '__' + index.SN;
        const selectValue = connectionInfo[infoKey as keyof typeof connectionInfo] ?? undefined;
        return (
            <Select
                dropdownMatchSelectWidth={180}
                style={{ minWidth: 180 }}
                placeholder="Select One"
                value={selectValue}
                allowClear
                onChange={(value) => {
                  OnSelectedChanged(value, infoKey);
                }}
            >
              {ConnectionInfo.map((item: any) => {
                return adapters
                    .filter((ad) => ad.AdapterType === type)
                    .map((i) => {
                      return (
                          <Select.Option key={i.Id} value={`${i.Id as string}@${item!.AdapterTitle}`} label={i.AdapterName}>
                            {i.AdapterName}
                          </Select.Option>
                      );
                    });
              })}
            </Select>
        );
      }
    },
    {
      title: 'Parameter',
      dataIndex: 'Parameter',
      width: '40%',
      render: (Parameter: any, index: any) => {
        return Parameter?.[0]?.SftpFolder != undefined ? (
            <div>
              <Input
                  id={'sftpFolder'}
                  value={sftpFolder}
                  onChange={(value) => {
                    OnInputChanged(value, 'SftpFolder');
                  }}
              />
            </div>
        ) : (
            ''
        );
      }
    }
  ];

  return (
      <Drawer
          visible={props.visible}
          width={720}
          onClose={(e) => props.onCancel()}
          title={props?.dataSource ? 'Edit data pipline' : 'Create a new data pipline'}
          footer={
            <div style={{ textAlign: 'right' }}>
              <Button type="primary" style={{ marginRight: 8 }} onClick={() => form.submit()}>
                Save
              </Button>
              <Button onClick={(e) => props.onCancel()}>Cancel</Button>
            </div>
          }
      >
        <Form onFinish={onFinish} onFinishFailed={onFinishFailed} form={form} layout="vertical">
          <Form.Item name="Name" label="Name" key="Name" rules={[{ required: true, message: 'Please input name' }]}>
            <Input />
          </Form.Item>

          <Form.Item
              name="UniqueName"
              label="Unique Name"
              key="UniqueName"
              rules={[{ required: true, message: 'Please input Unique Name' }]}
          >
            <Input disabled={props.dataSource ? true : false} />
          </Form.Item>

          <Form.Item name="Description" label="Description" key="Description">
            <Input.TextArea />
          </Form.Item>

          <Form.Item
              label="Action"
              name="ActionId"
              key="ActionId"
              rules={[{ required: true, message: 'Please select an action.' }]}
          >
            <Select
                placeholder="Select One"
                showSearch
                onChange={onActionChanged}
                filterOption={(input: any, option: any) => option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
            >
              {actions.map((item) => (
                  <Select.Option key={item.Id} value={item.Id as string} label={item.DisplayName}>
                    {item.DisplayName}
                  </Select.Option>
              ))}
            </Select>
          </Form.Item>
          <Collapse defaultActiveKey={['1']} style={{ marginBottom: 20 }}>
            <Collapse.Panel header="Action Description" key="1">
              <TextArea readOnly style={{ height: 120 }} bordered={false} value={selectedAction.Description} />
            </Collapse.Panel>
          </Collapse>

          {/* {connManager.map((item,index) => (
          <>
            <Form.Item key={item.ConnectionName} label={item.ConnectionName} name={["connManager",index,item.ConnectionName!]}  rules={[{ required: true, message: `Please select ${item.ConnectionName}` }]}>
              <Select placeholder="Select One" allowClear getPopupContainer={triggerNode => triggerNode.parentNode} >
                  {adapters.filter(ad => ad.AdapterType === item!.ConnectionType).map((i) => (
                      <Select.Option key={i.Id} value={`${i.Id as string}@${item!.ConnectionName}`} label={i.AdapterName}>
                          {i.AdapterName}
                      </Select.Option>
                  ))}
              </Select>
            </Form.Item>
            {AdapterType.SFTP ===item.ConnectionType &&
             <>
              <Form.Item
                  name={["connManager",index,"SftpFolder"]}
                  key="SftpFolder"
                  label={`${item.ConnectionName} SftpFolder`}
                  rules={[{ required: true, message: "Please input sftp folder" }]}
                >
              <Input />
            </Form.Item>
             </>
            }
          </> 
        ))}  */}

          <Form.Item
              label="Upload Parameter File"
              name="ProfileJSON"
              valuePropName="fileList"
              getValueFromEvent={normFile}
          >
            <Upload multiple={false} accept={'.json'} maxCount={1} beforeUpload={beforeUpload}>
              <Button icon={<UploadOutlined />}>Click to upload</Button>
            </Upload>
          </Form.Item>
        </Form>

        {tableVisable && connManager.length > 0 && (
            <Table columns={columns} dataSource={connectionAdapterTemp} scroll={{ x: 680 }} rowKey="SN"></Table>
        )}
      </Drawer>
  );
};

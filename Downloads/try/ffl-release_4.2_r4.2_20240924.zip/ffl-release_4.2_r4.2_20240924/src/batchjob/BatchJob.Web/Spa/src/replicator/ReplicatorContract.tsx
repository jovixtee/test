import { PagerResult } from "../common/contracts/PagerContracts";
import {
  AdapterType,
  ConnectionAdapterDto,
} from "../features/connections/ConnectionContract";

export class ReplicatorsResult {
  ManifestDto?: Array<ManifestDto>;
  Adapters?: Array<ConnectionAdapterDto>;
  Action?: Array<ReplicatorActionsDto>;
  PageredReplicatorPipline?: PagerResult<ReplicatorPipline>;
  PageredReplicatorPlan?: PagerResult<ReplicatorPlan>;
  Pipline?: ReplicatorPipline;
  Plan?: ReplicatorPlan;
  Type?: ServiceResultType;
  Corpus?: CorpusDto;
  TreeData?: Array<any>;
  TargetEntities?: Array<DatamodelingEntity>;
  SourceEntities?: Array<DatamodelingEntity>;
  EntityAttributes?: Array<EntityAttributes>;
}

export class FieldMappings {
  Id?: string;
  TargetAttribute?: string;
  TargetDataType?: string;
  SourceAttribute?: string;
  SourceDataType?: string;
}

export class EditTableData extends FieldMappings {
  IsEdit: boolean = false;
  IsNewData: boolean = false;
}

export interface IEditTableRef {
  getTableResult: () => {
    addData: FieldMappings[];
    updateData: FieldMappings[];
    deleteData: FieldMappings[];
  };
}

export class OperationFieldMappings {
  addData?: FieldMappings[];
  updateData?: FieldMappings[];
  deleteData?: FieldMappings[];
}

export enum ServiceResultType {
  Success = 0,
  Failed = 1,
  Error = 2,
  Exception = 3,
}

export enum ServiceType {
  Source = 0,
  Target = 1,
}

export enum FileType {
  Corpus = 1,
  Manfest = 2,
}

export class CorpusDto {
  Id?: string;
  DisplayName?: string;
  UniqueName?: string;
  Description?: string;
  CreatedOn?: number;
  CreatedBy?: string;
  ModifiedOn?: string;
  ModifiedBy?: number;
}

export class DatamodelingDocument {
  DisplayName?: string;
  Type?: FileType;
  FolderPath?: string;
  FileName?: string;
}

export const AdapterTypeMap = new Map<AdapterType, string>([
  [AdapterType.SQLServer, "SQL Server"],
  [AdapterType.PostgreSQL, "PostgreSQL"],
  [AdapterType.SFTP, "SFTP"]
]);

export class DataModeing {
  corpus?: CorpusDto;
  Document?: Array<DatamodelingDocument>;
}

export class ManifestDto {
  Id?: string;
  Name?: string;
  Corpus?: string;
  EntityCount?: string;
  CreatedOn?: number;
  CreatedBy?: string;
  ModifiedOn?: string;
  ModifiedBy?: number;
}


export class ConnManager {
  ConnectionName?: string;
  ConnectionType?: number;
}

export class ReplicatorPipline {
  Id?: string;
  Name?: string;
  UniqueName?: string;
  ConnManager?: Array<Adapter>;
  ActionId?: string;
  ProfileJSON?: string;
  Description?: string;
  CreatedOn?: number;
  CreatedBy?: string;
  ModifiedOn?: string;
  ModifiedBy?: number;
  ProfileJsonName?: string;
}

export class Adapter{
  AdapterName?: string;
  AdapterId?: string;
  SftpFolder?: string;
  AdapterTitle?: string;
  Index?: string;
}

export class ReplicatorPlan {
  Id?: string;
  DisplayName?: string;
  UniqueName?: string;
  Description?: string;
  DBAdapterId?: string;
  DBAdapterName?: string;
  TargetAdapterId?: string;
  TargetAdapterName?: string;
  SourceAdapterId?: string;
  SourceAdapterName?: string;
  SourceDocumentId?: string;
  TargetDocumentId?: string;
  EntityMapping?: Array<ReplicatorMapping>;
  ReplicatorSetting?: ReplicatorSetting;
  ProfileJSON?: string;
  ProfileJsonName?: string;
  CreatedOn?: string;
  CreatedBy?: string;
  ModifiedOn?: string;
  ModifiedBy?: string;
}

export class DocumentIds {
  SourceDocumentId?: string;
  TargetDocumentId?: string;
}



export class ReplicatorActionsDto {
  Id?: string;
  Description?: string;
  DisplayName?: string;
  Arguments?: string;
  SchemaJson?: string;
  ConnManager?: Array<ConnManager>;
  ActionType?: number;
  RunnerType?:string;
}

export class ReplicatorSetting {
  DatetimeFormat?: string;
  Splitor?: string;
  Mode?: RepliationModes;
  RunParallel?: boolean;
  Compress?: boolean;
  FileLimit?: number;
  FileNameTemplate?: string;
}

export enum RepliationModes {
  Full,
  Delta,
  FieldDelta,
}


export const RepliationModesMap = new Map<RepliationModes, string>([
  [RepliationModes.Full, "Full"],
  [RepliationModes.Delta, "Delta"],
  [RepliationModes.FieldDelta, "FieldDelta"]
  
]);

export class DatamodelingEntity {
  Type?: string;
  EntityName?: string;
  EntityPath?: string;
}

export class EntityAttributes {
  AttributesType?: string;
  AttributesName?: string;
}

export class ReplicatorMapping {
  Order?: number;
  Query?: string;
  Source?: string;
  Target?: string;
  Mappings?: Array<FieldMappings>;
}

export class StateDto {
  opened?: boolean;
}

export const CorpusPermissions = {
  ObjectCode: 201001,
  Read: 1,
  Create: 2,
  Update: 4,
  Delete: 8,
};

export const ManifestPermissions = {
  ObjectCode: 201001,
  Read: 1,
  Create: 2,
  Update: 4,
  Delete: 8,
};

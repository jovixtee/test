import React, { useState, useEffect } from "react";
import { Upload, Modal, Button,message } from 'antd';
import { UploadFile, UploadProps, ShowUploadListInterface } from 'antd/lib/upload/interface'
import { UploadOutlined } from '@ant-design/icons';
interface IDocumentProps {
    show: boolean;
    submit: (fileList: any[]) => void;
    cancel?: () => void;
    accept?: string;
    multiple?: boolean;
    disabled?: boolean;
    message?:string;
    beforeUpload?: (file: UploadFile) => boolean;
    showUploadList?: boolean | ShowUploadListInterface;
}
function ImportDocument(props: IDocumentProps) {
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [visible, setVisible] = useState(props.show);
    // const [uploading, setUploading] = useState(false);
    useEffect(() => {
        setFileList([]);
        // setUploading(false);
        setVisible(props.show);
    }, [props.show])
    const beforeUpload = (file: any) => {
        if (props.beforeUpload && !props.beforeUpload(file)) {
            file.status = 'error';
        }
        const isLt4M = file.size / 1024 / 1024 > 4;
        if (isLt4M) {
            message.error('file must smaller than 4MB!');
            return false;
        }

        setFileList([...fileList, file])
        return true;
    }
    const handleUpload = () => {
        // setUploading(true);
        props.submit && props.submit(fileList);
    };
    const documentProps: UploadProps = {
        fileList: fileList,
        beforeUpload: beforeUpload,
        accept: props.accept,
        multiple: props.multiple,
        disabled: props.disabled,
        showUploadList: props.showUploadList,
    }
    return (
        <Modal
            visible={visible}
            onOk={handleUpload}
            okText="Import"
            okButtonProps={{
                disabled: fileList.length === 0
            }
            }
            onCancel={() => {
                setVisible(false)
                if (props.cancel) props.cancel();
            }}
        >
            <Upload {...documentProps} >
                <Button icon={<UploadOutlined />}>Select File</Button>
            </Upload>
            { props.message &&
                <>
                    <div style={{marginTop:"20px"}}>
                        <div style={{"float":"left"}}>
                            <svg viewBox="0 0 1024 1024"  version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2824" width="30" height="30"><path d="M952.6 870.8L545.5 122.3c-18.4-34.1-48.6-35.5-67-1.4L71.4 871.6C53 905.6 70 928 109.1 928h805.8c39.1 0 56.1-23.1 37.7-57.2zM512 846.4c-25.9 0-46.9-20.8-46.9-46.3s20.9-46.3 46.9-46.3c25.9 0 46.9 20.8 46.9 46.3s-21 46.3-46.9 46.3z m39.4-199c-5.3 31.7-23 57.7-39.4 57.7-16.3 0-34-26-39.4-57.7l-39.8-241.1c-5.3-31.6 17-63.2 49.5-63.2h59.3c32.6 0 54.9 31.5 49.5 63.2l-39.7 241.1z" fill="#f4ea2a" p-id="2825"></path></svg>
                        </div>
                        <div style={{"marginLeft":"15px","marginTop":"5px","float":"left"}}>
                            {props.message}
                        </div>
                    </div>
                </>
            }
            
        </Modal>
    );
}

export default ImportDocument;
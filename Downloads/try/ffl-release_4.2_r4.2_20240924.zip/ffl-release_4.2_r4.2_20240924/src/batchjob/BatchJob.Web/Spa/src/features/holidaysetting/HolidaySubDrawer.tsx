import { DeleteOutlined } from "@ant-design/icons";
import { Button, DatePicker, Drawer, Form, Input, Radio, Select, Space } from "antd";
import React, { useEffect, useState } from "react"
import { Holiday, ScheduleDay, ScheduleMonth } from "./HolidaySettingContract";
import { EnumToArray } from '../../common/Utility';
import { Guid } from "guid-typescript";
import moment from 'moment';
import HolidaySettingApi from "./HolidaySettingApi";

interface IHolidaySubDrawerProps {
    Visible: boolean;
    OnClose: () => void;
    Holiday: Holiday;
    ProfileId: string;
}
const { Option } = Select;

const HolidaySubDrawer = (props: IHolidaySubDrawerProps) => {

    const [dayInMonth] = useState(EnumToArray(ScheduleDay).map((d) => { return { key: ScheduleDay[d], label: d, value: ScheduleDay[d] } }));
    const [monthArray] = useState(EnumToArray(ScheduleMonth).map((d) => { return { key: ScheduleMonth[d], label: d, value: ScheduleMonth[d] } }));
    const [currentType, setCurrentType] = useState(0);
    const [currentForm] = Form.useForm();
    useEffect(() => {
        props.Holiday.Profile = props.ProfileId;
        if (!props.Holiday.Id) {
            props.Holiday.Id = Guid.create().toString();
            props.Holiday.Type = 0;
            let currentDate = moment();
            let currentYear = currentDate.year().toString();
            let currentMonth = (currentDate.month() + 1).toString();
            let currentDay = currentDate.date().toString();
            props.Holiday.Holidays = [{ 
                CurrentYear: currentYear, 
                CurrentStartMonth: currentMonth, 
                CurrentEndMonth: currentMonth,
                CurrentStartDay: currentDay,
                CurrentEndDay: currentDay
            }];
        } else {
            if (!props.Holiday.Holidays) {
                props.Holiday.Holidays = props.Holiday.Dates!.map(d => { return { CurrentYear: d.Year!.toString(), CurrentStartMonth: d.Month!.toString(), CurrentStartDay: d.Day!.toString() } });
            }
        }

        let VM = { ...props.Holiday };
        if (currentType === 0) {
            VM.Holidays = props.Holiday.Holidays?.map(a => {
                let date = moment();
                if (props.Holiday.Id) {
                    date.set('year', Number(a.CurrentYear));
                    date.set('month', Number(a.CurrentStartMonth) - 1);
                    date.set('date', Number(a.CurrentStartDay));
                }
                return { HolidayDate: date, ...a }
            });
        }
        currentForm.resetFields();
        currentForm.setFieldsValue(VM);
        setCurrentType(VM.Type!);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.Holiday]);

    const submitForm = async (values: any) => {
        props.Holiday.Name = values.Name;
        props.Holiday.Description = values.Description;
        props.Holiday.Type = currentType;
        props.Holiday.Holidays = values.Holidays;
        if (currentType === 0) {
            // in-bound dto and out-bound dto are different.....
            props.Holiday.Holidays = values.Holidays.map((h:any) => { return { CurrentStartDay: h.HolidayDate.date().toString(), CurrentYear: h.HolidayDate.year().toString(), CurrentStartMonth: (h.HolidayDate.month() + 1).toString() } });
            // } else {
            // props.Holiday.Holidays = holidays;
        }
        
        props.Holiday.Holidays!.forEach((h, i) => h.Index = i);
        

        if (props.Holiday.Id) {
            await HolidaySettingApi.UpdateHolidays(props.Holiday);
        } else {
            await HolidaySettingApi.SaveHolidays(props.Holiday);
        }

        props.OnClose();
    }

    // const today = () => {
    //     const mmt = moment();
    //     return { Year: mmt.year(), Month: mmt.month() + 1, Day: mmt.date() };
    // }
    const submitFailed = () => { }


    const changeType = (typ: number) => {


        setCurrentType(typ);
    }


    const t1 = (fields:any, remove:any) => {
        return fields.map((field:any, index:any) => {
            if (currentType === 0) {
                return (<Space className="line-space">
                    <Form.Item name={[field.name, "HolidayDate"]}>
                        <DatePicker format={"YYYY/MM/DD"} disabledDate={d => d < moment().endOf('day')} />
                    </Form.Item>
                    <Form.Item>
                        <DeleteOutlined onClick={() => remove(field.name)} style={{ marginTop: '20', marginLeft: '20' }} />
                    </Form.Item>
                </Space>
                )
            } else if (currentType === 1) {
                return (
                    <Space className="line-space">
                        <span style={{ width: 60, display: 'inline-block', height: 46 }}>From day</span>
                        <Form.Item name={[field.name, "CurrentStartDay"]}>
                            {/* <Select style={{ width: 100 }} options={dayInMonth} /> */}
                            <Select dropdownClassName="select-drop-down"
                                style={{ width: "100px" }}>
                                {Object.keys(ScheduleDay)
                                    .filter((r) => !isNaN(Number(r)))
                                    .map((key) => {
                                    let item = Number(key);
                                    return (
                                        <Option value={item.toString()} key={item.toString()}>
                                            {/* {ScheduleDay[item]} */}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                        <span style={{ width: 40, display: 'inline-block', height: 46 }}>to day</span>
                        <Form.Item name={[field.name, "CurrentEndDay"]}>
                            {/* <Select style={{ width: 100 }} options={dayInMonth} /> */}
                            <Select dropdownClassName="select-drop-down"
                                style={{ width: "100px" }}>
                                {Object.keys(ScheduleDay)
                                    .filter((r) => !isNaN(Number(r)))
                                    .map((key) => {
                                    let item = Number(key);
                                    return (
                                        <Option value={item.toString()} key={item.toString()}>
                                            {/* {ScheduleDay[item]} */}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                        <Form.Item>
                            <DeleteOutlined onClick={() => remove(field.name)} style={{ marginTop: '20', marginLeft: '20' }} />
                        </Form.Item>
                    </Space>
                )
            } else {
                return (
                    <Space className="line-space">
                        <span style={{ display: 'inline-block', height: 46,width: "100%" }}>From</span>
                        <Form.Item name={[field.name, "CurrentStartMonth"]}>
                            {/* <Select  options={monthArray} /> */}
                            <Select dropdownClassName="select-drop-down"
                                style={{ width: "100px" }}>
                                {Object.keys(ScheduleMonth)
                                    .filter((r) => !isNaN(Number(r)))
                                    .map((key) => {
                                    let item = Number(key);
                                    return (
                                        <Option value={item.toString()} key={item.toString()}>
                                            {ScheduleMonth[item]}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                        <Form.Item name={[field.name, "CurrentStartDay"]}>
                            {/* <Select style={{ width: 100 }} options={dayInMonth} /> */}
                            <Select dropdownClassName="select-drop-down"
                                style={{ width: "100px" }}>
                                {Object.keys(ScheduleDay)
                                    .filter((r) => !isNaN(Number(r)))
                                    .map((key) => {
                                    let item = Number(key);
                                    return (
                                        <Option value={item.toString()} key={item.toString()}>
                                            {/* {ScheduleDay[item]} */}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                        <span style={{ display: 'inline-block', height: 46, width: "100%"}}>to</span>
                        <Form.Item name={[field.name, "CurrentEndMonth"]}>
                            {/* <Select options={monthArray} /> */}
                            <Select dropdownClassName="select-drop-down"
                                style={{ width: "100px" }}>
                                {Object.keys(ScheduleMonth)
                                    .filter((r) => !isNaN(Number(r)))
                                    .map((key) => {
                                    let item = Number(key);
                                    return (
                                        <Option value={item.toString()} key={item.toString()}>
                                            {ScheduleMonth[item]}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                        <Form.Item name={[field.name, "CurrentEndDay"]}>
                            {/* <Select style={{ width: 100 }} options={dayInMonth} /> */}
                            <Select dropdownClassName="select-drop-down"
                                style={{ width: "100px" }}>
                                {Object.keys(ScheduleDay)
                                    .filter((r) => !isNaN(Number(r)))
                                    .map((key) => {
                                    let item = Number(key);
                                    return (
                                        <Option value={item.toString()} key={item.toString()}>
                                            {/* {ScheduleDay[item]} */}
                                        </Option>
                                    );
                                })}
                            </Select>
                        </Form.Item>
                        <Form.Item>
                            <DeleteOutlined onClick={() => remove(field.name)} style={{ marginTop: '20', marginLeft: '20' }} />
                        </Form.Item>
                    </Space>)
            }
        });
    }

    return (<>
        <Drawer visible={props.Visible} title="Create Holiday" width={720} closable={true} onClose={props.OnClose}
            footer={<div style={{ textAlign: 'right' }}>
                <Button type="primary" onClick={currentForm.submit}>Save</Button>
                <Button onClick={props.OnClose} style={{ marginLeft: '10px' }}>Cancel</Button>
            </div>}>
            <Form form={currentForm} layout="vertical" onFinish={submitForm} onFinishFailed={submitFailed} style={{ marginTop: '20px' }}>
                <Form.Item label="Holiday Name" labelAlign="right" name="Name"
                    rules={[{ required: true, message: 'Enter a holiday name.' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Description" name="Description">
                    <Input />
                </Form.Item>
                <Form.Item label="Schedule Type" name="Type" initialValue={"0"}>
                    <Radio.Group defaultValue={0} onChange={(e) => changeType(e.target.value)}>
                        <Radio value={0}>Once</Radio>
                        <Radio value={1}>Monthly</Radio>
                        <Radio value={2}>Yearly</Radio>
                    </Radio.Group>
                </Form.Item>
                <Form.List name="Holidays" initialValue={[{ CurrentYear: "2021", CurrentStartMonth: "1", CurrentStartDay: "1", CurrentEndMonth: "1", CurrentEndDay: "1" }]}>
                    {(fields, { add, remove }) => {
                        return (<>
                            {t1(fields, remove)}
                            <Form.Item>
                                <Button onClick={() => add()}>Add</Button>
                            </Form.Item>
                        </>);
                    }}
                </Form.List>
            </Form>
        </Drawer>
    </>);
}

export default HolidaySubDrawer;
import { Space, Table, Input, Form } from 'antd';
import React, { FC, useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { ColumnsType } from "antd/lib/table";
import { EditOutlined, DeleteOutlined, CheckOutlined, CloseOutlined } from '@ant-design/icons';
import { ParamData, Param } from './ConnectionContract';
import UINotrification from "../../common/UINotrification";

interface IEditItem {
    key?: string;
    value?: string;
}

interface IEditTableProps {
    dataSource: Param[];
    ref?: any;
}

const ParamsEditTable: FC<IEditTableProps> = forwardRef((props, ref) => {
    const [dataSource, setDatasource] = useState<ParamData[]>([])
    const [editingData, setEditingData] = useState<ParamData>(new ParamData());
    const [form] = Form.useForm();
    useEffect(() => {
        const propsdata = props.dataSource.map(item => {
            return { ...item, IsEdit: false }
        })
        handleAddData(propsdata);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.dataSource])



    const handleAddData = (newDataSource: ParamData[]): void => {
        const newTableData = new ParamData();
        newTableData.Id = new Date().getTime().toString();
        newTableData.IsEdit = true;
        form.setFieldsValue({
            key: newTableData.Key,
            value: newTableData.Value,
        })
        newDataSource.unshift(newTableData);
        setDatasource(newDataSource)
        setEditingData(newTableData)
    }

    const onFailed = (values: any): void => {
        console.log('onFailed:', values);
    };

    const onFinish = (values: IEditItem): void => {
        console.log('onFinish:', values);
        let newDataSource = [...dataSource];
        let isExist = newDataSource.some(e => e.Key === values.key && e.IsEdit  === false);
        if (isExist) {
            UINotrification.error("duplicate key exists");
            return;
        }
        let data = handleOnFinish(values, newDataSource);
        form.resetFields();
        handleAddData(data);
    }

    const handleOnFinish = (record: IEditItem, newDataSource: ParamData[]) => {
        let data = newDataSource.find(item => item.Id === editingData.Id && item.IsEdit === true);
        if (data) {
            data.IsEdit = false;
            data.Key = record.key;
            data.Value = record.value;
        }
        return newDataSource;
    }

    const onCancelItemClick = (record: ParamData): void => {
        let newDataSource = [...dataSource];
        let editItem = newDataSource.find(item => item.Id === record.Id );
        if (editItem) {
            newDataSource = dataSource.filter(item => item.Id !== record.Id);
            setDatasource(newDataSource);
        }
        handleAddData(newDataSource);
    }

    const onDeleteItemClick = (record: ParamData): void => {
        let newDataSource = dataSource.filter(item => item.Id !== record.Id);
        setDatasource(newDataSource);
    }

    const onEditItemClick = (record: ParamData): void => {
        let newDataSource = [...dataSource];
        if (editingData.Key && editingData.Value) {
            let data = editingData as IEditItem;
            newDataSource = handleOnFinish(data, newDataSource);
        } else {
            newDataSource.shift();
        }
        let recordData = newDataSource.find(item => item.Id === record.Id);
        if (recordData) {
            recordData.IsEdit = true;
            form.setFieldsValue({
                key: record.Key,
                value: record.Value
            })
            setEditingData(recordData);
            setDatasource(newDataSource);
        }
    }


    const tableColumn: ColumnsType<ParamData> = [
        {
            title: "Key",
            dataIndex: "key",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="key" rules={[{ required: true, message: 'Please input Key!' }]}>
                            <Input placeholder={"please input key"} />
                        </Form.Item>
                        :
                        <span>{record.Key}</span>
                }
            </React.Fragment>
        },
        {
            title: "Value",
            dataIndex: "value",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="value" rules={[{ required: true, message: 'Please input value!' }]}>
                            <Input placeholder={"please input value"} />
                        </Form.Item>
                        :
                        <span>{record.Value}</span>
                }
            </React.Fragment>
        },
        {
            title: "Action",
            dataIndex: "Action",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Space>
                            <CheckOutlined onClick={() => form.submit()} />
                            <CloseOutlined onClick={() => onCancelItemClick(record)} />
                        </Space>
                        :
                        <Space>
                            <EditOutlined onClick={() => onEditItemClick(record)} />
                            <DeleteOutlined onClick={() => onDeleteItemClick(record)} />
                        </Space>
                }
            </React.Fragment>
        }
    ]

    useImperativeHandle(ref, () => ({
        getTableResult: () => {
            let data = dataSource.filter(item => item.Id !== editingData.Id && item.IsEdit === false);
            return data;
        }
    }));


    return <React.Fragment>
        <Form form={form} onFinish={onFinish} onFinishFailed={onFailed}  >
            <Table
                rowKey={(record) => record.Id}
                columns={tableColumn}
                dataSource={dataSource}
                pagination={false}
            />
        </Form>
    </React.Fragment>
}
)
export default ParamsEditTable





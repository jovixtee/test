import * as TransferContract from './TransferContract';
import apiservice from '../../utils/fetchutil';
import { PagerExpression } from '../../common/contracts/PagerContracts';

export interface ITransferApi {
    CreateTransferProfile(dto: TransferContract.TransferProfileDto, file: any): Promise<TransferContract.TransferServiceResult>;
    UpdateTransferProfile(dto: TransferContract.TransferProfileDto, file: any): Promise<TransferContract.TransferServiceResult>;
    PagerQuery(pager: PagerExpression): Promise<TransferContract.TransferServiceResult>;
    GetTransferResources(): Promise<TransferContract.TransferServiceResult>;
    DeleteTransferProfiles(ids: any): Promise<TransferContract.TransferServiceResult>;
}
export function GetApiService(): ITransferApi {
    return transferService;
}

const transferService: ITransferApi = {
    CreateTransferProfile: (dto: TransferContract.TransferProfileDto, file: any): Promise<TransferContract.TransferServiceResult> => {
        const fd = new FormData();
        fd.set('arg', JSON.stringify({ _streamLength: file?.size, importArguments: { FileName: dto.DataSyncXmlName, ProfileDto: dto } }));
        if (file) {
            fd.set('file', file);
        }
        return apiservice().post('/ITransferService/CreateTransferProfile', fd);
    },
    UpdateTransferProfile: (dto: TransferContract.TransferProfileDto, file: any): Promise<TransferContract.TransferServiceResult> => {
        const fd = new FormData();
        fd.set('arg', JSON.stringify({ _streamLength: file?.size, importArguments: { FileName: dto.DataSyncXmlName, ProfileDto: dto } }));
        if (file) {
            fd.set('file', file);
        }
        return apiservice().post('/ITransferService/UpdateTransferProfile', fd);
    },
    PagerQuery(pager: PagerExpression): Promise<TransferContract.TransferServiceResult> {
        return apiservice().post('/ITransferService/PagerQueryTransferProfile', { pager: pager });
    },
    GetTransferResources: (): Promise<TransferContract.TransferServiceResult> => {
        return apiservice().post('/ITransferService/GetTransferResources', {});
    },
    DeleteTransferProfiles: (ids: string[]): Promise<TransferContract.TransferServiceResult> => {
        return apiservice().post('/ITransferService/DeleteTransferProfiles', { ids: ids });
    }
}

// public ImportTask(file: any, callback?: (result: TaskManagerServiceResult) => void): void {
//     const fd = new FormData();

//     fd.set('arg', JSON.stringify({ _streamLength: file.size, importArguments: { FileName: file.name } }));
//     fd.set('file', file);

//     apiservice().post('/ITaskManagerService/Import', fd).then(result => callback?.(result));
// }
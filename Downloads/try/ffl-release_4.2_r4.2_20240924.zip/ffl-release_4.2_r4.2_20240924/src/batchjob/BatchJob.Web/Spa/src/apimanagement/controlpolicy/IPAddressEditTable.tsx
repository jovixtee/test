import { Space, Table, Input, Form, message } from 'antd';
import React, { FC, useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { ColumnsType } from "antd/lib/table";
import { EditOutlined, DeleteOutlined, CheckOutlined, CloseOutlined } from '@ant-design/icons';
import { IPAddressData, IPAddress } from '../../common/contracts/ModelContracts';

interface IEditItem {
    AddressFrom?: string;
    AddressTo?: string;
}

interface IEditTableProps {
    dataSource: IPAddress[];
    ref?: any;
}

const IPAddressEditTable: FC<IEditTableProps> = forwardRef((props, ref) => {
    const [dataSource, setDatasource] = useState<IPAddressData[]>([])
    const ipRules = /^((25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9]))$/;


    const [editingData, setEditingData] = useState<IPAddressData>(new IPAddressData());
    const [form] = Form.useForm();
    useEffect(() => {
        const propsdata = props.dataSource.map(item => {
            return { ...item, IsEdit: false }
        })
        handleAddData(propsdata);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.dataSource])



    const handleAddData = (newDataSource: IPAddressData[]): void => {
        const newTableData = new IPAddressData();
        newTableData.Id = new Date().getTime().toString();
        newTableData.IsEdit = true;

        form.setFieldsValue({
            AddressFrom: newTableData.AddressFrom,
            AddressTo: newTableData.AddressTo,
        })
        newDataSource.unshift(newTableData);
        setDatasource(newDataSource)
        setEditingData(newTableData)
    }

    const onFailed = (values: any): void => {
        console.log('onFailed:', values);
    };

    const onFinish = (values: IEditItem): void => {
        console.log('onFinish:', values);
        let newDataSource = [...dataSource];
        let data = handleOnFinish(values, newDataSource);
        form.resetFields();
        handleAddData(data);
    }

    const handleOnFinish = (record: IEditItem, newDataSource: IPAddressData[]) => {
        let data = newDataSource.find(item => item.Id === editingData.Id);
        if (data) {
            data.IsEdit = false;
            data.AddressFrom = record.AddressFrom;
            data.AddressTo = record.AddressTo;
        }
        return newDataSource;
    }

    const onCancelItemClick = (record: IPAddressData): void => {
        let newDataSource = [...dataSource];
        let editItem = newDataSource.find(item => item.Id === record.Id);
        if (editItem) {
            newDataSource = dataSource.filter(item => item.Id !== record.Id);
            setDatasource(newDataSource);
        }
        handleAddData(newDataSource);
    }

    const onDeleteItemClick = (record: IPAddressData): void => {
        let data = [...dataSource];
        data = data.filter(item => item.AddressFrom&&item.AddressTo);
        if(data.length === 1){
            message.error("IP Address must be greater than one record!");
            return;
        }


        let newDataSource = dataSource.filter(item => item.Id !== record.Id);
        setDatasource(newDataSource);
    }

    const onEditItemClick = (record: IPAddressData): void => {
        let newDataSource = [...dataSource];
        if (editingData.AddressFrom && editingData.AddressTo) {
            let data = editingData as IEditItem;
            newDataSource = handleOnFinish(data, newDataSource);
        } else {
            newDataSource.shift();
        }
        let recordData = newDataSource.find(item => item.Id === record.Id);
        if (recordData) {
            recordData.IsEdit = true;
            form.setFieldsValue({
                AddressFrom: record.AddressFrom,
                AddressTo: record.AddressTo
            })
            setEditingData(recordData);
            setDatasource(newDataSource);
        }
    }


    const tableColumn: ColumnsType<IPAddressData> = [
        {
            title: "IP address from",
            dataIndex: "AddressFrom",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="AddressFrom" rules={[
                            { required: true, message: 'Please input IP address from!' },
                            { pattern: ipRules, message: 'Please input the correct IP ' }
                        ]}>
                            <Input placeholder={"IP address from"} />
                        </Form.Item>
                        :
                        <span>{record.AddressFrom}</span>
                }
            </React.Fragment>
        },
        {
            title: "IP address to",
            dataIndex: "AddressTo",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="AddressTo" rules={[
                            { required: true, message: 'Please input IP address to!' },
                            { pattern: ipRules, message: 'Please input the correct IP ' }
                        ]}>
                            <Input placeholder={"IP address to"} />
                        </Form.Item>
                        :
                        <span>{record.AddressTo}</span>
                }
            </React.Fragment>
        },
        {
            title: "Action",
            dataIndex: "Action",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Space style={{float:"left", marginTop:"-20px"}}>
                            <CheckOutlined onClick={() => form.submit()} />
                            <CloseOutlined onClick={() => onCancelItemClick(record)} />
                        </Space>
                        :
                        <Space style={{float:"left",marginTop:"-20px"}}>
                            <EditOutlined onClick={() => onEditItemClick(record)} />
                            <DeleteOutlined onClick={() => onDeleteItemClick(record)} />
                        </Space>
                        
                }
            </React.Fragment>
        }
    ]

    useImperativeHandle(ref, () => ({
        getTableResult: () => {
            return dataSource.filter(item => item.Id !== editingData.Id);
        }
    }));


    return <React.Fragment>
        <Form form={form} onFinish={onFinish} onFinishFailed={onFailed}  >
            <Table
                rowKey={(record) => record.Id}
                columns={tableColumn}
                dataSource={dataSource}
                pagination={false}
            />
        </Form>
    </React.Fragment>
}
)
export default IPAddressEditTable





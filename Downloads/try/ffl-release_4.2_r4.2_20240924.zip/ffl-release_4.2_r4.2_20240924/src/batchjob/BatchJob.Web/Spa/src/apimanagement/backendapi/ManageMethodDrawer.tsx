import { Drawer, Form, Input, Button, Select, Divider, Spin, Space, Tooltip } from 'antd';
import React, { FC, useEffect, useRef, useState } from 'react';
import { IEditTableRef, MethodTypeMap, ParameterObject, ContentTypeDefault,  MethodTypeEnum, VersionthodTypeMap } from './BackendAPIContracts';
import {MethodDto,MethodType} from '../../common/contracts/ModelContracts';
import EditTable from './EditTable';
import { CreateMethod } from './BackendAPIApiService';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';

interface IManageMethodDrawerProps {
    visible: boolean;
    cancelClick: VoidFunction;
    isEdit: boolean;
    defaultData: MethodDto;
    versionId: string;
    parmData: Map<string, string>;
    getTableData: VoidFunction;
}
type Header = {
    key?: string;
    value?: string;
}
interface IMethodFrom {
    Type?: MethodTypeEnum,
    Path?: string,
    MethodType?: MethodType,
    Header?: Header[]
}
const { Option } = Select;

const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 14 },
};
const ManageMethodDrawer: FC<IManageMethodDrawerProps> = (props) => {
    const [selectContentTypeData, setSelectContentTypeData] = useState<string[]>([]);
    const [newSelectItemName, setNewSelectItemName] = useState<string>("");
    const [loading, setLoading] = useState<boolean>(false);
    const [form] = Form.useForm();
    const tableRef = useRef<IEditTableRef>();
    useEffect(() => {
        if (props.visible) {
            let header = conversionHeaderString(props.defaultData.Header!)
            if (header[0]?.value) {
                if (ContentTypeDefault.includes(header[0]?.value)) {
                    setSelectContentTypeData([...ContentTypeDefault])
                } else {
                    setSelectContentTypeData([...ContentTypeDefault, header[0]?.value])
                }
            } else {
                setSelectContentTypeData([...ContentTypeDefault])
            }
            console.log(props.defaultData)
            form.setFieldsValue({
                Type: (props.defaultData.MethodName) ? Number(props.defaultData.MethodName) : undefined,
                Path: props.defaultData.Path,
                Header: header,
                MethodType: props.defaultData.MethodType
            })
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.defaultData, props.visible])

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };
    const conversionHeaderString = (headerString: string): Header[] => {
        let defaultArray = [{ key: "Content-Type", value: "" }];
        let header: Header[] = headerString ? JSON.parse(headerString) : defaultArray;
        let result: Header[] = [];
        if (!Array.isArray(header)) {
            header = defaultArray
        }
        header.forEach(item => {
            if (item.hasOwnProperty('key') && item.hasOwnProperty('value')) {
                if (!(typeof (item["key"]) == 'string')) {
                    item["key"] = JSON.stringify(item["key"]);
                }
                if (!(typeof (item["value"]) == 'string')) {
                    item["value"] = JSON.stringify(item["value"]);
                }
                result.push(item)
            }
        });
        return result
    }


    const addSelectItem = (): void => {
        if (newSelectItemName) {
            setSelectContentTypeData([...selectContentTypeData, newSelectItemName])
            setNewSelectItemName("");
        }

    }
    const inputChange = (event: any): void => {
        setNewSelectItemName(event.target.value)
    }

    const onFinish = (values: IMethodFrom) => {
        if (tableRef.current?.getTableResult().isEditing) {
            console.log("discard confirm");
        }
        setLoading(true);
        let tableResult = tableRef.current?.getTableResult();
        let requestObject: any = {};
        let methodObject = new MethodDto();
        methodObject.Header = JSON.stringify(values.Header);
        methodObject.MethodName = values.Type;
        methodObject.MethodType = values.MethodType;
        methodObject.VersionId = props.versionId;
        methodObject.Path = values.Path;
        let parmObject = new ParameterObject();
        parmObject.addData = tableResult?.addData.map(item => { return { DefaultValue: item.DefaultValue, ParamterTypeID: item.ParamterTypeID, Key: item.Key, Id: "" } }) || [];
        if (props.isEdit) {
            methodObject.Id = props.defaultData.Id;
            parmObject.updateData = tableResult?.updateData.map(item => { return { DefaultValue: item.DefaultValue, ParamterTypeID: item.ParamterTypeID, Key: item.Key, Id: item.Id } }) || [];
            parmObject.deleteData = tableResult?.deleteData.map(item => { return { Id: item.Id } }) || [];
        }
        requestObject.method = methodObject;
        requestObject.param = parmObject;
        CreateMethod(requestObject)
            .then(res => {
                setLoading(false);
                closeDrawer();
                props.getTableData();
            })
            .catch(err => {
                setLoading(false);

            })
    }
    const closeDrawer = (): void => {
        form.resetFields();
        props.cancelClick()
    }



    return <Drawer
        visible={props.visible}
        width={720}
        destroyOnClose
        forceRender
        onClose={props.cancelClick}
        title={props.isEdit ? "Edit Method" : "Create a new Method"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" style={{ marginRight: 8 }} loading={loading} onClick={() => form.submit()}>Save</Button>
                <Button onClick={props.cancelClick} >Cancel</Button>
            </div>
        }
    >
        <Spin spinning={loading}>
            <Form {...layout} form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '20px' }}>
                <Form.Item label="Type" name="Type" rules={[{ required: true, message: 'Please input type!' }]}>
                    <Select style={{ minWidth: 120 }}>
                        {
                            Array.from(MethodTypeMap).map(([key, value]) => <Option value={value} key={value}>{key}</Option>)
                        }
                    </Select>
                </Form.Item>
                <Form.Item label="Method Type" name="MethodType" rules={[{ required: true, message: 'Please input Method Type!' }]}>
                    <Select style={{ minWidth: 120 }}>
                        {
                            Array.from(VersionthodTypeMap).map(([key, value]) => <Option value={value} key={value}>{key}</Option>)
                        }
                    </Select>
                </Form.Item>

                <Form.Item label="Path" name="Path" rules={[{ required: true, message: 'Please input path!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Header" required={true}>
                    <Form.List name="Header">
                        {(fields, { add, remove }) => (
                            <>
                                {fields.map(({ key, name, fieldKey, ...restField }, index) => {
                                    if (index === 0) {
                                        return <Space key={key} style={{ display: 'flex' }} align="baseline">
                                            <Form.Item
                                                {...restField}
                                                name={[name, 'key']}
                                                //fieldKey={[fieldKey, 'key']}
                                                rules={[{ required: true, message: 'Missing Key' }]}
                                            >
                                                <Input placeholder="Key" style={{ width: 172 }} disabled />
                                            </Form.Item>
                                            <Form.Item
                                                {...restField}
                                                name={[name, 'value']}
                                                //fieldKey={[fieldKey, 'value']}
                                                rules={[{ required: true, message: 'Missing Value' }]}
                                            >
                                                <Select style={{ width: 172 }}
                                                    dropdownRender={menu => (
                                                        <div>
                                                            {menu}
                                                            <Divider style={{ margin: '4px 0' }} />
                                                            <div style={{ display: 'flex', flexWrap: 'nowrap', padding: 8 }}>
                                                                <Input style={{ flex: 'auto' }} value={newSelectItemName} onChange={inputChange} />
                                                                <Button type="link"
                                                                    style={{ flex: 'none', padding: '8px', display: 'block', cursor: 'pointer' }}
                                                                    onClick={addSelectItem}
                                                                >Add item</Button>
                                                            </div>
                                                        </div>
                                                    )}
                                                >
                                                    {
                                                        selectContentTypeData.map((value) => <Option value={value} key={value}>
                                                            <Tooltip placement="top" title={value}>
                                                                <span>{value}</span>
                                                            </Tooltip>
                                                        </Option>)
                                                    }
                                                </Select>
                                            </Form.Item>
                                        </Space>
                                    } else {
                                        return <Space key={key} style={{ display: 'flex' }} align="baseline">
                                            <Form.Item
                                                {...restField}
                                                name={[name, 'key']}
                                                //fieldKey={[fieldKey, 'key']}
                                                rules={[{ required: true, message: 'Missing Key' }]}
                                            >
                                                <Input style={{ width: 172 }} placeholder="Key" />
                                            </Form.Item>
                                            <Form.Item
                                                {...restField}
                                                name={[name, 'value']}
                                               // fieldKey={[fieldKey, 'value']}
                                                rules={[{ required: true, message: 'Missing Value' }]}
                                            >
                                                <Input style={{ width: 172 }} placeholder="Value" />
                                            </Form.Item>
                                            <MinusCircleOutlined onClick={() => remove(name)} />
                                        </Space>
                                    }

                                })}
                                <Form.Item>
                                    <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>Add Header</Button>
                                </Form.Item>
                            </>
                        )}
                    </Form.List>

                </Form.Item>

            </Form>
            <EditTable
                parmData={props.parmData}
                dataSource={props.defaultData.Param || []}
                ref={tableRef}
            />
        </Spin>

    </Drawer>
}
export default ManageMethodDrawer
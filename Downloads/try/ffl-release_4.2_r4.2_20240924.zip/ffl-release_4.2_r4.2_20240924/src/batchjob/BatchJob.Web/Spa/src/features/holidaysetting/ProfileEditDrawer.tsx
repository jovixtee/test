import { Button, Checkbox, Drawer, Form, Input, Select } from "antd";
import React, { useEffect, useState } from "react";
import HolidaySettingApi from "./HolidaySettingApi";
import { HolidaySettingProfile, TimeZoneInfoDto, Workday } from './HolidaySettingContract';
import { EnumToArray } from '../../common/Utility';

interface IProfileEditDrawerProps {
    Visible: boolean;
    OnClose: () => void;
    Profile: HolidaySettingProfile;
}

const ProfileEditDrawer = (props: IProfileEditDrawerProps) => {

    const [timeZone, setTimeZone] = useState<TimeZoneInfoDto>();
    // const [defaultZone, setDefaultZone] = useState<TimeZoneInfoNode>();
    const [workdayOptions] = useState(EnumToArray(Workday).map((d) => { return { label: d, value: Workday[d] } }));
    const [fm] = Form.useForm();

    useEffect(() => {
        HolidaySettingApi.LoadTimeZoneInfos().then(rst => {
            setTimeZone(rst.TimeZoneInfos);
            // setDefaultZone(rst.TimeZoneInfos.Local);
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        let profile = props.Profile;

        if (!profile.ProfileId) {
            profile.TimeZoneInfoId = timeZone?.Local?.TimeZoneId;
            profile.Workdays = 127;
            profile.OrganizationName = "";
        }

        const workdayArray = Object.keys(Workday).filter(value => isNaN(Number(value)) === false).map(r => Number(r))
            .filter(n => (n & profile!.Workdays!) === n);
        fm.setFieldsValue({ WorkdayArray: workdayArray, ...profile });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.Profile]);

    const submitForm = async (values: any) => {
        props.Profile.OrganizationName = values.OrganizationName;
        let wd = 0;
        values.WorkdayArray.forEach((val:any) => { wd += val });
        props.Profile.Workdays = wd;

        props.Profile.TimeZoneInfoId = values.TimeZoneInfoId;
        props.Profile.TimeZoneDisplayName = values.TimeZone;

        if (props.Profile.ProfileId) {
            await HolidaySettingApi.UpdateProfile(props.Profile);
        } else {
            await HolidaySettingApi.SaveProfile(props.Profile);
        }

        props.OnClose();
    }

    const formFailed = () => { }

    return (
        <Drawer title={props.Profile.ProfileId ? "Edit holiday" : "Create new holiday"} width={720} destroyOnClose={true} onClose={props.OnClose} visible={props.Visible}
            footer={
                <div style={{ textAlign: 'right', }}>
                    <Button type="primary" onClick={() => fm.submit()} >Save</Button>
                    <Button onClick={props.OnClose} style={{ marginLeft: '10px' }}>Cancel</Button>
                </div>
            }>
            <Form layout="vertical" onFinish={submitForm} onFinishFailed={formFailed} form={fm}
                style={{ marginTop: '20px' }}>
                <Form.Item name="OrganizationName" label="Holiday Name" rules={[{ required: true, message: 'Enter a holiday name.' }]}>
                    <Input placeholder="Holiday Name" />
                </Form.Item>
                <Form.Item name="WorkdayArray" label="Workdays" initialValue={[1, 2, 4, 8, 16, 32, 64]}>
                    <Checkbox.Group options={workdayOptions} />
                </Form.Item>
                <Form.Item name="TimeZoneInfoId" label="Time Zone" rules={[{ required: true }]}>
                    <Select placeholder="Time Zone">
                        {timeZone && timeZone.TimeZones
                            && timeZone.TimeZones.map(r => <Select.Option value={r.TimeZoneId} key={r.TimeZoneId}>{r.TimeZoneDisplayName}</Select.Option>)
                        }
                    </Select>
                </Form.Item>
            </Form>
        </Drawer >
    )
}
export default ProfileEditDrawer;
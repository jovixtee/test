import { Space, Table, Input, Form } from 'antd';
import React, { FC, useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { ColumnsType } from "antd/lib/table";
import { EditOutlined, DeleteOutlined, CheckOutlined, CloseOutlined } from '@ant-design/icons';
import { EditHeaderTableData, MethodHeader, IEditHeaderTableRef } from '../../common/contracts/ModelContracts';

interface IEditItem {
    Name?: string;
    DefaultValue?: string;
    Type?: string;
}

interface IEditTableProps {
    dataSource: MethodHeader[];
    ref?: any;
}

const HeaderEditTable: FC<IEditTableProps> = forwardRef((props, ref) => {
    const [dataSource, setDatasource] = useState<EditHeaderTableData[]>(new Array<EditHeaderTableData>())
    const [addData, setAddData] = useState<MethodHeader[]>(new Array<MethodHeader>());
    const [deleteData, setDeleteData] = useState<MethodHeader[]>(new Array<MethodHeader>());
    const [updateData, setUpdateData] = useState<MethodHeader[]>(new Array<MethodHeader>());
    const [editingData, setEditingData] = useState<EditHeaderTableData>(new EditHeaderTableData());
    const [form] = Form.useForm();
    useEffect(() => {
        const propsdata = props.dataSource.map(item => {
            return { ...item, IsEdit: false, IsNewData: false }
        })
        setAddData([]);
        setDeleteData([]);
        setUpdateData([]);

        //setDatasource(propsdata);
        handleAddData(propsdata);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.dataSource])


    const handleAddData = (newDataSource: EditHeaderTableData[]): void => {
        const newTableData = new EditHeaderTableData();
        newTableData.Id = new Date().getTime().toString();
        newTableData.IsEdit = true;
        newTableData.IsNewData = true;

        form.setFieldsValue({
            Name: newTableData.Name,
            Type: newTableData.Type,
            DefaultValue: newTableData.DefaultValue
        })
        //newDataSource.push(newTableData);
        newDataSource.unshift(newTableData);
        setDatasource(newDataSource)
        setEditingData(newTableData)
    }

    const onFailed = (values: any): void => {
        console.log('onFailed:', values);
    };

    const onFinish = (values: IEditItem): void => {
        console.log('onFinish:', values);
        let newDataSource = [...dataSource];
        let data = handleOnFinish(values, newDataSource);
        form.resetFields();
        handleAddData(data);
    }

    const handleOnFinish = (record: IEditItem, newDataSource: EditHeaderTableData[]) => {
        let IsNew: boolean = false;
        let data = newDataSource.find(item => item.Id === editingData.Id);
        if (data) {
            data.IsEdit = false;
            data.Name = record.Name;
            data.Type = record.Type;
            data.DefaultValue = record.DefaultValue;
            IsNew = data.IsNewData;

            if (IsNew) {
                let newAddArray = [...addData]
                let newDataItem = newAddArray.find(item => item.Id === editingData.Id);
                if (newDataItem) {
                    newDataItem.Name = record.Name;
                    newDataItem.Type = record.Type;
                    newDataItem.DefaultValue = record.DefaultValue;
                } else {
                    newAddArray.unshift(data)
                }
                setAddData(newAddArray);
            } else {
                let newUpdateData = [...updateData]
                let newDataItem = newUpdateData.find(item => item.Id === editingData.Id);
                if (newDataItem) {
                    newDataItem.Name = record.Name;
                    newDataItem.Type = record.Type;
                    newDataItem.DefaultValue = record.DefaultValue;
                } else {
                    newUpdateData.unshift(data)
                }
                setUpdateData(newUpdateData);
            }
        }
        return newDataSource;
    }

    const onCancelItemClick = (record: EditHeaderTableData): void => {
        let newDataSource = [...dataSource];
        let editItem = newDataSource.find(item => item.Id === record.Id);
        if (editItem) {
            let isNewData = editItem.IsNewData;
            if (isNewData) {
                newDataSource = dataSource.filter(item => item.Id !== record.Id);
                setDatasource(newDataSource);
            } else {
                editItem.Name = editingData.Name;
                editItem.Type = editingData.Type;
                editItem.DefaultValue = editingData.DefaultValue;
                editItem.IsEdit = false;
                setDatasource(newDataSource);
            }
        }
        handleAddData(newDataSource);
    }

    const onDeleteItemClick = (record: EditHeaderTableData): void => {
        if (record.IsNewData) {
            let newAddData = addData.filter(item => item.Id !== record.Id);
            let newDataSource = dataSource.filter(item => item.Id !== record.Id);
            setAddData(newAddData)
            setDatasource(newDataSource);
        } else {
            let newDeleteData = [...deleteData];
            let newDataSource = dataSource.filter(item => item.Id !== record.Id);
            newDeleteData.push(record)
            setDeleteData(newDeleteData);
            setDatasource(newDataSource);
        }
    }

    const onEditItemClick = (record: EditHeaderTableData): void => {
        let newDataSource = [...dataSource];

        if (editingData.Name && editingData.Type) {
            let data = editingData as IEditItem;
            newDataSource = handleOnFinish(data, newDataSource);
        } else {
            newDataSource.shift();
        }
        let recordData = newDataSource.find(item => item.Id === record.Id);
        if (recordData) {
            recordData.IsEdit = true;
            form.setFieldsValue({
                Name: record.Name,
                Type: record.Type,
                DefaultValue: record.DefaultValue
            })
            setEditingData(recordData);
            setDatasource(newDataSource);
        }
    }


    const tableColumn: ColumnsType<EditHeaderTableData> = [
        {
            title: "Header Name",
            dataIndex: "Name",
            width:"35%",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="Name" rules={[{ required: true, message: 'Header Name is required' }]}>
                            <Input placeholder={"Header Name"} />
                        </Form.Item>
                        :
                        <span>{record.Name}</span>
                }
            </React.Fragment>
        },
        {
            title: "Type",
            dataIndex: "Type",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="Type" initialValue={"string"} rules={[{ required: true, message: 'Type is required' }]}>
                            <Input placeholder={"Type"} />
                        </Form.Item>
                        :
                        <span>{record.Type}</span>
                }
            </React.Fragment>
        },
        {
            title: "Value",
            dataIndex: "DefaultValue",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="DefaultValue" rules={[{ required: true, message: 'Value is required' }]}>
                            <Input placeholder={"Value"} />
                        </Form.Item>
                        :
                        <span>{record.DefaultValue}</span>
                }
            </React.Fragment>
        },
        {
            title: "Action",
            dataIndex: "Action",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Space>
                            <CheckOutlined onClick={() => form.submit()} />
                            <CloseOutlined onClick={() => onCancelItemClick(record)} />
                        </Space>
                        :
                        <Space>
                            <EditOutlined onClick={() => onEditItemClick(record)} />
                            <DeleteOutlined onClick={() => onDeleteItemClick(record)} />
                        </Space>
                }
            </React.Fragment>
        }
    ]

    useImperativeHandle(ref, (): any => ({
        getTableResult: () => {
            return {
                addData,
                updateData,
                deleteData
            }
        },
        resetTableData:() => {
             setAddData([]);
             setUpdateData([]);
             setDeleteData([]);
        }
    }));


    return <React.Fragment>
        <Form form={form} onFinish={onFinish} onFinishFailed={onFailed}  >
            <Table
                rowKey={(record) => record.Id}
                columns={tableColumn}
                dataSource={dataSource}
                pagination={false}
            />
        </Form>
    </React.Fragment>
}
)
export default HeaderEditTable





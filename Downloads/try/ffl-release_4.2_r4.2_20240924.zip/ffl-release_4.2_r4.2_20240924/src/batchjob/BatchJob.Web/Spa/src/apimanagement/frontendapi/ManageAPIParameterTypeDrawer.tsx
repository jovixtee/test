import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";
import { Button, Col, Drawer, Row, Space, Table } from "antd";
import React, { FC, useEffect, useState } from "react";
import { ColumnsType } from "antd/lib/table";
import ManageAPITypeFormDrawer from "./ManageAPITypeFormDrawer";
import { GetParameterType, DeleteParameterType } from './FrontendAPIApiService';
import {ParameterTypeDto} from '../../common/contracts/ModelContracts';

interface IManageAPIParameterTypeDrawerProps {
    visibile: boolean;
    cancelClick: VoidFunction;
    apiId: string;
}


const ManageAPIParameterTypeDrawer: FC<IManageAPIParameterTypeDrawerProps> = (props) => {

    const [selectTypeKey, setSelectTypeKey] = useState<React.Key[]>([]);

    const [manageAPITypeFormDrawerVisible, setManageAPITypeFormDrawer] = useState<boolean>(false);
    const [isEdit, setIsEdit] = useState<boolean>(false);
    const [editTypeData, setEditTypeData] = useState<ParameterTypeDto>(new ParameterTypeDto());
    const [loading, setLoading] = useState<boolean>(false);


    const [typeData, setTypeData] = useState<ParameterTypeDto[]>(new Array<ParameterTypeDto>())

    useEffect(() => {
        if (props.apiId) {
            requestGetParameterType();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.apiId])

    const requestGetParameterType = (): void => {
        setLoading(true)
        GetParameterType(props.apiId)
            .then(res => {
                setTypeData([...res])
                setLoading(false);
            })
            .catch(err => {
                setLoading(false);
            })
    }


    const onCreateTypeClick = (): void => {
        setIsEdit(false);
        setEditTypeData(new ParameterTypeDto());
        setManageAPITypeFormDrawer(true);
    }
    const onDeleteTypesClick = (): void => {
        requestDeleteParameterType([...selectTypeKey as string[]]);
    }
    const requestDeleteParameterType = (Ids: string[]): void => {
        setLoading(true)
        DeleteParameterType(Ids)
            .then(res => {
                setSelectTypeKey([]);
                requestGetParameterType();
            })
            .catch(err => {

                setLoading(false);
            })

    }
    const onEditTypeClick = (typeRecord: ParameterTypeDto): void => {
        setIsEdit(true);
        setEditTypeData(typeRecord);
        setManageAPITypeFormDrawer(true);
    }

    const cancelManageAPITypeFormDrawerClick = (): void => {
        setManageAPITypeFormDrawer(false);
        setEditTypeData(new ParameterTypeDto());
    }
    const onDeleteTypeClick = (typeId: string): void => {
        requestDeleteParameterType([typeId]);

    }
    const typeColumns: ColumnsType<ParameterTypeDto> = [
        {
            title: "Type Name",
            dataIndex: "Name",
        },
        {
            title: "Action",
            dataIndex: "Action",
            render: (_: any, record: any) => <Space>
                <Button type='link' onClick={() => { onEditTypeClick(record) }}>Edit</Button>
                <Button type='link' onClick={() => { onDeleteTypeClick(record.Id) }}>Delete</Button>
            </Space>
        }

    ]

    return <Drawer
        visible={props.visibile}
        width={720}
        destroyOnClose
        forceRender
        onClose={props.cancelClick}
        title={"Manage API Parameter Type"}

    >
        <Row style={{ margin: '16px 0' }}>
            <Col span={18}>
                <Space size='small'>
                    <Button type="text" onClick={onCreateTypeClick} disabled={loading}><PlusOutlined />Create</Button>
                    <Button type='text' icon={<DeleteOutlined />} disabled={selectTypeKey.length === 0} onClick={onDeleteTypesClick}> Delete</Button>
                </Space>
            </Col>
            <Col span={6}>

            </Col>
        </Row>
        <Table
            loading={loading}
            rowKey={(record: any) => record.Id}
            columns={typeColumns}
            dataSource={typeData}
            pagination={false}
            rowSelection={{
                selectedRowKeys: selectTypeKey,
                onChange: (selectedRowKeys: any, selectedRows: any) => {
                    setSelectTypeKey([...selectedRowKeys])
                },
            }}

        />
        <ManageAPITypeFormDrawer
            visibile={manageAPITypeFormDrawerVisible}
            cancelClick={cancelManageAPITypeFormDrawerClick}
            editTypeData={editTypeData}
            isEdit={isEdit}
            apiId={props.apiId}
            refreshData={() => { requestGetParameterType() }}
        />


    </Drawer>
}


export default ManageAPIParameterTypeDrawer
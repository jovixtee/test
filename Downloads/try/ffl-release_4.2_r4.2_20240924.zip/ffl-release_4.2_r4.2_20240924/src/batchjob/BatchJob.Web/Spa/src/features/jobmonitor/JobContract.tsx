import { AbstractServiceResult } from "../../common/contracts/AbstractServiceResult";
import { PagerResult } from "../../common/contracts/PagerContracts";

export class JobDetailDto {
  public static Id: string;
  public static JobId: string;
  public static  Comment: string;
  public static JsonDetail: string;
  public static CreatedOn: number;
  public static ModifiedOn: number;
  public static DetailContext: string;
}

export class JobDto {
  public static Id: string;
  public static Name: string;
  public static JobType: number;
  public static TaskName: string;
  public static TaskId: string;
  public static TypeStr: string;
  public static State: JobState;
  public static Progress: string;
  public static ScheduleRule: string;
  public static EndTime: number;
  public static StartTime: number;
  public static FinishTime: number;
  public static Stamp: number;
  public static Description: string;
  public static JobControl: number;
  public static HostName: string;
  public static Comment: string;
  public static LocalAddress: string;
  public static Level: number;
  public static TaskGroupId: string;
  public static TaskGroupName: string;
  public static JobHandlerId: string;
  public static NotificationId: string;
  public static NotificationType: number;
  public static JobDependencies: string;
  public static ExecuteHostName: string;
  public static Parameters: string;
  public static  CreatedOn: number;
  public static CreatedBy: string;
  public static ModifiedOn: number;
  public static ModifiedBy: string;
  public static Tag: string;
}

export enum JobState {
  Wait = 0,
  InProgress = 1,
  Finished = 2,
  Failed = 3,
  Exception = 4,
  Stopped = 5,
  Skipped = 6,
  Stopping = 7,
  Starting = 8,
  Pausing = 9,
  Paused = 10,
  Reruning = 11,
}

export class JobManagerServiceResult extends AbstractServiceResult {
  JobDtos?: JobDto[];
  public static HasRunningJob: boolean;
  public static Success: boolean;
  JobDto?: JobDto;
  JobQueueNames?: string[];
  Stream?: [];
  StreamName?: string;
  JobDetailPagerResult?: PagerResult<JobDetailDto>;
  JobDetailCustomPagerResult?: PagerResult<any>;
  JobPagerResult?: PagerResult<JobDto>;
  public static JobDetails: JobDetailDto[];
  GlobalSettings?: GlobalSettings;
}

export const JobPermissionCostants = {
  ObjectCode: 202001,
  Read: 1,
  Create: 2,
  Update: 4,
  Delete: 8,
};

export class GlobalSettings {
  Id?: string;
  GlobalType?: GlobalTypeEnum;
  ProfileJson?: string;
}
export enum GlobalTypeEnum {
  Retation = 0,
}

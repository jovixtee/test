import { Pager } from '../node/NodeContract';
import {MethodType} from '../../common/contracts/ModelContracts';

// export class BackendAPIVersionDetail {
//     Id?: string;
//     Endpoint?: string;
//     ControlPolicyID?: string;
//     AuthenticationID?: string;
//     Authentication?: string;
//     BackendID?: string;
//     Status?: StatusEnum;
// }
export enum MethodTypeEnum {
    GET = 1,
        POST = 2,
        PUT = 3,
        PATCH = 4,
        DELETE = 5,
        COPY = 6,
        HEAD = 7,
        OPTIONS = 8,
        LINK = 9,
        UNLINK = 10,
        PURGE = 11,
        LOCK = 12,
        UNLOCK = 13,
        PROPFIND = 14,
        VIEW = 15
}
export const MethodTypeMap = new Map<string, MethodTypeEnum>([
    ["GET", MethodTypeEnum.GET],
    ["POST", MethodTypeEnum.POST],
    ["PUT", MethodTypeEnum.PUT],
    ["PATCH", MethodTypeEnum.PATCH],
    ["DELETE", MethodTypeEnum.DELETE],
    ["COPY", MethodTypeEnum.COPY],
    ["HEAD", MethodTypeEnum.HEAD],
    ["OPTIONS", MethodTypeEnum.OPTIONS],
    ["LINK", MethodTypeEnum.LINK],
    ["UNLINK", MethodTypeEnum.UNLINK],
    ["PURGE", MethodTypeEnum.PURGE],
    ["LOCK", MethodTypeEnum.LOCK],
    ["UNLOCK", MethodTypeEnum.UNLOCK],
    ["PROPFIND", MethodTypeEnum.PROPFIND],
    ["VIEW", MethodTypeEnum.VIEW],
])

export const VersionthodTypeMap = new Map<string, MethodType>([
    ["Authentication Issue", MethodType.AuthenticationIssue],
    ["Authentication Revoke", MethodType.AuthenticationRevoke],
    ["Service Method", MethodType.ServiceMethod],
])
export class ParameterObject {
    addData?: VersionMethodParameter[];
    updateData?: VersionMethodParameter[];
    deleteData?: VersionMethodParameter[];

}


export class VersionMethodParameter {
    Id: string = "";
    Key?: string;
    DefaultValue?: string | number;
    ParamterTypeID?: string;

}


export class EditTableData extends VersionMethodParameter {
    IsEdit: boolean = false;
    IsNewData: boolean = false;
}

export class QueryBackendPager extends Pager {
    constructor(pageSize: number, jumpPage: number, SearchValue: string) {
        super(
            pageSize,
            jumpPage,
            "Name",
            SearchValue, ["Name"],
            []
        )
    }
}

export class QueryBackendMethodPager extends Pager {
    constructor(pageSize: number, jumpPage: number, SearchValue: string, VersionId?: string) {
        super(
            pageSize,
            jumpPage,
            "ModifiedOn",
            SearchValue, [],
            [
                {
                    "ColumnName": "VersionId",
                    "ColumnValues": [VersionId!]
                }
            ]
        )
    }
}


export interface IDictionary {
    key?: string,
    value?: string
}

export interface IEditTableRef {
    getTableResult: () => {
        addData: VersionMethodParameter[];
        updateData: VersionMethodParameter[];
        deleteData: VersionMethodParameter[];
        isEditing: boolean;
    }
}

export interface IPaginationC {
    currentPage: number;
    currentPageSize: number;
    total?: number;

}

export interface ISelectOption {
    key: string,
    value: string
}
export interface IGetSelectResult {
    [name: string]: ISelectOption[]
}



export interface VoidCallBackFunction {
    (): void
}

export enum ParameterTypeEnum {
    String = 1,
    Number = 2,
    Boolean = 3
}


export enum FromType {
    Frontend = 0,
    Backend = 1
}



export const ParameterTypeMap = new Map<string, ParameterTypeEnum>([
    ["String", ParameterTypeEnum.String],
    ["Number", ParameterTypeEnum.Number],
    ["Boolean", ParameterTypeEnum.Boolean],
])



export const ContentTypeDefault: string[] = [
    "application/xhtml+xml",
    "application/xml",
    "application/atom+xml",
    "application/json",
    "application/octet-stream",
    "application/x-www-form-urlencoded",
    "multipart/form-data",
    "text/html",
    "text/xml"
]
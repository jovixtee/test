import { Drawer, Form, Input, Button, Select, Spin } from 'antd';
import React, { FC, useEffect, useState } from 'react';
import { VoidCallBackFunction } from './BackendAPIContracts';
import {BackendDto, BackendDetailsDto, TypeMap, ProtocolType} from '../../common/contracts/ModelContracts';
import { CreateBackend } from './BackendAPIApiService';

interface IAPIForm {
    Name?: string;
    Description?: string;
    Protocol?: ProtocolType;
    BaseAddress?: string;
}

interface IManageAPIDrawerProps {
    visibile: boolean;
    cancelClick: VoidCallBackFunction;
    isEdit: boolean;
    defaultData: BackendDetailsDto;
    getTableData: VoidFunction;
}

const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 12 },
};
const { Option } = Select;

const ManageAPIDrawer: FC<IManageAPIDrawerProps> = (props) => {
    const [loading, setLoading] = useState<boolean>(false);
    const [form] = Form.useForm();

    useEffect(() => {
        form.setFieldsValue({
            Name: props.defaultData.Name,
            Description: props.defaultData.Description,
            Protocol: props.defaultData.Protocol,
            BaseAddress:props.defaultData.BaseAddress
        })
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.defaultData])

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };
    const onFinish = (values: IAPIForm) => {
        setLoading(true);
        let requestObject = new BackendDto();
        requestObject.Name = values.Name;
        requestObject.Description = values.Description;
        requestObject.Protocol = values.Protocol;
        requestObject.BaseAddress = values.BaseAddress;
        if (props.isEdit && props.defaultData.Id) {
            requestObject.Id = props.defaultData.Id;
        }
        CreateBackend(requestObject)
            .then(res => {
                closeDrawer();
                props.getTableData();
            })
            .catch(err => {
                setLoading(false);
            })

    }
    const closeDrawer = (): void => {
        setLoading(false);
        form.resetFields();
        props.cancelClick();
    }

    return <Drawer
        visible={props.visibile}
        width={720}
        destroyOnClose
        forceRender
        onClose={closeDrawer}
        title={props.isEdit ? "Edit API" : "Create a new API"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" style={{ marginRight: 8 }} loading={loading} onClick={() => form.submit()}>Save</Button>
                <Button onClick={closeDrawer} >Cancel</Button>
            </div>
        }
    >
        <Spin spinning={loading}>
            <Form {...layout} form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '20px' }}>
                <Form.Item label="Name" name="Name" rules={[{ required: true, message: 'Please input name!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Protocol" name="Protocol" rules={[{ required: true, message: 'Please input protocol!' }]}>
                    <Select style={{ minWidth: 120 }} disabled={props.isEdit}>
                        {
                            Array.from(TypeMap).map(([key, value]) => <Option value={value} key={value}>{key}</Option>)
                        }
                    </Select>
                </Form.Item>
                <Form.Item label="Base Address" name="BaseAddress" rules={[{ required: true, message: 'Please input a base address!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Description" name="Description" rules={[{ required: false, message: 'Please input description!' }]}>
                    <Input.TextArea rows={3} />
                </Form.Item>
            </Form>
        </Spin>


    </Drawer>
}
export default ManageAPIDrawer
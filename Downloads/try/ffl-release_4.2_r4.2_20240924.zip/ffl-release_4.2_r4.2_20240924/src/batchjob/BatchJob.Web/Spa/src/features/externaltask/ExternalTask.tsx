import React from 'react';
import { Breadcrumb, Drawer } from 'antd';
import { Link } from 'react-router-dom';
import ExternalTaskTable, { IData } from './ExternalTaskTable';
import ExternalTaskForm from './ExternalTaskForm';
import { registerI18n, getI18N } from '../../utils/I18nutil';
import en from './loc/en.json';
import zh from './loc/zh.json';
import './externaltask.css';
import PathConfig from '../../common/PathConfig';
interface IExternalTaskState {
    showCreateModal: boolean;
    item?: IData;
}
class ExternalTask extends React.Component<any, IExternalTaskState> {
    constructor(props: any, state: IExternalTaskState) {
        super(props);
        this.state = {
            showCreateModal: false,
            item: undefined
        };
        registerI18n("ExternalTask", zh, "zh");
        registerI18n("ExternalTask", en);
    }
    showForm = (item?: any): void => {
        this.setState({ item: item, showCreateModal: true });
    }
    hideCreate = (): void => {
        this.setState({ showCreateModal: false });
    }
    render(): JSX.Element {
        console.log(getI18N("ExternalTask", "Test1"));
        console.log(getI18N("ExternalTask", "Test1", "zh", "zh"));
        return (
            <div>
                <Breadcrumb>
                    <Breadcrumb.Item>
                        <Link to={PathConfig.addPrefix('/home')}>Home</Link>
                    </Breadcrumb.Item>
                    <Breadcrumb.Item>ExternalTask</Breadcrumb.Item>
                </Breadcrumb>
                <ExternalTaskTable showForm={this.showForm} />
                <Drawer
                    title="Basic Modal"
                    width="720px"
                    visible={this.state.showCreateModal}
                    onClose={this.hideCreate}
                    footer={null}
                >
                    <ExternalTaskForm onCancel={this.hideCreate} item={this.state.item} />
                </Drawer>
            </div>
        );
    }
}

export default ExternalTask;
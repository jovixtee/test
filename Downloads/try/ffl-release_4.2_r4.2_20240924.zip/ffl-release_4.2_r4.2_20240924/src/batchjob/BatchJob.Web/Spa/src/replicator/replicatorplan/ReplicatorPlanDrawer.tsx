import { Button, Drawer, Form, Steps } from "antd";
import React, { useEffect, useState, useRef } from "react";
import * as ReplicatorContract from "../ReplicatorContract";
import { GetApiService } from "../ReplicatorApiService";
import ReplicatorPlanForm from "./ReplicatorPlanForm";
import ReplicatorAddMapping from "./ReplicatorAddMapping";
import ReplicatorPlanSettings from "./ReplicatorPlanSettings";
import UINotrification from "../../common/UINotrification";
const { Step } = Steps;
interface ICorpusProps {
  dataSource?:ReplicatorContract.ReplicatorPlan,
  visible: boolean;
  onCancel: Function;
  refreshTable:Function;
}

export const ReplicatorPlanDrawer = (props: ICorpusProps) => {
  const childRef: any = useRef();
  const [current, setCurrent] = useState(0);
  const [dataSource, setDataSource] = useState<ReplicatorContract.ReplicatorPlan>({});
  

  useEffect(() => {
    if(props.dataSource?.Id){
      setDataSource(props.dataSource)
    }


 }, [props.dataSource]);

  const nextAddMapping = (isSuccessed: boolean, plan?: ReplicatorContract.ReplicatorPlan) => {
    if (isSuccessed) {
        setCurrent(1);
        setDataSource(plan!);
    }
  }

  const nextSetting = (isSuccessed: boolean, plan?: ReplicatorContract.ReplicatorPlan) => {
    if (isSuccessed) {
        setCurrent(2);
        console.log(plan)    
        setDataSource(plan!);
    }
  }

  const saveReplicatorPlan = (isSuccessed: boolean, plan?: ReplicatorContract.ReplicatorPlan) => {
    if (isSuccessed) {
      GetApiService().CreateReplicatorPlan(plan!).then(e=>{
        UINotrification.success("Created successfully");
        props.onCancel();
        props.refreshTable();
      }).catch(e=> UINotrification.error(e));
      
    }
  }


  const steps = [
    {
      title: "Replicator Plan",
      content: <ReplicatorPlanForm ref={childRef}  dataSource={dataSource} onNextAddMapping={nextAddMapping} />,
    },
    {
      title: "Add Mappings",
      content: <ReplicatorAddMapping dataSource={dataSource!} ref={childRef} onNextSetting={nextSetting}/>,
    },
    {
      title: "Replicator Settings",
      content: <ReplicatorPlanSettings dataSource={dataSource!} ref={childRef} onSaveReplicatorPlan={saveReplicatorPlan}/>,
    }
  ];

  useEffect(() => {
    setCurrent(0)
}, [props.visible])


const onNext = () => {
  if (current === 0) {
      childRef.current.onNext()
  }
  if (current === 1) {
      childRef.current.onAddMappingNext()
  }
  if (current === 2) {
    childRef.current.onNextSetting()
}
}



const onBack = () => {
  setCurrent(current - 1);
}


  return (
    <Drawer
      visible={props.visible}
      width={720}
      onClose={(e) => props.onCancel()}
      title={props?.dataSource ? "Edit replicator plan" : "Create a new replicator plan"}
      footer={
        <div style={{ textAlign: "right" }}>
          {current > 0 && (
            <Button
              type="primary"
              style={{ marginRight: 8 }}
              onClick={() => onBack()}
            >
              Previous
            </Button>
          )}

          {current < steps.length - 1 && (
            <Button
              type="primary"
              style={{ marginRight: 8 }}
              onClick={() => onNext()}
            >
              Next
            </Button>
          )}
          {current === steps.length - 1 && (
            <Button
              type="primary"
              style={{ marginRight: 8 }}
              onClick={() => onNext()}
            >
              Save
            </Button>
          )}
          <Button onClick={(e) => props.onCancel()}>Cancel</Button>
        </div>
      }
    >
      <div>
        <Steps current={current}>
          {steps.map((item) => (
            <Step key={item.title} title={item.title} />
          ))}
        </Steps>
        <div className="steps-content" style={{marginTop:20}}>{steps[current].content}</div>
      </div>
    </Drawer>
  );
};

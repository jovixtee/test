import React from 'react';
import CustomMenu from './CustomMenu';
import {menus} from './menu'


const SiderNav = (props: any) => {

  return (
    // <CustomMenu menus={menus} onMenuChanged={props.onNavChanged} />
    <CustomMenu menus={menus} />
  );
};

export default SiderNav;
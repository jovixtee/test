export class UserSummaryObject {
    UserId?: string;
    IdentityId?: string;
    DisplayName?: string;
    Email?: string;
    Username?: string;
    Authentication?: number;
    UserRole?: UserRoleEnum;
    Privileges?: Array<RolePrivilegeObject>;
}

export enum UserRoleEnum {
    UnKnown = 0,
    Owner = 1,
    Member = 2
}

export enum AuthenticationTypeEnum {
    UnKnown = 0,
    Basic = 1,
    ActiveDirectory = 2,
    ApmOidc = 3
}

export enum AccountStatusEnum {
    UnKnown = 0,
    Enable = 1,
    Disable = 2
}

export class PassportDto {
    Authentication?: AuthenticationTypeEnum;
    UserName?: string;
    Email?: string;
    Password?: string;
    RememberMe?: boolean;
    OidcRoles?: Array<string>;
}

export class RolePrivilegeObject {
    RolePrivilegeId?: string;
    PrivilegeId?: string;
    PrivilegeName?: string;
    AccessRight?: number;
    ObjectCode?: number;
}


export enum ServiceResultType {
    Success = 0,
    Failed = 1,
    Error = 2,
    Exception = 3,
};

export class LoginResult {
    Type?: ServiceResultType;
    Message?: string;
};
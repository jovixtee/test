import apiservice from '../../utils/fetchutil';
const serve = apiservice()
export const QueryUserSummary = (): Promise<any> => {
    return new Promise((resolve, reject) => {
      serve.post("/IAccountManagerService/QueryUserSummary").then((result) => {
        resolve(result)
      }).catch(error => {
        reject(error)
      })
    })
  }
  export const logoutFun = (): Promise<any> => {
    return new Promise((resolve, reject) => {
      serve.post("/IPassportService/Logout").then((result) => {
        resolve(result)
      }).catch(error => {
        reject(error)
      })
    })
  }
  export const UpdateUser = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
      serve.post("/IAccountManagerService/UpdateUserPassword", params).then((result) => {
        resolve(result)
      }).catch(error => {
        reject(error)
      })
    })
  }
import { Button, Drawer, Form, Steps } from "antd";
import React, { useEffect, useState, useRef } from "react";
import * as ReplicatorContract from "../ReplicatorContract";
import { GetApiService } from "../ReplicatorApiService";
import { UploadOutlined } from "@ant-design/icons";
import { UploadFile } from "antd/lib/upload/interface";
import { save } from "react-cookies";
import UploadCorpus from "./UploadCorpus";
import CorpusForm from "./CorpusForm";
import UINotrification from "../../common/UINotrification";
const { Step } = Steps;
interface ICorpusProps {
  visible: boolean;
  onCancel: Function;
  refreshTable:Function;
  dataSource?: ReplicatorContract.ReplicatorsResult;

}

export const CorpusDrawer = (props: ICorpusProps) => {
  const childRef: any = useRef();
  const [current, setCurrent] = useState(0);
  const [corpus, setCorpus] = useState<ReplicatorContract.CorpusDto>();
  const nextIsSuccess = (
    isSuccessed: boolean,
    values?: ReplicatorContract.CorpusDto
  ) => {
    if (isSuccessed) {
      setCurrent(1);
      setCorpus(values);
    }
  };

  const saveSuccess = (isSuccessed: boolean, data?: ReplicatorContract.DataModeing) => {
    if (isSuccessed) {
      console.log(data);
        GetApiService().CreateDatamodeling(data!).then(e=>{
          UINotrification.success("Created successfully");
          props.onCancel();
          props.refreshTable();
        }).catch(e=> UINotrification.error(e));
    }
  };

  const steps = [
    {
      title: "corpus",
      content: <CorpusForm ref={childRef} dataSource={props!.dataSource!.Corpus} nextIsSuccess={nextIsSuccess} />,
    },
    {
      title: "Upload corpus",
      content: (
        <UploadCorpus
          treeData={props!.dataSource!.TreeData}
          corpus={corpus!}
          ref={childRef}
          saveSuccess={saveSuccess}
        />
      ),
    },
  ];

  useEffect(() => {
    setCurrent(0);
  }, [props.visible]);

  const onNext = () => {
    if (current === 0) {
      childRef.current.onNext();
    }
  };

  const onBack = () => {
    setCurrent(current - 1);
  };
  const save = () => {
    if (current === 1) {
      childRef.current.save();
    }
  };

  return (
    <Drawer
      visible={props.visible}
      width={720}
      onClose={(e) => props.onCancel()}
      title={props?.dataSource ? "Edit corpus" : "Create a new corpus"}
      footer={
        <div style={{ textAlign: "right" }}>
          {current > 0 && (
            <Button
              type="primary"
              style={{ marginRight: 8 }}
              onClick={() => onBack()}
            >
              Previous
            </Button>
          )}

          {current < steps.length - 1 && (
            <Button
              type="primary"
              style={{ marginRight: 8 }}
              onClick={() => onNext()}
            >
              Next
            </Button>
          )}
          {current === steps.length - 1 && (
            <Button
              type="primary"
              style={{ marginRight: 8 }}
              onClick={() => save()}
            >
              Save
            </Button>
          )}
          <Button onClick={(e) => props.onCancel()}>Cancel</Button>
        </div>
      }
    >
      <div>
        <Steps current={current}>
          {steps.map((item) => (
            <Step key={item.title} title={item.title} />
          ))}
        </Steps>
        <div className="steps-content" style={{ marginTop: 20 }}>
          {steps[current].content}
        </div>
      </div>
    </Drawer>
  );
};

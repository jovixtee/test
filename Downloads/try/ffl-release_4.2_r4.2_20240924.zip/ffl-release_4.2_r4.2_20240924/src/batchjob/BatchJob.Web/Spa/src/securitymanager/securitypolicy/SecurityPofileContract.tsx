// class KeyVaultConfig {
//     KeyVaultId ?: string;
//     Name?: string;
//     ClientId?: string;
//     ClientSecret?: string;
//     KeyIdentity?: string;    
// };
class AsymmetricKey {
    AsymmetricCryptographyId?: string;
    Name?: string;
    PublicKey?: string;
    PrivateKey?: string;
};
class SymmetricKey{
    SymmetricCryptographyId?: string;
    Name?: string;
    EncryptionLength?: HashType;
    EncryptionKey?: string;
    MatchPassphrase?: string;
};
class CryptoDto{
    Key?: string;
    CryptoType?: CryptoType;
    Value?: string;
    PrivateKey?: string;
};
class SecuritySettingResult<T>{
    Result?: T;
};

enum CryptoType{
    AES,
    RSA,
    KeyVault
}

enum HashType{
    SHA256 = 0,
    SHA384 = 1,
    SHA512 = 2
}
class SecurityPofileDto {
    AsymmetricKey?: AsymmetricKey;
    //KeyVaultConfig?: KeyVaultConfig;
    SymmetricKey?: SymmetricKey 
}

const SecurityPermissionConstants={
    ObjectCode:103001,
    Read:1,
    Create:2,
    Update:4,
    Delete:8
};

export {
    SecuritySettingResult, SymmetricKey, AsymmetricKey, SecurityPofileDto,
    CryptoType,HashType,SecurityPermissionConstants,CryptoDto
};
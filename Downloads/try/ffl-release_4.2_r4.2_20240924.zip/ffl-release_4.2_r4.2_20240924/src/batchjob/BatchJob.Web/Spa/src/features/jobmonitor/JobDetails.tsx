import React, { useEffect, useState } from 'react';
import { Button, Row, Col, Radio } from 'antd';
import { DownloadOutlined, CloseOutlined } from '@ant-design/icons';
import { Link } from 'react-router-dom';
import DetailsSummary from './DetailsSummary';
import DetailsTable from './DetailsTable';
import PathConfig from '../../common/PathConfig';
import { JobDto } from './JobContract';
import apiservice from '../../utils/fetchutil';

const JobDetails = (props: any) => {
    const [jobId, setJobId] = useState<string>('');
    const [mode, setMode] = useState<string>('Summary');
    const [data, setData] = useState<JobDto | undefined>();

    const handleModeChange = function (e: any) {
        const target = e.target.value;
        setMode(target);
    };
    useEffect(() => {
        console.log(props.location.state.record)
        setData({ ...props.location.state.record })
        setJobId(props.location.state.record.Id)
    }, [props.location.state.record])

    const downloadBtn = async () => {
        apiservice().post('/IJobManagerService/DownloadJobDetails',{ jobId: jobId, timeZoneOffSet: 0 }, { accept: '*/*' }).then(response => {
            response.blob().then((blob: any) => {
                const aLink = document.createElement('a');
                document.body.appendChild(aLink);
                aLink.style.display = 'none';
                const objectUrl = window.URL.createObjectURL(blob);
                aLink.href = objectUrl;
                aLink.download = 'JobDetails.zip';
                aLink.click();
                document.body.removeChild(aLink);
            });
        });
    

        // axios.post('https://10.1.54.211:8011/api/IJobManagerService/DownloadJobDetails', { jobId: data.Id, timeZoneOffSet: 0 }, {
        //     responseType: 'blob'
        // }).then(function (res) {
        //     console.log(res)
        //     var blob = res.data;
        //     // FileReader主要用于将文件内容读入内存
        //     var reader = new FileReader();
        //     reader.readAsDataURL(blob);
        //     // onload当读取操作成功完成时调用
        //     reader.onload = function (e) {
        //         var a = document.createElement('a');
        //         // 获取文件名fileName
        //         var fileName = res.headers["content-disposition"].split("=");
        //         fileName = fileName[fileName.length - 1];
        //         fileName = fileName.replace(/"/g, "");
        //         a.download = fileName;
        //         a.href = e.target.result;
        //         document.body.appendChild(a);
        //         a.click();
        //         document.body.removeChild(a);
        //     }
        // });
        // let now = new Date();
        // let timeZoneOffSet = now.getTimezoneOffset();
        // let result = await DownloadJobDetails({ jobId: data.Id, timeZoneOffSet: 0 })
        // console.log(result)
        // let serve = apiservice('https://10.1.54.211:8011/api')
        // serve.post("/IJobManagerService/DownloadJobDetails", { jobId: data.Id, timeZoneOffSet: 0 }).then((result) => {
        //     console.log(result)
        //     //return result
        // }).catch(error => {

        //     console.log(error)
        // })

    }
    return (
        <div>
            <Row style={{ marginTop: "20px" }}>
                <Col span={18}>
                    <Button type="text" style={{ padding: '0px', paddingRight: '15px' }} onClick={downloadBtn}><DownloadOutlined />Download </Button>
                    <Button type="text">
                        <CloseOutlined style={{ color: 'red' }} /> <Link to={PathConfig.addPrefix("/jobmonitor")}>Cancel</Link>
                    </Button>
                </Col>
            </Row>
            <Radio.Group onChange={handleModeChange} value={mode} buttonStyle="solid"
                style={{ margin: "20px 0px 40px" }}>
                <Radio.Button value="Summary">Summary</Radio.Button>
                <Radio.Button value="Details">Details</Radio.Button>
            </Radio.Group>
            {
                mode === 'Summary' ?
                    <DetailsSummary record={data} ></DetailsSummary>
                    :
                    <DetailsTable jobId={jobId}></DetailsTable>
            }
        </div>
    );
};
export default JobDetails;
import React, { useState } from 'react';
import { Modal, message, Button } from 'antd';
import ManagerForm from './ManagerForm';
import { PagedQuery, DeleteProfile, CreateProfile, UpdateProfile } from '../ManagerApiserve';
import { PlusOutlined, EditOutlined, DeleteOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import { convertTicksToFormatDate } from '../../utils/dateconvert';
import { hasPermission } from '../../utils/permissionutil';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import AmpCommonTable, { IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { QueryProfile } from '../ManagerApiserve'
import { PermissionConstants, formartLevel } from './NotificationManagerContracts';
import ProfileReadDrawer from "./ProfileReadDrawer";
const { confirm } = Modal;
const Index = () => {

    const [refresh, setRefresh] = useState(1);
    const [selectedRecords, setSelectedRecords] = useState<any[]>();
    const [EditFormData, setEditFormData] = useState<any>({});
    const [visible, setVisible] = useState<boolean>(false);
    const [editVisible, setEditVisible] = useState<boolean>(false);
    const [profileVisible, setProfileVisible] = useState<boolean>(false);

    const columns = [
        {
            title: 'Notification Name', 
            dataIndex: 'Name',
            key: 'Name',
            sorter: true,
            width: '16%',
            render: (name: any, obj: any, index: any) => {
                return (<Button type='link' onClick={async () => {
                    let result = await QueryProfile({ id: obj.Id })
                    let data = formartLevel(result.Result)
                    console.log(data)
                    setEditFormData({ ...data });
                    setProfileVisible(true)
                }}>{name}</Button>)
            },
        }, {
            title: 'Description ',
            dataIndex: 'Description',
            key: 'Description',
            width: '16%',
        }, {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
            width: '16%',
        }, {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            width: '16%',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
            width: '16%'
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }
    ];

    const onCloseFun = () => {
        setVisible(false);
        setEditVisible(false);
        setProfileVisible(false);
    }

    let addSourceBtn = () => {
        setVisible(true)
    }

    let updateSourceBtn = () => {
        QueryProfile({ id: selectedRecords![0].Id }).then(res => {
            let data = formartLevel(res.Result)
            setEditFormData({ ...data });
            setEditVisible(true)
        });
    }

    let deleteSourceBtn = () => {
        let deleteIdArr: any[] = []
        selectedRecords!.forEach((item: any) => {
            deleteIdArr.push(item.Id)
        })
        confirm({
            title: 'Warning',
            icon: <ExclamationCircleOutlined />,
            content: 'You are about to delete the selected items. Are you sure you want to proceed?',
            onOk() {
                DeleteProfile({
                    ids: deleteIdArr
                }).then(res => {
                    if (res.Type === 0) {
                        message.success('delete succeed')
                    }
                }).finally(() => setRefresh(refresh + 1));
            },
            onCancel() {
                console.log('Cancel');
            },
        })
    }

    const getAddFormData = (data: any, emailSource: any, smsSource: any) => {
        onCloseFun();
        let Recipients = emailSource.map((item: any) => {
            return {
                Email: item.Address,
                ReportType: item.ReportType
            }
        })
        let Mobiles = smsSource.map((item: any) => {
            return String(item.PhoneNumber)
        })
        let SummaryLevel = 0
        if (data.SummaryLevel) {
            data.SummaryLevel.forEach((level: number) => {
                SummaryLevel = SummaryLevel | level
            })
        }
        let DetailLevel = 0
        if (data.DetailLevel) {
            data.DetailLevel.forEach((level: number) => {
                DetailLevel = DetailLevel | level
            })
        }
        let LogLevel = 0
        if (data.LogLevel) {
            data.LogLevel.forEach((level: number) => {
                LogLevel = LogLevel | level
            })
        }
        let SMSSummaryLevel = 0
        if (data.SMSSummaryLevel) {
            data.SMSSummaryLevel.forEach((level: number) => {
                SMSSummaryLevel = SMSSummaryLevel | level
            })
        }
        let params:any = {
            "profile": {
                "Name": data.Name,
                "Description": data.Description,
                "EmailProfile": {
                    "Status": 0,
                    "Recipients": Recipients,
                    "Format": data.Format,
                    "SummaryLevel": SummaryLevel,
                    "DetailLevel": DetailLevel,
                    "LogLevel": LogLevel,
                    "ConnectionId":data.ConnectionId,
                    "ProtocoIType":data.ProtocolType
                },
                "SmsProfile": {
                    "Status": 0,
                    "SummaryLevel": SMSSummaryLevel,
                    "Mobiles": Mobiles,
                    "ConnectionId":data.ConnectionId,
                    "ProtocoIType":data.ProtocolType
                },
                "profileType":data.NotificationAddress
               
            }
        }
        CreateProfile(params).then(res => {
            message.success('Create Profile Succeed!');
        }).finally(() => setRefresh(refresh + 1));
    }


    const getEditFormData = (data: any, emailSource: any, smsSource: any, Id: string) => {
    
        onCloseFun();
        let Recipients = emailSource.map((item: any) => {
            return {
                Email: item.Address,
                ReportType: item.ReportType
            }
        })
        let Mobiles = smsSource.map((item: any) => {
            return String(item.PhoneNumber)
        })
        let SummaryLevel = 0
        if (data.SummaryLevel) {
            data.SummaryLevel.forEach((level: number) => {
                SummaryLevel = SummaryLevel | level
            })
        }
        let DetailLevel = 0
        if (data.DetailLevel) {
            data.DetailLevel.forEach((level: number) => {
                DetailLevel = DetailLevel | level
            })
        }
        let LogLevel = 0
        if (data.LogLevel) {
            data.LogLevel.forEach((level: number) => {
                LogLevel = LogLevel | level
            })
        }
        let SMSSummaryLevel = 0
        if (data.SMSSummaryLevel) {
            data.SMSSummaryLevel.forEach((level: number) => {
                SMSSummaryLevel = SMSSummaryLevel | level
            })
        }
        let params:any = {
            "profile": {
                "Id": Id,
                "Name": data.Name,
                "Description": data.Description,
                "EmailProfile": {
                    "Status": 0,
                    "Recipients": Recipients,
                    "Format": data.Format,
                    "SummaryLevel": SummaryLevel,
                    "DetailLevel": DetailLevel,
                    "LogLevel": LogLevel,
                    "ConnectionId":data.ConnectionId,
                    "ProtocoIType":data.ProtocolType
                },
                "SmsProfile": {
                    "Status": 0,
                    "SummaryLevel": SMSSummaryLevel,
                    "Mobiles": Mobiles,
                    "ConnectionId":data.ConnectionId,
                    "ProtocoIType":data.ProtocolType
                },
                "profileType":data.NotificationAddress
            }
        }
        UpdateProfile(params).then(res => {
            message.success('Update User Succeed!');
        }).finally(() => {
            setRefresh(refresh + 1);
        })
    }


    const buttons: Array<IAmpTableButton> = [{
        Text: "Create",
        Primary: true,
        Icon: <PlusOutlined />,
        OnClick: addSourceBtn,
        EnableMode: 'always',
        HasPermission: hasPermission(PermissionConstants.ObjectCode, PermissionConstants.Create)
    }, {
        Text: "Edit",
        Icon: <EditOutlined />,
        OnClick: updateSourceBtn,
        EnableMode: 'single',
        HasPermission: hasPermission(PermissionConstants.ObjectCode, PermissionConstants.Update)
    }, {
        Text: "Delete",
        Icon: <DeleteOutlined />,
        OnClick: deleteSourceBtn,
        EnableMode: 'multiple',
        HasPermission: hasPermission(PermissionConstants.ObjectCode, PermissionConstants.Delete)
    }];

    const ApiPagerQuery = async (exp: PagerExpression) => {
        let obj = { expression: { ...exp } }
        let result = await PagedQuery(obj)
        return { total: result!.Result.TotalNumber, records: result!.Result.Result };
    }

    return (
        <>
            <AmpCommonTable
                Type="checkbox"
                RowKey="Id"
                Columns={columns}
                PagerQuery={ApiPagerQuery}
                OnSelectedChanged={records => setSelectedRecords(records)}
                SearchKeys={["Name"]}
                Refresh={refresh}
                Buttons={buttons}
                EnableSearch />

            {
                visible &&
                <ManagerForm
                    visible={visible}
                    onCloseFun={onCloseFun}
                    onGetFormData={getAddFormData}
                    title={'New Recipients Profile'} />
            }
            {editVisible &&
                <ManagerForm
                    visible={editVisible}
                    onCloseFun={onCloseFun}
                    onGetFormData={getEditFormData}
                    EditFormData={EditFormData}
                    title={'Edit Recipients Profile'} />
            }

            {profileVisible &&
                <ProfileReadDrawer
                    visible={profileVisible}
                    closeDrawer={onCloseFun}
                    refresh={() => setRefresh(refresh + 1)}
                    data={EditFormData}
                />
            }
        </>
    );
};
export default Index;
import { TaskDto, TaskManagerServiceResult } from './TaskManagerContract';
import {HolidaySettingServiceResult} from '../holidaysetting/HolidaySettingContract';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import { TaskGroupDto } from './TaskManagerContract';
import apiservice from '../../utils/fetchutil';

class TaskManagerApiService {
    private constructor() { }
    private static instance: TaskManagerApiService;
    public static getInstance(): TaskManagerApiService {
        if (this.instance == null) {
            this.instance = new TaskManagerApiService();
        }
        return TaskManagerApiService.instance;
    }

    public CreateTask(task: TaskDto, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/CreateTask', { task: task }).then(result => callback?.(result));
    }
    public UpdateTask(task: TaskDto, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/UpdateTask', { task: task }).then(result => callback?.(result));
    }
    public DeleteTasks(ids: Array<string>, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/DropTasks', { taskIds: ids }).then(result => callback?.(result));
    }
    public UpdateState(taskid: string, state: number, callback?: (result: TaskManagerServiceResult) => void): void {
        let dto = new TaskDto();
        dto.Id = taskid;
        dto.State = state;
        apiservice().post('/ITaskManagerService/UpdateTaskState', { task: dto }).then(result => callback?.(result));
    }
    public PagerQuery(pager: PagerExpression): Promise<TaskManagerServiceResult>  {
        return apiservice().post('/ITaskManagerService/PagerQuery', { taskPager: pager });
    }
    public RunTask(id: string, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/RunTask', { id: id }).then(result => callback?.(result));

    }
    public LoadTask(id: string, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/LoadTaskDetail', { id: id }).then(result => callback?.(result));
    }
    public CreateGroup(dto: TaskGroupDto, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/CreateGroup', { dto: dto }).then(result => callback?.(result));
    }
    public DeleteGroupByIds(ids: Array<string>, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/DeleteGroupByIds', { ids: ids }).then(result => callback?.(result));
    }
    public UpdateGroup(dto: TaskGroupDto, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/UpdateGroup', { dto: dto }).then(result => callback?.(result));
    }
    public GetGroupById(id: string, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/GetGroupById', { id: id }).then(result => callback?.(result));
    }
    public PagerQueryGroup(pager: PagerExpression): Promise<TaskManagerServiceResult> {
        return apiservice().post('/ITaskManagerService/PagerQueryGroup', { pager: pager });
    }
    public EnableTaskGroup(id: string, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/EnableTaskGroup', { id: id }).then(result => callback?.(result));
    }
    public DisableTaskGroup(id: string, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/DisableTaskGroup', { id: id }).then(result => callback?.(result));
    }
    public IsGroupNameExists(name: string, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/IsGroupNameExists', { name: name }).then(result => callback?.(result));
    }
    public RunTaskGroup(id: string, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/RunTaskGroup', { id: id }).then(result => callback?.(result));
    }
    public RunTaskGroupBySchedule(id: string, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/RunTaskGroupBySchedule', { id: id }).then(result => callback?.(result));
    }
    public QueryTasksByHandlerId(id: string, callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/QueryTasksByHandlerId', { handleId: id }).then(result => callback?.(result));
    }
    public GetAllActionSettings(callback?: (result: TaskManagerServiceResult) => void): void {
        apiservice().post('/ITaskManagerService/GetAllActionSettings', undefined).then(result => callback?.(result));
    }
    public ImportTaskGroup(file: any, callback?: (result: TaskManagerServiceResult) => void): void {
        const fd = new FormData();

        fd.set('arg', JSON.stringify({ _streamLength: file.size, importArguments: { FileName: file.name } }));
        fd.set('file', file);

        apiservice().post('/ITaskManagerService/ImportTaskGroup', fd).then(result => callback?.(result));
    }
    public ImportTask(file: any, callback?: (result: TaskManagerServiceResult) => void): void {
        const fd = new FormData();

        fd.set('arg', JSON.stringify({ _streamLength: file.size, importArguments: { FileName: file.name } }));
        fd.set('file', file);

        apiservice().post('/ITaskManagerService/Import', fd).then(result => callback?.(result));
    }
    public ExportTask(taskIds: string[]): void {
        apiservice().post('/ITaskManagerService/Export', { taskIds: taskIds }, { accept: '*/*' }).then(response => {
            response.blob().then((blob: any) => {
                const aLink = document.createElement('a');
                document.body.appendChild(aLink);
                aLink.style.display = 'none';
                const objectUrl = window.URL.createObjectURL(blob);
                aLink.href = objectUrl;
                aLink.download = 'Task.zip';
                aLink.click();
                document.body.removeChild(aLink);
            });
        });
    }
    public ExportTaskGroup(taskGroupIds: string[]): void {
        apiservice().post('/ITaskManagerService/ExportTaskGroup', { taskGroupIds: taskGroupIds }, { accept: '*/*' }).then(response => {
            response.blob().then((blob: any) => {
                const aLink = document.createElement('a');
                document.body.appendChild(aLink);
                aLink.style.display = 'none';
                const objectUrl = window.URL.createObjectURL(blob);
                aLink.href = objectUrl;
                aLink.download = 'TaskGroup.zip';
                aLink.click();
                document.body.removeChild(aLink);
            });
        });
    }
    public LoadHolidayProfileAsync(callback?: (result: HolidaySettingServiceResult) => void): void {
        apiservice().post('/IHolidaySettingService/QueryProfileNameACS', undefined).then(result => callback?.(result));
    }

    public LoadNotificationProfilesAsync(callback?: (result: any) => void): void {
        apiservice().post('/INotificationService/QueryNotificationProfiles', undefined).then(result => callback?.(result));
    }

    public GetJobQueueNames(callback?: (result: any) => void): void {
        apiservice().post('/IJobManagerService/GetJobQueueNames', undefined).then(result => callback?.(result));
    }
}

export default TaskManagerApiService;
import React, { useEffect } from 'react';
import { Button, Input, Select, Form, Collapse, Drawer } from 'antd';
const { Option } = Select;
const { Panel } = Collapse;
const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 16 },
};

const GroupEditForm = (props: any) => {
    const [form] = Form.useForm();
    const onSubmit = () => {
        form.submit();
    }
    const onFinish = (values: any) => {
        props.onGetData(values)
    };
    useEffect(() => {
        form.resetFields();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.EditFormData])
    return (
        <Drawer
            forceRender
            title="Edit Group"
            width={720}
            onClose={() => { props.onCloseFun() }}
            visible={props.visible}
            bodyStyle={{ paddingBottom: 80 }}
            footer={
                <div
                    style={{
                        textAlign: 'right',
                    }}
                >
                    <Button onClick={onSubmit} type="primary" style={{ marginRight: 8 }}> Save</Button>
                    <Button onClick={() => { props.onCloseFun() }} >Cancel</Button>
                    <div>{props.EditFormData.GroupName}</div>
                </div>
            }
        >
            <Form
                onFinish={onFinish}
                initialValues={props.EditFormData}
                form={form}
                {...layout}
            >
                <Collapse defaultActiveKey={['1', '2']}>
                    <Panel header="What is the group name?" key="1">
                        <Form.Item
                            name="GroupName"
                            label="Group Name"
                            rules={[{ required: true, message: 'Group Name is required!' }]}

                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="Description"
                            label="Description"
                        >
                            <Input.TextArea />
                        </Form.Item>
                    </Panel>
                    <Panel header="Which users would you like to add and which permission levels would you like to grant?" key="2">
                        <Form.Item name="Users" label="Users"  >
                            <Select
                            >
                                <Option value="male">male</Option>
                                <Option value="female">female</Option>
                                <Option value="other">other</Option>
                            </Select>
                        </Form.Item>
                        <Form.Item name="PermissionLevels" label="Permission Levels"  >
                            <Select
                                allowClear
                            >
                                <Option value="male">male</Option>
                                <Option value="female">female</Option>
                                <Option value="other">other</Option>
                            </Select>
                        </Form.Item>
                    </Panel>
                </Collapse>
            </Form>
        </Drawer>

    )
}
export default GroupEditForm;
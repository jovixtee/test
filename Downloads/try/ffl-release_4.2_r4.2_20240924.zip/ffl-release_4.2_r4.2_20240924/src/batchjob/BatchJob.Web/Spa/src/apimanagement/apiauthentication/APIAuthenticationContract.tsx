import { Pager } from '../node/NodeContract';
import {CustomType, AuthType, HashType, APIKeyType, GrantType} from '../../common/contracts/ModelContracts';


export interface IPaginationC {
    currentPage: number;
    currentPageSize: number;
    total?: number;
}
export const CustomTypeMap = new Map<string, CustomType>([
    ["MyInfo", CustomType.MyInfo]
])

export const HashTypeMap = new Map<string, HashType>([
    ["HS256", HashType.HS256],
    ["SHA1", HashType.SHA1]
])

export const AuthTypeFrontendMap = new Map<string, AuthType>([
    ["OAuth2", AuthType.OAuth],
    ["API key", AuthType.APIKey],
])

export const ApiKeyFrontendMap = new Map<string, APIKeyType>([
    ["JWT", APIKeyType.JWT],
    ["Constants", APIKeyType.Constants]
])

export const GrantTypeMap = new Map<string, GrantType>([
    ["Code", GrantType.Code],
    ["Client Credential", GrantType.ClientCredential]
])





export const AuthenticationTypeMap = new Map<string, AuthType>([
    ["OAuth2", AuthType.OAuth],
    ["API key", AuthType.APIKey],
    ["Client Cert", AuthType.ClientCert],
    ["Customise", AuthType.Customise],
])
export class QueryAuthenticationPager extends Pager {
    constructor(pageSize: number, jumpPage: number, SearchValue: string) {
        super(
            pageSize,
            jumpPage,
            "Name",
            SearchValue, ["Name"],
            []
        )
    }
}
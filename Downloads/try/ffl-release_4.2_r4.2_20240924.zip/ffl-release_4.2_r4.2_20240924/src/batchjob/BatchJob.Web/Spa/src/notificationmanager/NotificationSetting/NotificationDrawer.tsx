import React, { useEffect, useState } from 'react';
import { Button, Input, Select, Form, Drawer, Spin } from 'antd';
import { ProtocolType, NotificationSetting,ProtocolTypeMap } from './NotificationSettingContracts';
import { ConnectionAdapterDto } from "../../features/connections/ConnectionContract";
import { QueryConnByProtocolType, QueryNotifiSettingDetail, CreateNotifiSetting, UpdateNotificationSetting } from './NotificationService';
const { Option } = Select;


interface INotificationDrawerProps {
    visible: boolean;
    closeDrawer: () => void;
    refresh: () => void;
    id: string;
}

const NotificationDrawer = (props: INotificationDrawerProps) => {
    const [loading, setLoading] = useState<boolean>(false);
    const [connectionType, setConnectionType] = useState<ProtocolType>();
    const [isDefault, setIsDefault] = useState<boolean>(false);
    const [connections, setConnections] = useState<ConnectionAdapterDto[]>([]);
    const [form] = Form.useForm();
   
    useEffect(() => {
        if (props.id && props.id.length > 0) {
            QueryNotifiSettingDetail(props.id).then(dto => {
                setConnectionType(dto.ProtocolType!);
                form.setFieldsValue({
                    DisplayName: dto.DisplayName,
                    Description: dto.Description,
                    ProtocolType: dto.ProtocolType,
                    ConnectionId: dto.ConnectionId,
                    OnBehalf:dto.OnBehalf
                });
                setIsDefault(dto.IsDefault!);
                QueryConnByProtocolType(dto.ProtocolType!).then(res => {
                    setConnections(res);
                    form.setFieldsValue({
                        ConnectionId: dto.ConnectionId
                    });
                });
            });
        } else {
            form.resetFields();
        }
    }, [form, props.visible, props.id]);

    const onFinish = (values: any) => {
        setLoading(true);
        let requestObject = new NotificationSetting();
        requestObject.DisplayName = values.DisplayName;
        requestObject.Description = values.Description;
        requestObject.IsDefault = isDefault;
        requestObject.ProtocolType = values.ProtocolType;
        requestObject.ConnectionId = values.ConnectionId;
        requestObject.OnBehalf = values.OnBehalf;
        if (props.id && props.id.length > 0) {
            requestObject.Id = props.id;
            UpdateNotificationSetting(requestObject).then(res => {
                props.refresh();
                closeDrawer();
            }).finally(() => setLoading(false));
        } else {
            CreateNotifiSetting(requestObject).then(res => {
                props.refresh();
                closeDrawer();
            }).finally(() => setLoading(false));

        }
    };



    const closeDrawer = () => {
        form.resetFields();
        props.closeDrawer();
    }

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };

    const OnConnType = (value: ProtocolType): void => {
        setConnectionType(value);
        form.setFieldsValue({
            "ConnectionId": undefined
        })
        QueryConnByProtocolType(value).then(res => setConnections(res));
    }

    return (
        <Drawer
            forceRender
            width={720}
            onClose={closeDrawer}
            visible={props.visible}
            bodyStyle={{ paddingBottom: 80 }}
            title={(props.id && props.id.length > 0) ? "Edit NotificationSetting" : "Create a new NotificationSetting"}
            footer={
                <div style={{ textAlign: 'right' }} >
                    <Button onClick={() => form.submit()} type="primary" style={{ marginRight: 8 }}> Submit</Button>
                    <Button onClick={closeDrawer}>Cancel</Button>
                </div>
            }>
            <Spin spinning={loading}>
                <Form layout="vertical" form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '1.25rem' }}>

                    <Form.Item
                        name="DisplayName"
                        label="Display Name"
                        rules={[{ required: true, message: 'Display Name is required!' }]}>
                        <Input maxLength={256}/>
                    </Form.Item>

                    <Form.Item
                        name="Description"
                        label="Description">
                        <Input.TextArea />
                    </Form.Item>



                    <Form.Item label="Connection Type" name="ProtocolType" rules={[{ required: true, message: 'Please choice connection type' }]}>
                        <Select onChange={OnConnType} placeholder="Please select Connection Type">
                        {
                              Array.from(ProtocolTypeMap).map(([key, value]) => <Option value={key} key={key}>{value}</Option>)
                        }
                        </Select>
                    </Form.Item>
                    {
                        (connectionType !== undefined) &&
                        <>
                            <Form.Item label="Connection" name="ConnectionId" rules={[{ required: true, message: 'Please choice connection name' }]}>
                                <Select placeholder="Select One">
                                    {
                                        connections.map((item: ConnectionAdapterDto) => (
                                            <Option key={item.Id} value={item.Id || ""}>{item.AdapterName}</Option>
                                        ))
                                    }
                                </Select>
                            </Form.Item>
                        </>
                    }

                    <Form.Item
                        name="OnBehalf"
                        label="On Behalf"
                        rules={[
                            {
                                pattern:/^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$|^(?=systemuser:)/,
                                message:"Please enter the correct email address or 'systemuser:id' format"
                            },
                            
                        ]}>
                        <Input/>
                    </Form.Item>

                </Form>
            </Spin>
        </Drawer >

    )

}
export default NotificationDrawer;
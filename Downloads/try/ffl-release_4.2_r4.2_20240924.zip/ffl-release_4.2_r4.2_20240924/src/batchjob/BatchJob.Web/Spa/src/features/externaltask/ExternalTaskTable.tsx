import React from "react";
import { Table, Button, Input } from "antd";
import { TablePaginationConfig } from "antd/lib/table";
import { TableRowSelection, ColumnsType } from "antd/lib/table/interface";
import { PlusOutlined, DeleteOutlined, FolderOpenOutlined } from "@ant-design/icons";
import apiservice from '../../utils/fetchutil';

let _externalTaskTable: ExternalTaskTable;
const columns: ColumnsType<IData> = [
    {
        title: "Profile Name",
        dataIndex: "title",
        key: "title",
        sorter: true,
        render: (name: any, record: IData) => (
            <Button type="link" onClick={() => { _externalTaskTable.props.showForm(record);}}>
                {name}
            </Button>
        ),
        width: "10%",
    }, {
        title: "Descrption",
        dataIndex: "description",
        key: "description",
        width: "13%",
    }, {
        title: "Action",
        dataIndex: "action",
        key: "action",
        width: "10%"
    }, {
        title: "Target",
        dataIndex: "target",
        key: "target",
        width: "10%"
    }, {
        title: "Package Display Name",
        dataIndex: "packagedisplayname",
        key: "packagedisplayname",
        width: "10%"
    }, {
        title: "Created By",
        dataIndex: "createdby",
        key: "createdby",
        width: "10%"
    }, {
        title: "Created Time",
        dataIndex: "createdtime",
        key: "createdtime",
        width: "13%"
    }, {
        title: "Modified By",
        dataIndex: "modifiedby",
        key: "modifiedby",
        width: "10%"
    }, {
        title: "Modified Time",
        dataIndex: "modifiedtime",
        key: "modifiedtime",
        width: "15%"
    }];
const data1: IData = {
    uuid: "uuid ",
    title: "External ",
    description: "external description ",
    target: "connection",
    targetvalue: 0,
    packagedisplayname: "External Package",
    action: "Transfers",
    createdtime: "2010/05/25",
    modifiedby: "Administror",
    createdby: "Administror",
    modifiedtime: "2010/05/25"
};

export interface IData {
    uuid: string;
    title: string;
    description: string;
    target: string;
    targetvalue: number;
    packagedisplayname: string;
    action: string;
    createdby: string;
    createdtime: string;
    modifiedby: string;
    modifiedtime: string;
}
interface IExternalTaskTableState {
    data: IData[];
    pagination: TablePaginationConfig;
    selectedRowKeys: string[];
    loading: boolean;
    deleteDisabled: boolean;
}
interface IExternalTaskTableProps {
    showForm: (value?: IData) => void;
}
class ExternalTaskTable extends React.Component<IExternalTaskTableProps, IExternalTaskTableState> {
    constructor(props: IExternalTaskTableProps, state: IExternalTaskTableState) {
        super(props);
        this.state = {
            data: [],
            pagination: {
                current: 1,
                pageSize: 10,
            },
            selectedRowKeys: [],
            loading: false,
            deleteDisabled: true,
        };
        _externalTaskTable = this;

    }
    TaskManagerService = apiservice();
    componentDidMount(): void {
        // test
        this.setState({ data: this.getData(this.state.pagination) });
    }
    onSelectChange = (selectedRowKeys: any[], selectedRows: IData[]): void => {
        let deleteDisabled: boolean = true;
        if (selectedRowKeys.length > 0) {
            deleteDisabled = false;
        }

        this.setState({ selectedRowKeys, deleteDisabled });
    }
    getData = (pagination: TablePaginationConfig, sorter?: any, filters?: any): IData[] => {
        console.log(sorter, filters);
        console.log(this.TaskManagerService.hostUrl);
        this.TaskManagerService.get("/IPassportService/Logout").then(result => {
            console.log(result);
        }).catch((e)=>{
            console.log(e);
        })
        this.TaskManagerService.get("/IPassportService/Logout?id=1", { userId: "67a5ddb6-e283-4b56-b913-946fd481e903",userId1: "67a5ddb6-e283-4b56-b913-946fd481e903" }).then(result => {
            const _w: any = window;
            _w['getResult2'] = result;
            console.log(result);
        })
        this.TaskManagerService.post("/IAccountManagerService/DeleteUser").then(result => {
            const _w: any = window;
            _w['postResult'] = result;
            console.log(result);
        }).catch((e)=>{
            console.log(e);
        })
        const current: number = pagination.current || 1,
            pageSize: number = pagination.pageSize || 10,
            baseNum: number = (current - 1) * pageSize;
        let total: number = pagination.total || 10;
        pagination.total = total + 10;
        this.setState({ pagination });
        return [1 + baseNum, 2 + baseNum, 3 + baseNum,
        4 + baseNum, 5 + baseNum, 6 + baseNum,
        7 + baseNum, 8 + baseNum, 9 + baseNum, 10 + baseNum].map((value) => {
            return {
                uuid: data1.uuid + value,
                title: data1.title + value,
                description: data1.title + value,
                target: data1.target + value,
                targetvalue: value,
                packagedisplayname: data1.packagedisplayname + value,
                action: value % 2 ? "Transfers" : "External Task",
                createdby: "System",
                createdtime: new Date().toJSON(),
                modifiedby: "Administror",
                modifiedtime: new Date().toJSON()
            };
        });
    }

    handleTableChange = (pagination: TablePaginationConfig, filters: any, sorter: any) => {
        // test
        this.setState({ data: this.getData(pagination, sorter, filters) });
    }
    componentWillUnmount =()=>{
        console.log("componentWillUnmount");
    }
    componentWillMount =()=>{
        console.log("componentWillMount");
    }
    
    render(): JSX.Element {
        const rowSelection: TableRowSelection<IData> = {
            selectedRowKeys: this.state.selectedRowKeys,
            onChange: this.onSelectChange,
        };
        return (
            <>
                <div style={{ marginTop: "20px", marginBottom: "10px" }}>
                    <Button type="text" onClick={() => { this.props.showForm(); }}><PlusOutlined />Create</Button>
                    <Button type="text"
                        disabled={this.state.deleteDisabled}
                        onClick={() => { alert(this.state.selectedRowKeys); }}
                    >
                        <DeleteOutlined />Delete</Button>
                    <Button type="text"><FolderOpenOutlined />Package Manager</Button>
                    <Input.Search
                        placeholder="input search text"
                        onSearch={(value: any) => console.log(value)}
                        style={{ width: 200, float: "right" }}
                        enterButton
                    />
                </div>
                <Table
                    columns={columns}
                    rowSelection={rowSelection}
                    rowKey={record => record.uuid}
                    dataSource={this.state.data}
                    pagination={this.state.pagination}
                    loading={this.state.loading}
                    onChange={this.handleTableChange}
                >
                </Table>
            </>
        );
    }
}

export default ExternalTaskTable;
import apiservice from '../../utils/fetchutil';
import { PagerResult } from '../../common/contracts/PagerContracts';
import { IGetSelectResult,FromType } from './FrontendAPIContracts'
import {FrontendAPIDto,VersionDto,ParameterTypeDto,PublishNodeDto} from '../../common/contracts/ModelContracts';
import {NodeDetail} from '../../common/contracts/ModelContracts';

const serve = apiservice();

export const PagerQueryFrontend = (params: any): Promise<PagerResult<FrontendAPIDto>> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/PagerQueryFrontend", params).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const DeleteFrontend = (Id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteFrontend", { "id": Id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateFrontend = (detail: FrontendAPIDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateFrontend", { "dto": detail }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetVersionById = (Id: string): Promise<VersionDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetVersionById", { "id": Id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetSelects = (requestList: string[]): Promise<IGetSelectResult> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetSelects", { "dto": requestList }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateVersion = (detail: VersionDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateVersion", { "dto": detail }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}


export const DeleteVersion = (Id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteVersion", { "id": Id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}


export const GetParameterType = (Id: string): Promise<ParameterTypeDto[]> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetParameterType", { "dto": { "FrontendId": Id } }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const DeleteParameterType = (Ids: string[]): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteParameterType", { "dto": Ids }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateParameterType = (detail: ParameterTypeDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateParameterType", { "dto": detail }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateMethod = (params: any): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateMethod", { "dto": params }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const PagerMethodByVersionId = (params: any): Promise<PagerResult<any>> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/PagerMethodByVersionId", params).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const GetParameterByFrontendID = (Id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetSelectsWithVal", {
            "dto": {
                "Type": "Parameter",
                "Filter": [{
                    "ColumnName": "FrontendID",
                    "ColumnValue": Id
                }]
            }
        }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const DeleteMethods = (Ids: string[], fromType: FromType): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteMethods", { "dto": { "Ids": Ids, "FromType": fromType } }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetVersionByBackendID = (Id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetSelectsWithVal", {
            "dto": {
                "Type": "Version",
                "Filter": [{
                    "ColumnName": "BackendID",
                    "ColumnValue": Id
                }]
            }
        }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetMethodByBackendIDFrontendIDVersionID = (FrontendID: string, BackendID: string, VersionID: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetSelectsWithVal", {
            "dto": {
                "Type": "Method",
                "Filter": [{
                    "ColumnName": "FrontendID",
                    "ColumnValue": FrontendID
                },
                {
                    "ColumnName": "BackendID",
                    "ColumnValue": BackendID
                },
                {
                    "ColumnName": "VersionID",
                    "ColumnValue": VersionID
                }
                ]
            }
        }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const GetMethodById = (methodId: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetMethodById", { "id": methodId }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetParameterByBackendID = (Id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetSelectsWithVal", {
            "dto": {
                "Type": "Parameter",
                "Filter": [{
                    "ColumnName": "BackendID",
                    "ColumnValue": Id
                }]
            }
        }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const ImportMethod = (versionId: string, methodIds: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/ImportMethod", {
            "dto": {
                "VersionID": versionId,
                "backendMethods": methodIds
            }
        }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const GetAllAvailableNodes =():Promise<PagerResult<NodeDetail>>=>{
    return new Promise((res,rej)=>{
        serve.post("/IAPIManagementService/GetAllAvailableNodes").then((result) => {
            res(result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const PublishNodeMethod =(dto:PublishNodeDto):Promise<any>=>{
    return new Promise((res,rej)=>{
        serve.post("/IAPIManagementService/PublishNode",{dto}).then((result) => {
            res(result)
        }).catch(error => {
            rej(error)
        })
    })
}
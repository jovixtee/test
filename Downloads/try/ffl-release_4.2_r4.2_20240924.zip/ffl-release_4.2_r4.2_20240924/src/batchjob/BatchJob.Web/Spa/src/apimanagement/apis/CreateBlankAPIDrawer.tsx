import React, { FC, useEffect, useState } from 'react';
import { Form, Button, Input, Select, Radio, Spin, Drawer, message } from 'antd';
import { CreateVersionSetting, GetAllNode } from './APIsService';
import { NodeItemDto, VersionSettingDto } from '../../common/contracts/ModelContracts';


interface ICreateBlankAPIDrawerProps {
    blankVisible: boolean;
    closeDrawer: VoidFunction;
    onRefresh: () => void;
}

const { Option } = Select;
const { TextArea } = Input;

const CreateBlankAPIDrawer: FC<ICreateBlankAPIDrawerProps> = (props) => {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState<boolean>(false);
    const [node, setNode] = useState<NodeItemDto[]>([]);
    const [nodeUrl, setNodeUrl] = useState<string>("");

    const options = [
        { label: 'HTTP', value: 0, disabled: true },
        { label: "HTTPS", value: 1 },
        { label: 'Both', value: 2, disabled: true },
    ];

    useEffect(() => {
        handleGetAllNode();
    }, [])


    const handleGetAllNode = () => {
        setLoading(true);
        GetAllNode().then(res => {
            setNode(res);
        }).finally(() => setLoading(false));
    }


    const handleCreateVersionSetting = (detail: VersionSettingDto) => {
        setLoading(true);
        CreateVersionSetting(detail).then(res => {
            message.success("Create Success");
            props.onRefresh();
        }).finally(() => setLoading(false));
    }


    const handleNodeChange = (value: string, option: any) => {
        let nodeUrl = option.length > 0 ? option[0].nodeUrl : ""
        setNodeUrl(nodeUrl);
     
        let endpoint = form.getFieldValue("Endpoint");
        let baseUrl = nodeUrl + (endpoint ? endpoint : "");
        form.setFieldsValue({
            BaseUrl: baseUrl
        });
    };

    const handleUrlSuffixChange = (e: any) => {
        let endpoint = e.target.value;
        endpoint = endpoint.startsWith("/") ? endpoint : "/" + endpoint;
      
        var baseUrl = nodeUrl + endpoint;
        form.setFieldsValue({
            BaseUrl: baseUrl,
            Endpoint: endpoint
        });
    };

   

    const onFinish = (values: any) => {
        let setting = new VersionSettingDto();
        setting.DisplayName = values.DisplayName;
        setting.Identifier = values.Identifier;
        setting.Description = values.Description;
        setting.Endpoint = values.Endpoint;
        setting.ControlPolicyId = values.ControlPolicyId;
        setting.FrontendAuthId = values.FrontendAuthId;
        setting.BackendAuthId = values.BackendAuthId;
        setting.BaseAddress = values.BaseUrl;
        setting.ServiceAddress = values.ServiceAddress;
        setting.NodeID = values.NodeID;
        handleCreateVersionSetting(setting);
        closeDrawer();
    }

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };

    const closeDrawer = (): void => {
        form.resetFields();
        props.closeDrawer();
    }



    return (
        <Drawer
            visible={props.blankVisible}
            width={720}
            destroyOnClose
            forceRender
            onClose={closeDrawer}
            title={"Create a blank API"}
            footer={
                <div style={{ textAlign: 'right', }}>
                    <Button type="primary" style={{ marginRight: 8 }} disabled={loading} loading={loading} onClick={() => form.submit()}>Save</Button>
                    <Button onClick={closeDrawer} >Cancel</Button>
                </div>
            }>

            <Spin spinning={loading}>
                <Form form={form} layout="vertical" onFinish={onFinish} onFinishFailed={onFailed}>
                    {/* <Form.Item   >
                        <div className="ant-drawer-title" >General Setting</div>
                    </Form.Item> */}
                    <Form.Item label="Display Name" name="DisplayName" rules={[{ required: true, message: 'Please input Display name!' }]}>
                        <Input/>
                    </Form.Item>
                    <Form.Item label="Version identifier" name="Identifier" rules={[{ required: true, message: 'Please input Version identifier!' }]}>
                        <Input />
                    </Form.Item>
                    <Form.Item label="Description" name="Description" >
                        <TextArea rows={3} placeholder="" />
                    </Form.Item>
                    <Form.Item label="Web Service URL" name="ServiceAddress" rules={[{ required: true, message: 'Please input Web Service URL!' }]}>
                        <Input />
                    </Form.Item>

                    <Form.Item hidden label="URL scheme" name="scheme" initialValue={1} rules={[{ required: true, message: 'Please input URL scheme!' }]}>
                        <Radio.Group options={options} />
                    </Form.Item>

                    <Form.Item label="Node" name="NodeID" rules={[{ required: true, message: 'Please Select Node!' }]}>
                        <Select onChange={handleNodeChange} mode="multiple">
                            {
                                node && node.map(item => <Option value={item.key} key={item.key} nodeUrl={item.NodeUrl}>{item.value}</Option>)
                            }
                        </Select>
                    </Form.Item>
                    <Form.Item label="API URL suffix" name="Endpoint" rules={[{ required: true, message: 'Please input API URL suffix!' }]}>
                        <Input onChange={handleUrlSuffixChange} />
                    </Form.Item>
                    <Form.Item label="Base URL" name="BaseUrl" rules={[{ required: true, message: 'Please input Display Base URL!' }]}>
                        <Input disabled />
                    </Form.Item>
                </Form>
            </Spin>


        </Drawer>
    );
}
export default CreateBlankAPIDrawer
import React, { useState,useEffect } from 'react';
import AmpCommonTable, { DatetimeColumnTemplate, IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import { ProfileEditDrawer } from './ProfileEditDrawer';
import { ProfileReadDrawer } from './ProfileReadDrawer';
import { GetApiService } from './TransferApiService';
import * as TransferContract from './TransferContract';
import { hasPermission } from '../../utils/permissionutil';
import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import UINotrification from "../../common/UINotrification";

const TransferMain = () => {
    const [showReadonlyDrawer, setShowReadonlyDrawer] = useState(false);
    const [showEditDrawer, setShowEditDrawer] = useState(false);
    const [refresh, setRefresh] = useState(1);
    const [currentProfile, setCurrentProfile] = useState<TransferContract.TransferProfileDto>();
    const [selectedRecords, setSelectedRecords] = useState<TransferContract.TransferProfileDto[]>();
    const [readonlyProfile, setReadonlyProfile] = useState<TransferContract.TransferProfileDto>({});
    const [actions, setActions] = useState<Array<TransferContract.TransferActionDto>>([]);

    useEffect(() => {
        GetApiService().GetTransferResources().then(result => {
            if (result.TransferActions) {
                setActions(result.TransferActions!);
            }
        });
    }, []);
    const tableCols = [
        {
            title: 'Profile Name',
            dataIndex: 'Name',
            key: 'Name',
            sorter: true,
            ellipsis: true,
            width:"15%",
            render: (text: any, record: any) => <a onClick={() => viewProfile(record)}>{text}</a>
        }, {
            title: 'Mapping Database',
            dataIndex: 'MappingDBName',
            key: 'MappingDBName',
        }, {
            title: 'Source Connection', 
            dataIndex: 'SourceAdapterName',
            key: 'SourceAdapterName',
        }, {
            title: 'Destination Connection',
            dataIndex: 'DestinationAdapterName',
            key: 'DestinationAdapterName',
        }, {
            title: 'Action',
            dataIndex: 'ActionId',
            key: 'ActionId',
            ellipsis: true,
            width:"15%",
            render: (text: any, record: any) => actions.find(a => a.Id === record.ActionId)?.Name
        }, {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
        }, {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }];

    const buttonEvents = {
        createProfileClick: () => {
            setCurrentProfile({});
            setShowEditDrawer(true);
        },
        editProfileClick: () => {
            setCurrentProfile(selectedRecords![0]);
            setShowEditDrawer(true);
        },
        deleteProfileClick: () => {
            UINotrification.confirm(
                "You are about to delete the selected profiles. Are you sure you want to proceed?",
                "Confirm Deletion",
                async () => {
                    let ids = selectedRecords!.map(r => r.Id);
                    GetApiService().DeleteTransferProfiles(ids).finally(() => tableEvents.refreshTable());
                },
                () => {
                }
            );
    
        }
    }

    const tableEvents = {
        refreshTable: () => {
            setRefresh(refresh + 1);
        },
        onPagionationChange: (pager: PagerExpression) => {
            return GetApiService().PagerQuery(pager);
        }
    };

    const buttons: Array<IAmpTableButton> = [{
        Text: "Create",
        Primary: true,
        Icon: <PlusOutlined />,
        OnClick: buttonEvents.createProfileClick,
        EnableMode: 'always',
        HasPermission: hasPermission(TransferContract.TransferPermissions.ObjectCode, TransferContract.TransferPermissions.Create)
    }, {
        Text: "Edit",
        Icon: <EditOutlined />,
        OnClick: buttonEvents.editProfileClick,
        EnableMode: 'single',
        HasPermission: hasPermission(TransferContract.TransferPermissions.ObjectCode, TransferContract.TransferPermissions.Create)
    }, {
        Text: "Delete",
        Icon: <DeleteOutlined />,
        OnClick: buttonEvents.deleteProfileClick,
        EnableMode: 'multiple',
        HasPermission: hasPermission(TransferContract.TransferPermissions.ObjectCode, TransferContract.TransferPermissions.Delete)
    }];


    const drawerEvents = {
        onEditDrawerFinished: (name: string) => {
            setShowEditDrawer(false);
            setRefresh(refresh + 1);
        }
    };

    const viewProfile = (record: TransferContract.TransferProfileDto) => {
        setReadonlyProfile(record);
        setShowReadonlyDrawer(true);
    }

    const ApiPagerQuery = async (exp: PagerExpression) => {
        let result = await tableEvents.onPagionationChange(exp);
        return { total: result!.PageredTransferProfiles!.TotalNumber, records: result!.PageredTransferProfiles!.Result };
    }

    return (
        <div>
            <AmpCommonTable
                Type="checkbox"
                RowKey="Id"
                Columns={tableCols}
                PagerQuery={ApiPagerQuery}
                OnSelectedChanged={records => setSelectedRecords(records)}
                SearchKeys={["Name"]}
                Refresh={refresh}
                Buttons={buttons}
                EnableSearch />


            <ProfileEditDrawer
                visible={showEditDrawer}
                profileDto={currentProfile}
                onCancel={() => setShowEditDrawer(false)}
                onSave={(name: string) => drawerEvents.onEditDrawerFinished(name)} />

            <ProfileReadDrawer
                visible={showReadonlyDrawer}
                profileDto={readonlyProfile}
                onClose={() => setShowReadonlyDrawer(false)} />
        </div>
    );
}
export default TransferMain;
import React, { useState, useImperativeHandle, forwardRef } from "react";
import {
  PlusOutlined,
  DeleteOutlined,
  EditOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
} from "@ant-design/icons";
import apiService from "../../utils/fetchutil";
import {
  PagerExpression,
  PagerResult,
} from "../../common/contracts/PagerContracts";
import {
  AdapterType,
  ConnectionStatus,
  ConnectionAdapterDto,
  ConnectPermissionConstants,
} from "./ConnectionContract";
import { hasPermission } from "../../utils/permissionutil";
import ProfileReadDrawer from "./ProfileReadDrawer";
import AmpCommonTable, {
  IAmpTableButton,
  DatetimeColumnTemplate,
} from "../../components/antdx/AmpCommonTable";
import { Button } from "antd";
import UINotrification from "../../common/UINotrification";
interface EditableTableProps {
  OnEditClick: (record: ConnectionAdapterDto | undefined) => void;
  tableRef: any;
}

const EditableTable = (props: EditableTableProps) => {
  const [profileReadVisible, setProfileReadVisible] = useState(false);
  const [selectedRecords, setSeletedRecords] = useState<ConnectionAdapterDto[]>(
    []
  );
  const [refresh, setRefresh] = useState(1);
  const [readRecordId, setReadRecordId] = useState<string>();

  const openRead = (record: ConnectionAdapterDto) => {
    setReadRecordId(record.Id);
    setProfileReadVisible(true);
  };

  useImperativeHandle(props.tableRef, () => ({
    onRefresh: () => {
      setRefresh(refresh + 1);
    },
  }));

  const columns = [
    {
      title: "Name",
      dataIndex: "AdapterName",
      sorter: true,
      ellipsis: true,
      width: "15%",
      render: (text: any, record: ConnectionAdapterDto) => (
        <a type="link" onClick={() => openRead(record)}>
          {text}
        </a>
      ),
    },
    {
      title: "Description",
      dataIndex: "Description",
      ellipsis: true,
      width: "15%",
    },
    {
      title: "Type",
      dataIndex: "AdapterType",
      render: (text: number) => AdapterType[text],
    },
    {
      title: "Status",
      dataIndex: "Status",
      filters: [
        { text: "Enabled", value: ConnectionStatus.Enable },
        { text: "Disabled", value: ConnectionStatus.Disable },
      ],
      render: (text: number, record: ConnectionAdapterDto) =>
        record.Status === ConnectionStatus.Enable ? "Enabled" : "Disabled",
    },
    {
      title: "Created By",
      dataIndex: "CreatedBy",
    },
    {
      title: "Created Time",
      dataIndex: "CreatedOn",
      sorter: true,
      render: DatetimeColumnTemplate,
    },
    {
      title: "Modified By",
      dataIndex: "ModifiedBy",
    },
    {
      title: "Modified Time",
      dataIndex: "ModifiedOn",
      sorter: true,
      render: DatetimeColumnTemplate,
    },
  ];

  const buttons: Array<IAmpTableButton> = [
    {
      Text: "Create",
      Primary: true,
      Icon: <PlusOutlined />,
      OnClick: () => props.OnEditClick(undefined),
      EnableMode: "always",
      HasPermission: hasPermission(
        ConnectPermissionConstants.ObjectCode,
        ConnectPermissionConstants.Create
      ),
    },
    {
      Text: "Edit",
      Icon: <EditOutlined />,
      OnClick: () => props.OnEditClick(selectedRecords[0]),
      EnableMode: "single",
      HasPermission: hasPermission(
        ConnectPermissionConstants.ObjectCode,
        ConnectPermissionConstants.Create
      ),
    },
    {
      Text: "Delete",
      Icon: <DeleteOutlined />,
      OnClick: () => deleteEvent(),
      EnableMode: "multiple",
      HasPermission: hasPermission(
        ConnectPermissionConstants.ObjectCode,
        ConnectPermissionConstants.Delete
      ),
    },
    {
      Text: "Enable",
      Icon: <CheckCircleOutlined />,
      OnClick: () => updateStateEvent(ConnectionStatus.Enable),
      EnableMode: "single",
      HasPermission: hasPermission(
        ConnectPermissionConstants.ObjectCode,
        ConnectPermissionConstants.Update
      ),
    },
    {
      Text: "Disable",
      Icon: <CloseCircleOutlined />,
      OnClick: () => updateStateEvent(ConnectionStatus.Disable),
      EnableMode: "single",
      HasPermission: hasPermission(
        ConnectPermissionConstants.ObjectCode,
        ConnectPermissionConstants.Update
      ),
    },
  ];

  const updateStateEvent = async (state: ConnectionStatus) => {
    // await apiService().post(
    //   "/IConnectionAdapterService/UpdateConnectionStatus",
    //   { Id: selectedRecords[0].Id, Status: state }
    // );
    // setRefresh(refresh + 1);
    let status = "";
    if (state === 0) {
      status = "enable";
    }
    if (state === 1) {
      status = "disable";
    }
    UINotrification.confirm(
      "You are about to " +
        status +
        " the selected profiles. Are you sure you want to proceed?",
      "Confirm " + status,
      async () => {
        const result = await apiService().post(
          "/IConnectionAdapterService/UpdateConnectionStatus",
          { Id: selectedRecords[0].Id, Status: state }
        );

        if (result) {
          UINotrification.success(
            "Successfully " + status + " the Connection."
          );
        } else {
          UINotrification.error("Failed to " + status + " the Connection.");
        }
        setRefresh(refresh + 1);
      },
      () => {
        setRefresh(refresh + 1);
      }
    );
  };

  const deleteEvent = async () => {
    // await apiService().post("/IConnectionAdapterService/DeleteAdapterByIds", {
    //   Ids: selectedRecords.map((r) => r.Id),
    // });
    UINotrification.confirm(
      "You are about to delete the selected profiles. Are you sure you want to proceed?",
      "Confirm Deletion",
      async () => {
        const result = await apiService().post(
          "/IConnectionAdapterService/DeleteAdapterByIds",
          {
            Ids: selectedRecords.map((r) => r.Id),
          }
        );
        if (result) {
          UINotrification.success(
            "The selected records were deleted successfully."
          );
        } else {
          UINotrification.error("Failed to delete selected records.");
        }
        setRefresh(refresh + 1);
      },
      () => {
        setRefresh(refresh + 1);
      }
    );
  };

  const ApiPagerQueryJob = async (exp: PagerExpression) => {
    const result: PagerResult<ConnectionAdapterDto> = await apiService().post(
      "/IConnectionAdapterService/PagerQuery",
      { pager: exp }
    );

    return { total: result.TotalNumber, records: result.Result };
  };

  return (
    <>
      <AmpCommonTable
        Type="checkbox"
        RowKey="Id"
        Columns={columns}
        PagerQuery={ApiPagerQueryJob}
        OnSelectedChanged={(records) => setSeletedRecords(records)}
        SearchKeys={["Name"]}
        Refresh={refresh}
        Buttons={buttons}
        EnableSearch
      />
      <ProfileReadDrawer
        onClose={() => setProfileReadVisible(false)}
        Id={readRecordId}
        visible={profileReadVisible}
      />
    </>
  );
};

export default EditableTable;

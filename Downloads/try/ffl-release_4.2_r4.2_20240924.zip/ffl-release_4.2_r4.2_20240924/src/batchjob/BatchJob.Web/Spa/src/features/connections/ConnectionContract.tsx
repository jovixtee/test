
export interface SQLServerAdapterSettingDto {
    ServerName?: string;
    DataBaseName?: string;
    Password?: string;
    UserName?: string;
    Domain?: string;
    AuthenticationType?: SQLAuthenticationType;
    UseAws?:boolean,
    SecretId?:string
}
export interface DataverseAdapterSettingDto {
    UseAws?:boolean,
    Url?: string;
    ClientId?: string;
    ClientSecret?: string;
    AuthType?: DataverseAuthType;
    SecretId?:string
}
export interface PGSQLDestinationInfoDto {
    ServerName?: string;
    DataBaseName?: string;
}

export interface ConnectionFormDto {
    Id?: string;
    adapterName?: string;
    description?: string;
    adapterType?: AdapterType;
    UserName?: string;
    Password?: string;
    //sql server 
    AuthenticationType?: SQLAuthenticationType;
    SFTPAuthenticationType?: AuthenticationType;
    ServerName?: string;
    DatabaseName?: string;
    Domain?: string;
    //SFTP
    Host?: string;
    Port?: number;
    PrivateKey?: string;
    Passphrase?: string;
    authType?: AuthType;
    Url?: string;
}

export interface CRMAdapterSetting {
    Url?: string;
    UserName?: string;
    Password?: string;
    AuthType?: AuthType;
    Domain?: string;
    BridgeAddress?: string;
    UseServiceBridge?: boolean;
    UseAws?:boolean,
    SecretId?:string
}
export interface CRM365AdapterSetting {
    Url?: string;
    ClientId?: string;
    ClientSecret?: string;
    AuthType?: Dynamics365AuthType;
    UseAws?: boolean,
    SecretId: string
}
export interface PGSQLAdapterSettingDto {
    ServerName?: string;
    DataBaseName?: string;
    Password?: string;
    UserName?: string;
    Domain?: string;
    UseAws?:boolean,
    SecretId?:string
}
export interface SQLServerDestinationInfoDto {
    ServerName?: string;
    DataBaseName?: string;
}
export enum SQLAuthenticationType {
    Windows,
    SA
}

export enum ConnectionStatus {
    Enable,
    Disable,
}
export enum AdapterType {
    SQLServer = 0,
    //AzureStorage=1,
    SFTP = 2,
    Dynamics = 3,
    Exchange = 4,
    SMTP = 5,
    Web = 6,
    Dataverse = 7,
    SSRS = 8,
    PostgreSQL = 9,
    Dynamics365 =10
}

export const AdapterTypeMap = new Map<AdapterType,string>([
    [ AdapterType.SQLServer,"SQL Server"],
    [ AdapterType.SFTP,"SFTP"],
    [ AdapterType.Dynamics,"Dynamics"],
    [ AdapterType.Exchange,"Exchange"],
    [ AdapterType.SMTP,"SMTP"],
    [ AdapterType.Web,"Web"],
    [ AdapterType.Dataverse,"Dataverse"],
    [ AdapterType.SSRS,"SSRS"],
    [AdapterType.PostgreSQL, "PostgreSQL"],
    [AdapterType.Dynamics365, "Dynamics365"],
])

export enum AuthType {
    Office365,
    IFD,
    OAuth,
    AD,
    ClientSecret
}
export enum Dynamics365AuthType {
    ClientSecret
}
export enum DataverseAuthType {
    ClientSecret
}
export enum AuthenticationType {
    Password,
    PrivateKey,
    PrivateKeyAndPassword
}
export interface ConnectionAdapterDto {
    Id?: string;
    AdapterName?: string;
    Description?: string;
    Status?: ConnectionStatus;
    SQLServerAdapterSetting?: SQLServerAdapterSettingDto;
    DataverseAdapterSetting?:DataverseAdapterSettingDto
    AdapterType?: AdapterType;
    SQLServerDestinationInfo?: SQLServerDestinationInfoDto;
    CreatedOn?: number;
    CreatedBy?: string;
    ModifiedOn?: number;
    ModifiedBy?: string;
    SFTPAdapterSetting?: SFTPAdapterSettingDto;
    SFTPDestinationInfo?: SFTPDestinationInfo;
    CRMAdapterSetting?: CRMAdapterSetting;
    CRM365AdapterSetting?: CRM365AdapterSetting;
    SSRSAdapterSetting?:SSRSAdapterSettingDto;
    SSRSDestinationInfo?:SSRSDestinationInfo;
    ExchangeSetting?:ExchangeDto
    SMTPSetting?:SMTPDto
    WebSetting?:WebDto
    PGSQLAdapterSetting?: PGSQLAdapterSettingDto;
    PGSQLDestinationInfo?: PGSQLDestinationInfoDto;
}
export interface SFTPDestinationInfo {
    Host: string;
}
export interface SFTPAdapterSettingDto {
    AuthenticationType?: AuthenticationType;
    Host?: string;
    Port?: number;
    UserName?: string;
    Password?: string;
    PrivateKey?: string;
    Passphrase?: string;
    FileName?: string;
    UseAws?:boolean,
    SecretId?:string
}

export interface SSRSAdapterSettingDto{
    ServerEndpoint?: string;
    UserName?: string;
    Password?: string;
    CrmOrganization ?: string;
    UseAws?:boolean,
    SecretId ?: string;
}
export interface SSRSDestinationInfo{
    Info:string;
}


export interface ExchangeDto {
    ExchangeVersion: string;
    ServerEndpoint: string;
    ServerAccount: string;
    Password: string;
    OnBehalf: boolean;
    EmailAddress: string;
    UseAws:boolean;
    SecretId:string;
}

export interface SMTPDto {
    SSLEnable: boolean;
    ServerEndpoint: string;
    ServerAccount: string;
    Password: string;
    AnonymousSetting: boolean;
    UseAws:boolean;
    SecretId:string;
}



export interface WebDto {
    ServerEndpoint:string,
    UseAws:boolean;
    SecretId:string;
    Params:Param[]
}

export class Param {
    Id: string= "";
    Key?:string;
    Value?:string;
}

export class ParamData extends Param {
    IsEdit: boolean = false;
}


export interface ParamDto {
    Id: string;
    Key:string;
    Value:string;
}

export enum MethodTypeEnum {
    GET = 1,
    POST = 2,
    PUT = 3,
    PATCH = 4,
    DELETE = 5,
    COPY = 6,
    HEAD = 7,
    OPTIONS = 8,
    LINK = 9,
    UNLINK = 10,
    PURGE = 11,
    LOCK = 12,
    UNLOCK = 13,
    PROPFIND = 14,
    VIEW = 15
}

export enum ExchangeVersion
{
    Exchange2007 = 0,
    Exchange2007_SP1 = 1,
    Exchange2010 = 2,
    Exchange2010_SP1 = 3,
    Exchange2010_SP2 = 4,
    Exchange2013 = 5,
    Exchange2013_SP1 = 6,
    Exchange2016 = 7
}



export const ConnectPermissionConstants = {
    ObjectCode: 102001,
    Read: 1,
    Create: 2,
    Update: 4,
    Delete: 8
};

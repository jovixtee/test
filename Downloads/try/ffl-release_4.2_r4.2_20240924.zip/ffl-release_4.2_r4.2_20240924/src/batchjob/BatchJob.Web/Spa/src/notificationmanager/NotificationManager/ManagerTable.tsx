import React, { useState, useEffect } from "react";
import { Table } from 'antd';
import { convertTicksToFormatDate } from '../../utils/dateconvert';
import ManagerForm from './ManagerForm';
import { QueryProfile } from '../ManagerApiserve'

const ManagerTable = (props: any) => {
    const [selectedRowKeys, setSelectedRowKeys] = useState<any>([]);
    const [visible, setVisible] = useState<any>(false);
    const [EditFormData, setEditFormData] = useState<any>({});
    const [pagination, setPagination] = useState<any>({
        total: 0,
        current: 1,
        //defaultPageSize: 1,
        pageSize: 10,
        pageSizeOptions: [1, 5, 8, 10, 15, 20],
        showQuickJumper: true,
        //showSizeChanger: true,
    })
    const columns = [
        {
            title: 'Notification Name',
            dataIndex: 'Name',
            key: 'Name',
            sorter: true,
            width: '16%',
            // filters: props.filterNames.map((item: { Name: any; }) => {
            //     return { 
            //         text: item.Name, 
            //         value: item.Name
            //     }
            // }),
            render: (name: any, obj: any, index: any) => {
                return (<a onClick={async () => {
                    let result = await QueryProfile({ id: obj.Id })
                    let data = formartLevel(result.Result)
                    console.log(data)
                    setEditFormData({ ...data });
                    setVisible(true)
                }}>{name}</a>)
            },
        }, {
            title: 'Description ',
            dataIndex: 'Description',
            key: 'Description',
            width: '16%',
        }, {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
            width: '16%',
        }, {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            width: '16%',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
            width: '16%'
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }
    ];
    const formartLevel = (result: any) => {
        let SummaryLevel = [
            result.EmailProfile.SummaryLevel & 1,
            result.EmailProfile.SummaryLevel & 2,
            result.EmailProfile.SummaryLevel & 4
        ]
        let DetailLevel = [
            result.EmailProfile.DetailLevel & 1,
            result.EmailProfile.DetailLevel & 2,
            result.EmailProfile.DetailLevel & 4
        ]
        let LogLevel = [
            result.EmailProfile.LogLevel & 1,
            result.EmailProfile.LogLevel & 2,
            result.EmailProfile.LogLevel & 4
        ]
        let SMSSummaryLevel = [
            result.SmsProfile.SummaryLevel & 1,
            result.SmsProfile.SummaryLevel & 2,
            result.SmsProfile.SummaryLevel & 4
        ]
        result.Format = result.EmailProfile.Format
        result.SummaryLevel = SummaryLevel
        result.DetailLevel = DetailLevel
        result.LogLevel = LogLevel
        result.SMSSummaryLevel = SMSSummaryLevel

        return result
    }
    const loadPagination = (result: any) => {
        result.total = props.totalNumber
        return result
    }
    const onChangeTable = (pagination: any, filters: any, sorter: any, extra: any) => {
        setPagination(pagination)
        props.getTableChange(pagination, filters, sorter, extra)
    }
    const rowSelection = {
        selectedRowKeys,
        onChange: (selectedRowKeys: any, selectedRows: any) => {

            setSelectedRowKeys(selectedRowKeys)
            props.func(selectedRows)
        },
    };
    useEffect(() => {
        if (props.selectLength === 0) {
            setSelectedRowKeys([])
        }
    }, [props.selectLength])
    const onCloseFun = () => {
        setVisible(false)
    }
    const getFormData = (data: any, emailSource: any, smsSource: any, Id: string) => {
        props.getEditFormData(data, emailSource, smsSource, Id)
        setVisible(false)
    }

    return (
        <>
            <Table
                rowSelection={{ type: 'checkbox', ...rowSelection }}
                onChange={onChangeTable}
                columns={columns}
                dataSource={props.dataSource}
                rowKey='Id'
                pagination={loadPagination(pagination)}
                loading={props.tabLoading}
            // footer={() => { return <Row><Col span={6}>{`${props.selectLength} of ${props.dataSource.length} selected`}</Col></Row> }}
            >
            </Table>
            {visible && <ManagerForm EditFormData={EditFormData} visible={visible} onCloseFun={onCloseFun} onGetFormData={getFormData} title={'Edit Recipients Profile'}></ManagerForm>}
        </>
    );
};

export default ManagerTable;
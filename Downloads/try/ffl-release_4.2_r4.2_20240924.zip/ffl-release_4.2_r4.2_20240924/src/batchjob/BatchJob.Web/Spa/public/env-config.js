/*© 2022-2024, AvePoint, Inc. All rights reserved.*/
window.ave = {
    API_URL: "https://10.1.72.24:7443/api",
    OIDC_AUTHORITY: 'https://dbp-ids-uat.dev.edutechonline.org/',
    OIDC_CLIENTID: 'client',
    OIDC_REDIRECTURL: 'https://dbp-uat.dev.edutechonline.org/oidc-callback',
    OIDC_SCOPE: 'api1',
    OIDC_RESPONSE_TYPE: "code",
    PREFIX: '',
    LOGO: 'DATA BROKER',
    VERSION: '5.1.0'
}


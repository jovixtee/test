import React, { useState,useRef } from 'react';
import DrawerForm from './ConnectDrawer';
import EditableTable from './ConnectTable';
import { ConnectionAdapterDto } from './ConnectionContract'


const Connections = () => {
    const [editDrawerVisable, setEditDrawerVisable] = useState(false);
    const [editRecord, setEditRecord] = useState<ConnectionAdapterDto>({});
    const tableRef = useRef();

    const OpenEdit = (record?: ConnectionAdapterDto) => {
        setEditRecord(record ? record : {});
        setEditDrawerVisable(true);
    }

    const onCloseEvent = ()=>{
        setEditDrawerVisable(false);
        (tableRef.current as any)?.onRefresh();
    }

 

    return (
        <>
   
            <EditableTable OnEditClick={OpenEdit} tableRef={tableRef} />
            <DrawerForm
                formData={editRecord}
                visible={editDrawerVisable}
                closeDrawerEvent={onCloseEvent} />
        </>
    );
}
export default Connections; 
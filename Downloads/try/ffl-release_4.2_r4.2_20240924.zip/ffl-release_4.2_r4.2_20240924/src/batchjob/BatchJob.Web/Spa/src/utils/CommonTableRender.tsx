import React from "react";
import { convertTicksToMoment } from './dateconvert'

export const ticksToDateRender = function (ticks: any, record: any): any {
    return (<label>{ticks === 0 ? "NA" : convertTicksToMoment(ticks as number).format('YYYY-MM-DD HH:mm:ss')}</label>);
};
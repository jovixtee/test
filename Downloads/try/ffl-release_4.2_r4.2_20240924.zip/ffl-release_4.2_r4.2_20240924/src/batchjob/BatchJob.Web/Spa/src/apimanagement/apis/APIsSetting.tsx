import React, { FC, useEffect, useState } from "react";
import { Form, Button, Input, Layout, Spin, message } from 'antd';
import "./APIsContent.css";
import { CreateApi, GetApiById } from './APIsService';
import { FrontendAPIDto } from '../../common/contracts/ModelContracts';
const { TextArea } = Input;
const { Content, Footer } = Layout;

interface IAPIsSettingProps {
    Id?: string,
    refs?: any;
    hidden: boolean;
    refReshApi: (search: string) => void;
}
const APIsSetting: FC<IAPIsSettingProps> = (props) => {
    const [loading, setLoading] = useState<boolean>(false);
    const [form] = Form.useForm();

    useEffect(() => {
        if (props.Id) {
            handleGetApiById(props.Id);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.Id])


    const handleGetApiById = (id: string) => {
        setLoading(true);
        GetApiById(id).then(res => {
            form.setFieldsValue({
                Name: res.Name,
                Description: res.Description,
            });

        }).finally(() => setLoading(false));
    }

    const onFinish = (values: any) => {
        setLoading(true);
        let requestObject = new FrontendAPIDto();
        requestObject.Name = values.Name;
        requestObject.Description = values.Description;
        if (props.Id) {
            requestObject.Id = props.Id;
        }
        CreateApi(requestObject).then(res => {
            setLoading(false);
            props.refReshApi("");
            message.success("save success");
        }).finally(() => setLoading(false));
    }

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };



    return (
        <>
            <Content style={{ margin: '0 0 24px 24px', background: 'white', height: '77vh' }} hidden={props.hidden}>
                <Spin spinning={loading}>
                    <Form layout="vertical" form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ float: "left", margin: '20px', width: "50%" }}>
                        <Form.Item >
                            <div className="ant-drawer-title" >Version set</div>
                        </Form.Item>

                        <Form.Item label="Display name" name="Name" rules={[{ required: true, message: 'Please input Display name!' }]}>
                            <Input />
                        </Form.Item>
                        <Form.Item label="Description" name="Description" >
                            <TextArea rows={3} placeholder="" />
                        </Form.Item>
                    </Form>
                </Spin>
            </Content>
            <Footer style={{ background: 'white', marginLeft: '2px' }} hidden={props.hidden}>
                <div className="btn-right">
                    <Button style={{ width: '80px' }}>Cancel</Button>
                    <Button type="primary" loading={loading} onClick={() => form.submit()} style={{ marginLeft: "20px", width: '80px' }}>Save</Button>
                </div>
            </Footer>
        </>
    );
}

export default APIsSetting
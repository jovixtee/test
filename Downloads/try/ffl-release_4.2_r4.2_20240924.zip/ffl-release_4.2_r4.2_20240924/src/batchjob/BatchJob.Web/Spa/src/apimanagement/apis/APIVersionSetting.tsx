import React, { FC, useEffect, useState } from "react";
import { Form, Button, Input, Layout, Select, Table, Card, Spin, message, Divider } from 'antd';
import "./APIsContent.css";
import { PlusCircleTwoTone } from '@ant-design/icons';
import { CreateVersionSetting, GetVersionSetting, GetItemComboBoxData, GetPolicyComboBoxData } from './APIsService';
import { ComboBoxItem, PolicyItem, ViewControlPolicyRuleDto, NodeItemDto, VersionSettingDto, VersionComboBoxDto, FromType,PublishStatus } from '../../common/contracts/ModelContracts';
import ControlPolicyDrawer from '../controlpolicy/ControlPolicyDrawer';
import CreateBackendAuthenticationDrawer from '../apiauthentication/CreateBackendAuthenticationDrawer';
import CreateFrontendAuthenticationDrawer from '../apiauthentication/CreateFrontendAuthenticationDrawer';

const { Option } = Select;
const { TextArea } = Input;
const { Content, Footer } = Layout;

interface IAPIVersionSettingProps {
    id?: string,
    refs?: any;
    refReshApi: (search: string) => void;
    setTableIndex:(index:string)=>void;
}
const APIVersionSetting: FC<IAPIVersionSettingProps> = (props) => {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState<boolean>(false);
    const [allowEdit, setAllowEdit] = useState<boolean>(false);
    const [node, setNode] = useState<NodeItemDto[]>([]);
    const [frontendAuth, setFrontendAuth] = useState<ComboBoxItem[]>();
    const [backendAuth, setBackendAuth] = useState<ComboBoxItem[]>();
    const [policy, setPolicy] = useState<PolicyItem[]>();
    const [policyRule, setPolicyRule] = useState<ViewControlPolicyRuleDto[]>();
    const [nodeUrl, setNodeUrl] = useState<string>("");

    //control policy 
    const [visibleControl, setVisibleControl] = useState<boolean>(false);
    const [policyId] = useState<string>("");
    const [status, setStatus] = useState<PublishStatus>(PublishStatus.Draft);
    

    //Auth param
    const [isEditMode] = useState<boolean>(false);
    const [editingId] = useState<string>("");
    const [backendVisible, setBackendVisible] = useState<boolean>(false);
    const [frontendVisible, setFrontendVisible] = useState<boolean>(false);

    const columns = [
        {
            title: 'Rule',
            dataIndex: 'Rule',
        },
        {
            title: 'Type',
            dataIndex: 'Type',
        }
    ];

    useEffect(() => {
        if (props.id) {
            handleGetVersionSetting(props.id);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.id]);



    const handleGetVersionSetting = (id: string) => {
        setLoading(true);
        GetVersionSetting(id).then(data => {
            let comboBoxData = data.ComboBoxData as VersionComboBoxDto;
            setNode(comboBoxData.Node || []);
            setFrontendAuth(comboBoxData.FrontendAuth || []);
            setBackendAuth(comboBoxData.BackendAuth || []);
            setPolicy(comboBoxData.Policy || []);

            let setting = data.Setting as VersionSettingDto;
            form.setFieldsValue({
                DisplayName: setting.DisplayName,
                Description: setting.Description,
                ServiceAddress: setting.ServiceAddress,
                NodeID: setting.NodeID,
                Endpoint: setting.Endpoint,
                BaseUrl: setting.BaseAddress,
                ControlPolicyId: setting.ControlPolicyId,
                FrontendAuthId: setting.FrontendAuthId,
                BackendAuthId: setting.BackendAuthId,
                Status: setting.Status,
                Tag:setting.Tag
            });
            setStatus(setting.Status!);
            //setAllowEdit(setting.Status!==PublishStatus.Draft);
            let rule = comboBoxData.Policy?.find(e => e.key === setting.ControlPolicyId)?.Rule;
            setPolicyRule(rule);
            let nodeUrl = comboBoxData.Node?.find(e => setting.NodeID.indexOf(e.key) > -1)?.NodeUrl;
            setNodeUrl(nodeUrl || "");

        }).finally(() => setLoading(false));
    }

    const handleCreateVersionSetting = (detail: VersionSettingDto) => {
        setLoading(true);
        CreateVersionSetting(detail).then(res => {
            message.success("Create Success");
            props.refReshApi("");
        }).finally(() => setLoading(false));
    }

    const handleNodeChange = (value: string, option: any) => {
        let nodeUrl = option.length > 0 ? option[0].nodeUrl : ""
        setNodeUrl(nodeUrl);
        let endpoint = form.getFieldValue("Endpoint");
        let baseUrl = nodeUrl + (endpoint ? endpoint : "");
        form.setFieldsValue({
            BaseUrl: baseUrl
        });
    };

    const handlePolicyChange = (value: string, option: any) => {
        setPolicyRule(option?.rule);
    };

    const handleUrlSuffixChange = (e: any) => {
        let endpoint = e.target.value;
        endpoint = endpoint.startsWith("/") ? endpoint : "/" + endpoint;

        var baseUrl = nodeUrl + endpoint;
        form.setFieldsValue({
            BaseUrl: baseUrl,
            Endpoint: endpoint
        });
    };


    const onFinish = (values: any) => {
        let setting = new VersionSettingDto();
        if (props.id) {
            setting.Id = props.id;
        }
        setting.DisplayName = values.DisplayName;
        setting.Description = values.Description;
        setting.Endpoint = values.Endpoint;
        setting.ControlPolicyId = values.ControlPolicyId;
        setting.FrontendAuthId = values.FrontendAuthId;
        setting.BackendAuthId = values.BackendAuthId;
        setting.BaseAddress = values.BaseUrl;
        setting.ServiceAddress = values.ServiceAddress;
        setting.NodeID = values.NodeID;
        setting.Status = values.Status;
        setting.Tag = values.Tag;
        handleCreateVersionSetting(setting);
    }

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };

    const addPolicy = () => {
        setVisibleControl(true);
    };

    const addFrontendAuth = () => {
        setFrontendVisible(true);
    };

    const addBackendAuth = () => {
        setBackendVisible(true);
    };


    const refreshFrontendAuth = () => {
        setLoading(true);
        GetItemComboBoxData(FromType.Frontend).then(res => setFrontendAuth(res)).finally(() => setLoading(false));
    };

    const refreshBackendAuth = () => {
        setLoading(true);
        GetItemComboBoxData(FromType.Backend).then(res => setBackendAuth(res)).finally(() => setLoading(false));
    };
    const refreshPolicy = () => {
        setLoading(true);
        GetPolicyComboBoxData().then(res => setPolicy(res)).finally(() => setLoading(false));
    };

    const closeDrawer = () => {
        setVisibleControl(false);
        setFrontendVisible(false);
        setBackendVisible(false);
    };

    return (
        <>
            <Content style={{ marginBottom: "24px", overflow: 'initial' }}>
                <Spin spinning={loading}>
                    <Form form={form} layout="vertical" onFinish={onFinish} onFinishFailed={onFailed}>
                        <Card style={{ background: "white", width: "100%" }}>
                            <div style={{ float: "left", margin: '20px', width: "50%" }}>
                                <Form.Item>
                                    <div className="ant-drawer-title" >General Setting</div>
                                </Form.Item>
                                <Form.Item label="Version identifier" name="DisplayName" rules={[{ required: true, message: 'Please input Version identifier!' }]}>
                                    <Input disabled={allowEdit}/>
                                </Form.Item>
                                <Form.Item label="Description" name="Description" >
                                    <TextArea rows={3} placeholder="" disabled={allowEdit}/>
                                </Form.Item>
                                <Form.Item label="Web Service URL" name="ServiceAddress" rules={[{ required: true, message: 'Please input Display name!' }]}>
                                    <Input disabled={allowEdit}/>
                                </Form.Item>
                                <Form.Item label="Node" name="NodeID" rules={[{ required: true, message: 'Please Select Node!' }]}>
                                    <Select onChange={handleNodeChange} mode="multiple" disabled={allowEdit}>
                                        {
                                            node && node.map(item => <Option value={item.key} key={item.key} nodeUrl={item.NodeUrl}>{item.value}</Option>)
                                        }
                                    </Select>
                                </Form.Item>
                                <Form.Item label="API URL suffix" name="Endpoint" rules={[{ required: true, message: 'Please input Display name!' }]}>
                                    <Input onChange={handleUrlSuffixChange} disabled={allowEdit}/>
                                </Form.Item>
                                <Form.Item label="Base URL" name="BaseUrl" rules={[{ required: true, message: 'Please input Display Base URL!' }]}>
                                    <Input disabled={true} />
                                </Form.Item>
                                <Form.Item label="Policy" name="ControlPolicyId" rules={[{ required: false, message: 'Please Select Policy!' }]}>
                                    <Select onChange={handlePolicyChange} allowClear={true} disabled={allowEdit}
                                        dropdownRender={menu => (
                                            <div>
                                                {menu}
                                                <Divider style={{ margin: '1px 0' }} />
                                                <div style={{ padding: '5px 10px', color: "#50ABFF",cursor:"pointer" }} onClick={addPolicy}>
                                                    <PlusCircleTwoTone /> add policy
                                                </div>
                                            </div>
                                        )}>
                                        {
                                            policy && policy.map(item => <Option value={item.key} key={item.key} rule={item.Rule} >{item.value}</Option>)
                                        }
                                    </Select>
                                </Form.Item>
                                <Form.Item label="Policy">
                                    <Table rowKey={record => record.Id} columns={columns} pagination={false} dataSource={policyRule} />
                                </Form.Item>
                                <Form.Item label="Tag" name="Tag" rules={[{ max:100}]}>
                                    <Input disabled={allowEdit}/>
                                </Form.Item>
                            </div>
                        </Card>

                        <Card style={{ background: "white", width: "100%", marginTop: "20px" }}>
                            <div style={{ float: "left", margin: '20px', width: "50%" }}>

                                <Form.Item   >
                                    <div className="ant-drawer-title" >Authentication</div>
                                </Form.Item>

                                <Form.Item label="Frontend API" name="FrontendAuthId" rules={[{ required: false, message: 'Please Select Frontend Authentication!' }]}>
                                    <Select allowClear={true} disabled={allowEdit}
                                        dropdownRender={menu => (
                                            <div>
                                                {menu}
                                                <Divider style={{ margin: '1px 0' }} />
                                                <div style={{ padding: '5px 10px', color: "#50ABFF",cursor:"pointer" }} onClick={addFrontendAuth}>
                                                    <PlusCircleTwoTone /> add item
                                                </div>
                                            </div>
                                        )}>
                                        {frontendAuth && frontendAuth.map(item => <Option value={item.key} key={item.key}>{item.value}</Option>)}
                                    </Select>
                                </Form.Item>

                                <Form.Item label="Backend API" name="BackendAuthId" rules={[{ required: false, message: 'Please Select Backend Authentication!' }]}>
                                    <Select allowClear={true} disabled={allowEdit}
                                        dropdownRender={menu => (
                                            <div>
                                                {menu}
                                                <Divider style={{ margin: '1px 0' }} />
                                                <div style={{ padding: '5px 10px', color: "#50ABFF",cursor:"pointer" }} onClick={addBackendAuth}>
                                                    <PlusCircleTwoTone /> add item
                                                </div>
                                            </div>
                                        )}>
                                        {backendAuth && backendAuth.map(item => <Option value={item.key} key={item.key}>{item.value}</Option>)}
                                    </Select>
                                </Form.Item>
                            </div>
                        </Card>

                        <Card style={{ background: "white", width: "100%", marginTop: "20px" }} hidden>
                            <div style={{ float: "left", margin: '20px', width: "50%" }}>
                                <Form.Item>
                                    <div className="ant-drawer-title" >Publish status</div>
                                </Form.Item>

                                <Form.Item label="Status" name="Status" rules={[{ required: false, message: 'Please Select Status!' }]}>
                                    <Select disabled={allowEdit}>
                                        {Object.keys(PublishStatus)
                                            .filter((r) => !isNaN(Number(r)) && (Number(r)>= status))
                                            .map((key) => {
                                            let item = Number(key);
                                            return (
                                                <Option value={item} key={item}>
                                                {PublishStatus[item]}
                                                </Option>
                                            );
                                            })}
                                    </Select>
                                </Form.Item>
                            </div>
                        </Card>
                    </Form>
                </Spin>
            </Content>

            <Footer style={{ background: 'white', marginLeft: '2px' }} >
                <div className="btn-right">
                    <Button style={{ width: '80px' }} onClick={() => props.setTableIndex("1")}>Cancel</Button>
                    <Button type="primary" loading={loading} onClick={() => form.submit()} style={{ marginLeft: "20px", width: '80px' }}>Save</Button>
                </div>
            </Footer>


            <ControlPolicyDrawer
                visible={visibleControl}
                closeDrawer={closeDrawer}
                refresh={refreshPolicy}
                policyId={policyId}
            />


            <CreateFrontendAuthenticationDrawer
                cancelClick={closeDrawer}
                editingId={editingId}
                visible={frontendVisible}
                isEdit={isEditMode}
                getTableData={refreshFrontendAuth}
            />
            <CreateBackendAuthenticationDrawer
                cancelClick={closeDrawer}
                editingId={editingId}
                visible={backendVisible}
                isEdit={isEditMode}
                getTableData={refreshBackendAuth}
            />

        </>
    );
}

export default APIVersionSetting
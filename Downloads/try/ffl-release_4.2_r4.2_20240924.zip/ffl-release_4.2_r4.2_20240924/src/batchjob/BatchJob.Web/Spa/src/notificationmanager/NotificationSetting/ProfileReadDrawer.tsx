import { Button, Descriptions, Drawer } from "antd";
import React, { useEffect, useState } from 'react';
import { QueryNotifiSettingDetail,QueryConnByProtocolType } from './NotificationService';
import { NotificationSetting ,ProtocolTypeMap} from "./NotificationSettingContracts";
import { ConnectionAdapterDto } from "../../features/connections/ConnectionContract";
interface IProfileReadDrawerProps {
    visible: boolean;
    closeDrawer: () => void;
    refresh: (searchText: string) => void;
    id: string;
}

 const ProfileReadDrawer = (props: IProfileReadDrawerProps) => {
    const [profileDto, setProfileDto] = useState<NotificationSetting>({});
    const [connections, setConnections] = useState<ConnectionAdapterDto[]>([]);
    useEffect(() => {
        if (props.id && props.id.length > 0) {
            QueryNotifiSettingDetail(props.id).then(res => {
                setProfileDto(res);
                QueryConnByProtocolType(res.ProtocolType!).then(res => {
                    setConnections(res);
                });
            });
        }
    }, [ props.id]);

    




    return (<Drawer visible={props.visible} width={720} onClose={(e) => props.closeDrawer()}
        title={"View profile"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" onClick={(e) => props.closeDrawer()} >Close</Button>
            </div>
        }>
        <Descriptions column={1} bordered>
            <Descriptions.Item label="Display Name">{profileDto.DisplayName}</Descriptions.Item>
            <Descriptions.Item label="Description">{profileDto.Description}</Descriptions.Item>
            
            <Descriptions.Item label="Is Default">{profileDto.IsDefault?"true":"false"}</Descriptions.Item>
            <Descriptions.Item label="Connection Type">{ProtocolTypeMap.get(profileDto.ProtocolType!)}</Descriptions.Item>
            <Descriptions.Item label="Connection">{connections.find(a => a.Id === profileDto.ConnectionId)?.AdapterName}</Descriptions.Item>
        </Descriptions>
    </Drawer>)
};
export default ProfileReadDrawer;
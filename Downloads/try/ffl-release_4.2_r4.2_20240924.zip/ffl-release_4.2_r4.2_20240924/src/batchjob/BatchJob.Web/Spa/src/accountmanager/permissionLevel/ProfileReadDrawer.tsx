import { Table, Checkbox, Button, Descriptions, Drawer } from "antd";
import React, { useEffect, useState } from 'react';
import { QueryPrivilegeAll } from './permissionLevelApiServe';

interface IProfileReadDrawerProps {
    visible: boolean;
    onClose: Function;
    profileDto: any;

}
export interface Provider {
    Feature: string;
    Description: string;
    uuid: any;
}
export const ProfileReadDrawer = (props: IProfileReadDrawerProps) => {
    const [dataSource, setDataSource] = useState<any>([])
    const [user, setUser] = useState<string[]>([]);

    const columns = [
        {
            title: 'Name',
            dataIndex: 'Name',
            key: 'Name',
            width: '25%',

        }, {
            title: 'Feature ',

            key: 'DepthMask',
            width: '75%',
            render: (text: number, record: any) => {
                let defaultValue: number[] = []
                if (props.profileDto.Privileges.length > 0) {
                    props.profileDto.Privileges.forEach((value: any) => {
                        if (value.ObjectCode === record.ObjectCode) {
                            let temp = [value.AccessRight & 1, value.AccessRight & 2, value.AccessRight & 4, value.AccessRight & 8]
                            defaultValue = temp
                        }
                    })
                }
                return <Checkbox.Group disabled={true} options={record.options} defaultValue={defaultValue} />
            }
        }];
    useEffect(() => {
        getInitData();
    },[])
    const getInitData = async () => {
        if (props.profileDto.Privileges) {
            props.profileDto.Privileges.forEach((value: any) => {
                console.log(props.profileDto.Privileges)
                let defaultValue: number[] = []
                defaultValue = [value.AccessRight & 1, value.AccessRight & 2, value.AccessRight & 4, value.AccessRight & 8]
                value.checkedValues = defaultValue
            })
        }
        let result = await QueryPrivilegeAll()
        result.Result.forEach((item: any) => {
            item.options = [
                { label: 'Read', value: 1, disabled: !!!(item.DepthMask & 1) },
                { label: 'Create', value: 2, disabled: !!!(item.DepthMask & 2) },
                { label: 'Update', value: 4, disabled: !!!(item.DepthMask & 4) },
                { label: 'Delete', value: 8, disabled: !!!(item.DepthMask & 8) }
            ]
        })
        setDataSource(result.Result)
        if (props.profileDto.Users) {
            let users = props.profileDto.Users.map((item: any) => {
                return item.UserName
            })
            setUser(users)
        }
    }
    return (
        <Drawer visible={props.visible} width={720} onClose={(e) => props.onClose()}
            title={"View permission level"}
            footer={
                <div style={{ textAlign: 'right', }}>
                    <Button type="primary" onClick={(e) => props.onClose()} >Close</Button>
                </div>
            }>
            <Descriptions title="General" column={1} bordered>
                <Descriptions.Item label="Display Name">{props.profileDto.Role?.Name}</Descriptions.Item>
                <Descriptions.Item label="Description">{props.profileDto.Role?.Description}</Descriptions.Item>
            </Descriptions>
            <Descriptions title="Assign admins" style={{ marginTop: "24px" }} column={1} bordered>
                <Descriptions.Item label="Select Users">{user.join(",")}</Descriptions.Item>
            </Descriptions>
            <Descriptions title="PermissionLevel" style={{ marginTop: "24px" }}></Descriptions>
            <Table
                // rowSelection={{ type: 'checkbox', ...rowSelection }}
                columns={columns}
                dataSource={dataSource}
                rowKey='PrivilegeId'
                pagination={false}
            >
            </Table>
        </Drawer>
    )
};
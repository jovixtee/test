import { ColumnsType } from "antd/lib/table";
import React, { FC, useState, useEffect } from "react";
import { Row, Col, Table, Input, Space, Button } from "antd";
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { ViewControlPolicy } from '../../common/contracts/ModelContracts';
import ControlPolicyRuleTable from "./ControlPolicyRuleTable";
import { GetViewControlPolicy, DeleteControlPolicy, DeleteControlPolicyRuleById } from './ControlPolicyApiService';
import ControlPolicyDrawer from './ControlPolicyDrawer';
import ControlPolicyRuleDrawer from './ControlPolicyRuleDrawer';
import TaskRepository from '../../features/taskmanager/TaskRepository';

const Search = Input.Search;
const ControlPolicy: FC = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const [visibleControl, setVisibleControl] = useState<boolean>(false);
    const [visibleRule, setVisibleRule] = useState<boolean>(false);

    const [dataSource, setDataSource] = useState<ViewControlPolicy[]>([]);
    const [policyId, setPolicyId] = useState<string>("");
    const [ruleId, setRuleId] = useState<string>("");

    const tableColumn: ColumnsType<ViewControlPolicy> = [
        {
            title: 'Name',
            dataIndex: 'Name',
            ellipsis: true,
        },
        {
            title: 'Notification',
            dataIndex: 'Notification',
            ellipsis: true,
        },
        {
            title: 'Action(s)',
            dataIndex: 'Action',
            ellipsis: true,
            render: (text, record) =>
                <Space size="middle">
                    <PlusOutlined onClick={() => {
                        setPolicyId(record.Id);
                        setVisibleRule(true);
                    }} />
                    <EditOutlined onClick={() => {
                        setPolicyId(record.Id);
                        setVisibleControl(true);
                    }} />
                    <DeleteOutlined onClick={() => handleDeleteControlPolicy(record.Id)} />
                </Space>
        }
    ]

    useEffect(() => {
        handleGetViewControlPolicy("")
        TaskRepository.getInstance().LoadNotificationProfilesAsync();
    }, []);

    const openRuleDrawer = (ruleId: string) => {
        setRuleId(ruleId);
        setVisibleRule(true);
    };

    const deleteRule = (ruleId: string) => {
        setLoading(true);
        DeleteControlPolicyRuleById(ruleId).then(res => handleGetViewControlPolicy("")).finally(() => setLoading(false));
    };



    const handleGetViewControlPolicy = (searchText: string): void => {
        setLoading(true);
        GetViewControlPolicy(searchText).then(res => {
            setDataSource(res);
        }).finally(() => setLoading(false));
    }

    const handleDeleteControlPolicy = (id: string): void => {
        setLoading(true);
        DeleteControlPolicy([id]).then(res => {
            handleGetViewControlPolicy("");
        }).finally(() => setLoading(false));
    }

    const onSearch = (value: string): void => {
        handleGetViewControlPolicy(value);
    }

    const closeControlDrawer = (): void => {
        setRuleId("")
        setPolicyId("");
        setVisibleControl(false);
    }

    const closeRuleDrawer = (): void => {
        setRuleId("");
        setPolicyId("");
        setVisibleRule(false);
    }

    return <React.Fragment>
        <Row style={{ margin: '16px 0' }}>
            <Col span={18}>
                <Space size='small'>
                    <Button type="primary" icon={<PlusOutlined twoToneColor="#eb2f96" />} onClick={() => setVisibleControl(true)}>Create</Button>
                </Space>
            </Col>
            <Col span={6}>
                <Search placeholder="input search text" allowClear onSearch={onSearch} style={{ width: 200, float: 'right' }} />
            </Col>
        </Row>

        <Table
            loading={loading}
            rowKey={record => record.Id}
            dataSource={dataSource}
            columns={tableColumn}
            expandable={{
                rowExpandable: (record) => (record.Rule && record.Rule.length > 0) ? true : false,
                expandedRowRender: (record) => <ControlPolicyRuleTable ruleData={record.Rule || []} visibleDrawer={openRuleDrawer} deleteRule={deleteRule} />
            }}
            pagination={false}
        />

        <ControlPolicyDrawer
            visible={visibleControl}
            closeDrawer={closeControlDrawer}
            refresh={handleGetViewControlPolicy}
            policyId={policyId}
        />

        <ControlPolicyRuleDrawer
            visible={visibleRule}
            closeDrawer={closeRuleDrawer}
            refresh={handleGetViewControlPolicy}
            policyId={policyId}
            ruleId={ruleId} />

    </React.Fragment>
}

export default ControlPolicy
import React, { FC, useEffect, useState } from "react";
import { Drawer, Form, Input, Button, Spin, Checkbox, message } from "antd";
import { GlobalSettings, GlobalTypeEnum } from "./JobContract";
import { GetSettingsByGlobalType, AddSettings } from "./JobMonitorApiServe";

interface ISettingsDrawerProps {
  visible: boolean;
  onClose: () => void;
}

const GlobalSettingsDrawer: FC<ISettingsDrawerProps> = (props) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [globalSettings, setGlobalSettings] = useState<GlobalSettings>();
  const [form] = Form.useForm();
  useEffect(() => {
    if (props.visible) {
      GetSettingsByGlobalType({ type: GlobalTypeEnum.Retation }).then((res) => {
        if (res.GlobalSettings !== null) {
          setGlobalSettings({
            Id: res.GlobalSettings?.Id,
            GlobalType: res.GlobalSettings?.GlobalType,
            ProfileJson: res.GlobalSettings?.ProfileJson,
          });
          let json = parseJSON(res.GlobalSettings?.ProfileJson);
          let check = restChecked(json["status"]);
          form.setFieldsValue({
            PruningScope: json["days"],
            PruningStatus: check,
          });
        } else {
          setGlobalSettings({
            Id: "",
            GlobalType: GlobalTypeEnum.Retation,
            ProfileJson: "",
          });
        }
      });
    }
  }, [props.visible]);

  const onFinish = (values: any) => {
    setLoading(true);
    let value = { ...values };
    let status = getAllChecked(value.PruningStatus);
    let profileJson = JSON.stringify({
      days: value.PruningScope,
      status: status,
    });
    let dto = { ...globalSettings, ProfileJson: profileJson };
    AddSettings({ setting: dto })
      .then((res) => {
        message.success("Saved successfully");
        props.onClose();
      })
      .catch((error) => {
        setLoading(false);
        console.log(error);
      });
    setLoading(false);
  };

  const restChecked = (dataBaseValue: number) => {
    let defaultValue = 2;
    let value = 0;
    let result: any = [];
    for (let i = 0; value <= dataBaseValue; i++) {
      value = defaultValue << i;
      if (value <= dataBaseValue && (dataBaseValue & value) === value) {
        result.push(value);
      }
    }
    return result;
  };

  const getAllChecked = (list: any) => {
    return list?.reduce((prev: any, cur: any, item: any, arr: any) => {
      return prev | cur;
    });
  };
  function parseJSON(str: any) {
    if (typeof str == "string") {
      try {
        var obj = JSON.parse(str);
        return obj;
      } catch (e) {
        return null;
      }
    }
  }
  return (
    <Drawer
      visible={props.visible}
      width={720}
      destroyOnClose
      forceRender
      onClose={() => props.onClose()}
      title={"Global Settings"}
      footer={
        <div style={{ textAlign: "right" }}>
          <Button
            type="primary"
            style={{ marginRight: 8 }}
            loading={loading}
            onClick={() => form.submit()}
          >
            Save
          </Button>
          <Button onClick={() => props.onClose()}>Cancel</Button>
        </div>
      }
    >
      <Spin spinning={loading}>
        <Form
          form={form}
          onFinish={onFinish}
          style={{ marginTop: "16px" }}
          layout="vertical"
        >
          <Form.Item
            label="Pruning Scope"
            name="PruningScope"
            rules={[
              { required: true, message: "Please input  Pruning Scope!" },
            ]}
          >
            <Input
              type="number"
              addonBefore="Pruning jobs over "
              addonAfter="day(s)"
              min={1}
            />
          </Form.Item>
          <Form.Item
            label="Pruning Status:"
            name="PruningStatus"
            rules={[
              { required: true, message: "Please select at least one Status" },
            ]}
          >
            <Checkbox.Group>
              <Checkbox value={2}>Finished</Checkbox>
              <Checkbox value={4}>Exception</Checkbox>
              <Checkbox value={8}>Failed</Checkbox>
              <Checkbox value={16}>Stopped</Checkbox>
              <Checkbox value={32}>Skipped</Checkbox>
              <Checkbox value={64}>Paused</Checkbox>
            </Checkbox.Group>
          </Form.Item>
        </Form>
      </Spin>
    </Drawer>
  );
};
export default GlobalSettingsDrawer;

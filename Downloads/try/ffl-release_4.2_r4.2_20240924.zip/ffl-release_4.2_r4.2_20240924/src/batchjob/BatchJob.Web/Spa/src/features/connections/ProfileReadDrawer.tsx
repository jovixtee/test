import { Button, Descriptions, Drawer, Spin, Table } from "antd";
import React, { FC, useEffect, useState } from "react";
import apiservice from '../../utils/fetchutil';
import { AdapterType, ConnectionAdapterDto, AuthenticationType, SQLAuthenticationType, AuthType, DataverseAuthType } from './ConnectionContract';


interface IProfileReadDrawerProps {
    visible: boolean;
    onClose: () => void;
    Id: any
}

const ProfileReadDrawer: FC<IProfileReadDrawerProps> = (props) => {
    const [loading, setLoading] = useState<boolean>(false);
    const [dataSource, setDataSource] = useState<ConnectionAdapterDto>({});
    const apiService = apiservice();

    useEffect(() => {
        if (props.Id && props.Id.length > 0) {
            retrieveSelectData(props.Id);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.Id]);

    const columns = [{
        title: 'Key',
        dataIndex: 'Key',
        key: 'Key',
        width: '50%',

    },{
        title: 'Value',
        dataIndex: 'Value',
        key: 'Value',
        width: '50%',

    }];


    const retrieveSelectData = (id: string) => {
        setLoading(true);
        apiService.post("/IConnectionAdapterService/ViewAdapterById", { Id: id }).then((res: ConnectionAdapterDto) => {
            setDataSource(res);
            console.log(res);
        }).finally(() => setLoading(false));
    };

    return (<Drawer visible={props.visible} width={720} onClose={(e) => props.onClose()}
        title={"View connection"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" onClick={(e) => props.onClose()} >Close</Button>
            </div>
        }>
        <Spin spinning={loading}>
            <Descriptions column={1} bordered>
                <Descriptions.Item label="Connection Name">{dataSource.AdapterName}</Descriptions.Item>
                <Descriptions.Item label="Description">{dataSource.Description}</Descriptions.Item>
                <Descriptions.Item label="Connection Type">{AdapterType[dataSource.AdapterType!]}{dataSource.AdapterType === AdapterType.SSRS}</Descriptions.Item>
                {
                    dataSource.AdapterType === AdapterType.SQLServer && dataSource.SQLServerAdapterSetting &&
                    <>
                        <Descriptions.Item label="Authentication Method">{SQLAuthenticationType[dataSource.SQLServerAdapterSetting.AuthenticationType || 0]}</Descriptions.Item>
                        <Descriptions.Item label="Server Name">{dataSource.SQLServerAdapterSetting.ServerName}</Descriptions.Item>
                        <Descriptions.Item label="Database Name">{dataSource.SQLServerAdapterSetting.DataBaseName}</Descriptions.Item>
                        <Descriptions.Item label="Username">{dataSource.SQLServerAdapterSetting.UserName}</Descriptions.Item>
                        {/* <Descriptions.Item label="Password">{dataSource.SQLServerAdapterSetting.Password}</Descriptions.Item> */}
                    </>
                }
                {
                    dataSource.AdapterType === AdapterType.SFTP && dataSource.SFTPAdapterSetting &&
                    <>
                        <Descriptions.Item label="Authentication Method">{AuthenticationType[dataSource.SFTPAdapterSetting.AuthenticationType || 0]}</Descriptions.Item>
                        <Descriptions.Item label="Host">{dataSource.SFTPAdapterSetting.Host}</Descriptions.Item>
                        <Descriptions.Item label="Port">{dataSource.SFTPAdapterSetting.Port}</Descriptions.Item>
                        <Descriptions.Item label="Username">{dataSource.SFTPAdapterSetting.UserName}</Descriptions.Item>
                        {/* <Descriptions.Item label="Password">{dataSource.SFTPAdapterSetting.Password}</Descriptions.Item> */}
                    </>
                }
                {
                    dataSource.AdapterType === AdapterType.Dynamics && dataSource.CRMAdapterSetting &&
                    <>
                        <Descriptions.Item label="Auth Type">{AuthType[dataSource.CRMAdapterSetting.AuthType || 0]}</Descriptions.Item>
                        <Descriptions.Item label="Url">{dataSource.CRMAdapterSetting.Url}</Descriptions.Item>
                        <Descriptions.Item label="Domain">{dataSource.CRMAdapterSetting.Domain}</Descriptions.Item>
                        {
                            dataSource.CRMAdapterSetting.UseServiceBridge &&
                            <Descriptions.Item label="Service Bridge Address">{dataSource.CRMAdapterSetting.BridgeAddress}</Descriptions.Item>
                        }
                        <Descriptions.Item label="Username">{dataSource.CRMAdapterSetting.UserName}</Descriptions.Item>
                        {/*<Descriptions.Item label="Password">{dataSource.CRMAdapterSetting.Password}</Descriptions.Item> */}
                    </>
                }
                {
                    dataSource.AdapterType === AdapterType.Dataverse && dataSource.DataverseAdapterSetting &&
                    <>
                        <Descriptions.Item label="Auth Type">{DataverseAuthType[dataSource.DataverseAdapterSetting.AuthType || 0]}</Descriptions.Item>
                        <Descriptions.Item label="Url">{dataSource.DataverseAdapterSetting.Url}</Descriptions.Item>
                        <Descriptions.Item label="Client id">{dataSource.DataverseAdapterSetting.ClientId}</Descriptions.Item>
                        {/* <Descriptions.Item label="Password">{dataSource.CRMAdapterSetting.Password}</Descriptions.Item> */}
                    </>
                }
                {
                    dataSource.AdapterType === AdapterType.SSRS && dataSource.SSRSAdapterSetting &&
                    <>
                        <Descriptions.Item label="Url">{dataSource.SSRSAdapterSetting!.ServerEndpoint}</Descriptions.Item>
                        <Descriptions.Item label="Username">{dataSource.SSRSAdapterSetting!.UserName}</Descriptions.Item>
                        <Descriptions.Item label="Crm Organization">{dataSource.SSRSAdapterSetting!.CrmOrganization}</Descriptions.Item>
                    </>
                }
                {
                    dataSource.AdapterType === AdapterType.Web && dataSource.WebSetting &&
                    <>
                        <Descriptions.Item label="Url">{dataSource.WebSetting!.ServerEndpoint}</Descriptions.Item>
                        
                    </>
                }
            </Descriptions>
            {
                dataSource.AdapterType === AdapterType.Web && dataSource.WebSetting &&
                <>
                   <Descriptions title="Web parameters" style={{ marginTop: "24px" }}></Descriptions>
                    <Table
                        columns={columns}
                        dataSource={dataSource.WebSetting!.Params}
                        rowKey='id'
                        pagination={false}>
                    </Table>
                </>
            }
                      
        </Spin>
    </Drawer>)
};

export default ProfileReadDrawer;
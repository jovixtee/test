import apiservice from '../../utils/fetchutil';
import { PagerResult } from '../../common/contracts/PagerContracts';
import {AuthenticationDto, RedirectModel, TokenStore} from '../../common/contracts/ModelContracts';
const serve = apiservice();

export const PagerAuthentication = (params: any): Promise<PagerResult<AuthenticationDto>> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/PagerAuthentication", params).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const DeleteAuthentications = (Ids: string[]): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteAuthentications", { "dto": Ids }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetAuthenticationById = (authenticationId: string): Promise<AuthenticationDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetAuthenticationById", { "id": authenticationId }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetAuthenticationViewById = (authenticationId: string): Promise<AuthenticationDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetAuthenticationViewById", { "id": authenticationId }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateAuthentication = (params: AuthenticationDto, file: any): Promise<any> => {
    const fd = new FormData();
    let args: any = { "dto": params };
    if (file) {
        args._streamLength = file.size;
        args.importArguments = { FileName: file.name };
        fd.set('arg', JSON.stringify(args));
        //fd.set('arg', JSON.stringify({ _streamLength: file.size, importArguments: { FileName: file.name },dto:parms }));
        fd.set('file', file);
    }else{
        fd.set('arg', JSON.stringify(args));
    }
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateAuthentication", fd).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const GenerateClientId = (): Promise<any> => {
    return new Promise((res, rej) => {
        serve.get("/IAPIManagementService/GenerateClientId",).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GenerateSecret = (): Promise<any> => {
    return new Promise((res, rej) => {
        serve.get("/IAPIManagementService/GenerateSecret",).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}


export const CreateTokenStore = (tokenStore: TokenStore): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateTokenStore", { "dto": tokenStore }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const UpdateTokenStore = (tokenStore: TokenStore): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/UpdateTokenStore", { "dto": tokenStore }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetTokenStoreById = (id: string): Promise<TokenStore> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetTokenStoreById", { "id": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetTokenStoreByProfileId = (id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetTokenStoreByProfileId", { "id": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const ProceedGrant = (id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/ProceedGrant", { "id": id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetTokenAsync = (dto: any): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetTokenAsync", { "dto": dto }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}




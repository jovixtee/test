import { Space, Table, Input, Select, Button, Col, Row, Form } from 'antd';
import React, { FC, useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { ColumnsType } from "antd/lib/table";
import { VersionMethodParameter, EditTableData, IEditTableRef } from './BackendAPIContracts';


interface IEditTableProps {
    dataSource: VersionMethodParameter[];
    ref?: any;
    parmData: Map<string, string>;
}
interface IEditItem {
    Name?: string;
    Value?: string;
    Type?: string;

}




const Option = Select.Option;
const EditTable: FC<IEditTableProps> = forwardRef((props, ref) => {
    const [dataSource, setDatasource] = useState<EditTableData[]>(new Array<EditTableData>())
    const [isEditing, setIsEditing] = useState<boolean>(false);
    const [addData, setAddData] = useState<VersionMethodParameter[]>(new Array<VersionMethodParameter>());
    const [deleteData, setDeleteData] = useState<VersionMethodParameter[]>(new Array<VersionMethodParameter>());
    const [updateData, setUpdateData] = useState<VersionMethodParameter[]>(new Array<VersionMethodParameter>());
    const [editingData, setEditingData] = useState<EditTableData>(new EditTableData());
    const [form] = Form.useForm();
    useEffect(() => {
        const propsdata = props.dataSource.map(item => {
            return { ...item, IsEdit: false, IsNewData: false }
        })
        setDatasource(propsdata)
    }, [props.dataSource])

    const onAddParameterClick = (): void => {
        let newDataSource = [...dataSource];
        const newTableData = new EditTableData();
        newTableData.Id = new Date().getTime().toString();
        newTableData.IsEdit = true;
        newTableData.IsNewData = true;

        form.setFieldsValue({
            Name: newTableData.Key,
            Type: newTableData.ParamterTypeID,
            Value: newTableData.DefaultValue
        })
        newDataSource.unshift(newTableData);
        setDatasource(newDataSource)
        setIsEditing(true);
        setEditingData(newTableData)
    }
    const onFailed = (values: any): void => {
        console.log('onFailed:', values);
    };
    const onFinish = (values: IEditItem): void => {
        console.log('onFinish:', values);
        let newDataSource = [...dataSource];
        let IsNew: boolean = false;
        let data = newDataSource.find(item => item.Id === editingData.Id);
        if (data) {
            data.IsEdit = false;
            data.Key = values.Name;
            data.ParamterTypeID = values.Type;
            data.DefaultValue = values.Value;
            IsNew = data.IsNewData;

            if (IsNew) {
                let newAddArray = [...addData]
                let newDataItem = newAddArray.find(item => item.Id === editingData.Id);
                if (newDataItem) {
                    newDataItem.Key = values.Name;
                    newDataItem.ParamterTypeID = values.Type;
                    newDataItem.DefaultValue = values.Value;
                } else {
                    newAddArray.unshift(data)
                }
                setAddData(newAddArray);
            } else {
                let newUpdateData = [...updateData]
                let newDataItem = newUpdateData.find(item => item.Id === editingData.Id);
                if (newDataItem) {
                    newDataItem.Key = values.Name;
                    newDataItem.ParamterTypeID = values.Type;
                    newDataItem.DefaultValue = values.Value;
                } else {
                    newUpdateData.unshift(data)
                }
                setUpdateData(newUpdateData);

            }
        }
        setDatasource(newDataSource);
        setIsEditing(false);
        setEditingData(new EditTableData());
        form.resetFields();
    }
    const onCancelItemClick = (record: EditTableData): void => {
        let newDataSource = [...dataSource];
        let editItem = newDataSource.find(item => item.Id === record.Id);
        if (editItem) {
            let isNewData = editItem.IsNewData;
            if (isNewData) {
                let filterData = dataSource.filter(item => item.Id !== record.Id);
                setDatasource(filterData);

            } else {
                editItem.Key = editingData.Key;
                editItem.ParamterTypeID = editingData.ParamterTypeID;
                editItem.DefaultValue = editingData.DefaultValue;
                editItem.IsEdit = false;
                setDatasource(newDataSource);
            }

        }
        form.resetFields();
        setIsEditing(false);
        setEditingData(new EditTableData());

    }
    const onDeleteItemClick = (record: EditTableData): void => {
        if (record.IsNewData) {
            let newAddData = addData.filter(item => item.Id !== record.Id);
            let newDataSource = dataSource.filter(item => item.Id !== record.Id);
            setAddData(newAddData)
            setDatasource(newDataSource);
        } else {
            let newDeleteData = [...deleteData];
            let newDataSource = dataSource.filter(item => item.Id !== record.Id);
            newDeleteData.push(record)
            setDeleteData(newDeleteData);
            setDatasource(newDataSource);
        }
    }

    const onEditItemClick = (record: EditTableData): void => {

        let newDataSource = [...dataSource];
        let recordData = newDataSource.find(item => item.Id === record.Id);
        if (recordData) {
            recordData.IsEdit = true;
            form.setFieldsValue({
                Name: record.Key,
                Type: record.ParamterTypeID,
                Value: record.DefaultValue
            })
            setEditingData(recordData);
            setDatasource(newDataSource);
            setIsEditing(true);
        }
    }
    

    const tableColumn: ColumnsType<EditTableData> = [
        {
            title: "Name",
            dataIndex: "Key",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="Name" rules={[{ required: true, message: 'Please input description!' }]}>
                            <Input placeholder={"Name"} />
                        </Form.Item>
                        :
                        <span>{record.Key}</span>
                }
            </React.Fragment>
        },
        {
            title: "Type",
            dataIndex: "ParamterTypeID",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="Type" rules={[{ required: true, message: 'Please input type!' }]}>
                            <Select style={{ minWidth: 120 }} placeholder={"Type"}>
                                {
                                    Array.from(props.parmData).map(([key, value]) => <Option value={key as string} key={key}>{value}</Option>)
                                }
                            </Select>
                        </Form.Item>

                        :
                        <span>{record.ParamterTypeID ? props.parmData.get(record.ParamterTypeID) : ""}</span>
                }
            </React.Fragment>
        },
        {
            title: "Value",
            dataIndex: "DefaultValue",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Form.Item name="Value" rules={[{ required: false, message: 'Please input value!' }]}>
                            <Input placeholder={"Value"} />
                        </Form.Item>
                        :
                        <span>{record.DefaultValue}</span>
                }
            </React.Fragment>
        },
        {
            title: "Action",
            dataIndex: "Action",
            render: (_: any, record) => <React.Fragment>
                {
                    record.IsEdit ?
                        <Space>
                            <Button type="link" onClick={() => form.submit()}>Save</Button>
                            <Button type="link"  onClick={() => onCancelItemClick(record)}>Cancel</Button>
                        </Space>
                        :
                        <Space>
                            <Button type="link"  onClick={() => onEditItemClick(record)}>Edit</Button>
                            <Button type="link"  onClick={() => onDeleteItemClick(record)}>Delete</Button>
                        </Space>
                }
            </React.Fragment>
        }

    ]

    useImperativeHandle(ref, (): IEditTableRef => ({
        getTableResult: () => {
            return {
                addData,
                updateData,
                deleteData,
                isEditing
            }
        }
    }));


    return <React.Fragment>
        <Form form={form} onFinish={onFinish} onFinishFailed={onFailed}  >
            <Row style={{ marginBottom: 10 }}>
                <Col>
                    <Button type="primary" disabled={isEditing} onClick={onAddParameterClick}  >Add Parameter</Button>
                </Col>
            </Row>
            <Table
                rowKey={(record) => record.Id}
                columns={tableColumn}
                dataSource={dataSource}
                pagination={false}
            />
        </Form>
    </React.Fragment>
}
)
export default EditTable





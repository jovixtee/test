import React, { FC, useEffect, useState } from "react";
import { Drawer, Form, Input, Button, Select, Upload, Row, Col,message } from "antd";
import {
  ApiKeyFrontendMap,
  AuthTypeFrontendMap,
  HashTypeMap,
} from "./APIAuthenticationContract";
import {
  AuthType,
  AuthenticationDto,
  HashType,
  OAuthDto,
  APIKeyType,
  JWTDto,
  ConstDto,
  ApiKeyDto,
  FromType,
} from "../../common/contracts/ModelContracts";
import { UploadOutlined } from "@ant-design/icons";
import { UploadFile } from "antd/lib/upload/interface";
import {
  GenerateClientId,
  GenerateSecret,
  CreateAuthentication,
} from "./APIAuthenticationService";

interface IDataFrom {
  Name?: string;
  Description?: string;
  Type?: AuthType;
  APIKeyType?: APIKeyType;
  ClientId?: string;
  Scope?:string;
  Secret?: string;
  HashType?: HashType;
  AuthenticationUserName?: string;
  AuthenticationPassword?: string;
  TokenEndpoint?: string;
  AuthorizationHeader?:string;
}

interface ICreateFrontendAuthenticationDrawerProps {
  visible: boolean;
  cancelClick: VoidFunction;
  isEdit: boolean;
  editingId: string;
  getTableData: VoidFunction;
}

const { Option } = Select;
const CreateFrontendAuthenticationDrawer: FC<ICreateFrontendAuthenticationDrawerProps> =
  (props) => {
    const [typeValue, setTypeValue] = useState<AuthType>();
    const [apiKeyValue, setApiKeyValue] = useState<APIKeyType>();
    const [fileList,setFileList] = useState<any[]>([]);
    const [checkResult, setCheckResult] = useState<boolean>(true);
    const [clientId, setClientId] = useState<string>("");
    const [secret, setSecret] = useState<string>("");
    const [uploadFile, setUploadFile] = useState<UploadFile>();
    const [form] = Form.useForm();

    useEffect(() => {
      form.validateFields(["Certificate", "Secret"]);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [checkResult]);

    const onFailed = (values: any) => {
      console.log("Failed:", values);
    };

    const closeDrawer = (): void => {
      form.resetFields();
      setApiKeyValue(undefined);
      setTypeValue(undefined);
      setClientId("");
      setSecret("")
      props.cancelClick();
    };

    const handleChange = (info:any) => {
      let keyList = [...info.fileList];
      keyList = keyList.slice(-2);
      setFileList(keyList);
    }

    const beforeUpload = (file: any, FileList: UploadFile[]) => {
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isLt2M) {
        setFileList([]);
        message.error('file must smaller than 2MB!');
      }else{
        setUploadFile(file);
      }
      return !isLt2M;
    };

    const normFile = (e: any) => {
      if (Array.isArray(e)) {
        return e;
      }
      return e && e.fileList;
    };
    const checkSecretOrCertificate = (
      rule: any,
      value: any,
      callback: any
    ): void => {
      const formFileList = form.getFieldValue("Certificate");
      const secretValue = form.getFieldValue("Secret");
      const hasFile = formFileList && formFileList.length > 0;
      if (secretValue || hasFile) {
        setCheckResult(false);
        callback();
      } else {
        setCheckResult(true);
        callback("error");
      }
    };
    const onGenerateClientIdClick = (): void => {
      GenerateClientId()
        .then((res) => {
          console.log(res);
          setClientId(res);
          form.setFieldsValue({ ClientId: res });
        })
        .catch((err) => {
          console.error(err);
        });
    };
    const onGenerateSecretClick = (): void => {
      GenerateSecret()
        .then((res) => {
          console.log(res);
          setSecret(res);
          form.setFieldsValue({ "Secret": res });
        })
        .catch((err) => {
          console.error(err);
        });
    };

    const onFinish = (values: IDataFrom) => {
      // setButtonLoading(true);
      // setLoading(true);
      let requestObject = new AuthenticationDto();
      requestObject.Name = values.Name;
      requestObject.Description = values.Description;
      requestObject.FromType = FromType.Frontend;
      requestObject.AuthType = values.Type;
      if (values.Type === AuthType.OAuth) {
        let oauth = new OAuthDto();
        oauth.ClientId = values.ClientId;
        oauth.Secret = values.Secret;
        oauth.Scope = values.Scope;
        
        requestObject.AuthSetting = oauth;
      } else if (
        values.Type === AuthType.APIKey &&
        values.APIKeyType === APIKeyType.JWT
      ) {
        let apikey = new ApiKeyDto();
        let jwt = new JWTDto();
        jwt.HashType = values.HashType;
        jwt.ClientId = values.ClientId;
        jwt.Secret = values.Secret;
        apikey.APIKeyType = values.APIKeyType;
        apikey.APIKeySetting = jwt;
        requestObject.AuthSetting = apikey;
      } else if (
        values.Type === AuthType.APIKey &&
        values.APIKeyType === APIKeyType.Constants
      ) {
        let apikey = new ApiKeyDto();
        let constDto = new ConstDto();
        constDto.ConstKey = values.Secret;
        //constDto.AuthorizationHeader = values.AuthorizationHeader;

        apikey.APIKeyType = values.APIKeyType;
        apikey.APIKeySetting = constDto;
        requestObject.AuthSetting = apikey;
      }
      if (props.isEdit) {
        requestObject.Id = props.editingId;
      }
      CreateAuthentication(requestObject, uploadFile)
        .then((res) => {
          // setButtonLoading(false);
          // setLoading(false);
          closeDrawer();
          props.getTableData();
        })
        .catch((err) => {
          // setButtonLoading(false);
          // setLoading(false);
        });
    };
    const renderOAuthItem = () => {
      return (
        <>
          <Form.Item
            label="Client Id"
            name="ClientId"
            rules={[
              {
                required: true,
                message: "Please input Client Id!",
              },
            ]}
          >
            <Input  maxLength={256}/>
          </Form.Item>

          <Form.Item
            label="Secret"
            name="Secret"
            rules={[
              {
                required: true,
                message: "Please input Secret!",
              },
            ]}
          >
            <Input  maxLength={256}/>
          </Form.Item>
          <Form.Item
            label="Scope"
            name="Scope"
            rules={[
              {
                required: true,
                message: "Please input Scope!",
              },
            ]}
          >
            <Input  maxLength={256}/>
          </Form.Item>
        </>
      );
    };

    const renderApiKeyItem = () => {
      return (
        <>
          <Form.Item
            label="Scheme"
            name="APIKeyType"
            rules={[{ required: true, message: "Please input API Key Type!" }]}
          >
            <Select
              style={{ width: "100%" }}
              onChange={(e: APIKeyType) => setApiKeyValue(e)}
            >
              {Array.from(ApiKeyFrontendMap).map(([key, value]) => (
                <Option value={value} key={value}>
                  {key}
                </Option>
              ))}
            </Select>
          </Form.Item>
          {apiKeyValue === APIKeyType.JWT && (
            <>
              <Form.Item
                label="Hash"
                initialValue={1}
                name="HashType"
                rules={[{ required: true, message: "Please select HashType!" }]}
              >
                <Select style={{ width: "100%" }}>
                  {Array.from(HashTypeMap).map(([key, value]) => (
                    <Option value={value} key={value}>
                      {key}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item label="Client Id" required={true}>
                <Row>
                  <Col span={20}>
                    <Form.Item
                      noStyle
                      name="ClientId"
                      rules={[
                        { required: true, message: "Please input ClientId!" },
                      ]}
                    >
                      <Input value={clientId} readOnly />
                    </Form.Item>
                  </Col>
                  <Col span={4}>
                    <Button
                      type="primary"
                      style={{ marginLeft: 10 }}
                      onClick={onGenerateClientIdClick}
                    >
                      Generate
                    </Button>
                  </Col>
                </Row>
              </Form.Item>

              <Form.Item label="Secret" required={false}>
                <Row>
                  <Col span={20}>
                    <Form.Item
                      noStyle
                      name="Secret"
                      rules={[
                        {
                          required: checkResult,
                          validator: checkSecretOrCertificate,
                          message: "Please input Secret Or Certificate!",
                        },
                      ]}
                    >
                      <Input value={secret} readOnly />
                    </Form.Item>
                  </Col>
                  <Col span={4}>
                    <Button
                      type="primary"
                      style={{ marginLeft: 10 }}
                      onClick={onGenerateSecretClick}
                    >
                      Generate
                    </Button>
                  </Col>
                </Row>
              </Form.Item>
              <Form.Item
                name="Certificate"
                label="Certificate"
                valuePropName="fileList"
                getValueFromEvent={normFile}
                required={false}
                rules={[
                  {
                    required: checkResult,
                    validator: checkSecretOrCertificate,
                    message: "Please input Secret Or Certificate!",
                  },
                ]}
              >
                <Upload
                  name="Certificate" 
                  maxCount={1}
                  beforeUpload={beforeUpload}
                  fileList={fileList}
                  multiple={false}
                  onChange={handleChange}
                  accept={'.pfx,.cert,.crt'}
                >
                  <Button icon={<UploadOutlined />}>Click to upload</Button>
                </Upload>
              </Form.Item>
            </>
          )}
          {apiKeyValue === APIKeyType.Constants && (
            <>
              {/* <Form.Item
                label="Authorization Header"
                name="AuthorizationHeader"
                initialValue={"Authorization"}
                rules={[{ required: true, message: "Please input authorization header!" }]}
              >
                <Input/>
              </Form.Item> */}
              <Form.Item
                label="Constants Key"
                name="Secret"
                rules={[
                    { required: true, message: "Please input Const Key!" },
                ]}>
                <Row>
                  <Col span={20}>
                      <Form.Item  name="Secret" >
                      <Input />
                      </Form.Item>
                  </Col>
                  <Col span={4}>
                    <Button
                      type="primary"
                      style={{ marginLeft: 10 }}
                      onClick={onGenerateSecretClick}
                    >
                      Generate
                    </Button>
                  </Col>
                </Row>
              </Form.Item>
            </>
          )}
        </>
      );
    };

    return (
      <Drawer
        visible={props.visible}
        width={720}
        destroyOnClose
        forceRender
        onClose={closeDrawer}
        title={
          props.isEdit
            ? "Edit Frontend Authentication"
            : "Create a new Frontend Authentication"
        }
        footer={
          <div style={{ textAlign: "right" }}>
            <Button
              type="primary"
              style={{ marginRight: 8 }}
              onClick={() => form.submit()}
            >
              Save
            </Button>
            <Button onClick={closeDrawer}>Cancel</Button>
          </div>
        }
      >
        <Form
          form={form}
          onFinish={onFinish}
          onFinishFailed={onFailed}
          layout="vertical"
          style={{ marginTop: "1.25rem" }}
        >
          <Form.Item
            label="Name"
            name="Name"
            rules={[{ required: true, message: "Please input name!" }]}
          >
            <Input maxLength={256}/>
          </Form.Item>
          <Form.Item
            label="Description"
            name="Description"
            rules={[{ required: false }]}
          >
            <Input.TextArea rows={3} />
          </Form.Item>

          <Form.Item
            label="Authorization Type"
            name="Type"
            rules={[{ required: true, message: "Please input authorization type!" }]}
          >
            <Select
              style={{ width: "100%" }}
              onChange={(e: AuthType) => setTypeValue(e)}
            >
              {Array.from(AuthTypeFrontendMap).map(([key, value]) => (
                <Option value={value} key={value}>
                  {key}
                </Option>
              ))}
            </Select>
          </Form.Item>
          {typeValue === AuthType.OAuth && renderOAuthItem()}
          {typeValue === AuthType.APIKey && renderApiKeyItem()}
        </Form>
      </Drawer>
    );
  };
export default CreateFrontendAuthenticationDrawer;

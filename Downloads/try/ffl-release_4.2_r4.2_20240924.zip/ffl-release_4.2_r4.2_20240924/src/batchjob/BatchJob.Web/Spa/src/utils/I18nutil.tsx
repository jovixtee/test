import { getItem, setItem } from "./localstorageutil";
const _v = {
  language: "en"
};
export const registerI18n = (namespace: string, resources: any, language = "en") => {
  let i18n = getItem("i18n") || {};
  _v.language = language;
  if (resources) {
    const res = (i18n && i18n[namespace] && i18n[namespace][language] && i18n[namespace][language]) || {}
    res[language] = resources
    i18n[namespace] = res;
    setItem("i18n", i18n, 0);
  }
}
export const getI18N = (namespace: string, key: string, defaultValue?: string, language = "en") => {
  const res = getItem("i18n") || {};
  if (res && res[namespace] && res[namespace][language] && res[namespace][language][key]) {
    return res[namespace][language][key];
  } else {
    return defaultValue || "";
  }
}





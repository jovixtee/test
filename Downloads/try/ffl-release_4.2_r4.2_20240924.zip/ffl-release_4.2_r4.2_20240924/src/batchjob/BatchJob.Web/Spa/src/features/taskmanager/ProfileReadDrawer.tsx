import { Button,  Radio, Checkbox, Drawer, Descriptions } from 'antd';
import React, { FC, useEffect, useState } from "react";
import TaskRepository from './TaskRepository';
import { convertTicksToFormatDate } from '../../utils/dateconvert';
import { TaskDto,ScheduleRuleType, ScheduleSequence, ScheduleRuleTypeMap, WeekDay, WorkingHourOptions, ScheduleMonth } from './TaskManagerContract';
import { DatetimeFormat } from '../../common/contracts/WebConstants';
interface IProfileReadDrawerProps {
    visible: boolean;
    onClose: () => void;
    dataSource: TaskDto
}

const ProfileReadDrawer: FC<IProfileReadDrawerProps> = (props) => {
    const notificationProfiles = TaskRepository.getInstance().NotificationProfiles;
    const actionSettings = TaskRepository.getInstance().ActionSettings;
    const holidayProfile = TaskRepository.getInstance().HolidayProfile;
    const [data, setDate] = useState<any[]>();
    useEffect(() => {
        if (props.visible) {
            let dataSource = props.dataSource;
            let profile: any[] = [];
            let item = { "type": "text", "key": "Task Title", "value": dataSource.Name };
            profile.push(item);
            item = { "type": "text", "key": "Description", "value": dataSource.Description };
            profile.push(item);
            if (dataSource.NotificationProfileId) {
                let notification = notificationProfiles?.find(e => e.Id === dataSource.NotificationProfileId);
                item = { "type": "text", "key": "Notification Profile", "value": notification?.Name };
                profile.push(item);
                const options = [
                    { label: 'Finished', value: 2 },
                    { label: 'Finished with Exception', value: 4 },
                    { label: 'Failed', value: 4 },
                ];
                let notificationType = translate.restChecked(dataSource.NotificationType);
                let checkItem = { "type": "checkbox", "key": "Status", "value": notificationType, "data": options };
                profile.push(checkItem);
            }
            let jobAction = actionSettings?.find(e => e.Id === dataSource.JobAction?.HandlerId);
            item = { "type": "text", "key": "Action", "value": jobAction?.DisplayName };
            profile.push(item);
            item = { "type": "text", "key": "Run on executors", "value": dataSource?.Endpoints };
            profile.push(item);
            item = { "type": "text", "key": "Tag", "value": dataSource?.Tag };
            profile.push(item);
            if(dataSource.JobAction?.PartsAndValues){
                item = { "type": "text", "key": jobAction!.ActionParameterSettings![0].Label!, "value": dataSource.JobAction?.PartsAndValues[1] };
                profile.push(item);
            }

            const options = [
                { label: 'On Schedule', value: 0 },
                { label: 'Manually', value: 1 },
            ];
            let radioItem = { "type": "radio", "key": "Run the Task", "value": dataSource?.Type, "data": options };
            profile.push(radioItem);
            let scheduleRule = dataSource?.Schedule?.ScheduleRule;
            if (dataSource?.Type === 0) {
                item = { "type": "text", "key": "Schedule Type", "value": ScheduleRuleTypeMap?.get(scheduleRule!.RuleType!)};
                profile.push(item);

                item = { "type": "text", "key": "Start Time", "value": convertTicksToFormatDate(dataSource?.Schedule?.StartTime!, DatetimeFormat) };
                profile.push(item);
            }

            if(dataSource?.Type === 1){
                setDate(profile);
                return;
            }

            if ( scheduleRule?.RuleType === ScheduleRuleType.Minutely
                || scheduleRule?.RuleType === ScheduleRuleType.Hourly
                || scheduleRule?.RuleType === ScheduleRuleType.Daily
                || scheduleRule?.RuleType === ScheduleRuleType.Weekly) {
                let suffix = "";
                if (scheduleRule?.RuleType === ScheduleRuleType.Minutely) {
                    suffix = "Minutes";
                } else if (scheduleRule?.RuleType === ScheduleRuleType.Hourly) {
                    suffix = "Hours";
                } else if (scheduleRule?.RuleType === ScheduleRuleType.Daily) {
                    suffix = "Days";
                } else if (scheduleRule?.RuleType === ScheduleRuleType.Weekly) {
                    suffix = "Weeks";
                }
                item = { "type": "text", "key": "Recur every", "value": scheduleRule?.Interval + " " + suffix };
                profile.push(item);
                if (scheduleRule?.RuleType === ScheduleRuleType.Weekly) {
                    const options = [
                        { label: 'Sunday', value: 0 },
                        { label: 'Monday', value: 1 },
                        { label: 'Tuesday', value: 2 },
                        { label: 'Wednesday', value: 3 },
                        { label: 'Thursday', value: 4 },
                        { label: 'Friday', value: 5 },
                        { label: 'Saturday', value: 6 },
                    ];
                    let checkItem = { "type": "checkbox", "key": "", "value": scheduleRule?.DayOfWeekSpecifies, "data": options };
                    profile.push(checkItem);
                }
            }
           
            if (scheduleRule?.RuleType === ScheduleRuleType.Monthly) {
                let startTime = "";
                if (scheduleRule?.MonthlySubType === 0) {
                    startTime = "On day " + scheduleRule?.DayOfMonth + " of " + ScheduleMonth[scheduleRule?.SpecifyMonth!]
                } else if (scheduleRule?.MonthlySubType === 1) {
                    startTime = "On day " + scheduleRule?.DayOfMonth + " of every " + scheduleRule?.Interval + " months";
                } else if (scheduleRule?.MonthlySubType === 2) {
                    startTime = "The " + ScheduleSequence[scheduleRule?.WeekSequence!] + " " + WeekDay[scheduleRule?.DayOfWeekSpecifies![0]] + " of every " + scheduleRule?.Interval + " months";
                } else if (scheduleRule?.MonthlySubType === 3) {
                    startTime = "The " + ScheduleSequence[scheduleRule?.WeekSequence!] + " " + WeekDay[scheduleRule?.DayOfWeekSpecifies![0]] + " of " + ScheduleMonth[scheduleRule?.SpecifyMonth!]
                }
                item = { "type": "text", "key": "", "value": startTime };
                profile.push(item);
            }
            if (scheduleRule!.WorkingHoursOption as WorkingHourOptions && scheduleRule!.WorkingHoursOption !== WorkingHourOptions.None) {
                const options = [
                    { label: 'Run working hoursOn Schedule', value: 1 },
                    { label: 'Run out working hours', value: 2 },
                ];
                let radioItem = { "type": "radio", "key": "Working Hours", "value": scheduleRule?.WorkingHoursOption, "data": options };
                profile.push(radioItem);
                let start = convertTicksToFormatDate(scheduleRule?.WorkingHourStartTime!, 'HH:mm:ss');
                let end = convertTicksToFormatDate(scheduleRule?.WorkingHourEndTime!, 'HH:mm:ss')
                item = { "type": "text", "key": "", "value": start + "-" + end };
                profile.push(item);
                const checkOptions = [
                    { label: 'Sunday', value: 0 },
                    { label: 'Monday', value: 1 },
                    { label: 'Tuesday', value: 2 },
                    { label: 'Wednesday', value: 3 },
                    { label: 'Thursday', value: 4 },
                    { label: 'Friday', value: 5 },
                    { label: 'Saturday', value: 6 },
                ];
                let checkItem = { "type": "checkbox", "key": "", "value": scheduleRule?.WorkingDays, "data": checkOptions };
                profile.push(checkItem);
            }
            if(dataSource?.Schedule?.HolidayProfileId){
                let holiday = holidayProfile?.find(e => e.ProfileId === dataSource?.Schedule?.HolidayProfileId);
                item = { "type": "text", "key": "Skip Holidays", "value": holiday?.OrganizationName };
                profile.push(item);
            }
            setDate(profile);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.visible]);

    const translate = {
        restChecked: (dataBaseValue: number) => {
            let defaultValue = 2;
            let value = 0;
            let result: any = [];
            for (let i = 0; value <= dataBaseValue; i++) {
                value = defaultValue << i;
                if (value <= dataBaseValue && (dataBaseValue & value) === value) {
                    result.push(value);
                }
            }
            return result;
        },
        onFinished: (task: TaskDto) => {

        }
    }

    const renderItem = (data: any[]) => {
        return (
            <>
                <Descriptions column={1} bordered>
                    {
                        data?.map((item: any) => {
                            let obj = null;
                            switch (item.type) {
                                case "text":
                                    obj = (<Descriptions.Item label={item.key}>{item.value}</Descriptions.Item>);
                                    break;
                                case "radio":
                                    obj = (
                                        <Descriptions.Item label={item.key}>
                                            <Radio.Group disabled options={item.data} defaultValue={item.value} />
                                        </Descriptions.Item>
                                    );
                                    break;
                                case "checkbox":

                                    obj = (
                                        <Descriptions.Item label={item.key}>
                                            <Checkbox.Group disabled options={item.data} defaultValue={item.value} />
                                        </Descriptions.Item>
                                    );
                                    break;
                            }
                            return obj;
                        })
                    }
                </Descriptions>
            </>
        );
    }

    return (<Drawer visible={props.visible} width={720} onClose={(e) => props.onClose()}
        title={"View task"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" onClick={(e) => props.onClose()} >Close</Button>
            </div>
        }>
        {renderItem(data!)}
    </Drawer>)
};

export default ProfileReadDrawer;
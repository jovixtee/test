import React, { useState, useEffect, FunctionComponent } from 'react';
import { Route, Switch, BrowserRouter as Router, Redirect } from 'react-router-dom';
import Index from './features/index/Index';
import './App.css';
import 'antd/dist/antd.less';
import { APMOidcCallback } from './login/APMOidcCallback';
import { CookieKeys } from './common/contracts/WebConstants';
import UserContext from './context/UserContext';
import Login from './login/Login';
//import cookies from "react-cookies";
import { QueryUserSummary } from './features/index/Services';
import { UserSummaryObject } from './accountmanager/AccountManagerContract';
import { storeUserSummary } from './utils/permissionutil';
import PathJsConfig from './common/PathConfig';
import { validateCookie, refreshCookie } from './common/AuthenticationService';
import { AuthProceedGrantCallback } from './apimanagement/apiauthentication/AuthProceedGrantCallback';
const App: FunctionComponent = () => {
  //const initAuthed = cookies.load(CookieKeys.marsToken) != null;
  //if (initAuthed) console.log("Token exists.");

  const [renderRouter, setRenderRouter] = useState<any>();
  const [authed, setAuthed] = useState<boolean>(false);
  const [user, setUser] = useState<UserSummaryObject>();

  useEffect(() => {
    if (authed) {
      handleRefreshCookie();
      QueryUserSummary().then((result) => {
        const r = result.Result as UserSummaryObject;
        storeUserSummary(r);
        setUser(r);
      });
    }
  }, [authed]);

  const handleRefreshCookie = () => {
    const timer = setInterval(async () => {
      const cookieIsAccess = await refreshCookie();
      if (!cookieIsAccess) {
        clearInterval(timer);
      }
    }, 1000 * 60 * 5);
  };

  const handleValidateCookie = async () => {
    const cookieIsAccess = await validateCookie();

    accessRender(cookieIsAccess);
  };

  const UnauthedRender = () => {
    return (
      <Switch>
        <Route path={PathJsConfig.addPrefix('/oidc-callback')}>
          <APMOidcCallback onVerified={setAuthed} />
        </Route>
        <Route path={PathJsConfig.addPrefix('/')} exact>
          <Login onLogined={() => handleValidateCookie()} />
        </Route>
        <Redirect path={PathJsConfig.addPrefix('/')} to={PathJsConfig.addPrefix('/')} />
      </Switch>
    );
  };

  const accessRender = (isAccess: boolean) => {
    setAuthed(isAccess);
    if (isAccess) {
      setRenderRouter(AuthedRender());
    } else {
      setRenderRouter(UnauthedRender());
    }
  };

  const AuthedRender = () => {
    return (
      <Switch>
        <Route path={PathJsConfig.addPrefix('/auth-callback')}>
          <AuthProceedGrantCallback />
        </Route>
        <UserContext.Provider value={user}>
          <Index />
        </UserContext.Provider>
      </Switch>
    );
  };

  useEffect(() => {
    validateCookie().then((res) => accessRender(res));
  }, []);
  return <Router>{renderRouter}</Router>;
};
export default App;

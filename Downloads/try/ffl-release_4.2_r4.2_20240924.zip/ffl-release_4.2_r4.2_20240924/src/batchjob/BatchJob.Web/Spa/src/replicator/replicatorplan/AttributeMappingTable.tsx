
import React, { FC, useState, useEffect } from 'react';
import { Table } from 'antd';
import { ColumnsType } from "antd/lib/table";
import { FieldMappings } from '../ReplicatorContract';

interface IAttributeMappingProps {
    dataSource?: FieldMappings[];
}


const AttributeMappingTable: FC<IAttributeMappingProps> = (props) => {
    const [dataSource, setDataSource] = useState<FieldMappings[]>([]);

    useEffect(() => {
        setDataSource(props.dataSource!);
    }, [props.dataSource])

 

    const columns: ColumnsType<any> = [
        {
            title: 'Target Attribute',
            dataIndex: 'TargetAttribute',
        },
        {
            title: 'Target DataType',
            dataIndex: 'TargetDataType',
        },
        {
            title: 'Source Attribute',
            dataIndex: 'SourceAttribute',
        },
        {
            title: 'Source Data Type',
            dataIndex: 'SourceDataType',
        }
    ]

 
    return <React.Fragment>
        <Table
            rowKey={(record) => record.Id}
            columns={columns}
            dataSource={dataSource}
            pagination={false}

        />
    </React.Fragment>

}
export default AttributeMappingTable


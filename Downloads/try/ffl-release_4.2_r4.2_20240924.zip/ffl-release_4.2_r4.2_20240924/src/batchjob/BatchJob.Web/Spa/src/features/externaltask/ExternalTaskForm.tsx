import React from "react";
import { Form, Input, Select, Button } from "antd";
import { IData } from "./ExternalTaskTable";
import DateTimePicker from "../../components/DateTimePicker";
let formRef: any = React.createRef();

const formItemLayout = {
    labelCol: {
        xs: { span: 8 },
        sm: { span: 4 },
    },
    wrapperCol: {
        xs: { span: 16 },
        sm: { span: 8 },
    },
};
const tailFormItemLayout = {
    wrapperCol: {
        xs: {
            span: 16,
            offset: 0,
        },
        sm: {
            span: 8,
            offset: 4,
        },
    },
};
interface IPerson {
    id: number;
    name: string;
}

interface IExternalTaskFormState {
    item: IData;
    connections: IPerson[];
}
interface IExternalTaskFormProps {
    item?: IData;
    onCancel?: () => void;
}
class ExternalTaskForm extends React.PureComponent<IExternalTaskFormProps, IExternalTaskFormState> {
    constructor(props: IExternalTaskFormProps, state: IExternalTaskFormState) {
        super(props);
        if (props.item) {
            this.state = {
                item: props.item,
                connections: [
                    {
                        id: 1,
                        name: "connection1"
                    }, {
                        id: 2,
                        name: "connection2"
                    }
                    , {
                        id: 3,
                        name: "connection3"
                    }
                    , {
                        id: 4,
                        name: "connection4"
                    }
                    , {
                        id: 5,
                        name: "connection5"
                    }

                ]
            };
        } else {
            this.state = {
                item: {
                    uuid: "uuid new",
                    title: "1",
                    description: "",
                    target: "",
                    targetvalue: NaN,
                    packagedisplayname: "",
                    action: "",
                    createdby: "",
                    createdtime: "",
                    modifiedby: "",
                    modifiedtime: "",
                },
                connections: [
                    {
                        id: 1,
                        name: "connection1"
                    }, {
                        id: 2,
                        name: "connection2"
                    }
                    , {
                        id: 3,
                        name: "connection3"
                    }
                    , {
                        id: 4,
                        name: "connection4"
                    }
                    , {
                        id: 5,
                        name: "connection5"
                    }

                ]
            };


        }
    }
    onChange = (value: any): void => {
        const item: IData = this.state.item;
        item.targetvalue = value;
        this.setState({ item });
    }
    changeField = (value: any, filed: string): void => {
        const item: any = this.state.item;
        item[filed] = value.target.value;
        this.setState({ item });
    }
    onSubmit = () => {
        const item: IData = this.state.item;
        console.log(item);
        formRef.current.validateFields().then((result: any) => {
            this.props.onCancel && this.props.onCancel();
        }).catch((result: any) => {
            if (result.errorFields && result.errorFields.length > 0) {
                console.log(result.errorFields);
            }
        });

    }
    componentWillReceiveProps(nextProps: IExternalTaskFormProps): void {
        if (nextProps.item) {
            this.setState({ item: nextProps.item }, () => { formRef.current.resetFields(); });
        } else {
            this.setState({
                item: {
                    uuid: "uuid new",
                    title: "",
                    description: "",
                    target: "",
                    targetvalue: NaN,
                    packagedisplayname: "",
                    action: "",
                    createdby: "",
                    createdtime: "",
                    modifiedby: "",
                    modifiedtime: "",
                }
            }, () => { formRef.current.resetFields(); });
        }
    }

    render(): JSX.Element {
        return (
            <>
                <Select
                    showSearch
                    value={this.state.item.targetvalue}
                    style={{ marginLeft: 60, width: 300 }}
                    placeholder="Select a person"
                    optionFilterProp="children"
                    onChange={this.onChange}
                    filterOption={(input, option: any) =>
                        option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                    }
                >
                    {
                        this.state.connections.map((con) => <Select.Option key={con.id} value={con.id}>{con.name}</Select.Option>)
                    }
                </Select>
                <Form
                    {...formItemLayout}
                    ref={formRef}
                    scrollToFirstError
                    initialValues={this.state.item}
                >
                    <Form.Item
                        name="title"
                        label="Title"
                        rules={[
                            {
                                required: true,
                                message: "Please input your title",
                            },
                        ]}
                    >
                        <Input
                            style={{ marginLeft: 60, width: 300 }}
                            value={this.state.item.title}
                            onChange={(value: any) => { this.changeField(value, "title"); }}
                        />
                    </Form.Item>
                    <Form.Item
                        name="description"
                        label="Description"
                    >
                        <Input
                            style={{ marginLeft: 60, width: 300 }}
                            value={this.state.item.description}
                        />
                    </Form.Item>
                    <Form.Item
                        name="targetvalue"
                        label="Target"
                        rules={[
                            {
                                required: true,
                                message: "Please select target!",
                            },
                        ]}
                    >
                        <Select
                            showSearch
                            value={this.state.item.targetvalue}
                            style={{ marginLeft: 60, width: 300 }}
                            placeholder="Select a person"
                            optionFilterProp="children"
                            onChange={this.onChange}
                            filterOption={(input, option: any) =>
                                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                            {
                                this.state.connections.map((con) => <Select.Option key={con.id} value={con.id}>{con.name}</Select.Option>)
                            }
                        </Select>
                    </Form.Item>

                    <Form.Item
                        name="packagedisplayname"
                        label="Package Display Name"
                    >
                        <Input
                            value={this.state.item.packagedisplayname}
                            style={{ marginLeft: 60, width: 300 }}
                            onChange={(value: any) => {
                                this.changeField(value, "packagedisplayname");
                            }}
                        />
                    </Form.Item>

                    <Form.Item
                        name="createdtime"
                        label="CreatedTime"
                    >
                        <DateTimePicker value={637429206043850000} onChange={(ticks: number) => { console.log(ticks); }} />
                    </Form.Item>
                    <Form.Item {...tailFormItemLayout}>
                        <Button type="primary" htmlType="submit" onClick={this.onSubmit} >
                            Submit
                        </Button>
                    </Form.Item>
                </Form>
            </>
        );
    }
}

export default ExternalTaskForm;
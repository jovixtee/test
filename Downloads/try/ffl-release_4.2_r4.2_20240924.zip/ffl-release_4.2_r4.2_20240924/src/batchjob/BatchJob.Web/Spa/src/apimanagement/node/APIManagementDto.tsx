import { PagerResult } from '../../common/contracts/PagerContracts';

enum AuthType {
    byUser = 0,
    token = 1,
    custom = 2,
}

enum RateType {
    ByCount = 0,
    BySize = 1
}


enum BlockRuleType {
    WhiteList = 0,
    BlackList = 1
}

enum PolicyRuleType {
    Notification = 0,
    BlockRule = 1,
    Alert = 2,
}

enum VersionStatus {
    Draft = 0,
    Active = 1,
    Deprecate = 2
}

enum ServiceResultType {
    Success = 0,
    Failed = 1,
    Error = 2,
    Exception = 3,
};

class NodeDto {
    Id?: string;
    Host?: string;
    Schema?: string;
    Port?: number;
    Status?: string;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
}

class FrontendDto {
    Id?: string;
    Node?: NodeDto;
    Name?: string;
    BaseAddress?: string;
    Description?: string;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
}

class BackendDto {
    Id?: string;
    Name?: string;
    Protocol?: string;
    Description?: string;
    APIVersion?: APIVersionDto;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
}

class APIVersionDto {
    Id?: string;
    Status?: VersionStatus;
    Frontend?: FrontendDto;
    Endpoint?: string;
    ControlPolicy?: Array<ControlPolicyDto>;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;

}


class APIMethodDto {
    Id?: string;
    Path?: string;
    MethodName?: string;
    Header?: string;
    MethodParameter?: Array<MethodParameterDto>;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
}

class MethodParameterDto {
    Id?: string;
    Key?: string;
    StructurePattern?: Array<StructurePatternDto>;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
}

class StructurePatternDto {
    type?: string;
    property?: string;
}



class ControlPolicyDto {
    Id?: string;
    Name?: string;
    Description?: string;
    ControlPolicyRule?: Array<ControlPolicyRuleDto>;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
}

class ControlPolicyRuleDto {
    Id?: string;
    Type?: PolicyRuleType;
    SN?: number;
    ExtensionJSON?: [Array<APIRateDto>,Array<BlockRuleDto>];
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
}

class APIAuthenticationDto {
    Id?: string;
    AuthType?: AuthType;
    UserName?: string;
    Password?: string;
    Token?: string;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
}

class APIRateDto {
    Id?: string;
    RuleType?: RateType;
    Size?: number;
    Unit?: string;
}


class BlockRuleDto {
    Id?: string
    Type?: BlockRuleType;
    Rule?: string
}

class APIManagementDto{
    Frontend?:FrontendDto
    Backend?:BackendDto
}


class HistoryDto {
    Id?: string;
    FrontendUrl?: string;
    Method?: string;
    Header?: string;
    Body?: string;
    BackendUrl?: string;
    BackendMethod?: string;
    BackendHeader?: string;
    BackendBody?: string;
    Status?: string;
    Credential?: string;
    IncomeTimestamp?: number;
    OutgoTimestamp?: number;
}


//Result
class NodeResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<NodeDto>|Array<NodeDto>|NodeDto;
};

class FrontendResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<FrontendDto>|Array<FrontendDto>|FrontendDto;
}

class BackendResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<BackendDto>|Array<BackendDto>|BackendDto;
}

class APIVersionResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<APIVersionDto>|Array<APIVersionDto>|APIVersionDto;
}


class APIMethodResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<APIMethodDto>|Array<APIMethodDto>|APIMethodDto;
}

class MethodParameterResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<MethodParameterDto>|Array<MethodParameterDto>|MethodParameterDto;
}

class StructurePatternResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<StructurePatternDto>|Array<StructurePatternDto>|StructurePatternDto;
}

class ControlPolicyResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<ControlPolicyDto>|Array<ControlPolicyDto>|ControlPolicyDto;
}

class ControlPolicyRuleResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<ControlPolicyRuleDto>|Array<ControlPolicyRuleDto>|ControlPolicyRuleDto;
}

class APIAuthenticationResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<APIAuthenticationDto>|Array<APIAuthenticationDto>|APIAuthenticationDto;
}

class HistoryResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Result?: PagerResult<HistoryDto>|Array<HistoryDto>|HistoryDto;
}

export {
    NodeDto, FrontendDto, BackendDto, APIVersionDto, APIMethodDto, MethodParameterDto,APIManagementDto,
    ControlPolicyDto, APIAuthenticationDto, HistoryDto, ControlPolicyRuleDto, APIRateDto,BlockRuleDto,


    NodeResult, FrontendResult, BackendResult, APIVersionResult, APIMethodResult, MethodParameterResult,
    StructurePatternResult, ControlPolicyResult, ControlPolicyRuleResult, APIAuthenticationResult, HistoryResult
}
import React, { useState, useEffect, useImperativeHandle } from "react";
import moment from 'moment';
import { Radio, InputNumber,Input, Checkbox, Select, Form, Space, TimePicker, Row, Col } from 'antd';
import { convertTicksToMoment, convertMomentToTicks } from '../../utils/dateconvert';
import { ScheduleRuleType, ScheduleSequence, ScheduleRuleDto, WeekDay, WorkingHourOptions, ScheduleMonth, ScheduleDay, MonthlyRuleType } from './TaskManagerContract';
import DateTimePicker from '../../components/DateTimePicker';
import TaskRepository from './TaskRepository';

const defaultTicks: number = 621355968000000000;

const monthlyRuleRadioStyle = {
    display: 'block',
    height: '40px',
    lineHeight: '40px',
};

const subSelectionStyle = {
    width: '100px'
};

const monthInYear = new Array<any>();
const dayInMonth = new Array<any>();
const sequenceInMonth = new Array<any>();
const weekDays = new Array<any>();
const dayLastMonth = new Array<any>();
if (dayInMonth.length === 0) {
    for (let d in ScheduleDay) {
        if (parseInt(d)) {
            dayInMonth.push({ value: parseInt(d), label: d });
        }
    }
}

if (monthInYear.length === 0) {
    for (let d in ScheduleMonth) {
        if (parseInt(d)) {
            monthInYear.push({ value: parseInt(d), label: ScheduleMonth[d] });
        }
    }
}

if (sequenceInMonth.length === 0) {
    for (let d in ScheduleSequence) {
        if (parseInt(d)) {
            sequenceInMonth.push({ value: parseInt(d), label: ScheduleSequence[d] });
        }
    }
}

if (weekDays.length === 0) {
    for (let d in WeekDay) {
        if (!isNaN(parseInt(d))) {
            weekDays.push({ value: parseInt(d), label: WeekDay[d] });
        }
    }
}

if (dayLastMonth.length === 0) {
    for (let d in ScheduleDay) {
        if (parseInt(d)) {
            dayLastMonth.push({ value: parseInt(d), label: d });
        }
    }
}

interface ITaskScheduleRule {
    scheduleRule?: ScheduleRuleDto;
    taskForm?: any;
    ruleRef?: any;
    enableHolidaySetting?: boolean;
    setEnableHolidaySetting?: any;
}
function TaskScheduleRule(props: ITaskScheduleRule) {
    const taskForm = props.taskForm;
    const [scheduleType, setScheduleType] = useState<ScheduleRuleType>(ScheduleRuleType.Daily);
    const [monthlyRuleType, setMonthlyRuleType] = useState<number>(0);
    const [enableWorkingHours, setEnableWorkingHours] = useState(false);
    const [workingHourOptions, setWorkingHourOptions] = useState<number>(0);
    const holidayProfile = TaskRepository.getInstance().HolidayProfile;
    useEffect(() => {
        const setupForm = (rules: ScheduleRuleDto) => {
            let scheduleType = rules?.RuleType;
            setScheduleType(scheduleType as ScheduleRuleType);
            taskForm.setFieldsValue({
                ScheduleType: scheduleType
            });
            switch (scheduleType) {
                case ScheduleRuleType.Minutely:
                case ScheduleRuleType.Hourly:
                case ScheduleRuleType.Daily: 
                case ScheduleRuleType.Weekly:
                    taskForm.setFieldsValue({
                        ScheduleInterval: rules.Interval,
                        DayOfWeekSpecifies: rules.DayOfWeekSpecifies,
                    });
                    break;
                case ScheduleRuleType.Monthly:
                    let monthlySubType = rules.MonthlySubType
                    taskForm.setFieldsValue({
                        ScheduleMonthlyRuleType: monthlySubType,
                    });
                    if (MonthlyRuleType.DayAndMonth === monthlySubType) {
                        taskForm.setFieldsValue({
                         MR0_Day: rules.DayOfMonth,
                         MR0_Month: rules.SpecifyMonth
                        });
                    } else if (MonthlyRuleType.DayByInterval === monthlySubType) {
                        setMonthlyRuleType(monthlySubType);
                        taskForm.setFieldsValue({
                            MR1_Day: rules.DayOfMonth,
                            MR1_Interval: rules.Interval
                        });
                    } else if (MonthlyRuleType.DayOfWeekByInterval === monthlySubType) {
                        const w = rules?.DayOfWeekSpecifies ? rules?.DayOfWeekSpecifies[0] : 1;
                        setMonthlyRuleType(monthlySubType);
                        taskForm.setFieldsValue({
                            MR2_Sequence: rules.WeekSequence,
                            MR2_WeekDay: w,
                            MR2_Interval: rules.Interval
                        });
                    } else if (MonthlyRuleType.DayOfWeekAndMonth === monthlySubType) {
                        setMonthlyRuleType(monthlySubType);

                        const w = rules?.DayOfWeekSpecifies ? rules?.DayOfWeekSpecifies[0] : 1;
                        taskForm.setFieldsValue({
                            MR3_Sequence: rules.WeekSequence,
                            MR3_WeekDay: w,
                            MR3_Month: rules.SpecifyMonth
                        });
                    }else if(MonthlyRuleType.DayofLastAndMonth === monthlySubType){
                        setMonthlyRuleType(monthlySubType);
                        taskForm.setFieldsValue({
                            MR4_Day: rules.DayOfMonth,
                            MR4_Interval: rules.Interval
                        });
                    }
                    break;
                default:
                    break;
            }
            //Enable Working Hours
            if (rules.WorkingHoursOption as WorkingHourOptions && rules.WorkingHoursOption !== WorkingHourOptions.None) {
                //处理 Working Hours时间控件
                if (rules?.WorkingHourStartTime && rules?.WorkingHourEndTime) {
                    let WorkingHoursRange = [];
                    WorkingHoursRange.push(convertTicksToMoment(rules?.WorkingHourStartTime));
                    WorkingHoursRange.push(convertTicksToMoment(rules?.WorkingHourEndTime));
                    taskForm.setFieldsValue({
                        WorkingHoursRange: WorkingHoursRange
                    });
                }
                taskForm.setFieldsValue({ WorkingDays: rules?.WorkingDays })
                setWorkingHourOptions(rules?.WorkingHoursOption as WorkingHourOptions);
                setEnableWorkingHours(true);
            } else {
                setWorkingHourOptions(WorkingHourOptions.WorkingHours);
                setEnableWorkingHours(false);
                let defaultWorkingHoursRange = [];
                defaultWorkingHoursRange.push(moment('9:00:00', 'HH:mm:ss'));
                defaultWorkingHoursRange.push(moment('18:00:00', 'HH:mm:ss'));
                taskForm.setFieldsValue({ WorkingHoursRange: defaultWorkingHoursRange })
            }
            //Skip Holidays

        }

        if (props.scheduleRule) {
            setupForm(props.scheduleRule as ScheduleRuleDto)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.scheduleRule]);

    useImperativeHandle(props.ruleRef, () => ({
        getFormData: () => {
            let data = new ScheduleRuleDto();
            let scheduleType = taskForm.getFieldValue("ScheduleType");
            //let ScheduleStartTime =  taskForm.getFieldValue("ScheduleStartTime");
            let scheduleInterval = taskForm.getFieldValue("ScheduleInterval");
            let dayOfWeekSpecifies = taskForm.getFieldValue("DayOfWeekSpecifies");
            let MR0_Day = taskForm.getFieldValue("MR0_Day");
            let MR0_Month = taskForm.getFieldValue("MR0_Month");
            let MR1_Day = taskForm.getFieldValue("MR1_Day");
            let MR1_Interval = taskForm.getFieldValue("MR1_Interval");


            let MR2_Sequence = taskForm.getFieldValue("MR2_Sequence");
            let MR2_WeekDay = taskForm.getFieldValue("MR2_WeekDay");
            let MR2_Interval = taskForm.getFieldValue("MR2_Interval");

            let MR3_Sequence = taskForm.getFieldValue("MR3_Sequence");
            let MR3_WeekDay = taskForm.getFieldValue("MR3_WeekDay");
            let MR3_Month = taskForm.getFieldValue("MR3_Month");
            let MR4_Day = taskForm.getFieldValue("MR4_Day");
            let MR4_Interval = taskForm.getFieldValue("MR4_Interval");
            data.RuleType = scheduleType;

            if (scheduleType !== ScheduleRuleType.OnlyOnce) {
                data.Interval = scheduleInterval;
            }
            if (scheduleType === ScheduleRuleType.Monthly) {
                data.MonthlySubType = monthlyRuleType;
                // R0: DayAndMonthx
                // R1: DayByInterval
                // R2: DayOfWeekByInterval
                // R3: DayOfWeekAndMonth
                switch (monthlyRuleType) {
                    case MonthlyRuleType.DayAndMonth:
                        
                        data.DayOfMonth = MR0_Day;
                        data.SpecifyMonth = MR0_Month;
                        break;
                    case MonthlyRuleType.DayByInterval:
                        data.DayOfMonth = MR1_Day;
                        data.Interval = MR1_Interval;
                        break;
                    case MonthlyRuleType.DayOfWeekByInterval:
                        data.WeekSequence = MR2_Sequence;
                        data.DayOfWeekSpecifies = [];
                        data.DayOfWeekSpecifies.push(MR2_WeekDay);
                        data.Interval = MR2_Interval;
                        break;
                    case MonthlyRuleType.DayOfWeekAndMonth:
                        data.WeekSequence = MR3_Sequence;
                        data.DayOfWeekSpecifies = [];
                        data.DayOfWeekSpecifies.push(MR3_WeekDay);
                        data.SpecifyMonth = MR3_Month;
                        break;
                    case MonthlyRuleType.DayofLastAndMonth:
                        data.DayOfMonth = MR4_Day;
                        data.Interval = MR4_Interval;
                        break;
                }
            } else if (scheduleType === ScheduleRuleType.Weekly) {
                data.DayOfWeekSpecifies = dayOfWeekSpecifies;
            }
            if((scheduleType === ScheduleRuleType.Minutely || scheduleType === ScheduleRuleType.Hourly) && enableWorkingHours){
                let WorkingHoursRange = taskForm.getFieldValue("WorkingHoursRange");
                let WorkingDays = taskForm.getFieldValue("WorkingDays");
                if (WorkingHoursRange) {
                    let start = WorkingHoursRange[0];
                    let end = WorkingHoursRange[1];
                    data.WorkingHourStartTime = convertMomentToTicks(start);
                    data.WorkingHourEndTime = convertMomentToTicks(end);
                }
                data.WorkingDays = WorkingDays;
                data.WorkingHoursOption = workingHourOptions ? (workingHourOptions as WorkingHourOptions) : WorkingHourOptions.None;
            }
            return data;
        }
    }));


    return (
        <div>
            <Form.Item label="Schedule Type" name="ScheduleType">
                <Select placeholder="Select One" onChange={(e) => {
                        if (e === ScheduleRuleType.Minutely) {
                            taskForm.setFieldsValue({"ScheduleInterval":10});
                        }else{
                            taskForm.setFieldsValue({"ScheduleInterval":1});
                        }
                        setScheduleType(e as ScheduleRuleType);
                    }}>
                    <Select.Option value={ScheduleRuleType.OnlyOnce}>Only once</Select.Option>
                    <Select.Option value={ScheduleRuleType.Minutely}>By minute</Select.Option>
                    <Select.Option value={ScheduleRuleType.Hourly}>By hour</Select.Option>
                    <Select.Option value={ScheduleRuleType.Daily}>By day</Select.Option>
                    <Select.Option value={ScheduleRuleType.Weekly}>By week</Select.Option>
                    <Select.Option value={ScheduleRuleType.Monthly}>By month</Select.Option>
                </Select>
            </Form.Item>

            <Form.Item label="Start Time"
                name="ScheduleStartTime"
                rules={[
                    {
                        required: true,
                        message: 'Please select a Start Time!'
                    },
                    {
                        validator(rule, value) {
                            //console.log(value);
                            let currentTime = new Date().getTime() * 10000 + defaultTicks
                            //console.log(currentTime);
                            if (value && value < currentTime) {
                                return Promise.reject('The start time cannot be earlier than current time.');
                            } else {
                                return Promise.resolve();
                            }
                        }
                    }
                ]}>
                <DateTimePicker />
            </Form.Item>

            {(scheduleType === ScheduleRuleType.Minutely || scheduleType === ScheduleRuleType.Hourly || scheduleType === ScheduleRuleType.Daily || scheduleType === ScheduleRuleType.Weekly) &&
                <>
                    <Form.Item label="Recur every">
                        <Form.Item name="ScheduleInterval" initialValue={10} rules={[
                            {
                                validator(rule, value) {
                                    //console.log(currentTime);
                                    if (scheduleType === ScheduleRuleType.Minutely && value < 10) {
                                        return Promise.reject("'Recur every' cannot be less than 10.");
                                    } else if (value < 1) {
                                        return Promise.reject("'Recur every' cannot be less than 1.");
                                    }else{
                                        return Promise.resolve();
                                    }
                                }
                            }
                            ]} noStyle>
                             <Input style={{"width":"6.25rem"}} type="number" min={1}/>
                        </Form.Item>
                        <span style={{"marginLeft":".625rem"}}>
                            {
                                (scheduleType === ScheduleRuleType.Minutely && "Minutes") ||
                                (scheduleType === ScheduleRuleType.Hourly && "Hours") ||
                                (scheduleType === ScheduleRuleType.Daily && "Days") ||
                                (scheduleType === ScheduleRuleType.Weekly && "Weeks")
                            }
                        </span>
                    </Form.Item>
                </>
            }

            {scheduleType === ScheduleRuleType.Weekly &&
                <Form.Item name="DayOfWeekSpecifies" initialValue={[1, 2, 3, 4, 5]}>
                    <Checkbox.Group>
                        <Checkbox value={0}>Sunday</Checkbox>
                        <Checkbox value={1}>Monday</Checkbox>
                        <Checkbox value={2}>Tuesday</Checkbox>
                        <Checkbox value={3}>Wednesday</Checkbox>
                        <Checkbox value={4}>Thursday</Checkbox>
                        <Checkbox value={5}>Friday</Checkbox>
                        <Checkbox value={6}>Saturday</Checkbox>
                    </Checkbox.Group>
                </Form.Item>
            }

            {scheduleType === ScheduleRuleType.Monthly &&
                <Form.Item>
                    <Space>
                        <Form.Item name="ScheduleMonthlyRuleType" initialValue={monthlyRuleType} wrapperCol={{ span: 2 }}>
                            <Radio.Group onChange={(e) => setMonthlyRuleType(e.target.value)} >
                                <Row>
                                    <Col span="6">
                                        <Radio style={monthlyRuleRadioStyle} value={0}>On day</Radio>
                                    </Col>
                                    <Col span="18">
                                        <Space className="line-space">
                                            <Form.Item name="MR0_Day" initialValue={1}>
                                                <Select disabled={monthlyRuleType !== 0} style={subSelectionStyle} options={dayInMonth}>
                                                </Select>
                                            </Form.Item>
                                            <Form.Item>
                                                <span>of</span>
                                            </Form.Item>
                                            <Form.Item name="MR0_Month" initialValue={1}>
                                                <Select disabled={monthlyRuleType !== 0} style={subSelectionStyle} options={monthInYear}>
                                                </Select>
                                            </Form.Item>
                                        </Space>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col span="6">
                                        <Radio style={monthlyRuleRadioStyle} value={1}>On day</Radio>
                                    </Col>
                                    <Col span="18">
                                        <Space className="line-space" >
                                            <Form.Item name="MR1_Day" initialValue={1}>
                                                <Select disabled={monthlyRuleType !== 1} style={subSelectionStyle} options={dayInMonth} >
                                                </Select>
                                            </Form.Item>
                                            <Form.Item>
                                                <span style={{ width: '50px', display: 'inline-block' }}>of every</span>
                                            </Form.Item>
                                            <Form.Item name="MR1_Interval" initialValue={1}>
                                                <InputNumber min={1} disabled={monthlyRuleType !== 1}></InputNumber>
                                            </Form.Item>
                                            <Form.Item>
                                                <span>months</span>
                                            </Form.Item>
                                        </Space>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col span="6">
                                        <Radio style={monthlyRuleRadioStyle} value={2}>The</Radio>
                                    </Col>
                                    <Col span="18">
                                        <Space className="line-space" >
                                            <Form.Item name="MR2_Sequence" initialValue={1}>
                                                <Select disabled={monthlyRuleType !== 2} style={subSelectionStyle} options={sequenceInMonth}>
                                                </Select>
                                            </Form.Item>
                                            <Form.Item name="MR2_WeekDay" initialValue={1}>
                                                <Select disabled={monthlyRuleType !== 2} style={subSelectionStyle} options={weekDays}>
                                                </Select>
                                            </Form.Item>
                                            <Form.Item>
                                                <span style={{ width: '50px', display: 'inline-block' }}>of every</span>
                                            </Form.Item>

                                            <Form.Item name="MR2_Interval" initialValue={1}>
                                                <InputNumber min={1} disabled={monthlyRuleType !== 2}></InputNumber>
                                            </Form.Item>
                                            <Form.Item>
                                                <span>months</span>
                                            </Form.Item>

                                        </Space>
                                    </Col>
                                </Row>

                                <Row>
                                    <Col span="6">
                                        <Radio style={monthlyRuleRadioStyle} value={3}>The</Radio>
                                    </Col>
                                    <Col span="18">
                                        <Space className="line-space">
                                            <Form.Item name="MR3_Sequence" initialValue={1}>
                                                <Select disabled={monthlyRuleType !== 3} style={subSelectionStyle} options={sequenceInMonth}>
                                                </Select>
                                            </Form.Item>
                                            <Form.Item name="MR3_WeekDay" initialValue={1}>
                                                <Select disabled={monthlyRuleType !== 3} style={subSelectionStyle} options={weekDays}>
                                                </Select>
                                            </Form.Item>
                                            <Form.Item>
                                                <span>of</span>
                                            </Form.Item>
                                            <Form.Item name="MR3_Month" initialValue={1}>
                                                <Select disabled={monthlyRuleType !== 3} style={subSelectionStyle} options={monthInYear}>
                                                </Select>
                                            </Form.Item>
                                        </Space>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col span="6">
                                        <Radio style={monthlyRuleRadioStyle} value={4}>The</Radio>
                                    </Col>
                                    <Col span="18">
                                        <Space className="line-space" >
                                            <Form.Item name="MR4_Day" initialValue={1}>
                                                <Select disabled={monthlyRuleType !== 4} style={subSelectionStyle} options={dayLastMonth} >
                                                </Select>
                                            </Form.Item>
                                            <Form.Item>
                                                <span style={{ width: '121px', display: 'inline-block' }}>to last day of every</span>
                                            </Form.Item>
                                            <Form.Item name="MR4_Interval" initialValue={1}>
                                                <InputNumber min={1} disabled={monthlyRuleType !== 4}></InputNumber>
                                            </Form.Item>
                                            <Form.Item>
                                                <span>months</span>
                                            </Form.Item>
                                        </Space>
                                    </Col>
                                </Row>
                            </Radio.Group>
                        </Form.Item>
                    </Space>
                </Form.Item>
            }

            {(scheduleType === ScheduleRuleType.Minutely || scheduleType === ScheduleRuleType.Hourly) &&            
                <>
                    <Form.Item label="Working Hours">
                        <Checkbox checked={enableWorkingHours} onChange={(e) => setEnableWorkingHours(!enableWorkingHours)} >Enable Working Hours</Checkbox>
                        {enableWorkingHours &&
                            <>
                                <Form.Item >
                                    <Radio.Group onChange={(e) => setWorkingHourOptions(e.target.value)} defaultValue={workingHourOptions}>
                                        <Radio value={1}>Run working hours</Radio>
                                        <Radio value={2}>Run out working hours</Radio>
                                    </Radio.Group>
                                </Form.Item>
                                {workingHourOptions !== 0 &&
                                    <>
                                        <Form.Item name="WorkingHoursRange">
                                            <TimePicker.RangePicker></TimePicker.RangePicker>
                                        </Form.Item>

                                        <Form.Item name="WorkingDays" initialValue={[1, 2, 3, 4, 5]}>
                                            <Checkbox.Group>
                                                <Checkbox value={0}>Sunday</Checkbox>
                                                <Checkbox value={1}>Monday</Checkbox>
                                                <Checkbox value={2}>Tuesday</Checkbox>
                                                <Checkbox value={3}>Wednesday</Checkbox>
                                                <Checkbox value={4}>Thursday</Checkbox>
                                                <Checkbox value={5}>Friday</Checkbox>
                                                <Checkbox value={6}>Saturday</Checkbox>
                                            </Checkbox.Group>
                                        </Form.Item>
                                    </>
                                }
                            </>
                        }
                    </Form.Item>
                </>
            }
            <Form.Item label="Holidays">
                <Checkbox checked={props.enableHolidaySetting} onChange={(e) => props.setEnableHolidaySetting(!props.enableHolidaySetting)}>Skip Holidays</Checkbox>
                {props.enableHolidaySetting &&
                    <Form.Item name="HolidayProfileId" rules={[{ required: true, message: 'Please select a Holiday profile!' }]} style={{ marginTop: 10 }}>
                        <Select placeholder="Select One">
                            {holidayProfile?.map(item => (
                                <Select.Option key={item.ProfileId} value={item.ProfileId as string} label={item.OrganizationName}>
                                    {item.OrganizationName}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                }
            </Form.Item>
        </div>
    );
}

export default TaskScheduleRule;
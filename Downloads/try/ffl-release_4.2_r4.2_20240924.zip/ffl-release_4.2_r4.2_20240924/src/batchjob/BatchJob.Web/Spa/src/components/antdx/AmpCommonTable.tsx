import { Button, Table, TablePaginationConfig } from 'antd';
import Search from 'antd/lib/input/Search';
import { ColumnType } from 'antd/lib/table';
import { FilterValue, RowSelectionType, TableCurrentDataSource } from 'antd/lib/table/interface';
import React, { useEffect, useState } from 'react';
import { FilterCondition, PagerExpression } from '../../common/contracts/PagerContracts';
import { Guid } from 'guid-typescript';
import { convertTicksToFormatDate } from '../../utils/dateconvert';
import { DatetimeFormat } from '../../common/contracts/WebConstants';

export interface IAmpCommonTableProps<RecordType> {
  RowKey: string;
  Columns: ColumnType<any>[];
  PagerQuery: (pagerExp: PagerExpression) => Promise<{
    total: number | undefined;
    records: RecordType[] | undefined;
  }>;
  PagerConverter?: (
      pagerExp: PagerExpression,
      pagerConfg: TablePaginationConfig,
      filter?: Record<string, FilterValue>,
      sorter?: any
  ) => PagerExpression;

  /// change value to Force table refresh
  Refresh?: number;
  Type?: RowSelectionType;
  OnSelectedChanged?: (record: RecordType[]) => void;
  Buttons?: IAmpTableButton[];
  EnableSearch?: boolean;
  SearchKeys?: string[];
  DefaultSortKey?: string;
}

export interface IAmpTableButton {
  Text: string;
  OnClick: () => void;
  Icon: any;
  HasPermission: boolean;
  EnableMode: 'single' | 'multiple' | 'always';
  Primary?: boolean;
}
const AmpCommonTable = function <RecordType>(props: IAmpCommonTableProps<RecordType>) {
  const [pager, setPager] = useState<TablePaginationConfig>({ ...CommonPager });
  const [dataSource, setDataSource] = useState<any>([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [sortColumn, setSortColumn] = useState<any>({
    column: props.DefaultSortKey || 'ModifiedOn',
    isDesc: true
  });
  const [filters, setFilters] = useState<Array<FilterCondition>>([]);
  //const [selectRecords, setSelectedRecords] = useState<RecordType[]>([]);
  const [selectRecords, setSelectedRecords] = useState<string[]>([]);
  const [scrollY, setScrollY] = useState('');
  useEffect(() => {
    setScrollY(getTableScroll(undefined, undefined));
  }, []);
  useEffect(() => {
    setSelectedRecords([]);
    refreshTable();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.Refresh, searchText, pager]);

  const getTableScroll = (
      extraHeight: number | undefined,
      ref: { current: { getElementsByClassName: (arg0: string) => any[] } } | undefined
  ) => {
    if (typeof extraHeight == 'undefined') {
      extraHeight = 74;
    }
    let tHeader = null;
    if (ref && ref.current) {
      tHeader = ref.current.getElementsByClassName('ant-table-thead')[0];
    } else {
      tHeader = document.getElementsByClassName('ant-table-thead')[0];
    }
    let tHeaderBottom = 0;
    if (tHeader) {
      tHeaderBottom = tHeader.getBoundingClientRect().bottom;
    }
    // let height = document.body.clientHeight - tHeaderBottom - extraHeight
    const height = `calc(100vh - ${tHeaderBottom + extraHeight}px)`;
    if (ref && ref.current) {
      const placeholder = ref.current.getElementsByClassName('ant-table-placeholder')[0];
      if (placeholder) {
        placeholder.style.height = height;
        placeholder.style.display = 'flex';
        placeholder.style.alignItems = 'center';
        placeholder.style.justifyContent = 'center';
      }
    }
    return height;
  };
  const getPagerExpression = (
      pagination?: TablePaginationConfig,
      flt?: Record<string, FilterValue>,
      sorter?: any
  ): PagerExpression => {
    if (!pagination) pagination = pager;
    const exp: PagerExpression = {
      PageSize: pagination.pageSize,
      JumpPage: pagination.current,
      Filters: filters,
      SearchValue: searchText,
      SearcheKeys: props.SearchKeys,
      SortBy: sortColumn.column,
      IsDesc: sortColumn.isDesc
    };

    if (props.PagerConverter) {
      props.PagerConverter(exp, pager, flt, sorter);
    }
    return exp;
  };

  const refreshTable = async (pagerExp?: PagerExpression) => {
    if (!pagerExp) pagerExp = getPagerExpression();
    setLoading(true);
    try {
      const rst = await props.PagerQuery(pagerExp);
      setLoading(false);
      pager.total = rst.total;
      // setPager({ total: rst.total, ...pager });
      setDataSource(rst.records);
    } catch (err) {
      setLoading(false);
      console.error(err);
    }
  };

  const onChangeTable = (
      pagination?: TablePaginationConfig,
      filters?: Record<string, FilterValue>,
      sorter?: any,
      extra?: TableCurrentDataSource<RecordType>
  ) => {
    // const exp = getPagerExpression(pagination, filters, sorter);
    // refreshTable(exp)
    switch (extra!.action) {
      case 'paginate':
        break;
      case 'filter':
        const flt = [];
        for (const f in filters) {
          flt.push({ ColumnName: f, ColumnValues: filters[f] });
        }
        setFilters(flt as any);
        break;
      case 'sort':
        setSortColumn({
          column: sorter.field,
          isDesc: sorter.order !== 'ascend'
        });
        break;
    }
    const pager: any = { ...pagination };
    pager.showTotal = showTotal;
    setPager({ ...pager });
  };

  const getRowSelection = () => {
    const rowSelection = {
      selectedRowKeys: selectRecords,
      type: props.Type,
      onChange: (selectedRowKeys: string[], selectedRows: RecordType[]) => {
        setSelectedRecords(selectedRowKeys);
        props.OnSelectedChanged!(selectedRows);
      },
      getCheckboxProps: (record: any) => ({
        disabled: record.disabled
      })
    };

    return props.Type ? rowSelection : null;
  };

  const search = (search: string) => {
    const pagerExp = { ...pager };
    pagerExp.current = 1;
    setPager(pagerExp);
    setSearchText(search);
  };

  const disableButton = (btn: IAmpTableButton): boolean => {
    const enabled =
        btn.EnableMode === 'always' ||
        (btn.EnableMode === 'single' && selectRecords.length === 1) ||
        (btn.EnableMode === 'multiple' && selectRecords.length > 0);
    return !(btn.HasPermission && enabled);
  };

  return (
      <>
        {(props.EnableSearch || props.Buttons) && (
            <div style={{ marginBottom: '1rem', width: '100%' }}>
              {props.Buttons?.map((btn) => (
                  <Button
                      key={Guid.create().toString()}
                      type={btn.Primary ? 'primary' : 'text'}
                      onClick={btn.OnClick}
                      disabled={disableButton(btn)}
                  >
                    {btn.Icon}
                    {btn.Text}
                  </Button>
              ))}
              {props.EnableSearch && (
                  <Search
                      placeholder="input search text"
                      onSearch={search}
                      style={{ marginBottom: '1rem', width: 200, float: 'right' }}
                      allowClear
                  />
              )}
            </div>
        )}

        <Table
            rowKey={props.RowKey}
            rowSelection={getRowSelection() as any}
            onChange={onChangeTable as any}
            columns={props.Columns}
            dataSource={dataSource}
            pagination={pager}
            showSorterTooltip={false}
            loading={loading}
            scroll={{ y: scrollY }}
            summary={(pageData) => (
                <>
                  {selectRecords.length > 0 && (
                      <Table.Summary fixed="bottom">
                        <Table.Summary.Row>
                          <Table.Summary.Cell index={2} colSpan={4}>
                            Select item {selectRecords.length} of {pageData.length}
                          </Table.Summary.Cell>
                        </Table.Summary.Row>
                      </Table.Summary>
                  )}
                </>
            )}
            sticky
        ></Table>
      </>
  );
};

const showTotal = (total: number) => {
  return `Total ${total} items`;
};

const CommonPager: TablePaginationConfig = {
  current: 1,
  pageSize: 10,
  pageSizeOptions: ['10', '20', ' 50', '100'],
  showQuickJumper: true,
  showSizeChanger: true,
  showTotal: showTotal
};

const DatetimeColumnTemplate = (text: number) => {
  return <span>{convertTicksToFormatDate(text, DatetimeFormat)}</span>;
};

export { DatetimeColumnTemplate };
export default AmpCommonTable;

export const PermissionConstants = {
    ObjectCode: 102001,
    Read: 1,
    Create: 2,
    Update: 4,
    Delete: 8
};



export const formartLevel = (result: any) => {
    
    let SummaryLevel = [
            result.EmailProfile?.SummaryLevel & 1,
            result.EmailProfile?.SummaryLevel & 2,
            result.EmailProfile?.SummaryLevel & 4
    ]
        
    let  DetailLevel = [
            result.EmailProfile?.DetailLevel & 1,
            result.EmailProfile?.DetailLevel & 2,
            result.EmailProfile?.DetailLevel & 4
    ]
        
    let  LogLevel = [
        result.EmailProfile?.LogLevel & 1,
        result.EmailProfile?.LogLevel & 2,
        result.EmailProfile?.LogLevel & 4
    ]
    
    let SMSSummaryLevel = [
            result.SmsProfile?.SummaryLevel & 1,
            result.SmsProfile?.SummaryLevel & 2,
            result.SmsProfile?.SummaryLevel & 4
    ]
    result.Format = result.EmailProfile?.Format
    result.SummaryLevel = SummaryLevel
    result.DetailLevel = DetailLevel
    result.LogLevel = LogLevel
    result.SMSSummaryLevel = SMSSummaryLevel
    return result
}

 
 
export const ReportTypeMap = new Map<number, string>([
    [0, "Summary Recipients"],
    [1, "Details Recipients"],
])

export enum ProtocolType{
    Exchange = 4,
    SMTP = 5,
    Web = 6,
    Dynamics = 7
}
export class ConnectionAdapterItem {
    Id?:string;
    Name?:string;
}
export class NotificationSetting {
    Id?:string;
    DisplayName?:string;
    Description?:string;
    IsDefault?:boolean;
    ProtocolType?:ProtocolType;
    ConnectionId?:string;
    CreatedOn?: number;
    CreatedBy?: string;
    ModifiedOn?: number;
    ModifiedBy?: string;
}
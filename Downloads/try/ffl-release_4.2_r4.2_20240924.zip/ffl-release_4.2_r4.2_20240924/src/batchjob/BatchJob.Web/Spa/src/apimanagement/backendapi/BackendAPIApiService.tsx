import { PagerResult } from '../../common/contracts/PagerContracts';
import apiservice from '../../utils/fetchutil';
import {IGetSelectResult, FromType } from './BackendAPIContracts';
import {BackendDetailsDto,VersionDto,BackendDto,ParameterTypeDto,MethodDto} from '../../common/contracts/ModelContracts';

const serve = apiservice();

export const PagerQueryBackend = (params: any): Promise<PagerResult<BackendDetailsDto>> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/PagerQueryBackend", params).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const DeleteBackend = (Id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteBackend", { "id": Id }).then((result) => {
            res(result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateBackend = (detail: BackendDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateBackend", { "dto": detail }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetVersionById = (Id: string): Promise<VersionDto> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetVersionById", { "id": Id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetSelects = (requestList: string[]): Promise<IGetSelectResult> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetSelects", { "dto": requestList }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateVersion = (detail: VersionDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateVersion", { "dto": detail }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const DeleteVersion = (Id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteVersion", { "id": Id }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetParameterType = (Id: string): Promise<ParameterTypeDto[]> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetParameterType", { "dto": { "BackendId": Id } }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const DeleteParameterType = (Ids: string[]): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteParameterType", { "dto": Ids }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateParameterType = (detail: ParameterTypeDto): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateParameterType", { "dto": detail }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateMethod = (params: any): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/CreateMethod", { "dto": params }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const PagerMethodByVersionId = (params: any): Promise<PagerResult<MethodDto>> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/PagerMethodByVersionId", params).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetParameterByBackendID = (Id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/GetSelectsWithVal", {
            "dto": {
                "Type": "Parameter",
                "Filter": [{
                    "ColumnName": "BackendID",
                    "ColumnValue": Id
                }]
            }
        }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const DeleteMethods = (Ids: string[], fromType: FromType): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/IAPIManagementService/DeleteMethods", { "dto": { "ids": Ids, "fromType": fromType } }).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}









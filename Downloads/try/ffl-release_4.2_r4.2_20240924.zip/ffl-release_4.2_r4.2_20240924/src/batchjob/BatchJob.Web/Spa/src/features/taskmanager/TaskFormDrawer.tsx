import React, { useEffect, useState, useRef } from 'react';
import { Button, Input, Radio, Checkbox, Select, Form, Drawer } from 'antd';
import { convertDateToTicks } from '../../utils/dateconvert';
import { TaskDto, ScheduleActionDto, ScheduleDto, ScheduleRuleDto, ActionElementDto, TaskActionSettingDto, ServiceResultType, ActionParameterSettingDto } from './TaskManagerContract';
import TaskApiService from './TaskManagerApiService';
import TaskRepository from './TaskRepository';
import TaskScheduleRule from './TaskScheduleRule';
import apiservice from '../../utils/fetchutil';

interface ITaskFormDrawerProps {
    task: TaskDto;
    visible: boolean;
    onClose: () => void;
    onFinished: (task: TaskDto, type?: ServiceResultType) => void;
}
const TaskFormDrawer = (props: ITaskFormDrawerProps) => {
    let initStartTime = convertDateToTicks(new Date(Date.now() + 5 * 60 * 1000));
    const ruleRef = useRef<any>();
    const [actionProfileLabel, setActionProfileLabel] = useState<string>("Action Profile");
    const [enableNotification, setEnableNotification] = useState(false);
    const [enableHolidaySetting, setEnableHolidaySetting] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [taskFrom] = Form.useForm();
    const actionSettings = TaskRepository.getInstance().ActionSettings;
    const [taskType, setTaskType] = useState<number>(0);
    const [scheduleRule, setScheduleRule] = useState<ScheduleRuleDto>(new ScheduleRuleDto());
    const notificationProfiles = TaskRepository.getInstance().NotificationProfiles;
    const queueNames = TaskRepository.getInstance().QueueNames;

    const [firstParamSource, setFirstParamSource] = useState<Array<ActionElementDto>>();
    const [action, setAction] = useState<TaskActionSettingDto>({});

    useEffect(() => {
        if (action && action.ActionParameterSettings && action.ActionParameterSettings.length > 0) {
            const firstParam = action.ActionParameterSettings[0];
            if (firstParam && firstParam.ItemsSourceLink && firstParam.ItemsSourceLink.length > 0) {
                loadParamItemsource(firstParam.ItemsSourceLink!,undefined,firstParam);
                setActionProfileLabel(firstParam.Label!);
            } else {
                setFirstParamSource(undefined);
            }
        }else{
            setFirstParamSource(undefined);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [action]);

    const loadParamItemsource = (url: string, id?: string,param?:ActionParameterSettingDto) => {
        apiservice().post(url, param?.Data||{}).then(r => {
            switch (param?.Key){
                case "transfer argument":
                    setFirstParamSource(r.ElementDtos);
                    if (id) {
                        setActionProfileLabel(param.Label!);
                        taskFrom.setFieldsValue({ ActionProfileId: id! });
                    }
                    break;
                case "send report to":
                    let paramSource = r.Result.map((e:any)=>({'Id':e.Id,'Name':e.Name}));
                    setActionProfileLabel(param.Label!)
                    setFirstParamSource(paramSource);
                    if (id) {
                        taskFrom.setFieldsValue({ ActionProfileId: id! });
                    }
                    break;
                case "Replicator Pipline Profiles":
                    let piplineSource = r.MasterDtos.map((e:any)=>({'Id':e.Id,'Name':e.Name}));
                    setActionProfileLabel(param.Label!)
                    setFirstParamSource(piplineSource);
                    if (id) {
                        taskFrom.setFieldsValue({ ActionProfileId: id! });
                    }
                    break;
                case "Replicator Plan Profiles":
                    let planSource = r.MasterDtos.map((e:any)=>({'Id':e.Id,'Name':e.Name}));
                    setActionProfileLabel(param.Label!)
                    setFirstParamSource(planSource);
                    if (id) {
                        taskFrom.setFieldsValue({ ActionProfileId: id! });
                    }
            }
        });
    }

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };
    const onFinish = (values: any) => {
        //console.log('Success:', values);
        var dto = new TaskDto();
        dto.JobAction = new ScheduleActionDto();
        dto.Schedule = new ScheduleDto();
        dto.Schedule.ScheduleRule = new ScheduleRuleDto();
        dto.Id = props.task.Id;
        dto.State = props.task.State;
        dto.Tag = values.Tag;

        dto.Name = values.Name;
        dto.Description = values.Description;
        if (enableNotification) {
            dto.NotificationProfileId = values.NotificationProfileId;
            if(values.NotificationType.length > 0 ){
                let notificationType = getAllChecked(values.NotificationType);
                dto.NotificationType = notificationType;
            }else{
                dto.NotificationType = 0;
            }
        }
        dto.JobAction.HandlerId = values.ActionId;
        dto.ActionDisplayName = actionSettings?.find(a => a.Id === values.ActionId)!.DisplayName;
        dto.Endpoints = values.Endpoints;

        if (values.ActionProfileId) {
            let profileName = firstParamSource?.find(a => a.Id === values.ActionProfileId)!.Name;
            dto.JobAction.PartsAndValues = [values.ActionProfileId, profileName];
        }
        dto.Type = values.Type;
        //var selectedSetting = actionSettings?.find(a => a.Id === dto.JobAction?.HandlerId);
        //dto.JobAction.
        if (values.Type === 0) {
            //Schedule Type
            dto.Schedule.ScheduleRule.RuleType = values.ScheduleType;
            //Start Time
            dto.Schedule.StartTime = values.ScheduleStartTime;
            let scheduleRule = ruleRef.current.getFormData();
            dto.Schedule.ScheduleRule = scheduleRule;
            // enable Holidays
            if (enableHolidaySetting) {
                dto.Schedule.HolidayProfileId = values.HolidayProfileId;
            }
        }
        //time zone
        let date = new Date();
        dto.Schedule.TimeZone = -(date.getTimezoneOffset() / 60);
        console.log(dto.Schedule.TimeZone);
        if (isEdit) {
            TaskApiService.getInstance().UpdateTask(dto, (result) => { props.onFinished(dto, result.Type!) });
        } else {
            TaskApiService.getInstance().CreateTask(dto, (result) => { props.onFinished(dto, result.Type!) });
        }
    };



    const setupForm = (dto: TaskDto) => {
        taskFrom.resetFields();
        setIsEdit(dto.Id !== undefined);

        setTaskType(dto.Type);
        taskFrom.setFieldsValue({ Type: dto.Type })
        if (dto.Id) {
            setEnableNotification(dto.NotificationProfileId !== null);
            taskFrom.setFieldsValue({
                Name: dto.Name,
                Tag:dto.Tag,
                Description: dto.Description,
                ActionId: dto.JobAction?.HandlerId,
                HolidayProfileId: dto.Schedule?.HolidayProfileId,
                ScheduleStartTime: dto.Schedule?.StartTime ? dto.Schedule.StartTime : initStartTime,
                Endpoints: dto.Endpoints
            });
            //OnActionChanged(dto.JobAction?.HandlerId);
            //设置Status
            let notificationType = dto.NotificationType;
            if (notificationType) {
                let notificationTypeArr = restChecked(notificationType);
                taskFrom.setFieldsValue({
                    NotificationProfileId: dto.NotificationProfileId,
                    NotificationType: notificationTypeArr
                });
            }
            if (dto.Schedule?.HolidayProfileId) {
                setEnableHolidaySetting(true);
            }
            //设置公共数据
            if (dto?.Schedule?.ScheduleRule) {
                setScheduleRule(dto?.Schedule?.ScheduleRule as ScheduleRuleDto);
            }
            if (dto.JobAction?.PartsAndValues && dto.JobAction?.PartsAndValues.length > 0) {
                const setting = actionSettings?.find(a => a.Id === dto.JobAction?.HandlerId);
                loadParamItemsource(setting?.ActionParameterSettings![0].ItemsSourceLink!, dto.JobAction?.PartsAndValues[0],setting?.ActionParameterSettings![0])
            }
        } else {
            defaultValue();
        }
    };

    const restChecked = (dataBaseValue: number) => {
        let defaultValue = 2;
        let value = 0;
        let result: any = [];
        for (let i = 0; value <= dataBaseValue; i++) {
            value = defaultValue << i;
            if (value <= dataBaseValue && (dataBaseValue & value) === value) {
                result.push(value);
            }
        }
        return result;
    }

    const getAllChecked = (list: any) => {
        return list?.reduce((prev: any, cur: any, item: any, arr: any) => {
            return prev | cur;
        });
    };

    const defaultValue = () => {
        let rule = new ScheduleRuleDto();
        rule.RuleType = 0;
        setScheduleRule(rule);
        setEnableHolidaySetting(false);
        setAction({});
        setFirstParamSource(undefined);
        taskFrom.setFieldsValue({
            ScheduleStartTime: initStartTime,
        });
    };

    const OnActionChanged = (value: any) => {
        const act = actionSettings?.find(a => a.Id === value);
        setAction(act!);
        taskFrom.setFieldsValue({ ActionProfileId: undefined });
    }

    useEffect(() => {
        setupForm(props.task)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.task]);
    //解决二次打开抽屉，控件记录上次加载项目
    useEffect(() => {
        if (props.visible === false) {
            defaultValue();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.visible]);

    function onChange(value:any) {
        console.log(`selected ${value}`);
      }
      
      function onSearch(val:any) {
        console.log('search:', val);
      }
    return (
        <Drawer
            forceRender
            visible={props.visible}
            width={720}
            onClose={(e) => props.onClose()}
            title={isEdit ? "Edit task" : "Create a new task"}
            footer={
                <div style={{ textAlign: 'right', }}>
                    <Button type="primary" style={{ marginRight: 8 }} onClick={() => taskFrom.submit()}>Save</Button>
                    <Button onClick={props.onClose} >Cancel</Button>
                </div>
            }>
            <Form layout="vertical" form={taskFrom} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '16px' }} >
                <Form.Item label="Task Title" name="Name" rules={[{ required: true, message: 'Please input your Task Title!' }]}>
                    <Input />
                </Form.Item>

                <Form.Item label="Description" name="Description">
                    <Input.TextArea />
                </Form.Item>

                <Form.Item >
                    <Checkbox checked={enableNotification} onChange={(e) => setEnableNotification(!enableNotification)} >Enable E-mail Notification</Checkbox>
                </Form.Item>
                {enableNotification &&
                    (<>
                        <Form.Item label="Notification Profile" name="NotificationProfileId" rules={[{ required: true, message: 'Please select a notification profile!' }]}>
                            <Select placeholder="Select One">
                                {notificationProfiles?.map(item => (
                                    <Select.Option key={item.Id} value={item.Id as string} label={item.Name}>
                                        {item.Name}
                                    </Select.Option>
                                ))}
                                {/* <Select.Option value='NotificationProfileId'>Comming soon...</Select.Option> */}
                            </Select>
                        </Form.Item>
                        <Form.Item label="Status" name="NotificationType" rules={[{ required: true, message: 'Please select at least one Status' }]}>
                            <Checkbox.Group>
                                <Checkbox value={2}>Finished</Checkbox>
                                <Checkbox value={4}>Exception</Checkbox>
                                <Checkbox value={8}>Failed</Checkbox>
                            </Checkbox.Group>
                        </Form.Item>
                    </>)}


                <Form.Item label="Action" name="ActionId" rules={[{ required: true, message: 'Please select a Action!' }]}>
                    <Select allowClear placeholder="Select One" onChange={OnActionChanged}>
                        {actionSettings?.map(item => (
                            <Select.Option key={item.Id} value={item.Id as string} label={item.DisplayName}>
                                {item.DisplayName}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                {firstParamSource &&
                    <Form.Item label={actionProfileLabel} name="ActionProfileId" rules={[{ required: true, message: 'Please select a Action!' }]}>
                        <Select placeholder="Select One"  
                                showSearch
                                filterOption={(input:any, option:any) =>
                                    option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }>
                            {firstParamSource?.map(item => (
                                <Select.Option key={item.Id} 
                                    value={item.Id as string} 
                                    label={item.Name}>
                                    {item.Name}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                }

                <Form.Item label="Run on executors" name="Endpoints" rules={[{ required: true, message: 'Please select a executors!' }]}>
                    <Select placeholder="Select One">
                        {queueNames?.map(item => (
                            <Select.Option key={item} value={item as string} label={item}>
                                {item}
                            </Select.Option>
                        ))}
                    </Select>
                </Form.Item>

                <Form.Item label="Tag" name="Tag">
                    <Input />
                </Form.Item>

                <Form.Item label="Run the Task" name="Type" >
                    <Radio.Group onChange={(e) => setTaskType(e.target.value)}>
                        <Radio value={0}>On Schedule</Radio>
                        <Radio value={1}>Manually</Radio>
                    </Radio.Group>
                </Form.Item>

                {taskType === 0 &&
                    <>
                        <TaskScheduleRule
                            scheduleRule={scheduleRule}
                            taskForm={taskFrom}
                            ruleRef={ruleRef}
                            enableHolidaySetting={enableHolidaySetting}
                            setEnableHolidaySetting={setEnableHolidaySetting}
                        />
                    </>
                }
            </Form>
        </Drawer>
    );
};


export default TaskFormDrawer;
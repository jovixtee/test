import { convertTicksToMoment } from '../../utils/dateconvert';
import React from 'react';
import { TaskGroupDto,TaskManagerServiceResult } from './TaskManagerContract';
import { DatetimeFormat } from '../../common/contracts/WebConstants';
import TaskRepository from './TaskRepository';
import TaskApiService from './TaskManagerApiService';

import { convertTicksToFormatDate } from '../../utils/dateconvert';
import { ScheduleRuleType, ScheduleSequence, WeekDay, WorkingHourOptions, ScheduleMonth } from './TaskManagerContract';

export const NextRunTimeTemplate = function (ticks: any, record: any): any {
    return (<label>{ticks === 0 || ticks > 662380416000000000 ? "NA" : convertTicksToMoment(ticks as number).format(DatetimeFormat)}</label>);

};


export const GetTaskGroupProfileReader = function (dataSource: TaskGroupDto): Promise<any> {
    const jobActions = TaskRepository.getInstance().ActionSettings;
    let actions = new Set();
    jobActions?.forEach(j => {
        dataSource.Steps?.forEach(s => {
            if (j?.Id === s.Task?.JobAction?.HandlerId) {
                actions.add(j.Id!);
                return false;
            }
        })
    })
    let sourceTask = sourceDataTask(Array.from(actions));
    return sourceTask.then(task=>{
        let profile:any = [];
        let item = { "type": "text", "key": "Group Name", "value": dataSource.Name };
        profile.push(item);
        item = { "type": "text", "key": "Description", "value": dataSource.Description };
        profile.push(item);
        let options =jobActions?.map(e=>{
            return { label: e.DisplayName,value:e.Id }
        });
        let checkItem = { "type": "checkbox", "key": "Actions", "value": Array.from(actions), "data": options };
        profile.push(checkItem);
        let targetData:any[] = [];
        dataSource.Steps?.forEach(s => {
            targetData.push(s.Task?.Id || '');
        });
        let tasks:any[] = [];
        task.forEach((e:any)=>tasks.push.apply(tasks, e));
        let taskItem = { "type": "checkbox", "key": "Task", "value": targetData, "data":tasks };
        profile.push(taskItem);
       
        let radioOptions = [
            { label: 'On Schedule', value: 0 },
            { label: 'Manually', value: 1 },
        ];
        let radioItem = { "type": "radio", "key": "Run the Task", "value": dataSource?.Type, "data": radioOptions };
        profile.push(radioItem);

        let scheduleRule = dataSource?.Schedule?.ScheduleRule;
            if (dataSource?.Type === 0) {
                item = { "type": "text", "key": "Schedule Type", "value": ScheduleRuleType[scheduleRule?.RuleType!] };
                profile.push(item);
                item = { "type": "text", "key": "Start Time", "value": convertTicksToFormatDate(dataSource?.Schedule?.StartTime!, DatetimeFormat) };
                profile.push(item);
            }
            if(dataSource?.Type === 1){
                return profile;
            }
            if ( scheduleRule?.RuleType === ScheduleRuleType.Minutely
                || scheduleRule?.RuleType === ScheduleRuleType.Hourly
                || scheduleRule?.RuleType === ScheduleRuleType.Daily
                || scheduleRule?.RuleType === ScheduleRuleType.Weekly) {
                let suffix = "";
                if (scheduleRule?.RuleType === ScheduleRuleType.Minutely) {
                    suffix = "Minutes";
                } else if (scheduleRule?.RuleType === ScheduleRuleType.Hourly) {
                    suffix = "Hours";
                } else if (scheduleRule?.RuleType === ScheduleRuleType.Daily) {
                    suffix = "Days";
                } else if (scheduleRule?.RuleType === ScheduleRuleType.Weekly) {
                    suffix = "Weeks";
                }
                item = { "type": "text", "key": "Recur every", "value": scheduleRule?.Interval + " " + suffix };
                profile.push(item);
                if (scheduleRule?.RuleType === ScheduleRuleType.Weekly) {
                    const options = [
                        { label: 'Sunday', value: 0 },
                        { label: 'Monday', value: 1 },
                        { label: 'Tuesday', value: 2 },
                        { label: 'Wednesday', value: 3 },
                        { label: 'Thursday', value: 4 },
                        { label: 'Friday', value: 5 },
                        { label: 'Saturday', value: 6 },
                    ];
                    let checkItem = { "type": "checkbox", "key": "", "value": scheduleRule?.DayOfWeekSpecifies, "data": options };
                    profile.push(checkItem);
                }
            }
           
            if (scheduleRule?.RuleType === ScheduleRuleType.Monthly) {
                let startTime = "";
                if (scheduleRule?.MonthlySubType === 0) {
                    startTime = "On day " + scheduleRule?.DayOfMonth + " of " + ScheduleMonth[scheduleRule?.SpecifyMonth!]
                } else if (scheduleRule?.MonthlySubType === 1) {
                    startTime = "On day " + scheduleRule?.DayOfMonth + " of every " + scheduleRule?.Interval + " months";
                } else if (scheduleRule?.MonthlySubType === 2) {
                    startTime = "The " + ScheduleSequence[scheduleRule?.WeekSequence!] + " " + WeekDay[scheduleRule?.DayOfWeekSpecifies![0]] + " of every " + scheduleRule?.Interval + " months";
                } else if (scheduleRule?.MonthlySubType === 3) {
                    startTime = "The " + ScheduleSequence[scheduleRule?.WeekSequence!] + " " + WeekDay[scheduleRule?.DayOfWeekSpecifies![0]] + " of " + ScheduleMonth[scheduleRule?.SpecifyMonth!]
                }
                item = { "type": "text", "key": "", "value": startTime };
                profile.push(item);
            }
            if (scheduleRule!.WorkingHoursOption as WorkingHourOptions && scheduleRule!.WorkingHoursOption !== WorkingHourOptions.None) {
                const options = [
                    { label: 'Run working hoursOn Schedule', value: 1 },
                    { label: 'Run out working hours', value: 2 },
                ];
                let radioItem = { "type": "radio", "key": "Working Hours", "value": scheduleRule?.WorkingHoursOption, "data": options };
                profile.push(radioItem);
                let start = convertTicksToFormatDate(scheduleRule?.WorkingHourStartTime!, 'HH:mm:ss');
                let end = convertTicksToFormatDate(scheduleRule?.WorkingHourEndTime!, 'HH:mm:ss')
                item = { "type": "text", "key": "", "value": start + "-" + end };
                profile.push(item);
                const checkOptions = [
                    { label: 'Sunday', value: 0 },
                    { label: 'Monday', value: 1 },
                    { label: 'Tuesday', value: 2 },
                    { label: 'Wednesday', value: 3 },
                    { label: 'Thursday', value: 4 },
                    { label: 'Friday', value: 5 },
                    { label: 'Saturday', value: 6 },
                ];
                let checkItem = { "type": "checkbox", "key": "", "value": scheduleRule?.WorkingDays, "data": checkOptions };
                profile.push(checkItem);
            }
            if(dataSource?.Schedule?.HolidayProfileId){
                const holidayProfile = TaskRepository.getInstance().HolidayProfile;
                let holiday = holidayProfile?.find(e => e.ProfileId === dataSource?.Schedule?.HolidayProfileId);
                item = { "type": "text", "key": "Skip Holidays", "value": holiday?.OrganizationName };
                profile.push(item);
            }
        return profile;
    })

};

const sourceDataTask = (value: any) => {
    let tas = [];
    for (let i = 0; i < value.length; i++) {
        // eslint-disable-next-line no-loop-func
        tas.push(new Promise((a, b) => {
            TaskApiService.getInstance().QueryTasksByHandlerId(value[i], (result?: TaskManagerServiceResult) => {
                let data = result?.Tasks?.map((data, index) => {
                    return {label: data.Name, value: data.Id };
                })
                a(data);
            })
        }));
    }
    return Promise.all(tas) 
};
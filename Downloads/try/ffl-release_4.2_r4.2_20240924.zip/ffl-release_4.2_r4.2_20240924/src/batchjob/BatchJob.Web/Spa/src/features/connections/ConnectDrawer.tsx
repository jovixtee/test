import React, { FC, useState, useEffect, useRef } from "react";
import {
  Drawer,
  Form,
  Button,
  Input,
  Select,
  Checkbox,
  Upload,
  message,
} from "antd";
import apiservice from "../../utils/fetchutil";
import {
  AdapterType,
  AuthenticationType,
  SQLAuthenticationType,
  ConnectionStatus,
  ConnectionAdapterDto,
  ConnectPermissionConstants,
  AuthType,
  Dynamics365AuthType,
  Param,
  WebDto,
  SMTPDto,
  ExchangeDto,
  ExchangeVersion,
  AdapterTypeMap,
  DataverseAuthType
} from "./ConnectionContract";
import { hasPermission } from "../../utils/permissionutil";
import UINotrification from "../../common/UINotrification";
import ParamsEditTable from "./ParamsEditTable";
import { UploadFile } from "antd/lib/upload/interface";
import { UploadOutlined } from "@ant-design/icons";

const { Option } = Select;
const { TextArea } = Input;

interface formState {
  formData: ConnectionAdapterDto;
  visible: boolean;
  closeDrawerEvent: () => void;
}

const DrawerForm: FC<formState> = (props) => {
  const [enableUseServiceBridge, setEnableUseServiceBridge] = useState(false);
  const [onBehalf, setOnBehalf] = useState(false);
  const [useAws, setUserAws] = useState(true);
  const [anonymousSetting, setAnonymousSetting] = useState(true);
  const [uploadFile, setUploadFile] = useState<any>();
  const [fileList, setFileList] = useState<any[]>([]);
  const [authenticationType, setAuthenticationType] =
    useState<AuthenticationType>();
  const [form] = Form.useForm();
  const formRef = React.createRef<any>();
  const [adapterType, setAdapterType] = useState<AdapterType>();
  const [param, setParam] = useState<Param[]>([]);
  const [flags, setFlags] = useState<boolean>(true);
  const [checkName, setCheckName] = useState<boolean>(true);
  const [loadings, setLoadings] = useState<boolean>(false);
  const [saveLoadings, setSaveLoadings] = useState<boolean>(false);
  const apiService = apiservice();
  const paramRef = useRef<any>();

  useEffect(() => {
    if (props.formData && props.visible ===true) {
      initialValue(props.formData);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.formData, props.visible]);

  const initialValue = (dataSource: ConnectionAdapterDto) => {
    let data: any = {
      connectionName: dataSource.AdapterName,
      description: dataSource.Description,
      connectionType: dataSource.AdapterType,
    };

    if (
      dataSource.AdapterType === AdapterType.SQLServer &&
      dataSource.SQLServerAdapterSetting
    ) {
      data["SQLAuthenticationType"] =
        dataSource.SQLServerAdapterSetting.AuthenticationType;
      data["serverName"] = dataSource.SQLServerAdapterSetting.ServerName;
      data["DatabaseName"] = dataSource.SQLServerAdapterSetting.DataBaseName;
      data["UserName"] = dataSource.SQLServerAdapterSetting.UserName;
      //data["Password"] = dataSource.SQLServerAdapterSetting.Password;
      data["SecretId"] = dataSource.SQLServerAdapterSetting.SecretId;
      data["UseAws"] = dataSource.SQLServerAdapterSetting.UseAws;
      setUserAws(dataSource.SQLServerAdapterSetting.UseAws!);
    }
    if (
      dataSource.AdapterType === AdapterType.PostgreSQL &&
      dataSource.PGSQLAdapterSetting
    ) {
      data["serverName"] = dataSource.PGSQLAdapterSetting.ServerName;
      data["DatabaseName"] = dataSource.PGSQLAdapterSetting.DataBaseName;
      data["UserName"] = dataSource.PGSQLAdapterSetting.UserName;
      //data["Password"] = dataSource.SQLServerAdapterSetting.Password;
      data["SecretId"] = dataSource.PGSQLAdapterSetting.SecretId;
      data["UseAws"] = dataSource.PGSQLAdapterSetting.UseAws;
      setUserAws(dataSource.PGSQLAdapterSetting.UseAws!);
    }
    if (
      dataSource.AdapterType === AdapterType.Dataverse &&
      dataSource.DataverseAdapterSetting
    ) {
      data["DataverseAuthType"] =
        dataSource.DataverseAdapterSetting.AuthType;
      data["Url"] = dataSource.DataverseAdapterSetting.Url;
      data["ClientId"] = dataSource.DataverseAdapterSetting.ClientId;
      //data["ClientSecret"] = dataSource.DataverseAdapterSetting.ClientSecret;
      data["SecretId"] = dataSource.DataverseAdapterSetting.SecretId;
      data["UseAws"] = dataSource.DataverseAdapterSetting.UseAws;
      setUserAws(dataSource.DataverseAdapterSetting.UseAws!);
    }
    if (
      dataSource.AdapterType === AdapterType.SFTP &&
      dataSource.SFTPAdapterSetting
    ) {
      data["SFTPAuthenticationType"] =
        dataSource.SFTPAdapterSetting.AuthenticationType;
      data["Host"] = dataSource.SFTPAdapterSetting.Host;
      data["Port"] = dataSource.SFTPAdapterSetting.Port;
      data["UserName"] = dataSource.SFTPAdapterSetting.UserName;
      //data["Password"] = dataSource.SFTPAdapterSetting.Password;
      data["Passphrase"] = dataSource.SFTPAdapterSetting.Passphrase;
      //data["FileName"] = dataSource.SFTPAdapterSetting.FileName;
      data["PrivateKey"] = dataSource.SFTPAdapterSetting.PrivateKey;
      data["UseAws"] = dataSource.SFTPAdapterSetting.UseAws;
      data["SecretId"] = dataSource.SFTPAdapterSetting.SecretId;
      setUserAws(dataSource.SFTPAdapterSetting.UseAws!);
      setAdapterType(dataSource.AdapterType);
      setAuthenticationType(dataSource.SFTPAdapterSetting.AuthenticationType);
      if (dataSource.SFTPAdapterSetting.FileName) {
        setFileList([{ name: dataSource.SFTPAdapterSetting.FileName }]);
      }
    }
    if (dataSource.AdapterType === AdapterType.Dynamics && dataSource.CRMAdapterSetting ) {
      data["CRMAuthType"] = dataSource.CRMAdapterSetting.AuthType;
      data["Url"] = dataSource.CRMAdapterSetting.Url;
      data["Domain"] = dataSource.CRMAdapterSetting.Domain;
      data["UserName"] = dataSource.CRMAdapterSetting.UserName;
      //data["Password"] = dataSource.CRMAdapterSetting.Password;
      let useServiceBridge = dataSource.CRMAdapterSetting.UseServiceBridge;
      data["SecretId"] = dataSource.CRMAdapterSetting.SecretId;
      data["UseAws"] = dataSource.CRMAdapterSetting.UseAws;
      setUserAws(dataSource.CRMAdapterSetting.UseAws!);
      data["SecretId"] = dataSource.CRMAdapterSetting.SecretId;
      if (useServiceBridge) {
        data["BridgeAddress"] = dataSource.CRMAdapterSetting.BridgeAddress;
        data["UseServiceBridge"] =
          dataSource.CRMAdapterSetting.UseServiceBridge;
        setEnableUseServiceBridge(useServiceBridge || true);
      }
    }
    if (
      dataSource.AdapterType === AdapterType.Exchange &&
      dataSource.ExchangeSetting
    ) {
      data["ExchangeVersion"] = dataSource.ExchangeSetting.ExchangeVersion;
      data["ServerEndpoint"] = dataSource.ExchangeSetting.ServerEndpoint;
      data["ServerAccount"] = dataSource.ExchangeSetting.ServerAccount;
      //data["Password"] = dataSource.ExchangeSetting.Password;
      data["OnBehalf"] = dataSource.ExchangeSetting.OnBehalf;
      data["EmailAddress"] = dataSource.ExchangeSetting.EmailAddress;

      data["SecretId"] = dataSource.ExchangeSetting.SecretId;
      data["UseAws"] = dataSource.ExchangeSetting.UseAws;
      setUserAws(dataSource.ExchangeSetting.UseAws!);

    }
    if (dataSource.AdapterType === AdapterType.SMTP && dataSource.SMTPSetting) {
      data["SSLEnable"] = dataSource.SMTPSetting.SSLEnable;
      data["ServerEndpoint"] = dataSource.SMTPSetting.ServerEndpoint;
      data["ServerAccount"] = dataSource.SMTPSetting.ServerAccount;
      //Wdata["Password"] = dataSource.SMTPSetting.Password;
      data["AnonymousSetting"] = dataSource.SMTPSetting.AnonymousSetting;
      data["SecretId"] = dataSource.SMTPSetting.SecretId;
      data["UseAws"] = dataSource.SMTPSetting.UseAws;
      setUserAws(dataSource.SMTPSetting.UseAws!);
    }
    if (dataSource.AdapterType === AdapterType.Web && dataSource.WebSetting) {
      data["ServerEndpoint"] = dataSource.WebSetting.ServerEndpoint;

      data["SecretId"] = dataSource.WebSetting.SecretId;
      data["UseAws"] = dataSource.WebSetting.UseAws;
      setUserAws(dataSource.WebSetting.UseAws!);

      let params = dataSource.WebSetting.Params;
      setParam(params);
    }
    if (
      dataSource.AdapterType === AdapterType.SSRS &&
      dataSource.SSRSAdapterSetting
    ) {
      data["ServerEndpoint"] = dataSource.SSRSAdapterSetting.ServerEndpoint;
      data["UserName"] = dataSource.SSRSAdapterSetting.UserName;
      //data["Password"] = dataSource.SSRSAdapterSetting.Password;
      data["CrmOrganization"] = dataSource.SSRSAdapterSetting.CrmOrganization;
      data["SecretId"] = dataSource.SSRSAdapterSetting.SecretId;
      data["UseAws"] = dataSource.SSRSAdapterSetting.UseAws;
      setUserAws(dataSource.SSRSAdapterSetting.UseAws!);
    }
    if (dataSource.AdapterType === AdapterType.Dynamics365 && dataSource.CRM365AdapterSetting) {
      data["CRM365AuthType"] = dataSource.CRM365AdapterSetting.AuthType;
      data["Url"] = dataSource.CRM365AdapterSetting.Url;
      data["ClientId"] = dataSource.CRM365AdapterSetting.ClientId;
      //data["ClientSecret"] = dataSource.CRM365AdapterSetting.ClientSecret;
      data["UseAws"] = dataSource.CRM365AdapterSetting.UseAws;
      setUserAws(dataSource.CRM365AdapterSetting.UseAws!);
      data["SecretId"] = dataSource.CRM365AdapterSetting.SecretId;
    }
    setAdapterType(dataSource.AdapterType);
    form.setFieldsValue(data);
  };

  const handleChange = (info: any) => {
    let keyList = [...info.fileList];
    keyList = keyList.slice(-2);
    setFileList(keyList);
  };

  const beforeUpload = (file: any, FileList: UploadFile[]) => {
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      setFileList([]);
      message.error("file must smaller than 2MB!");
      return false;
    } else {
      setUploadFile(file);
    }
    return true;
  };

  const normFile = (e: any) => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  };

  const onFinish = (viewModel: any) => {
    let model: ConnectionAdapterDto = {
      AdapterName: viewModel.connectionName,
      Description: viewModel.description,
      AdapterType: viewModel.connectionType,
    };
    if (viewModel.connectionType === AdapterType.SQLServer) {
       model.SQLServerAdapterSetting = {
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        Domain: viewModel.Domain,
        AuthenticationType: viewModel.SQLAuthenticationType,
        ServerName: viewModel.serverName,
        DataBaseName: viewModel.DatabaseName,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
    } else if(viewModel.connectionType === AdapterType.Dataverse){
        model.DataverseAdapterSetting = {
          UseAws:useAws,
          Url: viewModel.Url,
          ClientId: viewModel.ClientId,
          ClientSecret: viewModel.ClientSecret,
          AuthType: viewModel.DataverseAuthType,
          SecretId:viewModel.SecretId,
        }
    }else if (viewModel.connectionType === AdapterType.SFTP) {
      model.SFTPAdapterSetting = {
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        AuthenticationType: viewModel.SFTPAuthenticationType,
        Host: viewModel.Host,
        Port: viewModel.Port,
        PrivateKey: viewModel.PrivateKey,
        Passphrase: viewModel.Passphrase,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
      if (uploadFile) {
        model.SFTPAdapterSetting.FileName = uploadFile.name;
      } else if (viewModel.PrivateKey) {
        model.SFTPAdapterSetting.FileName =
          props.formData!.SFTPAdapterSetting!.FileName;
      }
    } else if (viewModel.connectionType === AdapterType.Dynamics) {
      model.CRMAdapterSetting = {
        AuthType: viewModel.CRMAuthType,
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        Url: viewModel.Url,
        Domain: viewModel.Domain,
        BridgeAddress: viewModel.BridgeAddress,
        UseServiceBridge: enableUseServiceBridge,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
    } else if (viewModel.connectionType === AdapterType.Exchange) {
      model.ExchangeSetting = {
        ExchangeVersion: viewModel.ExchangeVersion,
        ServerEndpoint: viewModel.ServerEndpoint,
        ServerAccount: viewModel.ServerAccount,
        Password: viewModel.Password,
        OnBehalf: viewModel.OnBehalf,
        EmailAddress: viewModel.EmailAddress,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
    } else if (viewModel.connectionType === AdapterType.SMTP) {
      model.SMTPSetting = {
        SSLEnable: viewModel.SSLEnable,
        ServerEndpoint: viewModel.ServerEndpoint,
        ServerAccount: viewModel.ServerAccount,
        Password: viewModel.Password,
        AnonymousSetting: viewModel.AnonymousSetting,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
    } else if (viewModel.connectionType === AdapterType.Web) {
      let data = paramRef.current.getTableResult();
      let paramData =
        data.map((item: Param) => {
          return { Id: item.Id, Key: item.Key, Value: item.Value } as Param;
        }) || [];
      model.WebSetting = {
        ServerEndpoint: viewModel.ServerEndpoint,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
        Params: paramData
      };
    } else if (viewModel.connectionType === AdapterType.SSRS) {
      model.SSRSAdapterSetting = {
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        ServerEndpoint: viewModel.ServerEndpoint,
        CrmOrganization: viewModel.CrmOrganization,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
    }else if (viewModel.connectionType === AdapterType.PostgreSQL) {
      model.PGSQLAdapterSetting = {
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        Domain: viewModel.Domain,
        ServerName: viewModel.serverName,
        DataBaseName: viewModel.DatabaseName,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
    } else if (viewModel.connectionType === AdapterType.Dynamics365) {
      model.CRM365AdapterSetting = {
        AuthType: viewModel.CRM365AuthType,
        ClientId: viewModel.ClientId,
        ClientSecret: viewModel.ClientSecret,
        Url: viewModel.Url,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      }
    };
    if (props.formData && props.formData.Id) {
      model.Id = props.formData.Id;
    } else {
      model.Status = ConnectionStatus.Enable;
    }
    saveFormData(model);
  };

  const saveFormData = (model: ConnectionAdapterDto) => {
    const fd = new FormData();
    let args: any = { dto: model };
    if (uploadFile) {
      args._streamLength = uploadFile.size;
      args.importArguments = { FileName: uploadFile.name };
      fd.set("arg", JSON.stringify(args));
      //fd.set('arg', JSON.stringify({ _streamLength: file.size, importArguments: { FileName: file.name },dto:parms }));
      fd.set("file", uploadFile);
    } else {
      fd.set("arg", JSON.stringify(args));
    }
    setSaveLoadings(true);
    if (model.Id) {
      apiService
        .post("/IConnectionAdapterService/UpdateAdapter", fd)
        .then((result: ConnectionAdapterDto) => {
          UINotrification.success("Saved successfully");
          closeDrawer();
        })
        .catch((e) => {
          console.log(e);
        }).finally(()=>{
          setSaveLoadings(false);
          setFlags(true);
        });
    } else {
      apiService
        .post("/IConnectionAdapterService/CreateAdapter", fd)
        .then((result: ConnectionAdapterDto) => {
          UINotrification.success("Saved successfully");
          closeDrawer();
        })
        .catch((e) => {
          console.log(e);
        }).finally(()=>{
          setSaveLoadings(false);
          setFlags(true);
        });
    }
  };

  const onFinishFailed = (errorInfo: any) => {
    console.log("Failed:", errorInfo);
  };

  const ValidationForm = (formRef: any) => {
    setCheckName(false);
    const values = form.validateFields();
    values
      .then((res) => {
        validation(res);
      })
      .catch((e) => {
        console.log(e);
      }).finally(()=>setCheckName(true));
  };

  const validation = (viewModel: any) => {
    let model: any = {};
    setLoadings(true);
    if (viewModel.connectionType === AdapterType.SQLServer) {
      model = {
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        AuthenticationType: viewModel.SQLAuthenticationType,
        ServerName: viewModel.serverName,
        DataBaseName: viewModel.DatabaseName,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
      apiService
        .post("/IConnectionAdapterService/SQLServerValidate", {
          setting: model,
        })
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(()=>setLoadings(false));
    }else if(viewModel.connectionType === AdapterType.Dataverse){
      model = {
        UseAws: useAws,
        ClientId: viewModel.ClientId,
        ClientSecret: viewModel.ClientSecret,
        AuthType: viewModel.DataverseAuthType,
        Url: viewModel.Url,
        SecretId: viewModel.SecretId,
      };
      apiService
        .post("/IConnectionAdapterService/DataverseValidate", {
          setting: model,
        })
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(()=>setLoadings(false));
    } else if (viewModel.connectionType === AdapterType.SFTP) {
      model = {
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        AuthenticationType: viewModel.SFTPAuthenticationType,
        Host: viewModel.Host,
        Port: viewModel.Port,
        PrivateKey: viewModel.PrivateKey,
        Passphrase: viewModel.Passphrase,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };

      const fd = new FormData();
      let args: any = { setting: model };
      if (uploadFile) {
        args._streamLength = uploadFile.size;
        args.importArguments = { FileName: uploadFile.name };
        fd.set("arg", JSON.stringify(args));
        //fd.set('arg', JSON.stringify({ _streamLength: file.size, importArguments: { FileName: file.name },dto:parms }));
        fd.set("file", uploadFile);
      } else {
        fd.set("arg", JSON.stringify(args));
      }

      apiService
        .post("/IConnectionAdapterService/SFTPValidate", fd)
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(()=>setLoadings(false));
    } else if (viewModel.connectionType === AdapterType.Dynamics) {
      model = {
        AuthType: viewModel.CRMAuthType,
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        Url: viewModel.Url,
        Domain: viewModel.Domain,
        BridgeAddress: viewModel.BridgeAddress,
        UseServiceBridge: enableUseServiceBridge,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
      apiService
        .post("/IConnectionAdapterService/CRMValidate", { setting: model })
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(()=>setLoadings(false));
    } else if (viewModel.connectionType === AdapterType.Exchange) {
      let exchange: ExchangeDto = {
        ExchangeVersion: viewModel.ExchangeVersion,
        ServerEndpoint: viewModel.ServerEndpoint,
        ServerAccount: viewModel.ServerAccount,
        Password: viewModel.Password,
        OnBehalf: viewModel.OnBehalf,
        EmailAddress: viewModel.EmailAddress,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
      apiService
        .post("/IConnectionAdapterService/ExchangeValidate", {
          setting: exchange,
        })
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(()=>setLoadings(false));
    } else if (viewModel.connectionType === AdapterType.SMTP) {
      let smtp: SMTPDto = {
        SSLEnable: viewModel.SSLEnable,
        ServerEndpoint: viewModel.ServerEndpoint,
        ServerAccount: viewModel.ServerAccount,
        Password: viewModel.Password,
        AnonymousSetting: viewModel.AnonymousSetting,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
      apiService
        .post("/IConnectionAdapterService/SMTPValidate", { setting: smtp })
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(()=>setLoadings(false));
    } else if (viewModel.connectionType === AdapterType.Web) {
      let paramData = [];
      if(!useAws){
        let data = paramRef.current.getTableResult();
        paramData = data.map((item: Param) => {
          return { Id: item.Id, Key: item.Key, Value: item.Value } as Param;
        }) || [];
        setParam(paramData);
      }
      
      let WebSetting: WebDto = {
        ServerEndpoint: viewModel.ServerEndpoint,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
        Params: paramData
      };

      apiService
        .post("/IConnectionAdapterService/WebValidate", { setting: WebSetting })
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(()=>setLoadings(false));
    } else if (viewModel.connectionType === AdapterType.PostgreSQL) {
      model = {
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        ServerName: viewModel.serverName,
        DataBaseName: viewModel.DatabaseName,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
      apiService
        .post("/IConnectionAdapterService/PGSQLValidate", {
          setting: model,
        })
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(() => setLoadings(false));
    } else if (viewModel.connectionType === AdapterType.SSRS) {
      model = {
        UserName: viewModel.UserName,
        Password: viewModel.Password,
        ServerEndpoint: viewModel.ServerEndpoint,
        CrmOrganization: viewModel.CrmOrganization,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
      apiService
        .post("/IConnectionAdapterService/SSRSValidate", { setting: model })
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(() => setLoadings(false));
    } else if (viewModel.connectionType === AdapterType.Dynamics365) {
      model = {
        AuthType: viewModel.CRM365AuthType,
        ClientId: viewModel.ClientId,
        ClientSecret: viewModel.ClientSecret,
        Url: viewModel.Url,
        UseAws: useAws,
        SecretId: viewModel.SecretId,
      };
      apiService
        .post("/IConnectionAdapterService/CRM365Validate", { setting: model })
        .then((result: any) => {
          console.log("Success", result);
          UINotrification.success("Verification succeeded");
          setFlags(false);
        })
        .catch((e) => {
          console.log(e);
        }).finally(() => setLoadings(false));
    }
     
  };

  const closeDrawer = () => {
    form.resetFields();
    setParam([]);
    props.closeDrawerEvent();
  };
  const onConnectionTypeChange = (value: AdapterType, option: any) => {
    setAdapterType(value);
    let data: any = {
      connectionName: form.getFieldValue("connectionName"),
      description: form.getFieldValue("description"),
      connectionType: form.getFieldValue("connectionType"),
    };
    form.resetFields();
    form.setFieldsValue(data);
    setFlags(true);
  };

  const onAuthenticationTypeChange = (
    value: AuthenticationType,
    option: any
  ) => {
    setAuthenticationType(value);
  };

  const onChangeUseServiceBridge = (e: any) => {
    setEnableUseServiceBridge(e.target.checked);
    form.setFieldsValue({
      BridgeAddress: "",
    });
  };

  const onChangeOnBehalf = (e: any) => {
    setOnBehalf(e.target.checked);
    form.setFieldsValue({
      EmailAddress: "",
    });
  };

  const onChangeAnonymous = (e: any) => {
    setAnonymousSetting(e.target.checked);
    form.setFieldsValue({
      Password: "",
    });
  };

  return (
    <Drawer
      title={
        props.formData && props.formData.Id
          ? "Edit a connection"
          : "Create a new connection"
      }
      width={720}
      onClose={closeDrawer}
      visible={props.visible}
      destroyOnClose
      forceRender
      footer={
        <div style={{ textAlign: "right" }}>
          <Button
            disabled={
              !hasPermission(
                ConnectPermissionConstants.ObjectCode,
                ConnectPermissionConstants.Update
              )
            }
            onClick={() => {
              ValidationForm(formRef);
            }}
            style={{ marginRight: "8px" }}
            loading={loadings}
          >
            Validation Test
          </Button>
          <Button onClick={closeDrawer} style={{ marginRight: "8px" }}>
            Cancel
          </Button>
          <Button type="primary" onClick={() => form.submit()} disabled={flags} loading={saveLoadings}>
            Save
          </Button>
          {/* <Button type="primary" onClick={() => form.submit()}>Save</Button> */}
        </div>
      }
    >
      <Form
        name="basic"
        layout="vertical"
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        style={{ marginTop: "20px" }}
        ref={formRef}
        form={form}
      >
        <Form.Item
          label="Connection name"
          name="connectionName"
          rules={[{ required: checkName, message: "Please input connection name!" }]}
        >
          <Input placeholder="Please enter Connection name" maxLength={256}/>
        </Form.Item>
        <Form.Item label="Description" name="description">
          <TextArea rows={4} placeholder="Please enter your description" />
        </Form.Item>

        <Form.Item
          label="Connection type"
          name="connectionType"
          rules={[{ required: true, message: "Please choice connection type" }]}
        >
          <Select
            onChange={onConnectionTypeChange}
            placeholder="Please select connection type"
          >
          {
            Array.from(AdapterTypeMap).map(([key, value]) => <Option value={key} key={key}>{value}</Option>)
          }
          </Select>
        </Form.Item>

        <Form.Item
          name="UseAws"
          valuePropName="checked"
          initialValue={useAws}
        >
          <Checkbox onChange={(e) => setUserAws(e.target.checked)}>
            Use secret manager
          </Checkbox>
        </Form.Item>

        {useAws && (
          <>
            <Form.Item
              label="Secret manager key"
              name="SecretId"
              rules={[
                {
                  required: true,
                  message: "Please input secret manager key",
                },
              ]}
            >
              <Input placeholder="Please enter secret manager key" />
            </Form.Item>
          </>
        )}

        {!useAws && AdapterType.SQLServer === adapterType && (
          <>
            <Form.Item
              label="Authentication method"
              name="SQLAuthenticationType"
              rules={[
                {
                  required: true,
                  message: "Please choice authentication method",
                },
              ]}
            >
              <Select placeholder="Please select authentication method">
                {Object.keys(SQLAuthenticationType)
                  .filter((r) => !isNaN(Number(r)))
                  .map((key) => {
                    let item = Number(key);
                    return (
                      <Option value={item} key={item}>
                        {SQLAuthenticationType[item]}
                      </Option>
                    );
                  })}
              </Select>
            </Form.Item>
            <Form.Item
              label="Server name"
              name="serverName"
              rules={[{ required: true, message: "Please input server name" }]}
            >
              <Input placeholder="Please enter server name" />
            </Form.Item>
            <Form.Item
              label="Database name"
              name="DatabaseName"
              rules={[
                { required: true, message: "Please input Database name" },
              ]}
            >
              <Input placeholder="Please enter database name" />
            </Form.Item>
          </>
        )}
         {!useAws && AdapterType.Dataverse === adapterType && (
          <>
          <Form.Item
              label="Auth type"
              name="DataverseAuthType"
              rules={[
                {
                  required: true,
                  message: "Please choice auth type",
                },
              ]}
            >
              <Select placeholder="Please select auth type">
                {Object.keys(DataverseAuthType)
                  .filter((r) => !isNaN(Number(r)))
                  .map((key) => {
                    let item = Number(key);
                    return (
                      <Option value={item} key={item}>
                        {DataverseAuthType[item]}
                      </Option>
                    );
                  })}
              </Select>
            </Form.Item>
            <Form.Item
              label="Url"
              name="Url"
              rules={[{ required: true, message: "Please input url" }]}
            >
              <Input placeholder="Please enter url" />
            </Form.Item>
            <Form.Item
              label="Client id"
              name="ClientId"
              rules={[
                { required: true, message: "Please input client id" },
              ]}
            >
              <Input placeholder="Please enter client id" />
            </Form.Item>
            <Form.Item
              label="Client secret"
              name="ClientSecret"
              rules={[
                { required: true, message: "Please input client secret" },
              ]}
            >
              <Input placeholder="Please enter client secret" />
            </Form.Item>
          </>
        )}
        {!useAws && AdapterType.SFTP === adapterType && (
          <>
            <Form.Item
              label="Authentication method"
              name="SFTPAuthenticationType"
              rules={[
                {
                  required: true,
                  message: "Please choice authentication method",
                },
              ]}
            >
              <Select
                placeholder="Please select authentication method"
                onChange={onAuthenticationTypeChange}
              >
                {Object.keys(AuthenticationType)
                  .filter((r) => !isNaN(Number(r)))
                  .map((key) => {
                    let item = Number(key);
                    return (
                      <Option value={item} key={item}>
                        {AuthenticationType[item]}
                      </Option>
                    );
                  })}
              </Select>
            </Form.Item>
            <Form.Item
              label="Host"
              name="Host"
              rules={[{ required: true, message: "Please input host" }]}
            >
              <Input placeholder="Please input host path" />
            </Form.Item>
            <Form.Item
              label="Port"
              name="Port"
              rules={[{ required: true, message: "Please input port" }]}
            >
              <Input placeholder="Please enter port" />
            </Form.Item>
          </>
        )}
        {!useAws && (AdapterType.Dynamics === adapterType) && (
          <>
            <Form.Item
              label="Auth type"
              name="CRMAuthType"
              rules={[
                {
                  required: true,
                  message: "Please choice authentication method",
                },
              ]}
            >
              <Select placeholder="Please select authentication Method">
                {Object.keys(AuthType)
                  .filter((r) => !isNaN(Number(r)))
                  .map((key) => {
                    let item = Number(key);
                    return (
                      <Option value={item} key={item}>
                        {AuthType[item]}
                      </Option>
                    );
                  })}
              </Select>
            </Form.Item>
            <Form.Item
              label="Url"
              name="Url"
              rules={[{ required: true, message: "Please input Url" }]}
            >
              <Input placeholder="Please input Url" />
            </Form.Item>
            <Form.Item
              label="Domain"
              name="Domain"
              rules={[{ required: true, message: "Please input domain name" }]}
            >
              <Input placeholder="Please enter domain" />
            </Form.Item>
          </>
        )}
        {!useAws && AdapterType.SSRS === adapterType && (
          <>
            <Form.Item
              label="SSRS connection url"
              name="ServerEndpoint"
              rules={[
                { required: true, message: "Please input ssrs connection url!" },
              ]}
            >
              <Input placeholder="Please input ssrs connection url" />
            </Form.Item>
          </>
        )}
        {!useAws && AdapterType.PostgreSQL === adapterType && (
          <>
            <Form.Item
              label="Server name"
              name="serverName"
              rules={[{ required: true, message: "Please input server name" }]}
            >
              <Input placeholder="Please enter server name" />
            </Form.Item>
            <Form.Item
              label="Database name"
              name="DatabaseName"
              rules={[
                { required: true, message: "Please input Database name" },
              ]}
            >
              <Input placeholder="Please enter database name" />
            </Form.Item>
          </>
        )}
        {!useAws &&
          undefined !== adapterType &&
          (adapterType < 4 || adapterType === AdapterType.SSRS || adapterType === AdapterType.PostgreSQL )&&
          adapterType !== AdapterType.SFTP && (
            <>
              <Form.Item
                label="Username"
                name="UserName"
                rules={[{ required: true, message: "Please input username!" }]}
              >
                <Input placeholder="Please enter username" autoComplete="new-password"/>
              </Form.Item>
              <Form.Item
                label="Password"
                name="Password"
                rules={[{ required: true, message: "Please input password!" }]}
              >
                <Input placeholder="Please enter password" autoComplete="new-password" type="password" />
              </Form.Item>
            </>
        )}
        {!useAws && AdapterType.SSRS === adapterType && (
          <>
            <Form.Item
              label="CRM organization"
              name="CrmOrganization">
              <Input placeholder="Please input crm organization" />
            </Form.Item>
          </>
        )}

        {!useAws &&
          adapterType === AdapterType.SFTP &&
          authenticationType === AuthenticationType.Password && (
            <>
              <Form.Item
                label="Username"
                name="UserName"
                rules={[{ required: true, message: "Please input username!" }]}
              >
                <Input placeholder="Please enter user name" autoComplete="new-password"/>
              </Form.Item>
              <Form.Item
                label="Password"
                name="Password"
                rules={[{ required: true, message: "Please input password!" }]}
              >
                <Input placeholder="Please enter password" autoComplete="new-password" type="password" />
              </Form.Item>
            </>
          )}

        {!useAws &&
          adapterType === AdapterType.SFTP &&
          authenticationType === AuthenticationType.PrivateKey && (
            <>
              <Form.Item
                label="Username"
                name="UserName"
                rules={[{ required: true, message: "Please input username!" }]}
              >
                <Input placeholder="Please enter username" autoComplete="new-password"/>
              </Form.Item>
              <Form.Item
                label="Passphrase"
                name="Passphrase"
                rules={[
                  { required: false, message: "Please input passphrase!" },
                ]}
              >
                <Input placeholder="Please enter passphrase" />
              </Form.Item>
              <Form.Item
                name="PublicKey"
                label="Private key"
                valuePropName="fileList"
                getValueFromEvent={normFile}
                required={false}
              >
                <Form.Item name="PrivateKey" hidden={true}>
                  <Input />
                </Form.Item>
                <Upload
                  name="PublicKey"
                  maxCount={1}
                  beforeUpload={beforeUpload}
                  fileList={fileList}
                  multiple={false}
                  onChange={handleChange}
                  accept={'.key,.ppk'}
                >
                  <Button icon={<UploadOutlined />}>Click to upload</Button>
                </Upload>
              </Form.Item>
            </>
          )}
        {!useAws &&
          adapterType === AdapterType.SFTP &&
          authenticationType === AuthenticationType.PrivateKeyAndPassword && (
            <>
              <Form.Item
                label="Username"
                name="UserName"
                rules={[{ required: true, message: "Please input username!" }]}
              >
                <Input placeholder="Please enter username" autoComplete="new-password"/>
              </Form.Item>
              <Form.Item
                label="Password"
                name="Password"
                rules={[{ required: true, message: "Please input password!" }]}
              >
                <Input placeholder="Please enter password" type="password" autoComplete="new-password"/>
              </Form.Item>
              <Form.Item
                label="Passphrase"
                name="Passphrase"
                rules={[
                  { required: false, message: "Please input passphrase!" },
                ]}
              >
                <Input placeholder="Please enter passphrase" />
              </Form.Item>
              <Form.Item name="PrivateKey" hidden={true}>
                <Input />
              </Form.Item>
              <Form.Item
                name="PublicKey"
                label="Private key"
                valuePropName="fileList"
                getValueFromEvent={normFile}
                required={false}
              >
                <Form.Item name="PrivateKey" hidden={true}>
                  <Input />
                </Form.Item>
                <Upload
                  name="PublicKey"
                  maxCount={1}
                  beforeUpload={beforeUpload}
                  fileList={fileList}
                  multiple={false}
                  onChange={handleChange}
                  accept={'.key,.ppk'}
                >
                  <Button icon={<UploadOutlined />}>Click to upload</Button>
                </Upload>
              </Form.Item>
            </>
          )}

        {!useAws && (AdapterType.Dynamics === adapterType) && (
          <>
            <Form.Item name="UseServiceBridge">
              <Checkbox
                onChange={(e) => onChangeUseServiceBridge(e)}
                checked={enableUseServiceBridge}
              >
                Enable service bridge
              </Checkbox>
            </Form.Item>
            {enableUseServiceBridge && (
              <>
                <Form.Item
                  label="Service bridge address"
                  name="BridgeAddress"
                  rules={[
                    {
                      type: "url",
                      required: true,
                      message: "Please input service bridge address!",
                    },
                  ]}
                >
                  <Input placeholder="Please enter service bridge address" />
                </Form.Item>
              </>
            )}
          </>
        )}
        {!useAws && AdapterType.Exchange === adapterType && (
          <>
            <Form.Item
              label="Exchange version"
              name="ExchangeVersion"
              rules={[
                { required: true, message: "Please choice exchange version" },
              ]}
            >
              <Select placeholder="Please select exchange version">
                {Object.keys(ExchangeVersion)
                  .filter((r) => !isNaN(Number(r)))
                  .map((key) => {
                    let item = Number(key);
                    return (
                      <Option value={item} key={item}>
                        {ExchangeVersion[item]}
                      </Option>
                    );
                  })}
              </Select>
            </Form.Item>
            <Form.Item
              label="Server endpoint"
              name="ServerEndpoint"
              rules={[
                { required: true, message: "Please input server endpoint!" },
              ]}
            >
              <Input placeholder="Please enter server endpoint" />
            </Form.Item>
            <Form.Item
              label="Server account"
              name="ServerAccount"
              rules={[
                { required: true, message: "Please input server account!" },
              ]}
            >
              <Input placeholder="Please enter Server Account" />
            </Form.Item>
            <Form.Item
              label="Password"
              name="Password"
              rules={[{ required: true, message: "Please input password!" }]}
            >
              <Input type="password" placeholder="Please enter password" autoComplete="new-password"/>
            </Form.Item>
            <Form.Item name="OnBehalf" valuePropName="checked">
              <Checkbox
                onChange={(e) => onChangeOnBehalf(e)}
                checked={onBehalf}
              >
                OnBehalf
              </Checkbox>
            </Form.Item>
            {onBehalf && (
              <>
                <Form.Item
                  label="Email address"
                  name="EmailAddress"
                  rules={[
                    { required: true, message: "Please input email address!" },
                  ]}
                >
                  <Input placeholder="Please enter email address" />
                </Form.Item>
              </>
            )}
          </>
        )}
        {!useAws && AdapterType.SMTP === adapterType && (
          <>
            <Form.Item valuePropName="checked" name="SSLEnable">
              <Checkbox>SSL Enable</Checkbox>
            </Form.Item>
            <Form.Item
              label="Server endpoint"
              name="ServerEndpoint"
              rules={[
                { required: true, message: "Please input server endpoint!" },
              ]}
            >
              <Input placeholder="Please enter server endpoint" />
            </Form.Item>
            <Form.Item
              label="Server account"
              name="ServerAccount"
              rules={[
                { required: true, message: "Please input server account!" },
              ]}
            >
              <Input placeholder="Please enter server account" />
            </Form.Item>
            <Form.Item
              valuePropName="checked"
              name="AnonymousSetting"
              initialValue={anonymousSetting}
            >
              <Checkbox onChange={(e) => onChangeAnonymous(e)}>
                Anonymous Setting
              </Checkbox>
            </Form.Item>
            {!anonymousSetting && (
              <>
                <Form.Item
                  label="Password"
                  name="Password"
                  rules={[
                    { required: true, message: "Please input password!" },
                  ]}
                >
                  <Input type="password" placeholder="Please enter password" autoComplete="new-password"/>
                </Form.Item>
              </>
            )}
          </>
        )}
        {!useAws && AdapterType.Web === adapterType && (
          <>
            <Form.Item
              label="Server endpoint"
              name="ServerEndpoint"
              rules={[
                { required: true, message: "Please input server endpoint!" },
              ]}
            >
              <Input placeholder="Please enter server endpoint" />
            </Form.Item>
            <ParamsEditTable dataSource={param} ref={paramRef} />
          </>
        )}
        {!useAws && (AdapterType.Dynamics365 === adapterType) && (
          <>
            <Form.Item
              label="Auth type"
              name="CRM365AuthType"
              rules={[
                {
                  required: true,
                  message: "Please choice Auth type",
                },
              ]}
            >
              <Select placeholder="Please select Auth type">
                {Object.keys(Dynamics365AuthType)
                  .filter((r) => !isNaN(Number(r)))
                  .map((key) => {
                    let item = Number(key);
                    return (
                      <Option value={item} key={item}>
                        {Dynamics365AuthType[item]}
                      </Option>
                    );
                  })}
              </Select>
            </Form.Item>
            <Form.Item
              label="Url"
              name="Url"
              rules={[{ required: true, message: "Please input Url" }]}
            >
              <Input placeholder="Please input Url" />
            </Form.Item>
            <Form.Item
              label="Client Id"
              name="ClientId"
              rules={[{ required: true, message: "Please input Client Id" }]}
            >
              <Input placeholder="Please enter Client Id" />
            </Form.Item>
            <Form.Item
              label="Client Secret"
              name="ClientSecret"
              rules={[{ required: true, message: "Please input Client Secret" }]}
            >
              <Input placeholder="Please enter Client Secret" autoComplete="new-password" type="password" />
            </Form.Item>
          </>
        )}
      </Form>
    </Drawer>
  );
};
export default DrawerForm;

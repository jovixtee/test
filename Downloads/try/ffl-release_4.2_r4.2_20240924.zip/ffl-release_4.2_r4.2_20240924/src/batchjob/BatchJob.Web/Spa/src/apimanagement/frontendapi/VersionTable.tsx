
import React, { FC, useState } from 'react';
import { Table, Space, Button } from 'antd';
import { ColumnsType } from "antd/lib/table";
//import { FrontendAPIVersion } from './FrontendAPIContracts';
import {VersionStatusType,VersionDetailsDto} from '../../common/contracts/ModelContracts';
import DesignMethodDrawer from './DesignMethodDrawer';


interface IVersionTableProps {
    versionData: VersionDetailsDto[]  | undefined;
    versionEdit: EditVersionFunction;
    versionDelete: VersionDeleteFunction;
    apiId: string;
}

interface EditVersionFunction {
    (record: VersionDetailsDto): void
}

interface VersionDeleteFunction {
    (record: VersionDetailsDto): void
}


const VersionTable: FC<IVersionTableProps> = (props) => {

    const [designVersionMethodsDrawerVisible, setDesignVersionMethodsDrawerVisible] = useState<boolean>(false);
    const [designMethodVersionId, setDesignMethodVersionId] = useState<string>("");


    const columns: ColumnsType<VersionDetailsDto> = [
        { title: 'VersionName', dataIndex: 'Endpoint' },
        { title: 'APIControl', dataIndex: 'ControlPolicy' },
        { title: 'Authentication', dataIndex: 'Authentication' },
        {
            title: 'Status',
            dataIndex: 'Status',
            render: (text, record) => record.Status ? VersionStatusType[record.Status]:""
        },
        {
            title: 'Action',
            dataIndex: 'operation',
            key: 'operation',
            render: (text, record) => (
                <Space size="middle">
                    <Button type='link' onClick={() => onDesignVersionMethodsClick(record)}>Design</Button>
                    <Button type='link'  onClick={() => { props.versionEdit(record) }}>Edit</Button>
                    <Button type='link'  onClick={() => { props.versionDelete(record) }}>Delete</Button>
                </Space>
            ),
        },
    ];

    const onDesignVersionMethodsClick = (record: VersionDetailsDto): void => {
        setDesignMethodVersionId(record.Id)
        setDesignVersionMethodsDrawerVisible(true);

    }
    const closeDesignVersionMethodsDrawer = (): void => {
        setDesignMethodVersionId("");
        setDesignVersionMethodsDrawerVisible(false);

    }

    return <React.Fragment>
        <Table
            rowKey={(record) => record.Id}
            columns={columns}
            dataSource={props.versionData || []}
            pagination={false}

        />
        <DesignMethodDrawer
            visibile={designVersionMethodsDrawerVisible}
            cancelClick={closeDesignVersionMethodsDrawer}
            versionId={designMethodVersionId}
            apiId={props.apiId}
        />
    </React.Fragment>

}
export default VersionTable


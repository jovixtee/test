import React from 'react';
import DrawerForm from './SecurityPolicyDrawer';
import Security from './SecurityPolicyForm';
import apiservice from '../../utils/fetchutil';
import { SecurityPofileDto } from './SecurityPofileContract'

class SecurityPolicy extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            visible: false,
            showData: 'block',
            formData: null,
            isFormDataLoaded: false,
            tab:1,
            selectedTab:1
            //formIndexData: formIndexData
            //formData: defaultData
        };
    }

    apiService = apiservice();
    retrieveSelectData = () => {
        this.apiService.post('/ISecuritySetting/GetDefaultSecurityProfile').then(
            (result: SecurityPofileDto) => {
                // console.log(result)
                this.setState({ isFormDataLoaded:true, formData: result});
            }
        ).catch((e) => {
            console.log(e);
            })
    };
    onGet = () => {
        this.apiService.post('/ISecuritySetting/GenerateSymmetricKey').then(
            (result: SecurityPofileDto) => {
                // console.log(result)
                this.setState({ formData1: result});
            }
        ).catch((e) => {
            console.log(e);
        })
    };
    openDrawer = (tab: any) => {       
        this.setState({
            visible: true,
            tab: tab,
            selectedTab:tab
        });      
        // this.retrieveSelectData();
    }
    closeDrawer = () => {
        this.setState({ isFormDataLoaded: false, visible: false});
        this.retrieveSelectData();
    }

    render() {
        if (!this.state.formData)
             this.retrieveSelectData();
        return (
            <div>
               {this.state.isFormDataLoaded && <Security
                    formData={this.state.formData}
                    updateDrawer={this.openDrawer} 
                    selectedTab ={this.state.selectedTab}                   
               />}   
                {this.state.visible && <DrawerForm
                    visible={this.state.visible}
                    closeDrawerEvent={this.closeDrawer}
                    tab={this.state.tab}
                    onGet={this.onGet}
                />}
            </div>
        );
    }
}
export default SecurityPolicy;

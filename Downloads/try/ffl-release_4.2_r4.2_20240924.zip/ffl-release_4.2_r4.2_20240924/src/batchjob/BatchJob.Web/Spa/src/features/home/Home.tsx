import React, {FC} from 'react';

const Home: FC = ()=> {
    return <div>Welcome Home</div>;
};

export default Home;
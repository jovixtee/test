import { OidcClientSettings } from 'oidc-client';
import AveConfig from '../common/AveConfig';

export const APMOidcConfig: OidcClientSettings = {
  client_id: AveConfig.OIDC_CLIENTID(),
  authority: AveConfig.OIDC_AUTHORITY(),
  response_type: AveConfig.OIDC_RESPONSE_TYPE(),
  redirect_uri: AveConfig.OIDC_REDIRECTURL(),
  scope: AveConfig.OIDC_SCOPE(),
};
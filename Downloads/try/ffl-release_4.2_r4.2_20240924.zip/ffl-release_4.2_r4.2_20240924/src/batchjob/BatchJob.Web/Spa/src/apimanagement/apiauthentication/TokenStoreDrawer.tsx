﻿import React, {FC, useEffect, useState} from "react";
import {Button, Drawer, Form, Input} from "antd";
import {AuthenticationDto, GrantType, OAuthDto, TokenStore} from "../../common/contracts/ModelContracts";
import {CreateTokenStore, GetTokenStoreByProfileId, ProceedGrant} from "./APIAuthenticationService";
import UINotrification from "../../common/UINotrification";


interface ITokenStoDrawerProps {
    visibile: boolean;
    cancelClick: () => void;
    profile: AuthenticationDto;
}

interface ITokenStoreFrom {
    Id: string;
    Name: string;
    TokenType: string;
    ProfileId: string;
    Scope: string;
    AccessToken: string;
    Expiration: string;
    IdToken: string;
    RefreshToken: string;
}


const TokenStoreDrawer: FC<ITokenStoDrawerProps> = (props) => {
    const [form] = Form.useForm();
    const [oAuth, setOAuth] = useState<OAuthDto>();
    useEffect(() => {
        if (props.visibile) {
            let auth = props.profile;
            let oauth = auth.AuthSetting as OAuthDto;
            let tokenStore: any = {};
            tokenStore.Name = auth.Name;
            tokenStore.Granttype = oauth.GrantType === GrantType.Code ? "Code" : "Client credentials";
            setOAuth(oauth);
            GetTokenStoreByProfileId(auth.Id).then(e => {
                if (e !== null) {
                    //token get value
                    tokenStore.Scope = e.Scope;
                    tokenStore.IssueAt = e.IssueAt;
                    tokenStore.AccessToken = e.AccessToken;
                    tokenStore.Expiration = e.Expiration;
                    tokenStore.IdToken = e.IdToken;
                    tokenStore.TokenType = e.TokenType;
                    tokenStore.RefreshToken = e.RefreshToken;
                }
                form.setFieldsValue(tokenStore);
            });
        }
    }, [props.profile, props.visibile]);

    const onFinish = (values: ITokenStoreFrom) => {
        let auth = props.profile;
        let requestObject = new TokenStore();
        requestObject.Name = auth.Name;
        requestObject.ProfileId = auth.Id;
        requestObject.TokenType = values.TokenType;
        requestObject.Scope = values.Scope;
        requestObject.AccessToken = values.AccessToken;
        requestObject.Expiration = values.Expiration;
        requestObject.IdToken = values.IdToken;
        requestObject.RefreshToken = values.RefreshToken;
        CreateTokenStore(requestObject).then(e => {
            UINotrification.success("save successfully", () => {
                props.cancelClick();
            });
        })
    }


    const proceedGrant = () => {
        if (GrantType.Code === oAuth?.GrantType) {
            let grantType = oAuth?.GrantType == GrantType.Code ? "code" : "client_credentials";
            let authUrl = `${oAuth?.AuthorizationUrl}?response_type=${grantType}&client_id=${oAuth?.ClientId}&state=${props.profile.Id}&scope=${oAuth?.Scope}&redirect_uri=${oAuth?.RedirectUrl}`;
            window.open(authUrl, "Proceed grant", "width=1000,height=600,left=150,top=100");
            setTimeout(() => props.cancelClick(), 1000);
        } else {
            ProceedGrant(props.profile.Id).then(e => {
                let auth = props.profile;
                let oauth = auth.AuthSetting as OAuthDto;
                let tokenStore: any = {};
                tokenStore.Name = auth.Name;
                tokenStore.Granttype = oauth.GrantType === GrantType.Code ? "Code" : "Client credentials";
                if (e !== null) {
                    //token get value
                    tokenStore.Scope = e.Scope;
                    tokenStore.IssueAt = e.IssueAt;
                    tokenStore.AccessToken = e.AccessToken;
                    tokenStore.Expiration = e.Expiration;
                    tokenStore.IdToken = e.IdToken;
                    tokenStore.TokenType = e.TokenType;
                    tokenStore.RefreshToken = e.RefreshToken;
                }
                form.setFieldsValue(tokenStore);
                UINotrification.success("Proceed grant successfully")
            })
        }
    }

    const onFailed = (values: any) => {
        console.log("Failed:", values);
    };
    return (
        <Drawer
            visible={props.visibile}
            width={720}
            onClose={props.cancelClick}
            title={"Token Store"}
            footer={
                <div style={{textAlign: "right"}}>
                    <Button type="primary" style={{marginRight: 8}} onClick={proceedGrant}>
                        Proceed Grant
                    </Button>
                    <Button style={{marginRight: 8}} onClick={() => form.submit()}>Save</Button>
                    <Button style={{marginRight: 8}} onClick={() => props.cancelClick()}>Close</Button>
                </div>
            }>
            <Form
                layout="vertical"
                form={form}
                onFinish={onFinish}
                onFinishFailed={onFailed}
                style={{marginTop: "1.25rem"}}
            >
                <Form.Item
                    label="Name"
                    name="Name"
                    rules={[{required: true, message: "Please input name!"}]}
                >
                    <Input disabled={true} placeholder="Please input name" maxLength={256}/>
                </Form.Item>

                <Form.Item
                    label="Access token"
                    name="AccessToken"
                    rules={[{required: true, message: "Please input access token!"}]}
                >
                    <Input placeholder="Please input access token" maxLength={256}/>
                </Form.Item>

                <Form.Item
                    label="Issue at"
                    name="IssueAt"
                    rules={[{required: true, message: "Please input issueat!"}]}
                >
                    <Input placeholder="Please input issue at" maxLength={256}/>
                </Form.Item>

                <Form.Item
                    label="Expire at"
                    name="Expiration"
                    rules={[{required: true, message: "Please input expire at!"}]}
                >
                    <Input placeholder="Please input expire at" maxLength={256}/>
                </Form.Item>

                <Form.Item
                    label="Grant type"
                    name="Granttype"
                    rules={[{required: true, message: "Please input grant type!"}]}
                >
                    <Input disabled={true} placeholder="Please input grant type" maxLength={256}/>
                </Form.Item>
                <Form.Item name="TokenType">
                    <Input hidden={true}/>
                </Form.Item>
                <Form.Item name="RefreshToken">
                    <Input hidden={true}/>
                </Form.Item>
                <Form.Item name="AccessToken">
                    <Input hidden={true}/>
                </Form.Item>
                <Form.Item name="Scope">
                    <Input hidden={true}/>
                </Form.Item>
            </Form>
        </Drawer>
    );
}
export default TokenStoreDrawer
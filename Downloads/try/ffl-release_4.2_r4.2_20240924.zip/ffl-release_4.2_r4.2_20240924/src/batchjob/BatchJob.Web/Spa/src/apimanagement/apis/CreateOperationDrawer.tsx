import { Drawer, Input, Button, Select, Form, Spin, Tabs, message } from 'antd';
import React, { FC, useEffect, useState, useRef } from 'react';
import { IEditTableRef, IEditHeaderTableRef, MethodParameter, MethodHeader, OperationDto, MethodTypeEnum, OperationParam, OperationHeader } from '../../common/contracts/ModelContracts';
import { GetRequestUrl, SaveOperation, GetOperation } from './APIsService';
import ParameterEditTable from './ParameterEditTable';
import HeaderEditTable from './HeaderEditTable';

const { TabPane } = Tabs;
const { TextArea } = Input;
const { Option } = Select;

interface ICreateOperationProps {
    operationVisibile: boolean;
    isFrontend:boolean;
    baseAddress?:string;
    closeDrawer: VoidFunction;
    refreshMethod: any;
    methodId?: string;
    versionId: string;
}

const CreateOperationDrawer: FC<ICreateOperationProps> = (props) => {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState<boolean>(false);
    const tableRef = useRef<IEditTableRef>();
    const headertableRef = useRef<IEditHeaderTableRef>();

    const [params, setParams] = useState<MethodParameter[]>([]);
    const [headers, setHeaders] = useState<MethodHeader[]>([]);

    const [baseAddress, setBaseAddress] = useState<string>("");

    useEffect(() => {
        if (props.operationVisibile && props.methodId) {
            handleGetOperation(props.methodId);
        } else if (props.versionId.length > 0) {
            handleGetRequestUrl(props.versionId);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.methodId, props.operationVisibile, props.versionId])


    useEffect(() => {
        if (props.operationVisibile && props.baseAddress) {
            setBaseAddress(props.baseAddress)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.baseAddress, props.operationVisibile])

    const handleGetRequestUrl = (versionId: string) => {
        GetRequestUrl(versionId).then(res => {
            setBaseAddress(res);
            form.setFieldsValue({
                "requestUrl": res
            })
        });
    }

    const handleGetOperation = (id: string) => {
        setLoading(true);
        GetOperation(id).then(res => {
            form.setFieldsValue({
                "DisplayName": res.Name,
                "MethodName": res.MethodName,
                "Path": res.Path,
                "requestUrl": res.RequestUrl,
                "Description": res.Description
            });
            setParams(res.Param || []);
            setHeaders(res.Header || []);
        }).finally(() => setLoading(false));
    };



    const onFinish = (values: any) => {
        setLoading(true);
        let data = new OperationDto();
        if (props.methodId && props.methodId.length > 0) {
            data.Id = props.methodId;
        }
        data.Name = values.DisplayName;
        data.MethodName = values.MethodName;
        data.Path = values.Path;
        data.Description = values.Description;
        data.VersionID = props.versionId;
        let paramTableResult = tableRef.current?.getTableResult();
        let parmObject = new OperationParam();
        parmObject.addData = paramTableResult?.addData.map(item => { return { DefaultValue: item.DefaultValue, ParamterType: item.ParamterType, Name: item.Name, Id: "" } }) || [];
        if (props.methodId && props.methodId.length > 0) {
            parmObject.updateData = paramTableResult?.updateData.map(item => { return { DefaultValue: item.DefaultValue, ParamterType: item.ParamterType, Name: item.Name, Id: item.Id } }) || [];
            parmObject.deleteData = paramTableResult?.deleteData.map(item => { return { Id: item.Id } }) || [];
        }
        data.Param = parmObject;
        let HeaderTableResult = headertableRef.current?.getTableResult();
        let headerObject = new OperationHeader();
        headerObject.addData = HeaderTableResult?.addData.map(item => { return { DefaultValue: item.DefaultValue, Type: item.Type, Name: item.Name, Id: "" } }) || [];
        if (props.methodId && props.methodId.length > 0) {
            headerObject.updateData = HeaderTableResult?.updateData.map(item => { return { DefaultValue: item.DefaultValue, Type: item.Type, Name: item.Name, Id: item.Id } }) || [];
            headerObject.deleteData = HeaderTableResult?.deleteData.map(item => { return { Id: item.Id } }) || [];
        }
        data.Header = headerObject;
        console.log(data);
        SaveOperation(data).then(res => {
            message.success("Create success!");
            props.refreshMethod(props.versionId, "");
            form.resetFields();
            props.closeDrawer();

        }).finally(() => setLoading(false));

    }

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };

    const closeDrawer = (): void => {
        form.resetFields();
        props.closeDrawer();
    }


    const handlePathChange = (e: any) => {
        let val = e.target.value;
        val = val.startsWith("/") ? val : "/" + val;
        var requestUrl = baseAddress + val;
        form.setFieldsValue({
            Path: val,
            requestUrl: requestUrl,
        });
    };

    return (
        <Drawer
            visible={props.operationVisibile}
            width={720}
            destroyOnClose
            forceRender
            onClose={closeDrawer}
            title={props.methodId ? "Edit" : "Create operation"}
            footer={
                <div style={{ textAlign: 'right', }}>
                    <Button type="primary" style={{ marginRight: 8 }} disabled={loading} loading={loading} onClick={() => form.submit()}>Save</Button>
                    <Button onClick={closeDrawer} >Cancel</Button>
                </div>
            }>

            <Spin spinning={loading}>
                <Form form={form} layout="vertical" onFinish={onFinish} onFinishFailed={onFailed}>

                    <Form.Item label="Display Name" name="DisplayName" rules={[{ required: true, message: 'Please input Display name!' }]}>
                        <Input disabled={!props.isFrontend} />
                    </Form.Item>
                    <Form.Item label="URL" required>
                        <Input.Group compact>
                            <Form.Item name="MethodName" noStyle initialValue={MethodTypeEnum.GET} >
                                <Select style={{ width: '20%' }} >
                                    {
                                        Object.keys(MethodTypeEnum).filter(r => !isNaN(Number(r))).map((key) => {
                                            let item = Number(key);
                                            return <Option value={item} key={item}>{MethodTypeEnum[item]}</Option>
                                        })
                                    }
                                </Select>
                            </Form.Item>
                            <Form.Item name="Path" noStyle rules={[{ required: true, message: 'URL is required' }]}  >
                                <Input style={{ width: '80%' }} onChange={handlePathChange} />
                            </Form.Item>
                        </Input.Group>
                    </Form.Item>
                    <Form.Item label={props.isFrontend?"Request URL":"Backend URL"} name="requestUrl" >
                        <Input disabled />
                    </Form.Item>
                    { 
                        // props.isFrontend &&
                        <>
                            <Form.Item label="Description" name="Description" >
                                <TextArea rows={3} placeholder="" />
                            </Form.Item>
                    
                            <Tabs defaultActiveKey="1" style={{ margin: "24px 24px 0 24px" }}>
                                <TabPane tab="Query parameters" key="1">
                                    <ParameterEditTable
                                        dataSource={params || []}
                                        ref={tableRef} />
                                </TabPane>
                                <TabPane tab="Headers" key="2"  >
                                    <HeaderEditTable
                                        dataSource={headers || []}
                                        ref={headertableRef} />
                                </TabPane>
                            </Tabs>
                        </>
                    }
                </Form>
            </Spin>
        </Drawer>
    );
}
export default CreateOperationDrawer
import React, { FC, useEffect, useState } from "react";
import { Button, Descriptions, Drawer,Input,Radio,Checkbox } from "antd";
import {VoidCallBackFunction} from './AnalysticReportContract';
import { HistoryDto } from '../../common/contracts/ModelContracts';
import "../analysticreport/analysticReport.css";
import { convertTicksToMoment } from "../../utils/dateconvert";
const { TextArea } = Input;
 
interface IDetailDrawerProps {
    defaultData: HistoryDto;
    visibile:boolean;
    cancelClick: VoidCallBackFunction;
    //onClose?: () => void;
    isEdit:boolean;
}

const DetailDrawer: FC<IDetailDrawerProps> = (props) => {
    const [data, setData] = useState<any[]>();

    useEffect(() => {
        let profile: any[] = [];
        let item = { "type": "text", "key": "Node", "value": props.defaultData.Node };
        profile.push(item);
        item = { "type": "text", "key": "Tag", "value": props.defaultData.Tag };
        profile.push(item);
        item = { "type": "textarea", "key": "Request Body", "value": props.defaultData.RequestMessage };
        profile.push(item);
        item = { "type": "textarea", "key": "Response Body", "value": props.defaultData.ReponseMessage };
        profile.push(item);
        item = { "type": "text", "key": "Front API", "value": props.defaultData.FrontendName };
        profile.push(item);
        item = { "type": "text", "key": "Backend API", "value": props.defaultData.BackendName };
        profile.push(item);
        item = { "type": "text", "key": "Status", "value": props.defaultData.Status };
        profile.push(item);
        item = { "type": "text", "key": "Income Time", "value": props.defaultData.IncomeTimestamp ? convertTicksToMoment(props.defaultData.IncomeTimestamp  as number).format('YYYY-MM-DD hh:mm:ss') : "NA" };
        profile.push(item);
        item = { "type": "text", "key": "Outgo Time", "value": props.defaultData.OutgoTimestamp ? convertTicksToMoment(props.defaultData.OutgoTimestamp  as number).format('YYYY-MM-DD hh:mm:ss') : "NA" };
        profile.push(item);
        item = { "type": "text", "key": "Use Time", "value":  Math.floor((props.defaultData.OutgoTimestamp! - props.defaultData.IncomeTimestamp!)/10000)+"ms"};
        profile.push(item);


       
        setData(profile);
    }, [props.defaultData])
 

    const renderItem = (data: any[]) => {
        return (
            <>
                <Descriptions column={1} bordered>
                    {
                        data?.map((item: any) => {
                            let obj = null;
                            switch (item.type) {
                                case "text":
                                    obj = (<Descriptions.Item label={item.key}>{item.value}</Descriptions.Item>);
                                    break;
                                case "textarea":
                                    obj = (
                                        <Descriptions.Item label={item.key}>
                                            <TextArea   readOnly style={{ "height": 120 }} bordered={false} value={item.value}/>
                                        </Descriptions.Item>
                                    );
                                        break;
                                case "radio":
                                    obj = (
                                        <Descriptions.Item label={item.key}>
                                            <Radio.Group disabled options={item.data} defaultValue={item.value} />
                                        </Descriptions.Item>
                                    );
                                    break;
                                case "checkbox":
    
                                    obj = (
                                        <Descriptions.Item label={item.key}>
                                            <Checkbox.Group disabled options={item.data} defaultValue={item.value} />
                                        </Descriptions.Item>
                                    );
                                    break;
                            }
                            return obj;
                        })
                    }
                </Descriptions>
            </>
        );
    }

    return (
        <Drawer
          visible={props.visibile}
          width={720}
          onClose={props.cancelClick}
          title={"View analystic "}
          footer={
            <div style={{ textAlign: "right" }}>
              <Button type="primary" onClick={props.cancelClick}>
                Close
              </Button>
            </div>
          }
        >
          {renderItem(data!)}
        </Drawer>
      );
}
export default DetailDrawer
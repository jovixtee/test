import apiservice from '../../utils/fetchutil';
import { PagerResult } from '../../common/contracts/PagerContracts';
import {HistoryDto, TokenStore} from '../../common/contracts/ModelContracts'
const serve = apiservice();
export const PagerHistory =(params :any):Promise<PagerResult<HistoryDto>> => {
    return new Promise((res,rej)=>{
        serve.post("/IAPIManagementService/PagerHistory", params).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
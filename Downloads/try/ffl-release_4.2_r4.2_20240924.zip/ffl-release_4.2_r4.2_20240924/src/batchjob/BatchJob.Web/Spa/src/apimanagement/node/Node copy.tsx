
import React, { FC, useEffect, useState } from "react";
import { Breadcrumb, Input, Col, Row, Space, Table, Badge } from "antd";
import "./node.css";
import { QueryNodePager,StatusType } from './NodeContract';
import { NodeDetail, FrontendDto,FrontendDetailDto} from '../../common/contracts/ModelContracts';
import { ColumnsType } from "antd/lib/table/interface";
import NodeDetailDrawer from './NodeDetailDrawer';
import { PagerQueryNode,GetNodeDetailById } from './NodeApiService';


const Search = Input.Search;


const Node_1: FC = () => {

    const [dataSource, setDataSource] = useState<NodeDetail[]>(new Array<NodeDetail>());
    const [currentPageData, setCurrentPageData] = useState<any>({ currentPage: 1, currentPageSize: 10, total: 0 });
    const [nodeDetailDrawerVisible, setNodeDetailDrawerVisible] = useState<boolean>(false);
    const [viewNodeData, setViewNodedata] = useState<NodeDetail>(new NodeDetail());
    const [tableLoading, setTableLoading] = useState<boolean>(true);
    const [searchText, setSearchText] = useState<string>("");
    const tableColumn: ColumnsType<NodeDetail> = [
        {
            title: 'Host',
            dataIndex: 'Host',
        },
        {
            title: 'HostName',
            dataIndex: 'HostName',
        },
        {
            title: 'Schema',
            dataIndex: 'Schema',
        },
        {
            title: 'Port',
            dataIndex: 'Port',
        },
        {
            title: 'Status',
            dataIndex: 'Status',
            render: (_: any, record: NodeDetail) => <Badge status={"success"} text={record.Status?StatusType[record.Status]:""} />


        },
        {
            title: 'Action',
            dataIndex: 'Action',
            render: (_: any, record: NodeDetail) => <Space>
                <a onClick={() => onViewDetailClick(record)}>View Detail</a>
            </Space>
        }
    ]

    useEffect(() => {
        requestPagerQueryNode(1, searchText);
    }, [])
    const requestPagerQueryNode = (jumpPage: number, searchText: string) => {
        setTableLoading(true)
        PagerQueryNode({
            "pager": new QueryNodePager(currentPageData.currentPageSize, jumpPage, searchText)
        }).then(res => {
            setCurrentPageData({ ...currentPageData, currentPage: jumpPage, total: res.TotalNumber });
            if (res.Result) {
                setDataSource(res.Result);
            }
            setTableLoading(false)
        }).catch(err => {
            setTableLoading(false)
        })
    }

    const onSearch = (value: string): void => {
        setSearchText(value);
        requestPagerQueryNode(1, value);
    }
    const tablePageChange = (page: number, pageSize?: number | undefined): void => {
        requestPagerQueryNode(page, searchText)
    }

    const childTableColumns: ColumnsType<FrontendDetailDto> = [
        { title: 'API Name', dataIndex: 'Name', width: "30%" },
        { title: 'BaseAddress', dataIndex: 'BaseAddress' },

    ];
    const onViewDetailClick = (NodeData: NodeDetail): void => {
        GetNodeDetailById(NodeData.Id)
        .then(res=>{
        setViewNodedata(res);
        setNodeDetailDrawerVisible(true);
        })
    }
    const closeNodeDetailDrawer = (): void => {
        setNodeDetailDrawerVisible(false);
        setViewNodedata(new NodeDetail());
    }


    return <React.Fragment>

        <Breadcrumb>
            <Breadcrumb.Item>
                Node
                </Breadcrumb.Item>
        </Breadcrumb>
        <Row style={{ margin: '16px 0' }}>
            <Col span={18}>
                <Space size='small'>

                </Space>
            </Col>
            <Col span={6}>
                <Search placeholder="input search text" allowClear onSearch={onSearch} style={{ width: 200, float: 'right' }} />
            </Col>
        </Row>

        <Table
            rowKey={record => record.Id}
            dataSource={dataSource}
            columns={tableColumn}
            pagination={{
                defaultPageSize: 10,
                defaultCurrent: 1,
                total: currentPageData.total,
                pageSize: currentPageData.currentPageSize,
                onChange: tablePageChange,
                current: currentPageData.currentPage
            }}
            expandable={{
                expandedRowRender: (record) => <Table
                    rowKey="Id"
                    columns={childTableColumns}
                    dataSource={record.Frontend || []}
                    pagination={false}
                />,
                rowExpandable: (record) => (record.Frontend && record.Frontend.length > 0) ? true : false
            }}
            loading={tableLoading}
        />
        <NodeDetailDrawer
            Nodedata={viewNodeData}
            cancelClick={closeNodeDetailDrawer}
            visibile={nodeDetailDrawerVisible}

        />
    </React.Fragment>
}

export default Node_1
export class NotificationSetting {
    Id?:string;
    DisplayName?:string;
    Description?:string;
    IsDefault?:boolean;
    ProtocolType?:ProtocolType;
    ConnectionId?:string;
    OnBehalf?:string;
    CreatedOn?: number;
    CreatedBy?: string;
    ModifiedOn?: number;
    ModifiedBy?: string;
}

export class ConnectionAdapterItem {
    Id?:string;
    Name?:string;
}

export enum ProtocolType{
    Exchange = 4,
    SMTP = 5,
    Web = 6,
    Dynamics = 3,
    Dataverse = 7
}

export const ProtocolTypeMap = new Map<ProtocolType,string>([
    [ ProtocolType.Exchange,"Exchange"],
    [ ProtocolType.SMTP,"SMTP"],
    [ ProtocolType.Web,"Web"],
    [ ProtocolType.Dynamics,"Dynamics"],
    [ ProtocolType.Dataverse,"Dataverse"]
])


export enum SyncType{
    PullData = 1,
    PushData =2,
}


export const SyncTypeMap = new Map<string, SyncType>([
    ["Pull Data", SyncType.PullData],
    ["Push Data", SyncType.PushData]
])

export const PermissionConstants = {
    ObjectCode: 102001,
    Read: 1,
    Create: 2,
    Update: 4,
    Delete: 8
};


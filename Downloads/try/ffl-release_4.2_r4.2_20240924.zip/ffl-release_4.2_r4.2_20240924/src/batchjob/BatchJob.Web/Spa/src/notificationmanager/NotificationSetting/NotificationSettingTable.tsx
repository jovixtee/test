import React, { useState } from 'react';
import { PlusOutlined, EditOutlined, DeleteOutlined, CheckCircleOutlined } from '@ant-design/icons';
import { convertTicksToFormatDate } from '../../utils/dateconvert';
import { ProtocolType, NotificationSetting, PermissionConstants } from './NotificationSettingContracts';
import { DeleteNotificationSetting, NotificationSettingPagedQuery, NotifiySetDefault } from './NotificationService';
import { hasPermission } from '../../utils/permissionutil';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import NotificationDrawer from "./NotificationDrawer";
import ProfileReadDrawer from "./ProfileReadDrawer";
import AmpCommonTable, { IAmpTableButton } from '../../components/antdx/AmpCommonTable';

const NotificationSettingTable = (props: any) => {

    const [refresh, setRefresh] = useState(1);
    const [selectedRecords, setSelectedRecords] = useState<NotificationSetting[]>();

    const [visible, setVisible] = useState<boolean>(false);
    const [profileVisible, setProfileVisible] = useState<boolean>(false);

    const [id, setId] = useState<string>("");

    const columns = [
        {
            title: 'Display Name',
            key: 'DisplayName',
            dataIndex: 'DisplayName',
            sorter: true,
            ellipsis: true,
            width:"20%",
            render: (text: any, record: NotificationSetting) => <a onClick={() => viewProfile(record)}>{text}</a>

        }, {
            title: 'Description', 
            dataIndex: 'Description',
            key: 'Description',
            ellipsis: true,
            width:"20%",
        },
        {
            title: 'Is Default',
            dataIndex: 'IsDefault',
            key: 'IsDefault',
            width: '13%',
            render: (text: any, record: NotificationSetting) => {
                return <span>{record.IsDefault + ""}</span>
            }
        },
        {
            title: 'Protocol Type',
            key: 'ProtocolType',
            dataIndex: 'ProtocolType',
            width: '13%',
            sorter: true,
            render: (text: any, record: NotificationSetting) => {
                return <span>{ProtocolType[record.ProtocolType!]}</span>
            }
        },
        {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
            width: '13%',
        },
        {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            width: '13%',
            sorter: true,
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
            width: '13%'
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            width: '13%',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }];

    const viewProfile = (value: NotificationSetting) => {
        setProfileVisible(true);
        setId(value.Id!);
    }


    let addBtn = () => {
        setId("");
        setVisible(true)
    }

    let updateBtn = () => {
        setVisible(true)
        setId(selectedRecords![0].Id!);
    }

    let deleteBtn = () => {
        let ids = selectedRecords!.map(e => e.Id);
        DeleteNotificationSetting(ids).then(res => setRefresh(refresh + 1));
    }

    let defaultBtn = () => {
        let id = selectedRecords![0].Id;
        NotifiySetDefault(id!).then(e => setRefresh(refresh + 1));
    }

    const closeNotifiDrawer = (): void => {
        setVisible(false);
        setProfileVisible(false);
    }

    const handleRefresh = (): void => {
        setRefresh(refresh + 1);
    }


    const buttons: Array<IAmpTableButton> = [{
        Text: "Create",
        Primary: true,
        Icon: <PlusOutlined />,
        OnClick: addBtn,
        EnableMode: 'always',
        HasPermission: hasPermission(PermissionConstants.ObjectCode, PermissionConstants.Create)
    }, {
        Text: "Edit",
        Icon: <EditOutlined />,
        OnClick: updateBtn,
        EnableMode: 'single',
        HasPermission: hasPermission(PermissionConstants.ObjectCode, PermissionConstants.Update)
    }, {
        Text: "Delete",
        Icon: <DeleteOutlined />,
        OnClick: deleteBtn,
        EnableMode: 'multiple',
        HasPermission: hasPermission(PermissionConstants.ObjectCode, PermissionConstants.Delete)
    }, {
        Text: "Set Default",
        Icon: <CheckCircleOutlined />,
        OnClick: defaultBtn,
        EnableMode: 'single',
        HasPermission: hasPermission(PermissionConstants.ObjectCode, PermissionConstants.Create)
    }];

    const ApiPagerQuery = async (exp: PagerExpression) => {
        let result = await NotificationSettingPagedQuery(exp);
        return { total: result!.TotalNumber, records: result!.Result };
    }

    return (
        <>
            <AmpCommonTable
                Type="checkbox"
                RowKey="Id"
                Columns={columns}
                PagerQuery={ApiPagerQuery}
                OnSelectedChanged={records => setSelectedRecords(records)}
                SearchKeys={["DisplayName"]}
                Refresh={refresh}
                Buttons={buttons}
                EnableSearch />

            <NotificationDrawer
                visible={visible}
                closeDrawer={closeNotifiDrawer}
                refresh={handleRefresh}
                id={id} />
            <ProfileReadDrawer
                visible={profileVisible}
                closeDrawer={closeNotifiDrawer}
                refresh={handleRefresh}
                id={id} />
        </>
    );
};
export default NotificationSettingTable;
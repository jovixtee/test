import React, { useState, useEffect } from 'react';
import { ColumnsType } from 'antd/lib/table/interface';
import AmpCommonTable, { DatetimeColumnTemplate, IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import { hasPermission } from '../../utils/permissionutil';
import * as ReplicatorContract from '../ReplicatorContract';
import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import { GetApiService } from '../ReplicatorApiService';

const ManifestMain = () => {
    const [refresh, setRefresh] = useState(1);
    const [selectedRecords, setSelectedRecords] = useState<ReplicatorContract.ManifestDto[]>();

    const tableColumn: ColumnsType<ReplicatorContract.ManifestDto> = [
        {
            title: 'Name',
            dataIndex: 'Name',
            sorter: true
        },
        {
            title: 'Corpus Name',
            dataIndex: 'CorpusName',
            sorter: true
        },
        {
            title: 'Entity Count',
            dataIndex: 'EntityCount',
            sorter: true
        },
        {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy'
        },
        {
            title: 'Created On',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        },
        {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy'
        },
        {
            title: 'Modified On',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }
    ];

    const buttonEvents = {
        createProfileClick: () => { },
        editProfileClick: () => { },
        deleteProfileClick: () => { }
    };

    const tableEvents = {
        refreshTable: () => {
            setRefresh(refresh + 1);
        },
        onPagionationChange: (pager: PagerExpression) => {
            return GetApiService().ManifestPagerQuery(pager);
        }
    };

    const buttons: Array<IAmpTableButton> = [
        {
            Text: 'Create',
            Primary: true,
            Icon: <PlusOutlined />,
            OnClick: buttonEvents.createProfileClick,
            EnableMode: 'always',
            HasPermission: hasPermission(
                ReplicatorContract.ManifestPermissions.ObjectCode,
                ReplicatorContract.ManifestPermissions.Create
            )
        },
        {
            Text: 'Edit',
            Icon: <EditOutlined />,
            OnClick: buttonEvents.editProfileClick,
            EnableMode: 'single',
            HasPermission: hasPermission(
                ReplicatorContract.ManifestPermissions.ObjectCode,
                ReplicatorContract.ManifestPermissions.Create
            )
        },
        {
            Text: 'Delete',
            Icon: <DeleteOutlined />,
            OnClick: buttonEvents.deleteProfileClick,
            EnableMode: 'multiple',
            HasPermission: hasPermission(
                ReplicatorContract.ManifestPermissions.ObjectCode,
                ReplicatorContract.ManifestPermissions.Delete
            )
        }
    ];

    const ApiPagerQuery = async (exp: PagerExpression) => {
        const result: any = await tableEvents.onPagionationChange(exp);
        return { total: result!.Manifest!.TotalNumber, records: result!.Manifest!.Result };
    };

    return (
        <React.Fragment>
            <AmpCommonTable
                Type="checkbox"
                RowKey="Id"
                Columns={tableColumn}
                PagerQuery={ApiPagerQuery}
                OnSelectedChanged={(e: A) => setSelectedRecords(e)}
                SearchKeys={['FrontendName']}
                Refresh={refresh}
                EnableSearch
            />
        </React.Fragment>
    );
};

export default ManifestMain;

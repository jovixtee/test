import React, { useEffect, useState } from "react";
import { Button, Input, Select, Form, InputNumber, Drawer, Table, Space} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { ProtocolTypeMap} from "../NotificationSetting/NotificationSettingContracts";
const { Option } = Select;

const ManagerForm = (props: any) => {
  const emailReg = /^([A-z0-9])(\w|\-)+@[A-z0-9]+\.([A-z]{2,3})$/;
  const Columns = [
    {
      title: "Contact Number",
      dataIndex: "PhoneNumber",
      key: "PhoneNumber",
      width: "100%",
      render: (name: any, obj: any, index: any) => {
        return (
          <InputNumber type="phone" defaultValue={name} style={{ width: "100%" }} onBlur={(e) => onPhoneNumber(e.target.value, obj.id)}/>
        );
      },
    },
    {
      title: "Action",
      key: "action",
      render: (name: any, obj: any) => (
        <Button
          type="link"
          onClick={() => {
            let data = source.filter((item: any) => {
              return item.id !== obj.id;
            });
            setSource([...data]);
          }}
        >
          Delete
        </Button>
      ),
    },
  ];
  const [source, setSource] = useState<any>([]);
  const [paginationSms, setPaginationSms] = useState<any>({
    current: 1,
    pageSize: 3,
  });
  const [form] = Form.useForm();
  const onSubmit = () => {
    form.submit();
  };
  const onFinish = (values: any) => {
    if (props.EditFormData) {
      console.log("-----Edit data-------");
      props.onGetFormData(
        values,
        source,
        props.EditFormData.Id
      );
    } else {
      console.log("-----Add data-------");
      props.onGetFormData(values, null, source);
    }
  };

  useEffect(() => {
    const InitSmsProfile = () => {
      let SmsProfile = props.EditFormData.SmsProfile;
      if (SmsProfile != null && SmsProfile.Mobiles != null) {
        let array = SmsProfile.Mobiles.map((item: any, index: number) => {
          return {
            PhoneNumber: item,
            id: index,
          };
        });

        setSource([...array]);
      }
    };

    form.resetFields();
    if (props.visible && props.EditFormData) {
      form.setFieldsValue({"ProtocolType":ProtocolTypeMap.get(props.EditFormData.EmailProfile.ProtocoIType)})
      InitSmsProfile();
    }
  }, [props.visible, props.EditFormData, form]);

   
  useEffect(() => {
    if (props.EditFormData) {
      var obj = props?.EditFormData?.EmailProfile;
      form.setFieldsValue({
        ProtocolType: obj?.ProtocoIType,
      });
    } else {
      form.resetFields();
    }
  }, [form, props.visible, props.EditFormData]);
  
  const onPhoneNumber = (value: string | number | undefined, id: any) => {
    source.forEach((item: any) => {
      if (item.id === id) {
        item.PhoneNumber = value;
      }
    });
    setSource([...source]);
  };
 
  const addSmsBtn = () => {
    source.push({ PhoneNumber: null, id: source.length + 1 });
    setSource([...source]);
  };
   
  const onChangeTableSms = (
    pagination: any,
    filters: any,
    sorter: any,
    extra: any
  ) => {
    setPaginationSms(pagination);
  };

  return (
    <Drawer
      forceRender
      title={props.title}
      width={720}
      onClose={() => {
        props.onCloseFun();
      }}
      visible={props.visible}
      bodyStyle={{ paddingBottom: 80 }}
      footer={
        <div
          style={{
            textAlign: "right",
          }}
        >
          <Button onClick={onSubmit} type="primary" style={{ marginRight: 8 }}>
           
            Submit
          </Button>
          <Button
            onClick={() => {
              props.onCloseFun();
            }}
          >
            Cancel
          </Button>
        </div>
      }
    >
      <Form
        onFinish={onFinish}
        form={form}
        layout="vertical"
        initialValues={props.EditFormData}
      >
        <Form.Item
          name="Name"
          label="Display Name"
          rules={[{ required: true, message: "Display Name is required!" }]}
        >
          <Input />
        </Form.Item>
        <Form.Item name="Description" label="Description">
          <Input.TextArea />
        </Form.Item>

        <Form.Item
          label="Connection Type"
          name="ProtocolType"
          rules={[{ required: true, message: "Please choice connection type" }]}
        >
          <Select placeholder="Please select Connection Type" >
            {Array.from(ProtocolTypeMap).map(([key, value]) => (
              <Option value={key} key={key}>
                {value}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item name="SMS">
          <div>
            <Space size="small" style={{ float: "left" }}>
              <span>Contact</span>
            </Space>
            <Space size="small" style={{ float: "right" }}>
              <Button type="text" onClick={addSmsBtn}>
                <PlusOutlined
                  style={{
                    fontSize: "1rem",
                    fontWeight: "bold",
                    color: "green",
                  }}
                />
                Add
              </Button>
            </Space>
            <Table
              columns={Columns}
              dataSource={source}
              pagination={paginationSms}
              onChange={onChangeTableSms}
              rowKey="id"
            ></Table>
          </div>
        </Form.Item>
        
      </Form>
    </Drawer>
  );
};
export default ManagerForm;

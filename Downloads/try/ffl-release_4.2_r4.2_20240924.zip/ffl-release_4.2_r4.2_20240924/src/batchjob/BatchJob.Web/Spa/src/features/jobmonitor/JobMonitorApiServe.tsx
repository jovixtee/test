import { PagerExpression } from "../../common/contracts/PagerContracts";
import apiservice from "../../utils/fetchutil";
import {
  JobManagerServiceResult,
  GlobalTypeEnum,
  GlobalSettings,
} from "./JobContract";

const serve = apiservice();
export const PagerQueryJob = (
  pagerExp: PagerExpression
): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/PagerQueryJob", { pagerExpression: pagerExp })
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
export const TryStopJob = (params: any): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/TryStopJob", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
export const TryPauseJob = (params: any): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/TryPauseJob", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
export const TryResumeJob = (params: any): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/TryResumeJob", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
export const DeleteJobs = (params: any): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/DeleteJobs", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
export const DownloadJobDetails = (
  params: any
): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/DownloadJobDetails", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
export const PagerQueryJobDetail = (
  params: any
): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/PagerQueryJobDetail", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
export const RerunJob = (params: any): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/RerunJob", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
export const GetJobDetailCustomColumns = (params: any): Promise<any> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/GetJobDetailCustomColumns", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export const GetSettingsByGlobalType = (
  params: any
): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/GetSettingsByGlobalType", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};
export const AddSettings = (params: any): Promise<JobManagerServiceResult> => {
  return new Promise((resolve, reject) => {
    serve
      .post("/IJobManagerService/AddSettings", params)
      .then((result) => {
        resolve(result);
      })
      .catch((error) => {
        reject(error);
      });
  });
};

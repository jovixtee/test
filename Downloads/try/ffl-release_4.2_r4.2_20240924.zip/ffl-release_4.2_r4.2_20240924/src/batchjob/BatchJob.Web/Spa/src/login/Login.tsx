import React, { useState } from 'react';
import { Divider, Button, Tabs, Form, Checkbox, Input, Layout } from 'antd';
import apiservice from '../utils/fetchutil';
import { APMOidcUserManager } from '../context/UserContext';
import PathConfig from '../common/PathConfig';
import './login.css';
import Base64  from 'base-64';
const Login = (props: { onLogined: () => void }) => {
    return (
        <>
            <Layout style={{ height: '100%', minWidth: '900px', minHeight: '800px' }} >
                <Layout.Sider width="50%" id="left" style={{ paddingTop: '10%' }}>
                    <div id="form_formbaselogin">
                        <h1 style={{ font: 'normal normal 600 46px/62px Segoe UI' }}>Sign in</h1>
                        <Tabs>
                            <Tabs.TabPane tab="FormBased" key="1">
                                <FormBasedLoginForm onLogined={props.onLogined} />
                            </Tabs.TabPane>
                            <Tabs.TabPane tab="ADFS" key="2" disabled={true}>
                                <ADFSLoginForm />
                            </Tabs.TabPane>
                        </Tabs>
                        <Divider plain style={{ margin: '0' }} >or</Divider>
                        <Button id="btn_apmlogin" style={{ marginTop: '24px' }} className="loginpage_input" onClick={() => APMOidcUserManager.signinRedirect()}>Login with APM</Button>
                    </div>
                </Layout.Sider>
                <Layout style={{ minWidth: '650px' }}>
                    <Layout.Header id="right_header">
                        <img height='100%' alt="" src={PathConfig.addPrefix('/login-right.svg')} />
                    </Layout.Header>
                    <Layout.Content id="right_content">
                        <img height="140%" alt="" src={PathConfig.addPrefix('/login-middle.svg')} />
                    </Layout.Content>
                    <Layout.Footer id="right_footer">
                        <img height='100%' alt="" src={PathConfig.addPrefix('/login-left.svg')} />
                    </Layout.Footer>
                </Layout>
            </Layout>
        </>
    );
};


const FormBasedLoginForm = (props: { onLogined: () => void }) => {
    const [loading, setLoading] = useState(false);
    const doLogin = async (values: any) => {
        var password = Base64.encode(values.Password);
        await ApiLogin({ UserName: values.Username, Password:password});
    };
    const ApiLogin = (passportDto: { UserName: string, Password: string }): Promise<any> => {
        setLoading(true);

        return new Promise((resolve, reject) => {
            apiservice().post("/IPassportService/FormBasedLogin", passportDto,
                { headers: { 'Content-Type': 'application/x-www-form-urlencoded', }, }
            ).then((result) => {
                setLoading(false);
                if(result.Type === 0){
                    props.onLogined();
                }else{
                    alert(result.Message)
                }
                resolve(result)
            }).catch(error => {
                setLoading(false);
                !error && alert('Username or Password is incorrect.')
                reject(error?.toString())
            })
        })
    }
    return (<>
        <Form layout='vertical' onFinish={doLogin}>
            <Form.Item className="loginpage_input" name="Username" label="Username" rules={[{ required: true, message: "Please input your username." }]}>
                <Input />
            </Form.Item>
            <Form.Item className="loginpage_input" name="Password" label="Password" rules={[{ required: true, message: "Please input your password." }]}>
                <Input type="password" />
            </Form.Item>
            <Form.Item name="RememberMe">
                <div>
                    <Checkbox>Remember me</Checkbox>
                </div>
            </Form.Item>
            <Form.Item>
                <Button className="loginpage_input" type='primary' htmlType='submit' loading={loading}>Sign in</Button>
            </Form.Item>
        </Form>
    </>);
}


const ADFSLoginForm = () => {
    return (<></>);
}

export default Login;

import React, { FC } from 'react';
import { Table } from 'antd';
import { ColumnsType } from "antd/lib/table";
import {ViewVersion} from '../../common/contracts/ModelContracts';

interface IViewVersionTableProps {
    versionData: ViewVersion[]  | undefined;
}

const ViewVersionTable: FC<IViewVersionTableProps> = (props) => {

    const columns: ColumnsType<ViewVersion> = [
        { title: 'API name', dataIndex: 'ApiName', width: '22%' },
        { title: 'API URL suffix', dataIndex: 'Suffix', width: '27%' },
        { title: 'Web service URL', dataIndex: 'ServicceUrl', width: '27%' },
        { title: 'Version', dataIndex: 'Version', width: '24%' }
    ];

    

    return <React.Fragment>
        <Table
            rowKey={(record) => record.Id}
            columns={columns}
            dataSource={props.versionData || []}
            pagination={false}
        />
    </React.Fragment>

}
export default ViewVersionTable


import "./APIsContent.css";
import APIsList from "./APIsList";
import APIsDesign from "./APIsDesign";
import { GetAllApis, DeleteVersion, CloneVerison } from './APIsService';
import { Layout, Tabs, Spin } from 'antd';
import React, { FC, useEffect, useState } from "react";
import { APIsMenuDto } from '../../common/contracts/ModelContracts';
import APIsSetting from "./APIsSetting";
import APIVersionSetting from "./APIVersionSetting";
import CreateBlankAPIDrawer from "./CreateBlankAPIDrawer";
import CreateOpenAPIDrawer from "./CreateOpenAPIDrawer";
import BlankAPIContent from "./BlankAPIContent";


const { TabPane } = Tabs;
const { Sider } = Layout;

const APIsContent: FC = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const [blankVisible, setBlankVisible] = useState<boolean>(false);
    const [openVisible, setOpenVisible] = useState<boolean>(false);
    const [showSetting, setShowSetting] = useState<number>(0);
    const [allApis, setAllApis] = useState<APIsMenuDto[]>([]);
    const [openKeys, setOpenKeys] = useState<string>("");
    const [selectedKeys, setSelectedKeys] = useState<string>("");
    const [activeTabKey, setActiveTabKey] = useState<string>("1");
    useEffect(() => {
        handleGetAllApis("");
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const handleGetAllApis = (searchText: string) => {
        setLoading(true);
        GetAllApis(searchText).then(res => {
            if (res && res.length > 0) {
                setShowSetting(1);
            } else {
                setShowSetting(3);
            }
            setAllApis(res);
            setDefaultKey(res);
        }).finally(() => setLoading(false));
    }

    const handleDeleteVersion = (id: string) => {
        setLoading(true);
        DeleteVersion(id).then(res => {
            handleGetAllApis("");
        }).finally(() => setLoading(false));
    }


    const setDefaultKey = (data: APIsMenuDto[]) => {
        if (selectedKeys && selectedKeys.length > 0) {
            return;
        }
        for (let i = 0; i < data.length; i++) {
            let api = data[i];
            let version = data[i].Versions;
            if (version.length > 0) {
                setOpenKeys(api.Id || "");
                setSelectedKeys(version[0].Id || "");
                break;
            }
        }
    }



    const closeBlankDrawer = (): void => {
        setBlankVisible(false);
    }

    const closeOpenDrawer = (): void => {
        setOpenVisible(false);
    }

    const onSearchAPI = (searchText: string): void => {
        handleGetAllApis(searchText);
    }

    //version click
    const menuItemClick = (item: any) => {
        //setVersionId(item.key);
        setSelectedKeys(item.key);
        setShowSetting(1);
        setActiveTabKey("1");
    }

    //api click
    const titleClick = (item: any) => {
        setOpenKeys(item.key);
        //setFrontendId(item.key);
        setShowSetting(2);
    }

    const onCloneVersion = (id: string) => {
        CloneVerison(id).then(e => handleGetAllApis("")).finally(() => setLoading(false));
    }

    const onDeleteVersion = (id: string) => {
        handleDeleteVersion(id);
    }

    const onOpenBlank = () => {
        setBlankVisible(true);
    }

    const onOpenAPI = () => {
        setOpenVisible(true);
    }

    const onRefresh = () => {
        handleGetAllApis("");
    }

    const setTableIndex = (index:string) => {
        setActiveTabKey(index)
    }

  
    return (
        <>
            <Spin spinning={loading}>
                <Layout className="api-main">
                    <Sider width={260} style={{ background: 'white' }}>
                        {
                            <APIsList
                                title="All APIs"
                                data={allApis}
                                onOpenBlank={onOpenBlank}
                                onOpenAPI={onOpenAPI}
                                menuItemClick={menuItemClick}
                                onTitleClick={titleClick}
                                onSearchAPI={onSearchAPI}
                                onDeleteVersion={onDeleteVersion}
                                onCloneVersion={onCloneVersion}
                                openKeys={openKeys}
                                selectedKeys={selectedKeys}
                            />
                        }
                    </Sider>
                      <Layout hidden={showSetting===0} style={{height:'100%'}}>
                        <Tabs activeKey={activeTabKey} hidden={[2, 3].indexOf(showSetting) > -1} style={{ marginLeft: "24px" }} onTabClick={(key)=>setActiveTabKey(key)}>
                            <TabPane tab="Design" key="1">
                                <APIsDesign id={selectedKeys} />
                            </TabPane>
                            <TabPane tab="Settings" key="2">
                                <APIVersionSetting refReshApi={handleGetAllApis} setTableIndex={setTableIndex} id={selectedKeys} />
                            </TabPane>
                            <TabPane tab="Test" key="3" disabled />
                        </Tabs>


                        <APIsSetting
                            Id={openKeys}
                            refReshApi={handleGetAllApis}
                            hidden={[1, 3].indexOf(showSetting) > -1} />

                        <BlankAPIContent hidden={[1, 2].indexOf(showSetting) > -1} />

                    </Layout>  
                </Layout>
            </Spin>
            <CreateBlankAPIDrawer
                closeDrawer={closeBlankDrawer}
                onRefresh={onRefresh}
                blankVisible={blankVisible}
            />

            <CreateOpenAPIDrawer
                closeDrawer={closeOpenDrawer}
                onRefresh={onRefresh}
                openVisible={openVisible}
            />
        </>
    );
}


export default APIsContent;
import React, { useEffect, useImperativeHandle, forwardRef } from "react";
import { Input, Form } from "antd";
import * as ReplicatorContract from '../ReplicatorContract';

interface ICorpusFormProps {
  nextIsSuccess:Function;
  dataSource?:ReplicatorContract.CorpusDto
}

const CorpusForm = (props: ICorpusFormProps, ref: any) => {
  const [form] = Form.useForm();

  useEffect(() => {
     if(props.dataSource){
       form.setFieldsValue({
            DisplayName:props.dataSource.DisplayName,
            Description:props.dataSource.Description
       });
     }
  }, [form,props.dataSource]);


  useImperativeHandle(ref, () => ({
    onNext: () => {
      form.submit();
    },
  }));
  const onFinish = async (values: ReplicatorContract.CorpusDto) => {
    let corpus = new ReplicatorContract.CorpusDto();
    if(props.dataSource){
      corpus.Id = props.dataSource.Id;
    }
    corpus.DisplayName = values.DisplayName;
    corpus.Description = values.Description;
    props.nextIsSuccess(true,corpus);
  };
  const onFinishFailed = (errorInfo: any) => {
    props.nextIsSuccess(false, "");
  };

  return (
    <Form
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      form={form}
      layout="vertical"
    >
      <Form.Item
        name="DisplayName"
        label="Display name"
        rules={[{ required: true, message: "Please input display name" }]}
      >
        <Input />
      </Form.Item>
     
      <Form.Item name="Description" label="Description">
        <Input.TextArea />
      </Form.Item>
    </Form>
  );
};
export default forwardRef(CorpusForm);

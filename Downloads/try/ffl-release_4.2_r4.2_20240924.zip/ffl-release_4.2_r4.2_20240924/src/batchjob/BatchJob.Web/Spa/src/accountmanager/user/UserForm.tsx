import React, { useEffect, useState } from 'react';
import { Button, Input, Select, Form, Collapse, Drawer, Radio, message } from 'antd';
import { IFormPros } from './Interface';
import { QueryRoleAll } from './UserApiServe';
const { Option } = Select;
// const prefixSelector = (
//     <Form.Item name="prefix" noStyle initialValue="86"   >
//         <Select style={{ width: 70 }}>
//             <Option value="86">+86</Option>
//             <Option value="87">+87</Option>
//         </Select>
//     </Form.Item>
// );
// const layout = {
//     labelCol: { span: 6 },
//     wrapperCol: { span: 16 },
// };

const UserForm = (props: IFormPros) => {
    const [visible, setVisible] = useState<any>(false);
    const [days] = useState<any>();
    const [roleArr, setRoleArr] = useState<any>([]);
    const [form] = Form.useForm();
    const onSubmit = () => {
        form.submit();
    }
    const onFinish = (values: any) => {
        props.onGetFormData({ ...values, ...{ days } })
    };
    const onGenderChange = (value: any) => {
        switch (value) {
            case '1':
                form.setFieldsValue({ DisplayName: 'FormBased' });
                return;
            case '2':
                form.setFieldsValue({ DisplayName: 'ADJira' });
                return;
            case '3':
                form.setFieldsValue({ DisplayName: 'ADJiraIntegration' });
                return;
        }
    };
    // const changeRadio = (obj: any) => {
    //     if (obj.target.value === 'Customized') {
    //         setVisible(true)
    //     } else if (obj.target.value === 'Default') {
    //         setVisible(false)
    //     }
    // }
    // const onChangeDays = (value: any) => {
    //     console.log(value)
    //     setDays(value)
    // }
    useEffect(() => {
        getInitRole()
    }, [])
    useEffect(() => {
        form.resetFields()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.visible])

    const getInitRole = async () => {
        try {
            let result = await QueryRoleAll()
            if (result.Result) {
                setRoleArr(result.Result)
            }
        } catch (error) {
            setRoleArr([])
        }

    }
    const changeUserRole = (obj: any) => {
        if (obj.target.value === 1) {
            setVisible(false)
        } else if (obj.target.value === 2) {
            setVisible(true)
        }
    }
    return (
        <Drawer
            forceRender
            title="Add user"
            width={720}
            onClose={() => { props.onCloseFun() }}
            visible={props.visible}
            bodyStyle={{ paddingBottom: 80 }}
            footer={
                <div
                    style={{
                        textAlign: 'right',
                    }}
                >
                    <Button onClick={onSubmit} type="primary" style={{ marginRight: 8 }}> Submit</Button>
                    <Button onClick={() => { props.onCloseFun() }} >Cancel</Button>
                </div>
            }
        >
            <Form
                onFinish={onFinish}
                form={form}
                layout="vertical"
            >
                <Form.Item name="Authentication" label="Authentication" rules={[{ required: true }]} initialValue="1">
                    <Select onChange={onGenderChange} getPopupContainer={triggerNode => triggerNode.parentNode} >
                        <Option value='1'>Form Based</Option>
                    </Select>
                </Form.Item>
                <Collapse defaultActiveKey={['1']} style={{ marginTop: '24px' }}>
                    <Collapse.Panel header="Configure user information" key="1">
                        <Form.Item
                            name="DisplayName"
                            label="Display Name"
                            rules={[{ required: true, message: 'Display Name is required!' }]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="Email"
                            label="E-mail"
                            rules={[
                                {
                                    type: 'email',
                                    message: 'The input is not valid E-mail!',
                                },
                                {
                                    required: true,
                                    message: 'Please input your E-mail!',
                                },
                            ]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="Description"
                            label="Description"
                        >
                            <Input.TextArea />
                        </Form.Item>
                    </Collapse.Panel>
                </Collapse>
                <Collapse defaultActiveKey={['1']} style={{ marginTop: '24px' }}>
                    <Collapse.Panel header="Configure security settings" key="1">

                        <Form.Item
                            name="Username"
                            label="User Name"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your User Name',
                                },
                                {
                                    pattern: new RegExp(/^\S*$/),
                                    message: 'A username can\'t contain space!',
                                }
                            ]}
                        >
                            <Input autoComplete="off"/>
                        </Form.Item>
                        <Form.Item
                            name="Password"
                            label="Password"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your password!',
                                },
                                {min:8, message:"At least 8 bits."},
                                {
                                    pattern:/^(?=.*\d)(?=.*[a-zA-Z])(?=.*[~!@#.$%^&*])[\da-zA-Z~!@#.$%^&*]{8,}$/,
                                    message:"must contain three or more types:uppercase letters,lowercase letters,numbers,special characters"
                                }
                            ]}
                            hasFeedback
                        >
                            <Input.Password autoComplete="off"/>
                        </Form.Item>
                        <Form.Item
                            name="confirm"
                            label="Confirm Password"
                            dependencies={['Password']}
                            hasFeedback
                            rules={[
                                {
                                    required: true,
                                    message: 'Please confirm your password!',
                                },
                                ({ getFieldValue }) => ({
                                    validator(rule, value) {
                                        if (!value || getFieldValue('Password') === value) {
                                            return Promise.resolve();
                                        }
                                        return Promise.reject('The two passwords that you entered do not match!');
                                    },
                                }),
                            ]}
                        >
                            <Input.Password />
                        </Form.Item>

                    </Collapse.Panel>
                </Collapse>
                {/* <Form.Item
                            name="PasswordSetting"
                            label="Password Setting"
                            initialValue='Default'
                        >
                            <Radio.Group onChange={changeRadio}>
                                <Radio value="Default">Default</Radio>
                                <Radio value="Customized">Customized</Radio>
                            </Radio.Group>

                        </Form.Item>
                        <Form.Item
                            name="checkbox"
                            wrapperCol={{ offset: 6, span: 16 }}

                        >
                            <Checkbox.Group disabled={!visible}>
                                <Checkbox value="A" style={{ marginLeft: '0px' }}>
                                    User must change password at next logon
                                </Checkbox>
                                <Checkbox value="B" style={{ marginLeft: '0px' }}>
                                    The password cannot be changed according to the account password policy. Contact the administrator for help.
                                </Checkbox>
                                <Checkbox value="C" style={{ marginLeft: '0px' }}>
                                    <span>Password is valid for</span><InputNumber onChange={onChangeDays} style={{ width: 100 }} /><span>days</span>
                                </Checkbox>
                            </Checkbox.Group>
                        </Form.Item> */}
                <Form.Item
                    name="UserRole"
                    label="User Role"
                    initialValue={1}
                    style={{ marginTop: '24px' }}
                >
                    <Radio.Group onChange={changeUserRole}>
                        <Radio value={1}>Owner</Radio>
                        <Radio value={2}>Member</Radio>
                    </Radio.Group>

                </Form.Item>
                {
                    visible && <Form.Item name="PermissionLevels" label="PermissionLevels" >
                        <Select
                            allowClear
                            placeholder="select permission level"
                            mode='multiple'
                        >
                            {roleArr.map((item: any) => {
                                return <Option key={item.RoleId} value={item.RoleId}>{item.Name}</Option>
                            })}

                        </Select>
                    </Form.Item>
                }
            </Form>


        </Drawer>

    )

}



export default UserForm;
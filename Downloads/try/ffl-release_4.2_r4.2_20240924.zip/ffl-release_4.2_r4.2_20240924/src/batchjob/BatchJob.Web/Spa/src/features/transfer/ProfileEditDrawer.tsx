import { Button, Collapse, Drawer, Form, Input, Select, Upload ,message} from "antd";
import React, { useEffect, useState } from "react";
import * as TransferContrat from './TransferContract';
import { GetApiService } from './TransferApiService';
import { ConnectionAdapterDto } from "../connections/ConnectionContract";
import { UploadOutlined } from "@ant-design/icons";
import { UploadFile } from "antd/lib/upload/interface";

interface IProfileEditDrawerProps {
    visible: boolean;
    onSave: Function;
    onCancel: Function;
    profileDto?: TransferContrat.TransferProfileDto
}

export const ProfileEditDrawer = (props: IProfileEditDrawerProps) => {

    const [profileFrom] = Form.useForm();
    const [mappingDbs, setMappingDbs] = useState<Array<ConnectionAdapterDto>>([]);
    const [adapters, setAdapters] = useState<Array<ConnectionAdapterDto>>([]);
    const [srcAdapters, setSrcAdapters] = useState<Array<ConnectionAdapterDto>>([]);
    const [destAdapters, setDestAdapters] = useState<Array<ConnectionAdapterDto>>([]);
    const [actions, setActions] = useState<Array<TransferContrat.TransferActionDto>>([]);
    const [selectedAction, setSelectedAction] = useState<TransferContrat.TransferActionDto>({});

    const [documentService, setDocumentService] = useState<Array<ConnectionAdapterDto>>([]);


    useEffect(() => {
        GetApiService().GetTransferResources().then(result => {
            if (result.MappingDatabases) {
                setMappingDbs(result.MappingDatabases!);
            }
            if (result.Adapters) {
                setAdapters(result.Adapters!);
            }

            if (result.TransferActions) {
                setActions(result.TransferActions!);
            }
            if (result.DocumentService) {
                setDocumentService(result.DocumentService)
            }
        });
    }, []);

    useEffect(() => {
        if (props.profileDto?.Id) {
            const files = [];
            if (props.profileDto.DataSyncXmlName) {
                files.push({ name: props.profileDto.DataSyncXmlName });
            }
            profileFrom.setFieldsValue({
                Name: props.profileDto.Name,
                ActionId: props.profileDto.ActionId!,
                MappingDb: props.profileDto.MappingDBId!,
                MappingXml: files,
            });
            onActionChanged(props.profileDto?.ActionId);
            profileFrom.setFieldsValue({
                SourceConnection: props.profileDto.SourceAdapterId!,
                DestConnection: props.profileDto.DestinationAdapterId!,
                DocumentService: props.profileDto.DocumentServiceId!
            });
        } else {
            setSelectedAction({});
            profileFrom.resetFields();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.profileDto, profileFrom]);
    const beforeUpload = (file: any, FileList: UploadFile[]) => {
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isLt2M) {
            message.error("file must smaller than 2MB!");
            return false;
        }  
        return true;
    };
    const onFinish = (values: any) => {
        const getConnectionName = (id: string): string => {
            return adapters.find(a => a.Id === id)?.AdapterName!;
        }
        const getDocumentName = (id: string): string => {
            return documentService.find(a => a.Id === id)?.AdapterName!;
        }
        let profile: TransferContrat.TransferProfileDto = {
            Name: values.Name,
            ActionId: values.ActionId,
            SourceAdapterId: values.SourceConnection,
            SourceAdapterName: getConnectionName(values.SourceConnection),
            DestinationAdapterId: values.DestConnection,
            DestinationAdapterName: getConnectionName(values.DestConnection),
            MappingDBId: values.MappingDb,
            MappingDBName: getConnectionName(values.MappingDb),
            DocumentServiceId: values.DocumentService,
            DocumentServiceName: getDocumentName(values.DocumentService),
        };

        let file = undefined;
        if (values.MappingXml && values.MappingXml.length > 0) {
            profile.DataSyncXmlName =  values.MappingXml[0].name;
            file = values.MappingXml[0].originFileObj;
        }

        if (props.profileDto?.Id) {
            profile.Id = props.profileDto.Id;
            GetApiService().UpdateTransferProfile(profile, file).then(r => props.onSave(profile.Name));
        } else {
            GetApiService().CreateTransferProfile(profile, file).then(r => props.onSave(profile.Name));
        }

    }

    const onActionChanged = (value: any) => {
        if (value) {
            const item = actions.find(a => a.Id === value);
            setSelectedAction(item ?? {});

            const src = adapters.filter(ad => ad.AdapterType === item?.SourceType);
            setSrcAdapters(src ?? new Array<TransferContrat.TransferActionDto>());

            const dest = adapters.filter(ad => ad.AdapterType === item?.DestType);
            setDestAdapters(dest ?? new Array<TransferContrat.TransferActionDto>());
        }
    }

    const normFile = (e: any) => {
        if (Array.isArray(e)) {
            return e;
        }
        return e && e.fileList;
    };

    return (<Drawer visible={props.visible} width={720} onClose={(e) => props.onCancel()}
        title={props.profileDto?.Id ? "Edit profile" : "Create a new profile"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button onClick={(e) => props.onCancel()} style={{ marginRight: '8px' }} >Cancel</Button>
                <Button type="primary" onClick={() => profileFrom.submit()}>Save</Button>
            </div>
        }>
        <Form form={profileFrom} onFinish={onFinish} style={{ marginTop: '16px' }} layout="vertical" >
            <Form.Item label="Profile Name" name="Name"
                rules={[{ required: true, message: 'Please input profile name!' }]}>
                <Input />
            </Form.Item>
            <Form.Item label="Action" name="ActionId" rules={[{ required: true, message: 'Please select an action.' }]}>
                <Select placeholder="Select One" 
                        showSearch
                        onChange={onActionChanged}  
                        filterOption={(input:any, option:any) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }>
                    {actions.map((item) => (
                        <Select.Option key={item.Id} value={item.Id as string} label={item.Name}>
                            {item.Name}
                        </Select.Option>
                    ))}
                </Select>
            </Form.Item>
            <Collapse defaultActiveKey={['1']}>
                <Collapse.Panel header="Action Description" key="1">
                    <p>{selectedAction.Name}</p>
                </Collapse.Panel>
            </Collapse>
            <Form.Item label="Source Connection" name="SourceConnection" rules={[{ required: false }]}>
                <Select placeholder="Select One" allowClear>
                    {srcAdapters.map((item) => (
                        <Select.Option key={item.Id} value={item.Id as string} label={item.AdapterName}>
                            {item.AdapterName}
                        </Select.Option>
                    ))}
                </Select>
            </Form.Item>
            <Form.Item label="Destination Connection" name="DestConnection" rules={[{ required: true, message: 'Please select a connection.' }]}>
                <Select placeholder="Select One" allowClear>
                    {destAdapters.map((item) => (
                        <Select.Option key={item.Id} value={item.Id as string} label={item.AdapterName}>
                            {item.AdapterName}
                        </Select.Option>
                    ))}
                </Select>
            </Form.Item>
            <Form.Item label="Mapping Database" name="MappingDb" rules={[{ required: false }]}>
                <Select placeholder="Select One" allowClear>
                    {mappingDbs.map((item) => (
                        <Select.Option key={item.Id} value={item.Id as string} label={item.AdapterName}>
                            {item.AdapterName}
                        </Select.Option>
                    ))}
                </Select>
            </Form.Item>

            <Form.Item label="Web Service" name="DocumentService" rules={[{ required: false }]}>
                <Select placeholder="Select One" allowClear>
                    {documentService.map((item) => (
                        <Select.Option key={item.Id} value={item.Id as string} label={item.AdapterName}>
                            {item.AdapterName}
                        </Select.Option>
                    ))}
                </Select>
            </Form.Item>

            <Form.Item label="Mapping Xml File" name="MappingXml" valuePropName="fileList" getValueFromEvent={normFile}>
                <Upload multiple={false} accept={'.xml'} maxCount={1} beforeUpload={beforeUpload}>
                    <Button icon={<UploadOutlined />}>Click to upload</Button>
                </Upload>
            </Form.Item>
        </Form>
    </Drawer>)
};
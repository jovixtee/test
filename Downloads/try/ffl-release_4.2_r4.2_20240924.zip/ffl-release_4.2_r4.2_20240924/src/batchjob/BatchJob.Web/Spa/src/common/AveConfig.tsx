import * as LSUtil from '../utils/localstorageutil';
interface IAveConfig {
    API_URL: () => string;
    LOGO:() => string;
    OIDC_AUTHORITY: () => string;
    OIDC_CLIENTID: () => string;
    OIDC_REDIRECTURL: () => string;
    OIDC_SCOPE: () => string;
    OIDC_RESPONSE_TYPE: () => string;
    LOCAL: () => boolean;
    VERSION:() => string;
}

// function apiConfig(): IApiConfig {
//     let w = (window as any);
//     const config: IApiConfig = {
//         aveConfig: w.ave,
//         dbpRequestUrl: () => {
//             return w.ave.DBP_URL;
//         }
//     }
//     return config;
// }
// export default apiConfig;



class AveJsConfig implements IAveConfig {
    private w: any;


    constructor() {
         this.load();
    }
     
    private load =() =>  {
        let local = (window as any).ave.LOCAL;
        if(local){
            this.w = (window as any).ave;
        }else{
            this.w = LSUtil.getItem("env-config");
        }
        return this.w;
    }
　/**
 * import form /public/index.html
 * <script src="/public/env-config.js"></script> 
 * @returns api request URL
 * use fetchutil.tsx
 */
    public API_URL = () => this.load()?.API_URL;
    public OIDC_AUTHORITY = () => this.load()?.OIDC_AUTHORITY;
    public OIDC_CLIENTID = () => this.load()?.OIDC_CLIENTID;
    public OIDC_REDIRECTURL = () => this.load()?.OIDC_REDIRECTURL;
    public OIDC_SCOPE = () => this.load()?.OIDC_SCOPE;
    public OIDC_RESPONSE_TYPE = () => this.load()?.OIDC_RESPONSE_TYPE;
    public LOGO = () => this.load()?.LOGO;
    public VERSION = () => this.load()?.VERSION;
    public LOCAL = ():boolean => {
        return (window as any).ave.LOCAL;
    };
}

const AveConfig = new AveJsConfig();
export default AveConfig;
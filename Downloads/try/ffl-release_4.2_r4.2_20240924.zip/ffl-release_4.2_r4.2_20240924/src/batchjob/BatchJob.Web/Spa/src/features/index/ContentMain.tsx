import React, { FC } from "react";
import { Switch, Route, Redirect } from "react-router-dom";
import asyncComponent from "../../components/AsyncComponent";
import PathConfig from '../../common/PathConfig';



const Home = asyncComponent(() => import("../home/Home"));
const TaskLayout = asyncComponent(() => import("../taskmanager/TaskLayout"));
const JobMonitor = asyncComponent(() => import("../jobmonitor/JobMonitorLayout"));
const User = asyncComponent(() => import("../../accountmanager/user/User"));
const Group = asyncComponent(() => import("../../accountmanager/group/Group"));
const HolidaySetting = asyncComponent(() => import("../holidaysetting/HolidaySetting"));
const PermissionLevel = asyncComponent(() => import("../../accountmanager/permissionLevel/PermissionLevel"));
const Connections = asyncComponent(() => import("../connections/Connections"));
const Authentication = asyncComponent(() => import("../../accountmanager/authentication/Authentication"));
const SecurityPolicy = asyncComponent(() => import("../../securitymanager/securitypolicy/SecurityPolicy"));
const NotificationManager = asyncComponent(() => import("../../notificationmanager/Recipients/RecipientsTable"));
const NotificationSetting = asyncComponent(() => import("../../notificationmanager/NotificationSetting/NotificationSettingTable"));
const TransferMain = asyncComponent(() => import("../transfer/TransferMain"));
//const EmailServerSetting = asyncComponent(() => import("../../notificationmanager/OutgoingEmailSetting/OutgoingEmailSetting"));
const Node = asyncComponent(() => import("../../apimanagement/node/Node"));
const AnalysticReport = asyncComponent(() => import("../../apimanagement/analysticreport/AnalysticReport"));
const APIAuthentication = asyncComponent(() => import("../../apimanagement/apiauthentication/APIAuthentication"));
const BackendAPI = asyncComponent(() => import("../../apimanagement/backendapi/BackendAPI"));
const ControlPolicy = asyncComponent(() => import("../../apimanagement/controlpolicy/ControlPolicy"));
const FrontendAPI = asyncComponent(() => import("../../apimanagement/frontendapi/FrontendAPI"));
const APIsContent = asyncComponent(()=>import("../../apimanagement/apis/APIsContent"));
const DataPiplineMain = asyncComponent(() => import("../../replicator/replicatorpipeline/ReplicatorPiplineMain"));
const ContentMain: FC = () => {
    return (
        <div style={{ position: "relative",height:'100%' }}>
            <Switch>
                <Route exact path={PathConfig.addPrefix("/home")} component={Home} />
                <Route path={PathConfig.addPrefix("/taskmanager")} component={TaskLayout} />
                <Route path={PathConfig.addPrefix("/jobmonitor")} component={JobMonitor} />
                <Route path={PathConfig.addPrefix("/transfer/profile")} component={TransferMain} />
                <Route path={PathConfig.addPrefix("/home/account/user")} component={User} />
                <Route path={PathConfig.addPrefix("/connections")} component={Connections} />
                <Route path={PathConfig.addPrefix("/home/account/Group")} component={Group} />
                <Route path={PathConfig.addPrefix("/home/account/permission")} component={PermissionLevel} />
                <Route path={PathConfig.addPrefix("/holidaysetting")} component={HolidaySetting} />
                <Route path={PathConfig.addPrefix("/home/account/authentication")} component={Authentication} />
                <Route path={PathConfig.addPrefix("/home/security/securitypofile")} component={SecurityPolicy} />
                <Route path={PathConfig.addPrefix("/home/Recipients/RecipientsManager")} component={NotificationManager} />
                {/* <Route path={PathConfig.addPrefix("/home/Recipients/EmailServerSetting")} component={EmailServerSetting} /> */}
                <Route path={PathConfig.addPrefix("/home/apimanagement/node")} component={Node} />
                <Route path={PathConfig.addPrefix("/home/apimanagement/APIsContent")} component={APIsContent} />
                <Route path={PathConfig.addPrefix("/home/apimanagement/backendapi")} component={BackendAPI} />
                <Route path={PathConfig.addPrefix("/home/apimanagement/frontendapi")} component={FrontendAPI} />
                <Route path={PathConfig.addPrefix("/home/apimanagement/apiauthentication")} component={APIAuthentication} />
                <Route path={PathConfig.addPrefix("/dataPipeline/main")} component={DataPiplineMain} />
		<Route path={PathConfig.addPrefix("/home/apimanagement/controlpolicy")} component={ControlPolicy} />
                <Route path={PathConfig.addPrefix("/home/apimanagement/analysticreport")} component={AnalysticReport} />
                <Route path={PathConfig.addPrefix("/home/Recipients/NotificationSetting")} component={NotificationSetting} />
                <Redirect exact from="/" to={PathConfig.addPrefix("/home")} />

            </Switch>
        </div>
    );
};
export default ContentMain;
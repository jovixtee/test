import { Button, Descriptions, Drawer } from "antd";
import React, { useEffect, useState } from "react";
import * as TransferContrat from './TransferContract';
import { GetApiService } from './TransferApiService';

interface IProfileReadDrawerProps {
    visible: boolean;
    onClose: Function;
    profileDto: TransferContrat.TransferProfileDto
}

export const ProfileReadDrawer = (props: IProfileReadDrawerProps) => {
    const [actions, setActions] = useState<Array<TransferContrat.TransferActionDto>>([]);

    useEffect(() => {
        GetApiService().GetTransferResources().then(result => {
            if (result.TransferActions) {
                setActions(result.TransferActions!);
            }
        });
    }, []);

    const download = (filename:string, text:string) =>{
        var element = document.createElement('a');
        element.setAttribute('href', 'data:text/xml;charset=utf-8,' + encodeURIComponent(text));
        element.setAttribute('download', filename);
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
      }

      
 
    return (<Drawer visible={props.visible} width={720} onClose={(e) => props.onClose()}
        title={"View profile"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" onClick={(e) => props.onClose()} >Close</Button>
            </div>
        }>
        <Descriptions column={1} bordered>
            <Descriptions.Item label="Profile Name">{props.profileDto.Name}</Descriptions.Item>
            <Descriptions.Item label="Action">{actions.find(a => a.Id === props.profileDto.ActionId)?.Name}</Descriptions.Item>
            <Descriptions.Item label="Source Connection">{props.profileDto.SourceAdapterName}</Descriptions.Item>
            <Descriptions.Item label="Destination Connection">{props.profileDto.DestinationAdapterName}</Descriptions.Item>
            <Descriptions.Item label="Mapping Database">{props.profileDto.MappingDBName}</Descriptions.Item>
            {
                props.profileDto!.DataSyncXmlName! &&
                <>
                    <Descriptions.Item label="Mapping Xml File"><a onClick={ ()=>download(props.profileDto.DataSyncXmlName!,props.profileDto.DataSyncXml!)}>{props.profileDto.DataSyncXmlName}</a></Descriptions.Item>
                </>
            }
            <Descriptions.Item label="Web Service">{props.profileDto.DocumentServiceName}</Descriptions.Item>
        </Descriptions>
    </Drawer>)
};
import React, { FC, useState } from "react";
import { Button, Space } from "antd";
import { PermissionConstants } from './AnalysticReportContract';
import { HistoryDto } from '../../common/contracts/ModelContracts';
import { ColumnsType } from "antd/lib/table/interface";
import DetailDrawer from './DetailDrawer';
import { PagerHistory } from './AnalysticReportApiService';
import { convertTicksToMoment } from "../../utils/dateconvert";
import { ReloadOutlined } from '@ant-design/icons';
import AmpCommonTable, { IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import { hasPermission } from '../../utils/permissionutil';

const AnalysticReport: FC = () => {
    const [isEditMode, setIsEditMode] = useState<boolean>(false);
    const [manageAPIDrawerVisible, setManageAPIDrawerVisible] = useState<boolean>(false);
    const [apiDrawerDefaultData, setApiDrawerDefaultData] = useState<HistoryDto>(new HistoryDto());
    const [refresh, setRefresh] = useState(1);
    const [selectRecords, setSelectRecords] = useState<HistoryDto[]>([]);

    const tableColumn: ColumnsType<HistoryDto> = [
        {
            title: 'Host',
            dataIndex: 'Node',
            sorter:true
        },
        {
            title: 'Tag',
            dataIndex: 'Tag',
            sorter:true
        },
        {
            title: 'Frontend API',
            dataIndex: 'FrontendName',
            sorter:true
        },
        {
            title: 'Backend API',
            dataIndex: 'BackendName',
            sorter:true
        },
        {
            title: 'Status',
            dataIndex: 'Status',
            sorter:true
        },
        {
            title: 'Start Time',
            dataIndex: 'IncomeTimestamp',
            sorter:true,
            render: (_: any, record: HistoryDto) => record.IncomeTimestamp && record.IncomeTimestamp !== 0 ? convertTicksToMoment(record.IncomeTimestamp as number).format('YYYY-MM-DD hh:mm:ss') : "NA"
        },
        {
            title: 'Use time',
            render: (_: any, record: HistoryDto) => Math.floor((record.OutgoTimestamp! - record.IncomeTimestamp!)/10000)+"ms"
        },
        {
            title: 'Action',
            dataIndex: 'Action',
            render: (text, record) => <Space size="middle">
                <Button type="link" onClick={() => { createLinkEvent(record) }}>Detail</Button>
            </Space>
        },
    ]

    const createLinkEvent = (record: HistoryDto): void => {
        setIsEditMode(true);
        setApiDrawerDefaultData(record);
        setManageAPIDrawerVisible(true);
    }

    const closeLinkDrawer = (): void => {
        setManageAPIDrawerVisible(false);
    }

    const buttons: Array<IAmpTableButton> = [
        {
            Text: "Refresh",
            Primary: true,
            Icon: <ReloadOutlined />,
            OnClick: () => { setRefresh(refresh + 1) },
            EnableMode: 'always',
            HasPermission: hasPermission(PermissionConstants.ObjectCode, PermissionConstants.Delete)
        }
    ];

    const ApiPagerQuery = async (exp: PagerExpression) => {
        let param = { pager: { ...exp } }
        let result = await PagerHistory(param);
        return { total: result!.TotalNumber, records: result!.Result };
    }

    return <React.Fragment>
        <AmpCommonTable
            Type="checkbox"
            RowKey="Id"
            Columns={tableColumn}
            PagerQuery={ApiPagerQuery}
            OnSelectedChanged={e=>setSelectRecords(e)}
            SearchKeys={["FrontendName"]}
            Refresh={refresh}
            Buttons={buttons}
            EnableSearch />
       
        <DetailDrawer
            visibile={manageAPIDrawerVisible}
            cancelClick={closeLinkDrawer}
            isEdit={isEditMode}
            defaultData={apiDrawerDefaultData}
        />
    </React.Fragment>
}

export default AnalysticReport
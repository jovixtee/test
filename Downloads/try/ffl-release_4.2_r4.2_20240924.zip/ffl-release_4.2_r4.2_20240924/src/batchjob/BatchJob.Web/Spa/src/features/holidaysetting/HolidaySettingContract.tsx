import { PagerResult } from '../../common/contracts/PagerContracts';

export interface HolidaySettingServiceResult {
    ProfileId?: string;
    Profile?: HolidaySettingProfile;
    Profiles?: Array<HolidaySettingProfile>;
    ProfileOperationResult?: boolean;
    PagingProfiles?: PagerResult<HolidaySettingProfile>;
    TimeZoneInfos?: TimeZoneInfoDto;
    Holidays?: Array<Holiday>;
    SingleHoliday?: Holiday;
    Holiday?: HolidayDto;
    HolidayOperationResult?: boolean;
    // PagingHolidays ?:Dictionary;
    // public Dictionary<int, List<Holiday>> PagingHolidays { get; set; }
    ContainsSunday?: boolean;
}

export interface HolidaySettingProfile extends HolidayProfileBase {
    TimeZoneDisplayName?: string;
    WorkdayDisplaynames?: string;
    HolidaysNumber?: string;
    Description?: string;
    VersionId?: string;
    CreatedBy?: string;
    ModifiedBy?: string;
    CreatedOn?: number;
    ModifiedOn?: number;
    Holidays?: Array<string>;
    AccessScope?: string;
    // HolidaySettingProfile ?:
    // public HolidaySettingProfile()
    //     {
    //         Holidays = new List<string>();
    //     }
}
export interface TimeZoneInfoNode {
    TimeZoneId?: string;
    TimeZoneDisplayName?: string;
    StandardName?: string;
    SupportsDaylightSavingTime?: boolean;
}

export interface TimeZoneInfoDto {
    TimeZones?: Array<TimeZoneInfoNode>;
    Local?: TimeZoneInfoNode;
    // public TimeZoneInfoDto()
    // {
    //     TimeZones = new List<TimeZoneInfoNode>();
    //     Local = new TimeZoneInfoNode();
    // }
}

export interface Holiday extends HolidayDto {
    TimeZoneInfoId?: string;
    ModifiedBy?: string;
    CreatedBy?: string;
    ModifiedOn?: number;
    CreatedOn?: number;
    Dates?: Array<HolidayDate>;
    // DateTimes?: Array<DateTime>;
    // public Holiday()
    // {
    //     Dates = new List<HolidayDate>();
    //     DateTimes = new List<DateTime>();
    // }
}

export interface HolidaySettingResult {
    // NextUtcDate ?:DateTime;
    Duration?: number;
    IsWorkday?: boolean;
    DateType?: DayType;
    Profiles?: Array<HolidaySettingProfile>;
    Holidays?: Array<Holiday>;
    // HolidaySettingResult ?:
}

export interface HolidayDate {
    Year?: number;
    Month?: number;
    Day?: number;
    Index?: number;
}


export enum DataType {
    Once = 0,
    Monthly = 1,
    Yearly = 2
}
export enum Workday {

    Sunday = 1,

    Monday = 2,

    Tuesday = 4,

    Wednesday = 8,

    Thursday = 16,

    Friday = 32,

    Saturday = 64
}
export enum DayType {

    Workday = 1,

    Weekend = 2,

    Holiday = 4
}
export interface HolidayProfileBase {
    ProfileId?: string;
    OrganizationName?: string;
    TimeZoneInfoId?: string;
    Connection?: string;
    BusinessUnit?: string;
    Workdays?: number;
}
export interface HolidayDto {
    Id?: string;
    Name?: string;
    Description?: string;
    Profile?: string;
    Type?: number;
    Holidays?: Array<HolidayDateRange>
}


export interface HolidayDateRange {
    CurrentYear?: string;
    CurrentStartMonth?: string;
    CurrentStartDay?: string;
    CurrentEndMonth?: string;
    CurrentEndDay?: string;
    Index?: number;
    Id?: string;
}

export interface PagingInfo {
    Start?: DateInfo;
    End?: DateInfo;
    Current?: DateInfo;
}

export interface DateInfo {
    Year?: number;
    Month?: number;
    Day?: number;
}
export enum ScheduleDay {
    Day_1 = 1,
    Day_2 = 2,
    Day_3 = 3,
    Day_4 = 4,
    Day_5 = 5,
    Day_6 = 6,
    Day_7 = 7,
    Day_8 = 8,
    Day_9 = 9,
    Day_10 = 10,
    Day_11 = 11,
    Day_12 = 12,
    Day_13 = 13,
    Day_14 = 14,
    Day_15 = 15,
    Day_16 = 16,
    Day_17 = 17,
    Day_18 = 18,
    Day_19 = 19,
    Day_20 = 20,
    Day_21 = 21,
    Day_22 = 22,
    Day_23 = 23,
    Day_24 = 24,
    Day_25 = 25,
    Day_26 = 26,
    Day_27 = 27,
    Day_28 = 28,
    Day_29 = 29,
    Day_30 = 30,
    Day_31 = 31
};

export enum ScheduleMonth {
    January = 1,
    February = 2,
    March = 3,
    April = 4,
    May = 5,
    June = 6,
    July = 7,
    August = 8,
    September = 9,
    October = 10,
    November = 11,
    December = 12
};

const HolidayPermissionConstants = {
    ObjectCode: 203001,
    Read: 1,
    Create: 2,
    Update: 4,
    Delete: 8
};
export {
    HolidayPermissionConstants
};
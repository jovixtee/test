import { Drawer, Input, Button, Row, Col, Space, Table, Typography, Tag } from 'antd';
import React, { FC, useEffect, useState } from 'react';
import { VoidCallBackFunction, FrontendAPIVersionMethodDetail, VersionMethodParameter, QueryFrontendMethodPager, FromType, MethodTypeEnum, IPaginationC, IDictionary, VersionthodTypeMap } from './FrontendAPIContracts';
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons';
import { ColumnsType } from 'antd/lib/table';
import ManageMethodDrawer from './ManageMethodDrawer';
import ImportAPIModel from './ImportAPIModel';
import { GetParameterByFrontendID, PagerMethodByVersionId, DeleteMethods, GetMethodById } from './FrontendAPIApiService';

interface IDesignMethodDrawerProps {
    visibile: boolean;
    cancelClick: VoidCallBackFunction;
    versionId: string;
    apiId: string;
}

const Search = Input.Search;
const { Text } = Typography;


const DesignMethodDrawer: FC<IDesignMethodDrawerProps> = (props) => {

    const [selectMethodKey, setSelectMethodKey] = useState<React.Key[]>([]);
    const [dataSource, setDatasource] = useState<FrontendAPIVersionMethodDetail[]>(new Array<FrontendAPIVersionMethodDetail>());
    const [currentPageData, setCurrentPageData] = useState<IPaginationC>({ currentPage: 1, currentPageSize: 10, total: 0 });
    const [searchText, setSearchText] = useState<string>("");
    const [isEditMode, setIsEditMode] = useState<boolean>(false);
    const [manageMethodDrawerVisible, setManageMethodDrawerVisible] = useState<boolean>(false);
    const [methodDrawerData, setMethodDrawerData] = useState<FrontendAPIVersionMethodDetail>(new FrontendAPIVersionMethodDetail());

    const [importAPIModelVisible, setImportAPIModelVisible] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);
    const [parmData, setParmData] = useState<Map<string, string>>(new Map());

    const tableColumn: ColumnsType<FrontendAPIVersionMethodDetail> = [
        {
            title: 'Path',
            dataIndex: 'Path',
            render: (_: any, record: FrontendAPIVersionMethodDetail) => record.MethodName ? <React.Fragment><Tag color="#87d068">{MethodTypeEnum[record.MethodName]}</Tag>{record.Path}</React.Fragment> : record.Path
        },
        {
            title: 'Action',
            dataIndex: 'Action',
            render: (_: any, record: FrontendAPIVersionMethodDetail) => <Space size="middle">
                <Button type='link' onClick={() => { onEditMethodClick(record) }}>Edit</Button>
                <Button type='link' onClick={() => { requestDeleteMethods([record.Id]) }}>Delete</Button>
            </Space>
        }
    ]

    useEffect(() => {
        if (props.visibile) {
            initData()
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.versionId, props.visibile])
    const initData = (): void => {

        setLoading(true);
        GetParameterByFrontendID(props.apiId)
            .then(res => {
                let ParamTypeData: IDictionary[] = res.ParamType || [];
                let ParamTypeDataMap = new Map<string, string>();
                ParamTypeData.forEach(item => {
                    ParamTypeDataMap.set(item.key as string, item.value as string)
                })
                setParmData(ParamTypeDataMap);
                reqeustPagerMethodByVersionId(1, searchText)
            })
            .catch(err => {
                reqeustPagerMethodByVersionId(1, searchText)
            })

    }



    const onSearch = (value: string): void => {
        setSearchText(value)
        reqeustPagerMethodByVersionId(1, value);

    }

    const requestDeleteMethods = (Ids: string[]): void => {
        setLoading(true);
        DeleteMethods(Ids, FromType.Frontend)
            .then(res => {
                reqeustPagerMethodByVersionId(1, searchText);
            })
            .catch(err => {
                setLoading(false);

            })

    }
    const reqeustPagerMethodByVersionId = (jumpPage: number, searchText: string) => {
        if (props.versionId) {
            setLoading(true);
            PagerMethodByVersionId({
                "pager": new QueryFrontendMethodPager(currentPageData.currentPageSize, jumpPage, searchText, props.versionId)
            }).then(res => {
                setCurrentPageData({ ...currentPageData, currentPage: jumpPage, total: res.TotalNumber });
                console.log(res)
                if (res.Result) {
                    setDatasource(res.Result);
                }
                setLoading(false)
            }).catch(err => {
                setLoading(false)
            })
        }
    }

    const onDeleteMethodsClick = (): void => {
        requestDeleteMethods([...selectMethodKey as string[]])

    }

    const tablePageChange = (page: number, pageSize?: number | undefined): void => {
        reqeustPagerMethodByVersionId(page, searchText);

    }

    const conversionHeaderString = (headerString: string): IDictionary[] => {
        let defaultArray = [{ key: "Content-Type", value: "" }];
        let header: IDictionary[] = headerString ? JSON.parse(headerString) : defaultArray;
        let result: IDictionary[] = [];
        if (!Array.isArray(header)) {
            header = defaultArray
        }
        header.forEach(item => {
            if (item.hasOwnProperty('key') && item.hasOwnProperty('value')) {
                if (!(typeof (item["key"]) == 'string')) {
                    item["key"] = JSON.stringify(item["key"]);
                }
                if (!(typeof (item["value"]) == 'string')) {
                    item["value"] = JSON.stringify(item["value"]);
                }
                result.push(item)
            }
        });
        return result
    }
    const MethodDetail = (record: FrontendAPIVersionMethodDetail) => {
        const methodDetailColumns: ColumnsType<VersionMethodParameter> = [
            {
                title: 'Name',
                dataIndex: 'Key',
            },
            {
                title: 'Type',
                dataIndex: 'Type',
                render: (_: any, record: VersionMethodParameter) => record.ParamterTypeID ? parmData.get(record.ParamterTypeID) : ""
            },
            {
                title: 'Value',
                dataIndex: 'DefaultValue',
            }
        ]

        return <React.Fragment>
            <Row style={{ marginBottom: 10 }}>
                <Col span={4}> <Text strong>Type: </Text></Col>
                <Col span={20}><div style={{ marginLeft: "47px" }}>{record.MethodName ? MethodTypeEnum[record.MethodName] : ""}</div></Col>
            </Row>
            <Row style={{ marginBottom: 10 }}>
                <Col span={4}><Text strong>Header: </Text></Col>
                <Col span={20}><div style={{ marginLeft: "47px" }}>
                    {record.Header ? conversionHeaderString(record.Header).map(({ key, value }, index) => (
                        <div key={index}>
                            <Row style={{ marginBottom: 10 }}>
                                <Col span={6}><Text strong>{key}: </Text></Col>
                                <Col span={18}><div>{value}</div></Col>
                            </Row>
                        </div>

                    )) : "Not have Header"}
                </div></Col>
            </Row>
            <Row style={{ marginBottom: 10 }}>
                <Col span={4}><Text strong>Method Type: </Text></Col>
                <Col span={20}><div style={{ marginLeft: "47px" }}>{Array.from(VersionthodTypeMap).find(([key, value]) => value === record.MethodType)?.[0]}</div></Col>
            </Row>
            <Row style={{ marginBottom: 10 }}>
                <Col span={4}><Text strong>Path: </Text></Col>
                <Col span={20}><div style={{ marginLeft: "47px" }}>{record.Path}</div></Col>
            </Row>
            <Row>
                <Col span={4}><Text strong>Parameter: </Text></Col>
                <Col span={20}>
                    <Table
                        rowKey={record => record.Id}
                        columns={methodDetailColumns}
                        dataSource={record.param}
                        pagination={false}
                    />
                </Col>
            </Row>

        </React.Fragment>
    }


    const onAddMethodClick = (): void => {
        setIsEditMode(false);
        setMethodDrawerData(new FrontendAPIVersionMethodDetail())
        setManageMethodDrawerVisible(true);


    }
    const onEditMethodClick = (methodRecord: FrontendAPIVersionMethodDetail): void => {
        //console.log(apiId,versionRecord)
        GetMethodById(methodRecord.Id)
            .then(res => {
                if (res) {
                    setIsEditMode(true);
                    setMethodDrawerData(res);
                    setManageMethodDrawerVisible(true);
                }
            })
            .catch(err => {

            })

    }

    const closeManageMethodsDrawer = (): void => {
        setManageMethodDrawerVisible(false);
        setMethodDrawerData(new FrontendAPIVersionMethodDetail())
    }

    const openImportAPIModel = () => {
        setImportAPIModelVisible(true)
    }
    const closeImportAPIModel = () => {
        setImportAPIModelVisible(false)
    }
    const closeDrawer = (): void => {
        props.cancelClick();
        setParmData(new Map());
        setLoading(false);
        setDatasource([]);

    }



    return <Drawer
        visible={props.visibile}
        width={720}
        destroyOnClose
        onClose={closeDrawer}
        title={"Design Version Methods"}
    >
        <Row style={{ margin: '16px 0' }}>
            <Col span={18}>
                <Space size='small'>
                    <Button type="text" onClick={onAddMethodClick} disabled={loading} ><PlusOutlined />Create</Button>
                    <Button type='text' disabled={selectMethodKey.length === 0} icon={<DeleteOutlined />} onClick={onDeleteMethodsClick}>Delete</Button>
                    <Button type="text" onClick={openImportAPIModel} disabled={loading} ><PlusOutlined />Import Method</Button>
                </Space>
            </Col>
            <Col span={6}>
                <Search placeholder="input search text" allowClear onSearch={onSearch} style={{ width: 200, float: 'right' }} />
            </Col>
        </Row>


        <Table
            rowKey={record => record.Id}
            dataSource={dataSource}
            loading={loading}
            columns={tableColumn}
            pagination={{
                defaultPageSize: 10,
                defaultCurrent: 1,
                total: currentPageData.total,
                pageSize: currentPageData.currentPageSize,
                onChange: tablePageChange,
                current: currentPageData.currentPage
            }}
            rowSelection={{
                selectedRowKeys: selectMethodKey,
                type: "checkbox",
                onChange: (selectedRowKeys: React.Key[]) => {
                    setSelectMethodKey(selectedRowKeys)
                }
            }}

            expandable={{
                expandedRowRender: (record) => MethodDetail(record)

            }}

        />
        <ManageMethodDrawer
            cancelClick={closeManageMethodsDrawer}
            isEdit={isEditMode}
            visible={manageMethodDrawerVisible}
            defaultData={methodDrawerData}
            versionId={props.versionId}
            parmData={parmData}
            apiId={props.apiId}
            getTableData={() => { reqeustPagerMethodByVersionId(1, searchText) }}
        />
        <ImportAPIModel
            visible={importAPIModelVisible}
            onCancel={closeImportAPIModel}
            getTableData={() => { initData() }}
            apiId={props.apiId}
            versionId={props.versionId}
        />

    </Drawer>
}
export default DesignMethodDrawer
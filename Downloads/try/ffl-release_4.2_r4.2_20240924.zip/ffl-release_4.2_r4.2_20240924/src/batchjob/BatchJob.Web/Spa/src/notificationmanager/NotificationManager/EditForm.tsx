import React, { Component, useEffect, useState } from 'react';
import { Button, Input, Checkbox, Select, Form, InputNumber, Drawer, Radio, Table } from 'antd';



const { Option } = Select;


const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 16 },
};

const ManagerForm = (props: any) => {
    const emailColumns = [
        {
            title: 'Report Type',
            dataIndex: 'DisplayName',
            key: 'DisplayName',
            sorter: true,
            width: '15%',
            render: (name: any, obj: any, index: any) => {
                return (<Select>
                    <Option key={1} value={1}>11</Option>
                    <Option key={1} value={1}>22</Option>
                </Select>)
            },
        }, {
            title: 'E-mail Address',
            dataIndex: 'DisplayName',
            key: 'DisplayName',
            sorter: true,
            width: '15%',
            render: (name: any, obj: any, index: any) => {
                return (<Input></Input>)
            },
        }]
    const smsColumns = [
        {
            title: 'Notification Name',
            dataIndex: 'DisplayName',
            key: 'DisplayName',
            sorter: true,
            width: '100%',
            render: (name: any, obj: any, index: any) => {
                return (<InputNumber style={{ width: '100%' }}></InputNumber>)
            },
        }]
    const [roleArr, setRoleArr] = useState<any>([]);
    const [address, setAddress] = useState<any>(1);
    const [form] = Form.useForm();
    const onSubmit = () => {
        form.submit();
    }
    const onFinish = (values: any) => {
        props.onGetFormData({ ...values })
    };
    useEffect(() => {
        getInitRole()
    }, [])
    useEffect(() => {
        form.resetFields()
    }, [props.visible])

    const getInitRole = async () => {
        try {
            // let result = await QueryRoleAll()

        } catch (error) {
            setRoleArr([])
        }

    }
    const changeAddress = (obj: any) => {
        setAddress(obj.target.value)
    }
    return (
        <Drawer
            forceRender
            title="New Recipients Profile"
            width={720}
            onClose={() => { props.onCloseFun() }}
            visible={props.visible}
            bodyStyle={{ paddingBottom: 80 }}
            footer={
                <div
                    style={{
                        textAlign: 'right',
                    }}
                >
                    <Button onClick={onSubmit} type="primary" style={{ marginRight: 8 }}> Submit</Button>
                    <Button onClick={() => { props.onCloseFun() }} >Cancel</Button>

                </div>
            }
        >
            <Form
                onFinish={onFinish}
                form={form}
                {...layout}
            >
                <Form.Item
                    name="DisplayName"
                    label="Display Name"
                    rules={[{ required: true, message: 'Display Name is required!' }]}
                >
                    <Input />
                </Form.Item>
                <Form.Item
                    name="description"
                    label="Description"
                >
                    <Input.TextArea />
                </Form.Item>
                <Form.Item
                    name="UserRole"
                    label="User Role"
                    initialValue={1}
                >
                    <Radio.Group onChange={changeAddress}>
                        <Radio value={1}>E-mail</Radio>
                        <Radio value={2}>SMS</Radio>
                    </Radio.Group>

                </Form.Item>

                {
                    address === 1 ?
                        <Form.Item name="PermissionLevels" label="E-mail" >

                            <Table
                                columns={emailColumns}
                            ></Table>
                        </Form.Item> :
                        <Form.Item name="PermissionLevels" label="SMS" >
                            <Table
                                columns={smsColumns}
                            ></Table>
                        </Form.Item>

                }
            </Form>
        </Drawer>

    )

}
export default ManagerForm;
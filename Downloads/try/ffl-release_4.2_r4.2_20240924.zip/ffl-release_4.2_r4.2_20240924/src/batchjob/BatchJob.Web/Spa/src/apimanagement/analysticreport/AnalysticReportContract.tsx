import { FilterCondition, PagerExpression } from '../../common/contracts/PagerContracts';

export interface VoidCallBackFunction {
    (): void
}

export class Pager implements PagerExpression {
	PageSize: number = 10;
	JumpPage: number;
	IsSort?: boolean;
	IsDesc?: boolean;
	SortBy?: string;
	CurrentPage?: number;
	SearchValue?: string;
	SearcheKeys?: Array<string>;
	Filters?: FilterCondition[];
	constructor(pageSize: number, jumpPage: number,
		SortBy: string,
		SearchValue: string,
		SearcheKeys: Array<string>,
		Filters: FilterCondition[]) {
		this.PageSize = pageSize
		this.JumpPage = jumpPage;
		this.SortBy = SortBy;
		this.SearchValue = SearchValue;
		this.SearcheKeys = SearcheKeys;
		this.Filters = Filters;
	}
}

export class QueryReportPager extends Pager {
	constructor(pageSize: number, jumpPage: number, SearchValue: string) {
		super(
			pageSize,
			jumpPage,
			"Method",
			SearchValue, ["Method"],
			[]
		)
	}
}

export const PermissionConstants = {
    ObjectCode: 102001,
    Read: 1,
    Create: 2,
    Update: 4,
    Delete: 8
};
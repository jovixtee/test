
import apiservice from '../../utils/fetchutil';
const serve = apiservice()
export const GetDefaultSecurityProfile = (): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/ISecuritySetting/GetDefaultSecurityProfile").then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const UpdateSecurityProfile = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/ISecuritySetting/UpdateSecurityProfile", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
import React, { useState } from "react";
import { Table} from 'antd';
import PermissionLevelMainForm from './PermissionLevelMainForm';
import { convertTicksToFormatDate } from '../../utils/dateconvert';
import { QueryRoleDetail } from './permissionLevelApiServe';
import { ProfileReadDrawer } from './ProfileReadDrawer';

const PermissionLevelTable = (props: any) => {
    const columns = [
        {
            title: 'Permission Level Name',
            dataIndex: 'Name',
            key: 'Name',
            sorter: true,
            width: '24%',
            ellipsis: true,
            render: (name: any, obj: any, index: any) => <a onClick={() => editSourceBtn(obj)}>{name}</a>,
        }, {
            title: 'Description',
            dataIndex: 'Description',
            key: 'Description',
            ellipsis: true,
            width: '12%'
        }, {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
            width: '13%'
        }, {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            width: '13%',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
            width: '13%'
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            width: '25%',
            render: (text: number) => {
                return <span>{convertTicksToFormatDate(text, 'YYYY-MM-DD HH:mm:ss')}</span>
            }
        }];
    let EditGeneralFormData = {};
    let UserId: object[] = [];
    const [visible, setVisible] = useState<any>(false);
    const [drawerText, setDrawerText] = useState<string>('');
    const [EditFormData, setEditFormData] = useState<any>({});
    const [showReadonlyDrawer, setShowReadonlyDrawer] = useState(false);

    // const [readonlyProfile, setReadonlyProfile] = useState<props.EditFormData>({});
    // const viewProfile = (record: props.EditFormData) => {
    //     setReadonlyProfile(record);
    //     setShowReadonlyDrawer(true);
    // }
    
    let editSourceBtn  = async (obj: any) =>  {
        let result = await QueryRoleDetail({RoleId: obj.RoleId })
        setEditFormData({ ...result.Result });
        // if (EditFormData.Users) {
        //     let users = EditFormData.Users.map((item: any) => {
        //         return item.UserId
        //         console.log(item.UserId)
        //     })
        //     setUser({EditFormData})
        // }
        setShowReadonlyDrawer(true);
    }
    const [pagination, setPagination] = useState<any>({
        current: 1,
        //defaultPageSize: 10,
        pageSize: 10,
        pageSizeOptions: [1, 5, 8, 10, 15, 20, 50],
        showQuickJumper: true,
        //showSizeChanger: true,
    });
    const [selectedRowKeys, setSelectedRowKeys] = useState<any>([]);
    // const QueryDetail = async (obj: any) => {
    //     let result = await QueryRoleDetail({ RoleId: obj.RoleId })
    //     console.log(result.Result)
    //     setEditFormData({ ...result.Result });
    //     setVisible(true)
    //     setDrawerText('Edit Permission Level')
    // }
    const loadPagination = (result: any) => {
        result.total = props.totalNumber
        return result
    }
    const onChangeTable = (pagination: any, filters: any, sorter: any, extra: any) => {
        setPagination(pagination)
        props.getTableChange(pagination, filters, sorter, extra)
    }
    const rowSelection = {
        selectedRowKeys,
        onChange: (selectedRowKeys: any, selectedRows: any) => {
            setSelectedRowKeys(selectedRowKeys)
            props.func(selectedRows)
        },
    };
    const onCloseFun = () => {
        setVisible(false)
    }

    const getEditAssignFormData = (userId: string[]) => {
        console.log(userId)
        UserId = userId.map((value) => {
            return {
                UserId: value
            }
        })
    }
    const getEditGeneralFormData = (values: any) => {
        EditGeneralFormData = values
        console.log(values)
    }
    const getEditLevelFormData = async (values: any) => {
        props.getEditFormData(Object.assign(values, EditGeneralFormData, { UserId: UserId }))
        setVisible(false)
    };
    return (
        <>
            <Table
                rowSelection={{ type: 'checkbox', ...rowSelection }}
                onChange={onChangeTable}
                columns={columns}
                dataSource={props.dataSource}
                rowKey='RoleId'
                pagination={loadPagination(pagination)}
                loading={props.tabLoading}
            // footer={() => { return <Row><Col span={6}>{`${props.selectLength} of ${props.dataSource.length} selected`}</Col></Row> }}
            >
            </Table>
                     
            {showReadonlyDrawer&&<ProfileReadDrawer visible={showReadonlyDrawer} profileDto={EditFormData} onClose={() => setShowReadonlyDrawer(false)}/>}

            <PermissionLevelMainForm text={drawerText} EditFormData={EditFormData} onCloseFun={onCloseFun} visible={visible}
                onLevelFormData={getEditLevelFormData}
                onGeneralData={getEditGeneralFormData}
                onAssignFormData={getEditAssignFormData}
            ></PermissionLevelMainForm>
        </>
    );
};

export default PermissionLevelTable;
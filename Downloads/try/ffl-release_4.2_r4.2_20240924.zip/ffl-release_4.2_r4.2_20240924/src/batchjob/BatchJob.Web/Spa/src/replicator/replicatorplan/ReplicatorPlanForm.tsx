import React, { useEffect, useImperativeHandle, forwardRef,useState } from "react";
import { Input, Form, Select, TreeSelect,Cascader } from "antd";
import * as ReplicatorContract from "../ReplicatorContract";
import {} from "antd";
import { GetApiService } from "../ReplicatorApiService";
import { DataNode } from "antd/lib/tree";
import { AdapterType, ConnectionAdapterDto } from "../../features/connections/ConnectionContract";
interface IReplicatorPlanForm {
  onNextAddMapping:Function;
  dataSource?:ReplicatorContract.ReplicatorPlan
}


const ReplicatorPlanForm = (props: IReplicatorPlanForm, ref: any) => {
  const [form] = Form.useForm();
  const [treeData, setTreeData] = useState<DataNode[]>([]);
  const [connectionTree, setConnectionTree] = useState<any[]>([]);
  const [adapters, setAdapters] = useState<Array<ConnectionAdapterDto>>([]);
  const [dbAdapters, setDBAdapters] = useState<Array<ConnectionAdapterDto>>([]);

  const getConnectionName = (id: string): string => {
    return adapters.find(a => a.Id === id)?.AdapterName!;
  }
  useImperativeHandle(ref, () => ({
    onNext: () => {
      form.submit();
    },
  }));

  useEffect(() => {
    if(props.dataSource){
      form.setFieldsValue({
           DisplayName:props.dataSource.DisplayName,
           Description:props.dataSource.Description,
           DBAdapterId:props.dataSource.DBAdapterId,
           //SourceAdapterId:props.dataSource.SourceAdapterId,
           //TargetAdapterId:props.dataSource.TargetAdapterId,
           SourceDocumentId:props.dataSource.SourceDocumentId,
           TargetDocumentId:props.dataSource.TargetDocumentId
      });
    }
 }, [form,props.dataSource]);


  useEffect(() => {
    GetApiService().GetReplicatorResources().then((result) => {
      if(result.TreeData){
        setTreeData(result.TreeData);
      }
      if (result.Adapters) {
        let adapters = result.Adapters;
        setAdapters(adapters);

        const db = adapters.filter(ad => ad.AdapterType === AdapterType.SQLServer);
        setDBAdapters(db ?? []);
        let data:any[] = [];
        ReplicatorContract.AdapterTypeMap.forEach((title,key) => {
          let children = adapters.filter(ad => ad.AdapterType === key).map(e=>{
              return {label : e.AdapterName,value:e.Id!, children:[]}
          });
          let item:any ={  value: key,  label : title, children:children,disabled:children.length === 0}
          data.push(item);
        });
        setConnectionTree(data);
      }
    });
}, []);



  const onFinish = async (values: ReplicatorContract.ReplicatorPlan) => {
    let plan = new ReplicatorContract.ReplicatorPlan();
    plan.DisplayName = values.DisplayName;
    plan.Description = values.Description;
    plan.DBAdapterId = values.DBAdapterId;
    plan.DBAdapterName = getConnectionName(values.DBAdapterId!);
    plan.SourceAdapterId = values.SourceAdapterId![1];
    plan.SourceAdapterName = getConnectionName(values.SourceAdapterId![1]);
    plan.TargetAdapterId = values.TargetAdapterId![1];
    plan.TargetAdapterName = getConnectionName(values.TargetAdapterId![1]);
    plan.SourceDocumentId = values.SourceDocumentId;
    plan.TargetDocumentId =values.TargetDocumentId;
    props.onNextAddMapping(true, plan);
  };
  const onFinishFailed = (errorInfo: any) => {
    props.onNextAddMapping(false, "");
  };

  

  return (
    <Form
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      form={form}
      layout="vertical"
    >
      <Form.Item
        name="DisplayName"
        label="DisplayName"
        rules={[{ required: true, message: "Please input display name" }]}
      >
        <Input />
      </Form.Item>

      <Form.Item name="Description" label="Description">
          <Input.TextArea />
      </Form.Item>
      
      <Form.Item
        label="Database"
        name="DBAdapterId"
        rules={[{ required: true, message: "Please select a connection." }]}
      >
        <Select placeholder="Select One" allowClear>
            {dbAdapters.map((item) => (
              <Select.Option key={item.Id} value={item.Id as string} label={item.AdapterName}>
                  {item.AdapterName}
              </Select.Option>
            ))}
        </Select>
      </Form.Item>

      <Form.Item
        label="Target connection"
        name="TargetAdapterId"
        rules={[{ required: true, message: "Please select a target connection." }]}
      >
        <Cascader
            allowClear
            options={connectionTree}
            placeholder="Please select"
          />
      </Form.Item>

      <Form.Item
        label="Source connection"
        name="SourceAdapterId"
        rules={[{ required: true, message: "Please select a source connection." }]}>
           <Cascader
              allowClear
              options={connectionTree}
              placeholder="Please select"
            />
      </Form.Item>

      <Form.Item
        label="Source Corpus"
        name="SourceDocumentId"
        rules={[{ required: true, message: "Please select a source corpus." }]}
      >
        <TreeSelect
              allowClear
              showSearch
              style={{ width: "100%" }}
              dropdownStyle={{ maxHeight: 400, overflow: "auto" }}
              treeData={treeData}
              placeholder="Please select"
        />
      </Form.Item>

      <Form.Item
        label="Target Corpus"
        name="TargetDocumentId"
        rules={[{ required: true, message: "Please select a target corpus." }]}
      >
        <TreeSelect
          allowClear
          showSearch
          style={{ width: "100%" }}
          dropdownStyle={{ maxHeight: 400, overflow: "auto" }}
          treeData={treeData}
          placeholder="Please select"
        />
      </Form.Item>
    </Form>
  );
};
export default forwardRef(ReplicatorPlanForm);

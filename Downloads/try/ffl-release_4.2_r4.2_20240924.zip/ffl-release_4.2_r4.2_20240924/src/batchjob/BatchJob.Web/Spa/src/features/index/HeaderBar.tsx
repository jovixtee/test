import React, { useEffect, useState } from 'react';
import { Menu, Dropdown, Modal, message } from 'antd';
import { ExclamationCircleOutlined, UserOutlined } from "@ant-design/icons";
import UserSetting from './UserSetting';
import UserInformation from './UserInfomation';
import * as LSUtil from '../../utils/localstorageutil';
import { QueryUserSummary, UpdateUser, logoutFun } from './Services';
import { UserSummaryStorageKey } from '../../utils/permissionutil';
import cookies from 'react-cookies';
import { CookieKeys } from '../../common/contracts/WebConstants';
import PathConfig from '../../common/PathConfig';
const { confirm } = Modal;

const HeaderBar = () => {
  const [visible, setVisible] = useState<any>(false);
  const [showUserInfo, setShowUserInfo] = useState<any>(false);
  const [userInfo, setUserInfo] = useState<any>({});

  useEffect(() => {
    getUserInfo();
  }, [])

  const getUserInfo = async () => {
    let result = await QueryUserSummary();
    setUserInfo(result.Result);
  };

  const logout = () => {
    confirm({
      title: 'Warning',
      icon: <ExclamationCircleOutlined />,
      content: 'Are you sure you want to exit current user?',
      onOk() {
        logoutFun().then((result) => {
          cookies.remove(CookieKeys.marsToken)
          LSUtil.removeItem(UserSummaryStorageKey);
          window.location.href = PathConfig.addPrefix('/');
        })
      }
    })
  };

  const goUserSetting = async () => {
    setVisible(true)
  };

  const onFinish = async (data: any) => {
    let params = {
      userDetail: {
        User: {
          UserId: data.UserId,
          DisplayName: data.DisplayName,
          Username: data.Username,
          Description: data.Description,
          Password: data.Password,
          NewPassword:data.NewPassword
        },

      }
    }
    let result = await UpdateUser(params)
    setVisible(false)
    if (result.Type === 0) {
      message.success('Update User Succeed!')
      setVisible(false)
      logoutFun().then((result) => {
        LSUtil.removeItem('LoginInfo');
        LSUtil.removeItem(UserSummaryStorageKey);
        window.location.href = PathConfig.addPrefix('/login');
      }).catch(error => {
        console.log(error)
      })
    } else {
      message.success('Update User Failed!')
    }
  };

  const onCloseFun = async () => {
    setVisible(false)
  };

  const onCloseShowUserInfo = () => {
    setShowUserInfo(false)
  };

  const goUserInfo = async () => {
    setShowUserInfo(true)
  };

  const menu = (
    <Menu className='menu'>
      <Menu.ItemGroup title='User Center' className='menu-group'>
        <Menu.Item>Hi - {userInfo.DisplayName ? userInfo.DisplayName : ''}</Menu.Item>
        <Menu.Item ><span onClick={goUserInfo}>User Information</span></Menu.Item>
        <Menu.Item><span onClick={logout}>Log out</span></Menu.Item>
      </Menu.ItemGroup>
      <Menu.ItemGroup title='Settings' className='menu-group'>
        <Menu.Item ><span onClick={goUserSetting}>User Setting</span></Menu.Item>
        {/* <Menu.Item>System Setting</Menu.Item> */}
      </Menu.ItemGroup>
    </Menu>
  )
  const login = (
    <Dropdown overlay={menu}>
      <UserOutlined onClick={() => { }} />
    </Dropdown>
  )
  return (
    <>
      {login}
      {visible && <UserSetting EditFormData={userInfo} onCloseFun={onCloseFun} onGetData={onFinish} ></UserSetting>}
      {showUserInfo && <UserInformation EditFormData={userInfo} onCloseFun={onCloseShowUserInfo}></UserInformation>}
    </>
  );
};

export default HeaderBar;
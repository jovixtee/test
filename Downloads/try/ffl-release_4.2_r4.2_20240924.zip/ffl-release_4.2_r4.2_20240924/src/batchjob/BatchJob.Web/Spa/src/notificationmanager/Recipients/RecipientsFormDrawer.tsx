/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from "react";
import { Button, Input, Select, Form, Drawer, Table, Space, message} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { ProtocolTypeMap} from "../NotificationSetting/NotificationSettingContracts";
import { Recipients } from "./NotificationManagerContracts";
import { CreateProfile, UpdateProfile } from '../ManagerApiserve';
const { Option } = Select;

interface ProfileReadDrawerProps {
    visible: boolean;
    closeDrawer: () => void;
    refresh: () => void;
    data: Recipients;
}

const RecipientsFormDrawer = (props: ProfileReadDrawerProps) => {
    useEffect(() => {
        if(props.visible && props.data.Id){
            form.setFieldsValue({
                "Name":props.data.Name,
                "Description":props.data.Description,
                "ConnectionType":props.data.ConnectionType
            });
            let sourceData = props.data.Contact?.map((e:string,index:number)=>({"Contact":e,"id":index}));
            setSource(sourceData);
        }
    }, [props.visible, props.data])


  const Columns = [
    {
      title: "Contact Address",
      dataIndex: "Contact",
      key: "Contact",
      width: "100%",
      render: (name: any, obj: any, index: any) => {
        return (
          <Input type="text" defaultValue={name} style={{ width: "100%" }} max={254} 
                  // onKeyUp={(e:any)=>{
                  //     let data = e.target.value;
                  //     let newdata = data.replace(/[^a-zA-Z0-9@.-]/g,'');
                  //     e.target.value = newdata;
                  // }}
                  onBlur={(e) => onContactNumber(e.target.value, obj.id)}/>
              );
      },
    },
    {
      title: "Action",
      key: "action",
      render: (name: any, obj: any) => (
        <Button
          type="link"
          onClick={() => {
            let data = source.filter((item: any) => {
              return item.id !== obj.id;
            });
            setSource([...data]);
          }}
        >
          Delete
        </Button>
      ),
    },
  ];
  const [source, setSource] = useState<any>([]);
  const [pagination, setPagination] = useState<any>({
    current: 1,
    pageSize: 3,
  });
  const [form] = Form.useForm();
  const onSubmit = () => {
    form.submit();
  };
  const onFinish = (values: Recipients) => {
      let dto = {...values};

      let flag = source.some((item:any) => {
        let contact = item.Contact;
          let reg= /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/;
          return !reg.test(contact);            
      });

      if(flag){
        message.error("Please enter the correct contact");  
        return;
      }


      dto.Contact = source.map((e:any)=>e.Contact);
      if(props.data.Id){
        dto.Id = props.data.Id;
        UpdateProfile(dto).then(res=>{
            message.success("Saved successfully");
            props.closeDrawer();
            props.refresh();
        });
      }else{
        CreateProfile(dto).then(res=>{
            message.success("Saved successfully");
            props.closeDrawer();
            props.refresh();
        });
      }
  };
  
  const onContactNumber = (value: string | number | undefined, id: any) => {
    source.forEach((item: any) => {
      if (item.id === id) {
        item.Contact = value;
      }
    });
    setSource([...source]);
  };
 
  const addBtn = () => {
    if(source.length >= 200){
        message.error("Contact number cannot be greater than 200");
        return; 
    }
    if(source.length > 0){
        let contact = source[0].Contact;
        let reg= /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/; 
        if(!reg.test(contact)){
            message.error("Please enter the correct contact");  
            return; 
        }    
    }
    source.unshift({ Contact: null, id: source.length + 1 });
    setSource([...source]);
  };
   
  const onChangeTable = (
    pagination: any,
    filters: any,
    sorter: any,
    extra: any
  ) => {
    setPagination(pagination);
  };

  return (
    <Drawer
      forceRender
      title={props.data.Id ?"Edit Recipients Profile":"New Recipients Profile"}
      width={720}
      onClose={()=> props.closeDrawer()}
      visible={props.visible}
      bodyStyle={{ paddingBottom: 80 }}
      footer={
        <div style={{ textAlign: "right"}}>
          <Button onClick={onSubmit} type="primary" style={{ marginRight: 8 }}> Submit </Button>
          <Button onClick={()=> props.closeDrawer()}>Cancel</Button>
        </div>
      }
    >
      <Form
        onFinish={onFinish}
        form={form}
        layout="vertical">
        <Form.Item
          name="Name"
          label="Display Name"
          rules={[{ required: true, message: "Display Name is required!" }]}>
          <Input />
        </Form.Item>

        <Form.Item name="Description" label="Description">
          <Input.TextArea />
        </Form.Item>

        <Form.Item
          label="Connection Type"
          name="ConnectionType"
          rules={[{ required: true, message: "Please choice connection type" }]}>

          <Select placeholder="Please select Connection Type" >
            {Array.from(ProtocolTypeMap).map(([key, value]) => (
              <Option value={key} key={key}>
                {value}
              </Option>
            ))}
          </Select>
        </Form.Item>
        
        <Form.Item name="Contact">
          <div>
            <Space size="small" style={{ float: "left" }}> <span>Contact</span></Space>
            <Space size="small" style={{ float: "right" }}>
              <Button type="text" onClick={addBtn}>
                <PlusOutlined  style={{ fontSize: "1rem",fontWeight: "bold",color: "green"}}/> Add
              </Button>
            </Space>

            <Table
              columns={Columns}
              dataSource={source}
              pagination={pagination}
              onChange={onChangeTable}
              rowKey="id"
            ></Table>
          </div>
        </Form.Item>
      </Form>
    </Drawer>
  );
};
export default RecipientsFormDrawer;

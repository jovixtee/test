import React, { useEffect, useState } from 'react';
import { Button, Drawer, Table, Descriptions } from 'antd';
import { ProtocolTypeMap} from "../NotificationSetting/NotificationSettingContracts";
import { Recipients } from './NotificationManagerContracts';
interface IProfileReadDrawerProps {
    visible: boolean;
    closeDrawer: () => void;
    refresh: (searchText: string) => void;
    data: Recipients;
}

const ProfileReadDrawer = (props: IProfileReadDrawerProps) => {
    const [source, setSource] = useState<any>([]);
   
    const columns = [
        {
          title: "Contact Address",
          dataIndex: "Contact",
          key: "Contact"
        }
      ];

    useEffect(() => {
        if(props.visible && props.data.Id){
            let sourceData = props.data.Contact?.map((e:string,index:number)=>({"Contact":e}));
            setSource(sourceData);
        }
       
    }, [props.visible, props.data])

    return (
        <Drawer
            forceRender
            title="View profile"
            width={720}
            onClose={() => { props.closeDrawer() }}
            visible={props.visible}
            bodyStyle={{ paddingBottom: 80 }}
            footer={
                <div style={{ textAlign: 'right' }}>
                    <Button type="primary" onClick={() => { props.closeDrawer() }} >Cancel</Button>
                </div>
            }>

            <Descriptions column={1} bordered>
                <Descriptions.Item label="Display Name">{props.data.Name}</Descriptions.Item>
                <Descriptions.Item label="Description">{props.data.Description}</Descriptions.Item>
                <Descriptions.Item label="Connection Type">{ProtocolTypeMap.get(props.data.ConnectionType!)}</Descriptions.Item>
            </Descriptions>
            <Descriptions title="Contact" style={{ marginTop: "24px" }} />
            <Table
                columns={columns}
                dataSource={source}
                pagination={false}
                rowKey='id'
            />
        </Drawer >
    )
}
export default ProfileReadDrawer;
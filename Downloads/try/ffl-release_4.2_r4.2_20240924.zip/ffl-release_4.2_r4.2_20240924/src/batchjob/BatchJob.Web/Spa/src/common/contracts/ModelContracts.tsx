///import { StatusType } from "../../apimanagement/node/NodeContract";

export class NodeDto {
    Id: string = "0";
    Host?: string;
    HostName?: string;
    Schema?: string;
    Port?: number;
    Status?: string;
}

export class NodeDetail {
    Id: string = "0";
    Host?: string;
    HostName?: string;
    Schema?: string;
    Port?: number;
    Status?: NodeStatusType;
    Frontend?: FrontendDetailDto[];
}

export class PublishNodeDto {
    FrontendId?: string;
    NodeId?: string;
}

export interface FrontendDto {
    Id?: string;
    NodeID?: string;
    Name?: string;
    BaseAddress?: string;
    Description?: string;
    Versions?: VersionDto[]
}

export class VersionDto {
    Id?: string;
    Status?: VersionStatusType;
    FrontendID?: string;
    BackendID?: string;
    Endpoint?: string;
    ControlPolicyID?: string;
    AuthenticationID?: string;
}

export interface FrontendDetailDto {
    Id?: string;
    NodeID?: string;
    Name?: string;
    BaseAddress?: string;
    Description?: string;
    Versions?: VersionDetailsDto[];
}

export interface VersionDetailsDto {
    Endpoint?: string;
    ControlPolicy?: string;
    Authentication?: string;
    Status?: VersionStatusType;
    Id: string;
}

export enum VersionStatusType {
    Draft = 0,
    Active = 1,
    Deprecate = 2
}

///Backend API
export class BackendDto {
    Id: string = "";
    Name?: string;
    Description?: string;
    Protocol?: ProtocolType;
    BaseAddress?: string;
}

export class BackendDetailsDto {
    Id: string = "";
    Name?: string;
    Description?: string;
    Protocol?: ProtocolType;
    versions?: VersionDetailsDto[];
    BaseAddress?: string;
}

export enum ProtocolType {
    HttpHttps = 0,
    Ftp = 1
}

export const TypeMap = new Map<string, ProtocolType>([
    ["Http/Https", ProtocolType.HttpHttps],
    ["Ftp", ProtocolType.Ftp],
])
export const StatusMap = new Map<string, VersionStatusType>([
    ["Active", VersionStatusType.Active],
    ["Draft", VersionStatusType.Draft],
    ["Deprecate", VersionStatusType.Deprecate],
])

export class ParameterTypeDto {
    Id: string = "";
    Name?: string;
    ExtensionJSON?: string;
    FrontendId?: string;
    BackendId?: string;
}

export class MethodDto {
    Id: string = "";
    Path?: string;
    MethodName?: MethodTypeEnum;
    MethodType?: MethodType;
    Header?: string;
    VersionId?: string;
    Param?: MethodParameterDto[];
    Version?: VersionDto;
    Frontend?: FrontendDto;
    Method?: MethodDto;
    Backend?: BackendDto;
}

export class MethodParameterDto {
    Id: string = "";
    Key?: string;
    DefaultValue?: string | number;
    ParamterTypeID?: string;
    MethodID?: string;
}

export enum MethodTypeEnum {
    GET = 1,
    POST = 2,
    PUT = 3,
    PATCH = 4,
    DELETE = 5,
    COPY = 6,
    HEAD = 7,
    OPTIONS = 8,
    LINK = 9,
    UNLINK = 10,
    PURGE = 11,
    LOCK = 12,
    UNLOCK = 13,
    PROPFIND = 14,
    VIEW = 15
}

export const MethodTypeColor = new Map<string, string>([
    ["GET", "#04A400"],
    ["POST", "#0077DC"],
    ["PUT", "#805F43"],
    ["PATCH", "#40E0D0"],
    ["DELETE", "#E43E3E"],
    ["COPY", "#808080"],
    ["HEAD", "#696A6B"],
    ["OPTIONS", "#A52A2A"],
    ["LINK", "#FA8072"],
    ["UNLINK", "#A0522D"],
    ["PURGE", "#FF8C00"],
    ["LOCK", "#F5F5DC"],
    ["UNLOCK", "#90EE90"],
    ["PROPFIND", "#00FA9A"],
    ["VIEW", "#00CED1"]
])


export enum MethodType {
    None = 0,
    AuthenticationIssue = 1,
    AuthenticationRevoke = 2,
    ServiceMethod = 3
}

// Frontend Api
export class FrontendAPIDto {
    Id: string = "";
    NodeID?: string;
    Name?: string;
    BaseAddress?: string;
    Description?: string;
    Versions?: VersionDetailsDto[];
}

//Authentication
export class AuthenticationDto {
    Id: string = "";
    Name?: string;
    Description?: string;
    FromType?: FromType;
    AuthType?: AuthType;
    AuthSetting?: OAuthDto | ApiKeyDto | ClientCertDto | CustomiseDto;
    Certificate?: string;
    // AuthType?: AuthType;
    // FromType?: FromType;
    // TokenEndpoint?:string;
    // ClientId?: string;
    // Secret?: string;
    // Certificate?: string;
    // Password?: string;
    // UserName?: string;
    // HashType?: HashType;
    CreatedOn?: number;
    CreatedBy?: string;
    ModifiedOn?: number;
    ModifiedBy?: string;
}

export class OAuthDto {
    TokenEndpoint?: string;
    ClientId?: string;
    Secret?: string;
    Scope?: string;
    GrantType?:GrantType; 
    AuthorizationUrl?: string;
    RefreshTokenUrl?: string;
    RedirectUrl?: string;
}

export class ApiKeyDto {
    APIKeyType?: APIKeyType;
    APIKeySetting?: JWTDto | BasicDto | CustomiseDto | ConstDto
}

export class JWTDto {
    HashType?: HashType;
    ClientId?: string;
    Secret?: string;
}

export class BasicDto {
    UserName?: string;
    Password?: string;
}

export class CustomiseDto {
    CustomType?: CustomType;
    CustomiseSetting?: MyInfoDto;
}

export class MyInfoDto {
    ApplicationID?: string;
    EServiceID?: string;
    Password?: string;
}

export class ConstDto {
    ConstKey?: string;
    AuthorizationHeader?: string;
}

export class ClientCertDto {
    Host?: string;
    Passphrase?: string;

}


// export enum AuthType {
//     JWT = 1,
//     Basic = 2,
//     Custom = 3,
//     OAuthPlatfrom = 4,
// }

export enum AuthType {
    OAuth = 1,
    APIKey = 2,
    ClientCert = 3,
    Customise = 4
}


export enum APIKeyType {
    JWT = 1,
    Basic = 2,
    Constants = 3
}

export enum FromType {
    Frontend = 0,
    Backend = 1
}

export enum CustomType {
    MyInfo = 1
}

//ControlPolicy
export class ControlPolicyDto {
    Id: string = "";
    Name?: string;
    Notification?: string;
    Description?: string;
    ControlPolicyRule?: ControlPolicyRuleDto[];
    CreatedOn?: number;
    CreatedBy?: string;
    ModifiedOn?: number;
    ModifiedBy?: string;
}

export enum RuleType {
    RateLimit = 0,
    Block = 1
}

export class ExtensionRateLimitDto {
    LimitType?: LimitType;
    Period?: string;
    Limit?: string;
    //SizeLimit?:string
}

export enum LimitType {
    ByCount = 1,
    BySize = 2
}

export enum BlockType {
    WhiteList = 0,
    BlackList = 1,
}

//AnalysticReport

export class HistoryDto {
    Id?: string;
    FrontendName?: string;
    Node?: string;
    Method?: string;
    Header?: string;
    Body?: string;
    BackendName?: string;
    BackendMethod?: string;
    BackendHeader?: string;
    BackendBody?: string;
    Status?: string;
    Credential?: string;
    IncomeTimestamp?: number;
    OutgoTimestamp?: number;
    RequestMessage?: string;
    ReponseMessage?: string;
    Tag?: string;
}

export enum HashType {
    None = 0,
    HS256 = 1,
    SHA1 = 2,
}

export enum GrantType {
    Code = 0,
    ClientCredential = 1
}

// new version dto 

export class APIDto {
    Id: string = "";
    Name?: string;
    Description?: string;
}

export class APIsMenuDto {
    Id?: string;
    Name?: string;
    Versions: VersionMenuDto[] = []
}

export class VersionMenuDto {
    Id?: string;
    DisplayName?: string;
}

export class MethodMenuDto {
    Id?: string;
    Name?: string;
    MethodName?: string
    VersionID?: string
}

export class MethodContentDto {
    Frontend?: ViewFrontendDto
    Policy?: ViewControlPolicyDto
    Backend?: ViewBackendDto
}

export class ViewFrontendDto {
    Id?: string;
    MethodName?: string;
    BaseAddress?: string;
    Path?: string;
    Parameters?: ViewParameter[];
    Headers?: ViewHeader[];
}

export class ViewBackendDto {
    Id?: string;
    BaseAddress?: string;
    Path?: string;
}

export class ViewParameter {
    Name?: string;
    ParameterType?: string
}

export class ViewHeader {
    Name?: string;
    Type?: string;
}

export class ViewControlPolicyDto {
    Id?: string;
    Name?: string;
    Description?: string;
    Rule?: ViewControlPolicyRuleDto[];
}

export class ViewControlPolicyRuleDto {
    Id: string = "";
    Rule?: string;
    Type?: string;
}

export class ComboBoxItem {
    key: string = "";
    value: string = "";
}

export class NodeItemDto {
    key: string = "";
    value: string = "";
    NodeUrl: string = "";
}

export class VersionComboBoxDto {
    Node?: NodeItemDto[];
    Policy?: PolicyItem[];
    FrontendAuth?: ComboBoxItem[];
    BackendAuth?: ComboBoxItem[];
}

export class PolicyItem {
    key: string = "";
    value: string = "";
    Rule?: ViewControlPolicyRuleDto[];
}

export class VersionSettingDto {
    Id?: string;
    Endpoint?: string;
    ControlPolicyId?: string;
    FrontendAuthId?: string;
    BackendAuthId?: string;
    DisplayName?: string;
    Identifier?: string;
    Description?: string;
    BaseAddress?: string;
    ServiceAddress?: string;
    Status?: PublishStatus;
    NodeID: string[] = [];
    Tag?: string;
}


export class ImportVersionDto extends VersionSettingDto {
    operations?: OperationDto[];
}


export class VersionDataDto {
    Setting?: VersionSettingDto;
    ComboBoxData?: VersionComboBoxDto;
}

export enum UrlScheme {
    HTTP = 0,
    HTTPS = 1,
    Both = 2
}

export class MethodParameter {
    Id: string = "";
    Name?: string;
    ParamterType?: string;
    DefaultValue?: string | number;
}

export class EditTableData extends MethodParameter {
    IsEdit: boolean = false;
    IsNewData: boolean = false;
}

export interface IEditTableRef {
    getTableResult: () => {
        addData: MethodParameter[];
        updateData: MethodParameter[];
        deleteData: MethodParameter[];
    }
}


export class MethodHeader {
    Id: string = "";
    Name?: string;
    Type?: string;
    DefaultValue?: string | number;
}

export class EditHeaderTableData extends MethodHeader {
    IsEdit: boolean = false;
    IsNewData: boolean = false;
}

export interface IEditHeaderTableRef {
    getTableResult: () => {
        addData: MethodHeader[];
        updateData: MethodHeader[];
        deleteData: MethodHeader[];
    }
}

export class OperationParam {
    addData?: MethodParameter[];
    updateData?: MethodParameter[];
    deleteData?: MethodParameter[];

}

export class OperationHeader {
    addData?: MethodHeader[];
    updateData?: MethodHeader[];
    deleteData?: MethodHeader[];
}

export class OperationDto {
    Id?: string;
    Name?: string;
    Path?: string;
    MethodName?: string;
    Description?: string;
    VersionID?: string;
    Param?: OperationParam;
    Header?: OperationHeader
}


export class ViewOperationDto {
    Id?: string;
    Name?: string;
    Path?: string;
    MethodName?: string;
    RequestUrl?: string;
    Description?: string;
    Param?: MethodParameter[];
    Header?: MethodHeader[]
}

export class ViewNode {
    Id: string = "";
    DisplayName?: string;
    BaseAddress?: string;
    Status?: NodeStatusType;
    Version?: ViewVersion[];
}

export class ViewVersion {
    Id: string = "";
    ApiName?: string;
    Suffix?: string;
    ServicceUrl?: string;
    Version?: string;
}

export enum NodeStatusType {
    Online = 1,
    Offline = 2
}


export class ViewControlPolicy {
    Id: string = "";
    Name?: string;
    Notification?: string;
    Rule?: ViewControlRulePolicy[];
}

export class ViewControlRulePolicy {
    Id: string = "";
    SN?: number;
    RuleType?: RuleTypeEnum;
    ExtensionJSON?: string;
}

export class TokenStore {
    Name?: string;
    TokenType?: string;
    ProfileId?: string;
    Scope?: string;
    AccessToken?: string;
    Expiration?: string;
    IdToken?: string;
    RefreshToken?: string;
}

export class RedirectModel
{
    code ?: string;
    state ?: string;
}

export enum RuleTypeEnum {
    RateLimite = 1,
    IPFilter = 2
}

export const RuleTypeMap = new Map<string, RuleTypeEnum>([
    ["Rate Limite", RuleTypeEnum.RateLimite],
    ["IP Filter", RuleTypeEnum.IPFilter]
])

export enum BlockTypeEnum {
    Allowed = 1,
    NotAllowed = 2,
}

export const BlockTypeMap = new Map<string, BlockTypeEnum>([
    ["Allowed IPS", BlockTypeEnum.Allowed],
    ["Not Allowed IPS ", BlockTypeEnum.NotAllowed]
])


export const LimitTypeMap = new Map<string, LimitType>([
    ["ByCount", LimitType.ByCount],
    ["BySize", LimitType.BySize]
])


export class IPAddress {
    Id: string = "";
    AddressFrom?: string;
    AddressTo?: string;
}

export class IPAddressData extends IPAddress {
    IsEdit: boolean = false;
}

export class IPRule {
    IsEdit: boolean = false;
}

export class ExtensionBlockRuleDto {
    BlockType?: BlockTypeEnum;
    IPRule?: IPAddress[];
}

export class ControlPolicyRuleDto {
    Id: string = "";
    SN?: number;
    RuleType?: RuleTypeEnum;
    PolicyID?: string;
    RateLimit?: ExtensionRateLimitDto;
    BlockRule?: ExtensionBlockRuleDto;
}


export enum PublishStatus {
    Draft = 1,
    Published = 2,
    Deprecated = 3,
    InActive = 4,
}
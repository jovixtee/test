import React, {useEffect, useState} from "react";
import {GetTokenAsync} from "./APIAuthenticationService";
import UINotrification from "../../common/UINotrification";
import {Button, Result} from "antd";

export const AuthProceedGrantCallback = (props: any) => {
    const [callbackMessage, setCallbackMessage] = useState(true);
    const [timeer, setTimeer] = useState(10);
    const getParamData = () => {
        let url = window.location.search;
        let index = url.indexOf('?')
        let obj: any = {}
        if (index !== -1) {
            let str = url.substr(1)
            let arr = str.split('&')
            for (let i = 0; i < arr.length; i++) {
                Object.defineProperty(obj, arr[i].split('=')[0], {
                    value: arr[i].split('=')[1],
                    writable: true,
                    enumerable: true,
                    configurable: true
                });
                //obj[arr[i].split('=')[0]] = arr[i].split('=')[1]
            }
        }
        return obj
    };


    useEffect(() => {
        let data = getParamData();
        GetTokenAsync(data).then(e => {
            countdown(true);
        }).catch(e=>countdown(false));
    }, []);
    
    const countdown = (success:boolean) =>{
        setCallbackMessage(success);
        let t = timeer;
        let timer = setInterval(function () {
            setTimeer(t--);
            if (t < 0) {
                clearInterval(timer);
                window.close();
            }
        }, 1000);
    }

    return (
        <>
            {
                callbackMessage &&
                <>
                    <Result
                        status="success"
                        title="Proceed Grant Successfully!"
                        subTitle="Order number: 2017182818828182881 Cloud server configuration takes 1-5 minutes, please wait."
                        extra={[
                            <Button type="primary" key="console" onClick={()=>window.close()}>
                                Close ( {timeer+"s "})
                            </Button>
                        ]}/>
                </>
            }


            {
                !callbackMessage &&
                <>
                    <Result
                        status="error"
                        title="Proceed Grant Failed!"
                        subTitle="Please check and modify the following information before resubmitting."
                        extra={[
                            <Button type="primary" key="console" onClick={()=>window.close()}>
                                Close ( {timeer+"s "})
                            </Button>
                        ]}
                    />
                </>
            }
        </>
    )
};
      
       
      
 
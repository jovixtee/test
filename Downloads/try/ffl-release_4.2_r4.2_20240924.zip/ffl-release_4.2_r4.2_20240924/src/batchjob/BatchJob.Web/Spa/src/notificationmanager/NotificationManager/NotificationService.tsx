import apiservice from '../../utils/fetchutil';
import { ConnectionAdapterItem ,NotificationSetting,ProtocolType} from "./NotificationManagerContracts";
import { PagerResult,PagerExpression } from '../../common/contracts/PagerContracts';
import { message } from 'antd';
const serve = apiservice();


 

export const QueryConnByProtocolType = (protocolType: ProtocolType): Promise<ConnectionAdapterItem[]> => {
    return new Promise((res, rej) => {
        serve.post("/INotificationService/QueryConnByProtocolType", { "protocolType": protocolType }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}


export const QueryNotifiSettingDetail = (id: string): Promise<NotificationSetting> => {
    return new Promise((res, rej) => {
        serve.post("/INotificationService/QueryNotifiSettingDetail", { "id": id }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const CreateNotifiSetting = (dto: NotificationSetting): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/INotificationService/CreateNotifiSetting", { "dto": dto }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const UpdateNotificationSetting = (dto: NotificationSetting): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/INotificationService/UpdateNotificationSetting", { "dto": dto }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const NotificationSettingPagedQuery = (dto: PagerExpression): Promise<PagerResult<NotificationSetting>> => {
    return new Promise((res, rej) => {
        serve.post("/INotificationService/NotificationSettingPagedQuery", { "expression": dto }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const DeleteNotificationSetting = (id: string[]): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/INotificationService/DeleteNotifiSetting", { "id": id }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const NotifiySetDefault = (id: string): Promise<any> => {
    return new Promise((res, rej) => {
        serve.post("/INotificationService/NotifiySetDefault", { "id": id }).then((result) => {
            if (result.EventCode === 1) {
                message.error(result.Message);
            }
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
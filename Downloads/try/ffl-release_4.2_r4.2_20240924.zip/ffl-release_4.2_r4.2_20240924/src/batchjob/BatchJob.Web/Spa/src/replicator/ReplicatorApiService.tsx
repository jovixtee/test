import * as ReplicatorContract from './ReplicatorContract';
import apiservice from '../utils/fetchutil';
import { PagerExpression, PagerResult } from '../common/contracts/PagerContracts';


export interface IReplicatorApi {
    CreateDatamodeling(data:ReplicatorContract.DataModeing): Promise<ReplicatorContract.ReplicatorsResult>;

    ManifestPagerQuery(pager: PagerExpression):  Promise<PagerResult<ReplicatorContract.ManifestDto>>;

    CorpusUploadZipFile(dto:ReplicatorContract.CorpusDto,file: any):Promise<any[]>;

    GetReplicatorResources(): Promise<ReplicatorContract.ReplicatorsResult>;

    SaveReplicatorPipline(dto:ReplicatorContract.ReplicatorPipline,file: any): Promise<ReplicatorContract.ReplicatorsResult>;

    PiplinePagerQuery(pager: PagerExpression):  Promise<PagerResult<ReplicatorContract.ReplicatorsResult>>;

    GetPiplineById(id:string): Promise<ReplicatorContract.ReplicatorsResult>;

    DeletePiplineById(id:any): Promise<ReplicatorContract.ReplicatorsResult>;

    DeletePlanById(id:any): Promise<ReplicatorContract.ReplicatorsResult>;
    
    DeleteCorpus(id:any): Promise<ReplicatorContract.ReplicatorsResult>;

    PagerQueryCorpus(pager: PagerExpression):  Promise<PagerResult<ReplicatorContract.ReplicatorsResult>>;

    GetDatamodelingById(id:string): Promise<ReplicatorContract.ReplicatorsResult>;

    PagerQueryPlan(pager: PagerExpression):  Promise<PagerResult<ReplicatorContract.ReplicatorsResult>>;

    GetEntityMappingById(dto:ReplicatorContract.DocumentIds): Promise<ReplicatorContract.ReplicatorsResult>;
    GetEntityField(path:string,id:string,type:ReplicatorContract.ServiceType): Promise<ReplicatorContract.ReplicatorsResult>;

    CreateReplicatorPlan(plan:ReplicatorContract.ReplicatorPlan): Promise<ReplicatorContract.ReplicatorsResult>;
    

    GetReplicatorPlanById(id:string): Promise<ReplicatorContract.ReplicatorsResult>;
    
}
export function GetApiService(): IReplicatorApi {
    return replicatorApi;
}

const replicatorApi: IReplicatorApi = {
    ManifestPagerQuery: function (pager: PagerExpression): Promise<PagerResult<ReplicatorContract.ManifestDto>> {
        return apiservice().post('/IReplicatorsService/PagerQueryManifest', { pager: pager });
    },
    CorpusUploadZipFile: function (dto: ReplicatorContract.CorpusDto, file: any): Promise<any[]> {
        const fd = new FormData();
        fd.set('arg', JSON.stringify({ _streamLength: file.size, importArguments: { FileName: file.name, Corpus: dto } }));
        if (file) {
            fd.set('file', file);
        }
        return apiservice().post('/IReplicatorsService/UploadZipFile', fd);
    },
    GetReplicatorResources: function (): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/GetReplicatorResources');
    },
    SaveReplicatorPipline: function (dto: ReplicatorContract.ReplicatorPipline, file: any): Promise<ReplicatorContract.ReplicatorsResult> {
        const fd = new FormData();
        fd.set('arg', JSON.stringify({ _streamLength: file?.size, importArguments: { FileName: file?.name, Pipline: dto } }));
        if (file) {
            fd.set('file', file);
        }
        return apiservice().post('/IReplicatorsService/SaveReplicatorPipline', fd);
    },
    PiplinePagerQuery: function (pager: PagerExpression): Promise<PagerResult<ReplicatorContract.ReplicatorsResult>> {
        return apiservice().post('/IReplicatorsService/PiplinePagerQuery', { pager: pager });
    },
    GetPiplineById: function (id: string): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/GetPiplineById', { id: id });
    },
    DeletePiplineById: function (id: any): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/DeletePiplineById', { id: id });
    },
    PagerQueryCorpus: function (pager: PagerExpression): Promise<PagerResult<ReplicatorContract.ReplicatorsResult>> {
        return apiservice().post('/IReplicatorsService/PagerQueryCorpus', { pager: pager });
    },
    DeleteCorpus: function (id: any): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/DeleteCorpus', { id: id });
    },
    CreateDatamodeling: function (data: ReplicatorContract.DataModeing): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/CreateDatamodeling', { dto: data });
    },
    GetDatamodelingById: function (id: string): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/GetDatamodelingById', { id: id });
    },
    PagerQueryPlan: function (pager: PagerExpression): Promise<PagerResult<ReplicatorContract.ReplicatorsResult>> {
        return apiservice().post('/IReplicatorsService/PagerQueryPlan', { pager: pager });
    },
    DeletePlanById: function (id: any): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/DeletePlanById', { id: id });
    },
    GetEntityMappingById: function (dto: ReplicatorContract.DocumentIds): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/GetEntityMappingById', { dto: dto });
    },
    GetEntityField: function (path: string, id: string, type: ReplicatorContract.ServiceType): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/GetEntityField', { path: path, id: id, type: type });
    },
    CreateReplicatorPlan: function (plan: ReplicatorContract.ReplicatorPlan): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/CreateReplicatorPlan', { plan: plan });
    },
    GetReplicatorPlanById: function (id: string): Promise<ReplicatorContract.ReplicatorsResult> {
        return apiservice().post('/IReplicatorsService/GetReplicatorPlanById', { id: id });
    }
}

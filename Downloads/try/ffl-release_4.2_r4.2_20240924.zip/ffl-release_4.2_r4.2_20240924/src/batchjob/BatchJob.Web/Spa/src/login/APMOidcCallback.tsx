import React, { useState } from "react";
import { APMOidcUserManager } from '../context/UserContext';
import apiservice from '../utils/fetchutil';
import { PassportDto, AuthenticationTypeEnum, ServiceResultType } from '../accountmanager/AccountManagerContract';

export const APMOidcCallback = (props: any) => {

    const [errorMsg, setErrorMsg] = useState('');

    APMOidcUserManager.signinRedirectCallback().then(usr => {
        const passport: PassportDto = {
            UserName: usr!.profile.name,
            Authentication: AuthenticationTypeEnum.ApmOidc,
            Email: usr!.profile.email,
            OidcRoles: usr!.profile.role,
        };

        apiservice().post("/IPassportService/APMOidcCallback", { passportDto: passport }, { headers: { "Content-Type": "application/json", "Authorization": "Bearer " + usr?.access_token } }).then((result) => {
            if (result.Type === ServiceResultType.Success) {
                props.onVerified(true);
            } else { 
                setErrorMsg(result.Message);
            }
        });
    });

    return (<>{errorMsg}</>);
}
import React, { ReactElement } from "react";
import { Component } from "react";
import {
    UserAddOutlined, EyeOutlined, DashboardOutlined, WindowsOutlined, ScheduleOutlined, DatabaseOutlined, ApartmentOutlined, NotificationOutlined,
    SecurityScanOutlined, MonitorOutlined, ApiOutlined, TeamOutlined, SettingOutlined, ClockCircleOutlined, UsergroupAddOutlined, SafetyOutlined,
    SafetyCertificateOutlined, ProfileOutlined
} from '@ant-design/icons';
import asyncComponent from "./AsyncComponent";
const Home = asyncComponent(() => import("../features/home/Home"));
const TaskLayout = asyncComponent(() => import("../features/taskmanager/TaskLayout"));
const JobMonitor = asyncComponent(() => import("../features/jobmonitor/JobMonitorLayout"));
const User = asyncComponent(() => import("../accountmanager/user/User"));
const Group = asyncComponent(() => import("../accountmanager/group/Group"));
const HolidaySetting = asyncComponent(() => import("../features/holidaysetting/HolidaySetting"));
const PermissionLevel = asyncComponent(() => import("../accountmanager/permissionLevel/PermissionLevel"));
const Connections = asyncComponent(() => import("../features/connections/Connections"));
const Authentication = asyncComponent(() => import("../accountmanager/authentication/Authentication"));
const SecurityPolicy = asyncComponent(() => import("../securitymanager/securitypolicy/SecurityPolicy"));
const NotificationManager = asyncComponent(() => import("../notificationmanager/NotificationManager/NotificationManager"));
const Node = asyncComponent(() => import("../apimanagement/node/Node"));
const AnalysticReport = asyncComponent(() => import("../apimanagement/analysticreport/AnalysticReport"));
const APIAuthentication = asyncComponent(() => import("../apimanagement/apiauthentication/APIAuthentication"));
const BackendAPI = asyncComponent(() => import("../apimanagement/backendapi/BackendAPI"));
const ControlPolicy = asyncComponent(() => import("../apimanagement/controlpolicy/ControlPolicy"));
const FrontendAPI = asyncComponent(() => import("../apimanagement/frontendapi/FrontendAPI"));
const TransferMain = asyncComponent(() => import("../features/transfer/TransferMain"));

export interface IPlatformMenuItem {
    key: string;
    icon: ReactElement;
    title: string;
    component?: Component;
    subs?: Array<IPlatformMenuItem>;
}

const PlatformMenuItems: Array<IPlatformMenuItem> = [
    {
        key: 'home',
        icon: <DashboardOutlined />,
        title: 'Dashboard'
    },
    {
        title: 'Features',
        icon: <WindowsOutlined />,
        key: '/features',
        subs: [
            { key: '/taskmanager', title: 'Task Manager', icon: <ScheduleOutlined />, },
            { key: '/jobmonitor', title: 'Job Monitor', icon: <EyeOutlined />, },
            { key: '/connections', title: 'Connections', icon: <DatabaseOutlined />, },
            { key: '/holidaysetting', title: 'Holiday Setting', icon: <ClockCircleOutlined />, },
            { key: '/transfer/profile', title: 'Transfer Profile', icon: <ProfileOutlined />, },
        ]
    },
];

export const MasterPage = () => {


    return (<></>);
};
import React, { useRef } from "react";
import { useEffect } from "react";
import * as TaskManagerContract from './TaskManagerContract';
import TaskManagerApiService from './TaskManagerApiService';
import { useState } from "react";
import { Select } from "antd";
import apiservice from '../../utils/fetchutil';
import FormItem from "antd/lib/form/FormItem";

export interface ITaskActionControlProps {
    value: TaskManagerContract.ScheduleActionDto;
    onChange?: (value: TaskManagerContract.ScheduleActionDto) => void;
}

export const TaskActionControl = (props: ITaskActionControlProps) => {
    const [settings, setSettings] = useState<Array<TaskManagerContract.TaskActionSettingDto>>();
    const [currentSetting, setCurrentSetting] = useState<TaskManagerContract.TaskActionSettingDto>();
    const [firstParamSource, setFirstParamSource] = useState<Array<TaskManagerContract.ActionElementDto>>();
    const [firstParamLabel, setFirstParamLabel] = useState<string>('');

    useEffect(() => {
        TaskManagerApiService.getInstance().GetAllActionSettings(result => { setSettings(result?.ActionSettings); })
    }, []);

    useEffect(() => {
        if (props.value && props.value.HandlerId) {
            const setting = settings!.find(s => s.Id === props.value.HandlerId);
            taskActionChanged(setting!.Id);
            if (setting?.ActionParameterSettings && setting?.ActionParameterSettings.length > 0) {
                const firstParam = setting?.ActionParameterSettings[0];
                if (firstParam) {
                    switch (firstParam.Type) {
                        case TaskManagerContract.ControlType.Combo:
                            apiservice().post(firstParam.ItemsSourceLink!, {}).then(r => {
                                setCurrentSetting(setting);
                                setFirstParamSource(r.ElementDtos);
                            });
                            break;
                        default:
                            setCurrentSetting(setting);
                            break;
                    }
                }
            }
        } else {
            setCurrentSetting({});
            setFirstParamSource([]);
        }
    }, [props.value]);

    const taskActionChanged = (value: any) => {
        const setting = settings!.find(s => s.Id === value);
        if (setting) {
            props.value.HandlerId = value;
            props.value.DisplayName = setting.DisplayName;

            if (setting.ActionParameterSettings && setting.ActionParameterSettings.length > 0) {
                setFirstParamLabel(setting.ActionParameterSettings[0].Label!);
                const firstParam = setting.ActionParameterSettings[0];

                switch (firstParam.Type) {
                    case TaskManagerContract.ControlType.Combo:
                        apiservice().post(firstParam.ItemsSourceLink!, {}).then(r => {
                            setCurrentSetting(setting);
                            setFirstParamSource(r.ElementDtos);
                        });
                        break;
                    default:
                        setCurrentSetting(setting);
                        break;
                }
            }
        }
    };

    const paramSettingChanged = (value: any) => {
        props.value.PartsAndValues = [value];
    };

    return (
        <>
            <FormItem {...props} label='Action' name='ActionId'>
                <Select placeholder="Select One" onChange={taskActionChanged}>
                    {settings?.map(item => (
                        <Select.Option key={item.Id} value={item.Id!} label={item.DisplayName}>
                            {item.DisplayName}
                        </Select.Option>
                    ))}
                </Select>
            </FormItem>
            {
                currentSetting?.ActionParameterSettings && currentSetting.ActionParameterSettings.length > 0 && currentSetting.ActionParameterSettings[0].Type === TaskManagerContract.ControlType.Combo &&
                <FormItem {...props} label={firstParamLabel} name="firstParamValue">
                    <Select placeholder="Select One" onChange={paramSettingChanged}>
                        {firstParamSource?.map(item => (
                            <Select.Option key={item.Id} value={item.Id!} label={item.Name}>
                                {item.Name}
                            </Select.Option>
                        ))}
                    </Select>
                </FormItem>

            }</>);
};
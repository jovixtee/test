import React from 'react';
import { Route, Switch } from 'react-router-dom';
import JobMonitor from './JobMonitor';
import JobDetails from './JobDetails';
import PathConfig from '../../common/PathConfig';
const JobMonitorLayout = () => {
    return (
        <div>
            <Switch>
                <Route path={PathConfig.addPrefix('/jobmonitor/details/')} component={JobDetails} />
                <Route path={PathConfig.addPrefix('/jobmonitor')} component={JobMonitor} />
            </Switch>
        </div>
    );
};
export default JobMonitorLayout;
import React, { FC, useState, useEffect } from "react";
import { Row, Col, Table, Input, Badge } from "antd";
import { ColumnsType } from "antd/lib/table";
import { ViewNode, NodeStatusType } from '../../common/contracts/ModelContracts';
import  ViewVersionTable  from './ViewVersionTable';
import { GetViewNode } from './NodeApiService';

const Search = Input.Search;
const Node: FC = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const [dataSource, setDataSource] = useState<ViewNode[]>([]);

    const tableColumn: ColumnsType<ViewNode> = [
        {
            title: 'Display name',
            dataIndex: 'DisplayName',
            width: '22%'
        },
        {
            title: 'Base URL',
            dataIndex: 'BaseAddress',
            width: '54%'
        },
        {
            title: 'Status',
            dataIndex: 'Status',
            render: (_: any, record: ViewNode) => <Badge status={record.Status === NodeStatusType.Online?"success":"error"} text={record.Status ? NodeStatusType[record.Status] : ""} />,
            width: '24%'
        }
    ]

    useEffect(() => {
        handleGetViewNode("")
    }, [])

     

    const handleGetViewNode = (searchText: string): void => {
        setLoading(true);
        GetViewNode(searchText).then(res=>{
            setDataSource(res);
            console.log(res);
        }).finally(()=>setLoading(false));

    }


    const onSearch = (value: string): void => {
        handleGetViewNode(value);
    }


    return <React.Fragment>

        <Row style={{ margin: '16px 0' }}>
            <Col span={24}>
                <Search placeholder="Search APIs" allowClear onSearch={onSearch} style={{ marginBottom: "16px", width: 200, float: "right" }} />
            </Col>
        </Row>

        <Table
            loading={loading}
            rowKey={record => record.Id}
            dataSource={dataSource}
            columns={tableColumn}
            expandable={{
                rowExpandable: (record) => (record.Version && record.Version.length > 0) ? true : false,
                expandedRowRender: (record) => <ViewVersionTable  versionData={record.Version||[]}/>
            }}
            pagination={false}
        />

    </React.Fragment>
}

export default Node
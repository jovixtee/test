import { message, Modal } from 'antd';
const { confirm } = Modal;
class UINotrification {

    static success(msg: string, callback?: any) {
        msg && message.success({ content: msg, onClose: callback });
    }

    static error(msg: string, callback?: any) {
        msg && message.error({ content: msg, onClose: callback });
    }


    static confirm(msg: string, title: string, ok: Function, cancel: Function) {
        msg && confirm({
            title: title,
            content: msg,
            onOk() {
                ok();
            },
            onCancel() {
                cancel();
            },
        });
    }

}
export default UINotrification;
import { Button, Descriptions, Drawer } from "antd";
import React, { useEffect, useState } from "react";

interface IProfileReadDrawerProps {
    visible: boolean;
    onClose: Function;
    profileDto: any
}

export const ProfileReadDrawer = (props: IProfileReadDrawerProps) => {
    const [dataSource, setDataSource] = useState<any>({});
    const [roleSource, setRoleSource] = useState<string>("");
    useEffect(() => {
        if(props.visible){
            setDataSource(props.profileDto.User);
            let role = props.profileDto.Roles;
            let roleMap = role.map((e:any)=>e.RoleName).join(",");
            setRoleSource(roleMap);
        }
    }, [props.visible,props.profileDto]);
    return (<Drawer visible={props.visible} width={720} onClose={(e) => props.onClose()}
        title={"View user"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" onClick={(e) => props.onClose()} >Close</Button>
            </div>
        }>
        <Descriptions column={1} bordered>
            <Descriptions.Item label="Display Name">{dataSource.DisplayName}</Descriptions.Item>
            <Descriptions.Item label="E-mail">{dataSource.Email}</Descriptions.Item>
            <Descriptions.Item label="Description">{dataSource.Description}</Descriptions.Item>
            <Descriptions.Item label="User Name">{dataSource.Username}</Descriptions.Item>
            {/* <Descriptions.Item label="User Role">{dataSource.UserRole ===1 ?"Owner":"Member"}</Descriptions.Item> */}
            {
              dataSource.UserRole ===1 &&
              <>
              <Descriptions.Item label="User Role">
               Owner
              </Descriptions.Item>
              </>
            } 
            {
              dataSource.UserRole !==1 &&
              <>
              <Descriptions.Item label="User Role">
               Member
              </Descriptions.Item>
              <Descriptions.Item label="PermissionLevels">
               {roleSource}
              </Descriptions.Item>
              </>
            } 
           
        </Descriptions>
    </Drawer>)
};
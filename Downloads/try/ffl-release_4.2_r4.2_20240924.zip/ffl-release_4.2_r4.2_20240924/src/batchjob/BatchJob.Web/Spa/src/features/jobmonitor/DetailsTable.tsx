import React, { useEffect, useState } from "react";
import { PagerQueryJobDetail, GetJobDetailCustomColumns } from './JobMonitorApiServe';
import JobUtil from './JobUtil';
import AmpCommonTable, { DatetimeColumnTemplate } from '../../components/antdx/AmpCommonTable';
import { PagerExpression } from "../../common/contracts/PagerContracts";

const DetailsTable = (props: any) => {
    const [columns, setSolumns] = useState<any[]>([]);

    useEffect(() => {
        getJobDetailCustomColumns();
    }, [props]);

    async function getJobDetailCustomColumns() {
        let tempColumns: any[] = [];
        const result = await GetJobDetailCustomColumns({ jobId: props.jobId });
        result.CustomColumns.forEach((item: any) => {
            tempColumns = [...tempColumns, {
                title: item.DisplayName,
                dataIndex: item.InternalName,
                key: item.InternalName
            }];
        });
        tempColumns = [...tempColumns, {
            title: 'Status',
            dataIndex: 'State',
            key: 'State',
            width: '100px',
            render: (stat: number, record: any, index: number) => (<span>{JobUtil.GetStateString(stat)}</span>)
        }];
        tempColumns = [...tempColumns, {
            title: 'Comment',
            dataIndex: 'Comment',
            key: 'Comment'
        }];
        setSolumns(tempColumns);
    }

    const apiPagerQueryJob = async (exp: PagerExpression) => {
        const result = await PagerQueryJobDetail({ pagerExpression: exp, jobId: props.jobId });
        return { total: result.JobDetailPagerResult!.TotalNumber, records: result!.JobDetailPagerResult!.Result };
    };

    return (
        <>
            <AmpCommonTable RowKey="Id" Columns={columns} PagerQuery={apiPagerQueryJob} />
        </>
    );
};

export default DetailsTable;
import React, { FC } from "react";
import { Menu, Input, Row, Col, Tag, Dropdown, Modal,Button,Tooltip } from 'antd';
import { EllipsisOutlined, ExclamationCircleOutlined,PlusOutlined } from '@ant-design/icons';
import { MethodMenuDto ,MethodTypeColor} from '../../common/contracts/ModelContracts';

const { Search } = Input;

interface IAPIOperationsProps {
    title: string,
    data: MethodMenuDto[]

    menuItemClick: (item: any) => void,
    addOperation?: () => void,
    onSearchAPI: (searchText: string) => void;
    onCloneOperations: (id: string) => void;
    onDeleteOperations: (id: string) => void;

    selectedKeys:string
}

const APIOperations: FC<IAPIOperationsProps> = (props) => {

    const handleMenuClick = (event: any): void => {
        let eventKey = event.key.split(":");
        let key = eventKey[0];
        let id = eventKey[1];
        let title = eventKey[2];
        switch (key) {
            case "Clone":
                Modal.confirm({
                    title: 'Confirmation',
                    icon: <ExclamationCircleOutlined />,
                    content: 'Are you sure you want to clone operation "' + title + '"?',
                    okText: 'Confirm',
                    cancelText: 'Cancel',
                    onOk: () => props.onCloneOperations(id)
                });
                break;
            case "Delete":
                Modal.confirm({
                    title: 'Confirmation',
                    icon: <ExclamationCircleOutlined />,
                    content: 'Are you sure you want to delete operation "' + title + '"?',
                    okText: 'Yes',
                    cancelText: 'No',
                    onOk: () => props.onDeleteOperations(id)
                });

                break;
        }
    }

    const renderMenuItem = (data: MethodMenuDto[]) => {
        return (
            data.map(item => {
                const menu = (
                    <Menu onClick={handleMenuClick}>
                        <Menu.Item key={"Clone:" + item.Id + ":" + item.Name}>Clone</Menu.Item>
                        <Menu.Item key={"Delete:" + item.Id + ":" + item.Name}>Delete</Menu.Item>
                    </Menu>
                );

                const menuItem = <Menu.Item key={item.Id}>
                    <Tooltip placement="top" title={item.Name}>
                        <Tag color={MethodTypeColor.get(item.MethodName||"GET")}>{item.MethodName}</Tag>
                        <span style={{float:"right",width:"120px",overflow:"hidden",textOverflow:"ellipsis",paddingRight:"25px"}}>
                            {item.Name}
                        </span>
                    </Tooltip>
                   
                    <div onClick={(e) => e.stopPropagation()}>
                        <Dropdown placement="bottomRight" overlay={menu} trigger={['click']}>
                            <EllipsisOutlined className="right" />
                        </Dropdown>
                    </div>
                </Menu.Item>
                return menuItem;
            })
        )
    }




    return (
        <>
            <div style={{ background: 'white' }}>
                <Row style={{ height: "50px", alignContent: "center" }}>
                    <Col span={18}>
                        <div className="ant-drawer-title" style={{ float: "left", paddingLeft: "10px" }}>{props.title}</div>
                    </Col>
                    <Col span={6} >
                            <Button type="text" icon={<PlusOutlined />} style={{ float: 'right' }} onClick={props.addOperation} />
                    </Col>
                </Row>
                <Search placeholder="Input search text" style={{ paddingLeft: "10px" }} allowClear onSearch={(value) => props.onSearchAPI(value)} />
                <Menu mode="inline" onClick={props.menuItemClick} selectedKeys={[props.selectedKeys]} style={{ paddingLeft: "10px" }}>
                    {renderMenuItem(props.data)}
                </Menu>
            </div>
        </>
    )
}

export default APIOperations
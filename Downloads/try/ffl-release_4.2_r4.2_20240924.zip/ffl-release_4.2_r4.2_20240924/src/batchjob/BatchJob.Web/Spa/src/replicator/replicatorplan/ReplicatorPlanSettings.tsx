import React, {useImperativeHandle, forwardRef} from "react";
import {Input, Form, Collapse, Radio, Select} from "antd";
import * as ReplicatorContract from "../ReplicatorContract";

interface IReplicatorPlanSettingsProps {
  onSaveReplicatorPlan: Function;
  dataSource?: ReplicatorContract.ReplicatorPlan;
}

const ReplicatorPlanSettings = (props: IReplicatorPlanSettingsProps, ref: any) => {
  const [form] = Form.useForm();
  useImperativeHandle(ref, () => ({
    onNextSetting: () => {
      form.submit();
    },
  }));
  const onFinish = async (values: ReplicatorContract.ReplicatorSetting) => {
    let plan = {...props.dataSource};
    let setting = new ReplicatorContract.ReplicatorSetting();
    setting.DatetimeFormat = values.DatetimeFormat;
    setting.Splitor = values.Splitor;
    setting.Mode = values.Mode;
    setting.RunParallel = values.RunParallel;
    setting.Compress = values.Compress;
    setting.FileLimit = values.FileLimit;
    setting.FileNameTemplate = values.FileNameTemplate;
    plan.ReplicatorSetting = setting;
    props.onSaveReplicatorPlan(true, plan);
  };
  const onFinishFailed = (errorInfo: any) => {
    props.onSaveReplicatorPlan(false, "");
  };

  return (
      <Form
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
          form={form}
          layout="vertical"
      >
        <Collapse defaultActiveKey={["1"]} style={{marginBottom: 20}}>
          <Collapse.Panel header="Replicator Settings" key="1">
            <Form.Item
                name="DatetimeFormat"
                label="Datetime Format"
                rules={[{required: false, message: "Please input display name"}]}
            >
              <Input/>
            </Form.Item>
            <Form.Item
                name="Splitor"
                label="Splitor"
                rules={[{required: false, message: "Please input display name"}]}
            >
              <Input/>
            </Form.Item>
            <Form.Item
                name="RepliationModes"
                label="RepliationModes"
                rules={[{required: true, message: "Please input repliation modes"}]}
            >
              <Select placeholder="Select One" allowClear>
                {Array.from(ReplicatorContract.RepliationModesMap).map(([key, value]) => (
                    <Select.Option value={key} key={key}>
                      {value}
                    </Select.Option>
                ))}
              </Select>
            </Form.Item>
            <Form.Item
                name="RunParallel"
                label="Run Parallel"
                rules={[{required: true, message: "Please input display name"}]}
            >
              <Radio.Group>
                <Radio value={1}>True</Radio>
                <Radio value={2}>False</Radio>
              </Radio.Group>
            </Form.Item>
            <Form.Item
                name="Compress"
                label="Compress"
                rules={[{required: true, message: "Please input compress"}]}
            >
              <Radio.Group>
                <Radio value={1}>True</Radio>
                <Radio value={2}>False</Radio>
              </Radio.Group>
            </Form.Item>
            <Form.Item
                name="FileLimit"
                label="FileLimit"
                rules={[{required: false, message: "Please input display name"}]}
            >
              <Input/>
            </Form.Item>

            <Form.Item
                name="FileNameTemplate"
                label="FileName Template"
                rules={[{required: true, message: "Please input fileName template"}]}
            >
              <Input/>
            </Form.Item>
          </Collapse.Panel>
        </Collapse>
      </Form>
  );
};
export default forwardRef(ReplicatorPlanSettings);

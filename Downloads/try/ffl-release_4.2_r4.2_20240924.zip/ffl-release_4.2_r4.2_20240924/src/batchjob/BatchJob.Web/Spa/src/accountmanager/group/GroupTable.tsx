import React, { useState } from "react";
import { Table, Row, Col, Button } from 'antd';
import GroupEditForm from './GroupEditForm';
const GroupTable = (props: any) => {
    const columns = [
        {
            title: 'Group Name',
            dataIndex: 'GroupName',
            key: 'GroupName',
            sorter: true,
            render: (name: any, obj: any, index: any) => {
                return (<Button type="link" onClick={() => {
                    setEditFormData({ ...obj });
                    setVisible(true)
                }}>{name}</Button>)
            },
            width: '16%',
        }, {
            title: 'Description',
            dataIndex: 'Description',
            key: 'Description',
            width: '16%'
        }, {
            title: 'Created By',
            dataIndex: 'createdby',
            key: 'createdby',
            width: '17%'
        }, {
            title: 'Created Time',
            dataIndex: 'createdtime',
            key: 'createdtime',
            width: '17%'
        }, {
            title: 'Modified By',
            dataIndex: 'modifiedby',
            key: 'modifiedby',
            width: '17%'
        }, {
            title: 'Modified Time',
            dataIndex: 'modifiedtime',
            key: 'modifiedtime',
            width: '17%'
        }];
    const [visible, setVisible] = useState<any>(false);  
    const [EditFormData, setEditFormData] = useState<any>({});  
    const onChangeTable = (pagination: any, filters: any, sorter: any, extra: any) => {
        props.getTableChange(pagination, filters, sorter, extra)
    }
    const rowSelection = {
        onChange: (selectedRowKeys: any, selectedRows: any) => {
            console.log(selectedRowKeys,"++selectedRowKeys")
            props.func(selectedRows)
        },

    };
    const onCloseFun = () => {
        setVisible(false)
    }
    const onFinish = (values: any) => {
        console.log(values, "get Edit Data")
        setVisible(false)
    };
    return (

        <>
            <Table
                rowSelection={{ type: 'checkbox', ...rowSelection }}
                onChange={onChangeTable}
                columns={columns}
                dataSource={props.dataSource}
                rowKey='uuid'
                footer={() => { return <Row><Col span={6}>{`${props.selectLength} of ${props.dataSource.length} selected`}</Col></Row> }}
            >
            </Table>
            <GroupEditForm EditFormData={EditFormData} onCloseFun={onCloseFun} visible={visible} onGetData={onFinish} ></GroupEditForm>
        </>
    );
};

export default GroupTable;
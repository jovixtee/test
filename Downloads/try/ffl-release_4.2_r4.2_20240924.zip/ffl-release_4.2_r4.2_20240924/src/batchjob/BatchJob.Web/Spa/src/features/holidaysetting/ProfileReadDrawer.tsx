import { Button, Descriptions, Drawer, Spin, Table } from "antd";
import React, { FC, useEffect, useState } from "react";
import HolidaySettingApi from "./HolidaySettingApi";
import { HolidaySettingProfile, HolidaySettingServiceResult } from './HolidaySettingContract';
import HolidaySettingUtil from "./HolidaySettingUtil";

interface IProfileReadDrawerProps {
    visible: boolean;
    onClose: () => void;
    profile: HolidaySettingProfile
}

const ProfileReadDrawer: FC<IProfileReadDrawerProps> = (props) => {

    const [profile, setProfile] = useState<HolidaySettingProfile>({});
    const [holidaySource, setHolidaySourceSource] = useState<any[]>([]);

    const columns = [
        {
            title: 'Holiday',
            dataIndex: 'Name'
        },
        {
            title: 'Description',
            dataIndex: 'Description',
        },
        {
            title: 'Schedule Type',
            dataIndex: 'TypeStr',
        },
        {
            title: 'Date',
            dataIndex: 'DateStr',
        }
    ];

    useEffect(() => {
        if (props.profile != null) {
            console.log(props.profile)
            setProfile(props.profile);
            retrieveHolidayData(props.profile.ProfileId);
        }
    }, [props.profile]);


    const retrieveHolidayData = async (id: any) => {
        HolidaySettingApi.QueryAllHolidaysByProfileId(id).then(
            (result: HolidaySettingServiceResult) => {
                let holidayDatas = result.Holidays?.map(value => HolidaySettingUtil.ConvertVM(value))
                setHolidaySourceSource(holidayDatas || []);
            }
        ).catch((e) => {
            console.log(e);
        })
    };



    return (<Drawer visible={props.visible} width={720} onClose={(e) => props.onClose()}
        title={"View holiday"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" onClick={(e) => props.onClose()} >Close</Button>
            </div>
        }>

        <Spin spinning={false}>
            <Descriptions column={1} bordered>
                <Descriptions.Item label="Holiday Name">{profile.OrganizationName}</Descriptions.Item>
                <Descriptions.Item label="Workday">{profile.Workdays}</Descriptions.Item>
                <Descriptions.Item label="Time">{profile.TimeZoneDisplayName}</Descriptions.Item>
                <Descriptions.Item label="Holiday Number">{profile.HolidaysNumber}</Descriptions.Item>
            </Descriptions>
            <Descriptions title="Holiday" style={{ marginTop: "1.875rem" }}></Descriptions>
            <Table
                columns={columns}
                dataSource={holidaySource}
            />
        </Spin>
    </Drawer>)
};

export default ProfileReadDrawer;
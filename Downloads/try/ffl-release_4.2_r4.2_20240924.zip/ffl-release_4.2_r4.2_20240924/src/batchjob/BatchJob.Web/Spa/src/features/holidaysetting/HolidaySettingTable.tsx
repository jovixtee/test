﻿import React, { useState } from 'react';
import { Drawer, Form, Button, Col, Row, Input, Select, Table, Menu, Dropdown, Breadcrumb } from 'antd';
import { PlusOutlined, DeleteOutlined, EditOutlined, CheckCircleOutlined, StopOutlined, DownOutlined, ImportOutlined, ExportOutlined } from '@ant-design/icons';
import { any } from 'prop-types';
import apiservice from '../../utils/fetchutil';
import { PagerResult, PagerExpression } from '../../common/contracts/PagerContracts';
import { HolidayPermissionConstants, HolidaySettingServiceResult } from './HolidaySettingContract';
import { hasPermission } from '../../utils/permissionutil';
import ProfileReadDrawer from './ProfileReadDrawer';



let _externalTaskTable: EditableTable;
const { Search } = Input;
const onSearch = (value: any) => console.log(value);
let pager: PagerExpression;
const columns = [
    {
        title: 'Profile Name',
        dataIndex: 'name',
        key: 'name',
        sorter: true,
        ellipsis: true,
        width:"25%",
        //record当前行数据
        render: (name: any, record: any) => (
            <a type="link" onClick={() => { _externalTaskTable.onOpenProfile(record) }}>
                {name}
            </a>
        ),
    },
    {
        title: 'Workday',
        dataIndex: 'workday',
        key: 'workday',
        ellipsis: true,
        width:"25%",
    },
    {
        title: 'Time',
        dataIndex: 'time',
        key: 'time',
        ellipsis: true,
        width:"30%",
    },
    {
        title: 'Holiday Number',
        dataIndex: 'holidaynumber',
        key: 'holidaynumber',
        ellipsis: true,
        width:"15%"
    }
];


class EditableTable extends React.Component<any, any> {
    //这条语句的作用
    private formRef = React.createRef<any>();
    constructor(props: any) {
        super(props);
        this.state = {
            selectedRowKeys: [],
            sorter: {},
            pageData: [],
            pager: pager,
            createModal: {
                title: "Create Profile",
                visible: false,
                weeks: ['1']
            },
            importmodal: {
                visible: false,
            },
            visibleProfileDrawer: false,
            profile: {}
        };
        _externalTaskTable = this;
    };
    apiService = apiservice();
    onSelectChange = (selectedRowKeys: string[]) => {
        console.log('selectedRowKeys changed: ', selectedRowKeys);
        this.setState({ selectedRowKeys });
    };
    createEvent = () => {
        this.props.openDrawerEvent(null);
    };
    createLinkEvent = (e: any) => {
        this.props.openLinkDrawer(e);
    };
    editEvent = () => {
        this.props.openDrawerEvent(this.state.selectedRowKeys[0]);
    };

    handleimportmodalok = (event: any): void => {
    }
    handleimportmodalcancel = (event: any): void => {
    }
    onExportClick = (event: any): void => {
    }
    onImportClick = (event: any): void => {
        this.props.openImportDrawer(this.state.selectedRowKeys[0]);
    }

    handleClick = () => {
        this.props.openLinkDrawer()
    }

    handleDelete = (selectedRowKeys: any) => {
        this.apiService.post("/IHolidaySettingService/DeleteProfiles", { profileIds: this.state.selectedRowKeys }).then(
            (result: HolidaySettingServiceResult) => {
                console.log('Success', result);
                this.props.retrievePageData(this.props.pager);
            }
        ).catch((e) => {
            console.log(e);
        })
    };

    handleLinkEvent = (selectedRowKeys: any) => {
        _externalTaskTable.createLinkEvent(this.state.selectedRowKeys[0]);
    };

    onOpenProfile = (e: any) => {
        this.setState({ visibleProfileDrawer: true, profile: e });
    };

    onCloseProfile = () => {
        this.setState({ visibleProfileDrawer: false });
    };

    render() {
        const { selectedRowKeys } = this.state;
        const rowSelection: any = {
            selectedRowKeys,
            onChange: this.onSelectChange,
        };
        const hasSelected = selectedRowKeys.length > 0;
        const isSingleSelected = selectedRowKeys.length == 1;
        const selectedSingleData = () => {
            if (selectedRowKeys.length != 1) {
                return undefined;
            }
            // return this.state.pageData.find((data:any)=>{return data.key == this.state.selectedRowKeys[0]}) 
        };

        return (

            <div style={{ height: '700' }}>
                <div style={{ marginBottom: 16 }}>
                    <Button type="text" disabled={!hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Create)} icon={<PlusOutlined />} onClick={this.createEvent}>Create</Button>
                    <Button type="text"
                        disabled={!hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Update) || this.state.selectedRowKeys.length !== 1}
                        icon={<EditOutlined />}
                        onClick={this.editEvent}>
                        Update
                    </Button>
                    <Button type="text"
                        disabled={!hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Delete) || this.state.selectedRowKeys.length < 1}
                        icon={<DeleteOutlined />}
                        onClick={this.handleDelete}>
                        Delete
                    </Button>
                    <Button type="text"
                        disabled={!hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Create) || this.state.selectedRowKeys.length !== 1}
                        icon={<PlusOutlined twoToneColor="#eb2f96" />}
                        onClick={this.handleLinkEvent}>
                        Holidays
                    </Button>

                    <Button type="text"
                        disabled={!hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Delete) || this.state.selectedRowKeys.length < 1}
                        icon={<ImportOutlined />} onClick={this.onImportClick}>Import</Button>
                    <Button type="text"
                        disabled={!hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Delete) || this.state.selectedRowKeys.length < 1}
                        icon={<ExportOutlined />} onClick={this.onExportClick}>Export</Button>

                    <div style={{ float: 'right' }}>
                        <Search
                            placeholder="input Keywords"
                            allowClear
                            onSearch={(val) => {
                                let seachPager = this.props.pager;
                                seachPager.SearchValue = val;
                                this.setState({ pager: seachPager });
                                this.props.retrievePageData(seachPager);
                            }}
                            style={{ width: 200, margin: '0 10px' }}
                        />
                    </div>
                </div>
                <Table rowSelection={rowSelection}
                    columns={columns}
                    dataSource={this.props.pageData}
                />
                <ProfileReadDrawer
                    visible={this.state.visibleProfileDrawer}
                    onClose={this.onCloseProfile}
                    profile={this.state.profile} />
            </div>


        );
    }
}
export default EditableTable;










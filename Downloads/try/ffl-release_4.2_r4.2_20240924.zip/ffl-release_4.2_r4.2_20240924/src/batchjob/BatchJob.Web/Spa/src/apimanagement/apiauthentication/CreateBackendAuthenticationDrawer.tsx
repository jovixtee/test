import React, {FC, useEffect, useState} from "react";
import {Button, Drawer, Form, Input, message, Select, Spin, Upload} from "antd";
import {AuthenticationTypeMap, GrantTypeMap, HashTypeMap,} from "./APIAuthenticationContract";
import {ApiKeyDto, APIKeyType, AuthenticationDto, AuthType, BasicDto, ClientCertDto, ConstDto, CustomiseDto, CustomType, FromType, GrantType, HashType, JWTDto, MyInfoDto, OAuthDto,} from "../../common/contracts/ModelContracts";
import {UploadOutlined} from "@ant-design/icons";
import {UploadFile} from "antd/lib/upload/interface";
import {CreateAuthentication,} from "./APIAuthenticationService";

interface IDataFrom {
    Name?: string;
    Description?: string;
    Type?: AuthType;
    APIKeyType?: APIKeyType;
    ClientId?: string;
    Secret?: string;
    HashType?: HashType;
    AuthenticationUserName?: string;
    AuthenticationPassword?: string;
    TokenEndpoint?: string;
    CustomType?: CustomType;
    Host?: string;
    Passphrase?: string;
    Scope?: string;
    Password?: string;
    AuthorizationHeader?: string;
    ConstKey?: string;
    GrantType?:GrantType;
    AuthorizationUrl?: string;
    RefreshTokenUrl?: string;
    RedirectUrl?: string;
}

interface ICreateBackendAuthenticationDrawerProps {
    visible: boolean;
    cancelClick: VoidFunction;
    isEdit: boolean;
    editingId: string;
    getTableData: VoidFunction;
    editData?: AuthenticationDto;
}

const {Option} = Select;
const CreateBackendAuthenticationDrawer: FC<ICreateBackendAuthenticationDrawerProps> =
    (props) => {
        const [certificate, setCertificate] = useState<string>("");
        const [typeValue, setTypeValue] = useState<AuthType>();
        const [apiKeyValue, setApiKeyValue] = useState<APIKeyType>();
        const [fileList, setFileList] = useState<any[]>([]);
        const [customValue, setCustomValue] = useState<CustomType>();
        const [checkResult, setCheckResult] = useState<boolean>(true);
        const [loading, setLoading] = useState<boolean>(false);
        const [buttonLoading, setButtonLoading] = useState<boolean>(false);
        const [fromType, setFromType] = useState<boolean>(false);
        const [uploadFile, setUploadFile] = useState<UploadFile>();
        const [grantTypeEnum, setGrantTypeEnum] = useState<GrantType>();
        const [form] = Form.useForm();

        useEffect(() => {
            if (props.visible) {
                setUploadFile(undefined);
                setFileList([]);
                if (props.editingId) {
                    makeFormData(props.editData ?? new AuthenticationDto);
                    // requestGetAuthenticationById(props.editingId);
                } else {
                    setFromType(false);
                }
            }
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [props.editingId, props.visible]);

        useEffect(() => {
            form.validateFields(["Certificate", "Secret"]);
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [checkResult]);

        const makeFormData = (result: AuthenticationDto): void => {
            if (result.Id) {
                let data: any = {};
                setTypeValue(result.AuthType);
                data.Name = result.Name;
                data.Description = result.Description;
                data.FromType = result.FromType;
                setFromType(result.FromType === FromType.Frontend);
                data.Type = result.AuthType;
                if (result.AuthType === AuthType.OAuth) {
                    data.TokenEndpoint = (result.AuthSetting as OAuthDto)!.TokenEndpoint;
                    data.ClientId = (result.AuthSetting as OAuthDto)!.ClientId;
                    data.Secret = (result.AuthSetting as OAuthDto)!.Secret;
                    data.Scope = (result.AuthSetting as OAuthDto)!.Scope;
                    let grantType = (result.AuthSetting as OAuthDto)!.GrantType;
                    setGrantTypeEnum(grantType);
                    data.GrantType = grantType;
                    if(grantType === GrantType.Code){
                        data.AuthorizationUrl = (result.AuthSetting as OAuthDto)!.AuthorizationUrl;
                        data.RefreshTokenUrl = (result.AuthSetting as OAuthDto)!.RefreshTokenUrl;
                        data.RedirectUrl = `${window.location.protocol}://${window.location.host}/auth-callback`;
                    }
                }

                if (result.AuthType === AuthType.APIKey) {
                    let apiKey = result.AuthSetting as ApiKeyDto;
                    data.APIKeyType = apiKey.APIKeyType;
                    setApiKeyValue(apiKey.APIKeyType);
                    if (apiKey.APIKeyType === APIKeyType.JWT) {
                        let dto = apiKey.APIKeySetting as JWTDto;
                        data.HashType = dto.HashType;
                        data.ClientId = dto.ClientId;
                        data.Secret = dto.Secret;
                        if (result.Certificate) {
                            let fileName = [{"name": getFileNameByPath(result!.Certificate!)}];
                            setFileList(fileName);
                            setCertificate(result.Certificate!);
                            // console.log(fileName);
                        }
                    }

                    if (apiKey.APIKeyType === APIKeyType.Basic) {
                        let dto = apiKey.APIKeySetting as BasicDto;
                        data.AuthenticationUserName = dto.UserName;
                        data.AuthenticationPassword = dto.Password;
                    }

                    if (apiKey.APIKeyType === APIKeyType.Constants) {
                        let dto = apiKey.APIKeySetting as ConstDto;
                        data.ConstKey = dto.ConstKey;
                    }
                }
                if (result.AuthType === AuthType.ClientCert) {
                    let cert = result.AuthSetting as ClientCertDto;
                    data.Host = cert!.Host;
                    data.Passphrase = cert!.Passphrase;
                    let fileName = [{"name": getFileNameByPath(result.Certificate!)}];
                    setCertificate(result.Certificate!);
                    setFileList(fileName);
                    data.CertFile = fileName;
                }

                if (result.AuthType === AuthType.Customise) {
                    let customise = result.AuthSetting as CustomiseDto;
                    data.CustomType = customise.CustomType;
                    setCustomValue(customise.CustomType);
                    if (customise.CustomType === CustomType.MyInfo) {
                        let myinfo = customise.CustomiseSetting as MyInfoDto;
                        data.ClientId = myinfo.ApplicationID;
                        data.Secret = myinfo.EServiceID;
                        data.Password = myinfo.Password;
                        let fileName = [{"name": getFileNameByPath(result.Certificate!)}];
                        setCertificate(result.Certificate!);
                        setFileList(fileName);
                        data.CertFile = fileName;
                    }
                }
                form.setFieldsValue(data);
            }
        }

        // const requestGetAuthenticationById = (Id: string): void => {
        //     setLoading(true);
        //     GetAuthenticationById(Id)
        //         .then((result) => {
        //             if (result) {
        //                 let data: any = {};
        //                 setTypeValue(result.AuthType);
        //                 data.Name = result.Name;
        //                 data.Description = result.Description;
        //                 data.FromType = result.FromType;
        //                 setFromType(result.FromType === FromType.Frontend);
        //                 data.Type = result.AuthType;
        //                 if (result.AuthType === AuthType.OAuth) {
        //                     data.TokenEndpoint = (result.AuthSetting as OAuthDto)!.TokenEndpoint;
        //                     data.ClientId = (result.AuthSetting as OAuthDto)!.ClientId;
        //                     data.Secret = (result.AuthSetting as OAuthDto)!.Secret;
        //                     data.Scope = (result.AuthSetting as OAuthDto)!.Scope;
        //                     let grantType = (result.AuthSetting as OAuthDto)!.GrantType;
        //                     data.GrantType = grantType;
        //                     setGrantTypeEnum(grantType);
        //                     if(grantType === GrantType.Code){
        //                         data.AuthorizationUrl = (result.AuthSetting as OAuthDto)!.AuthorizationUrl;
        //                         data.RefreshTokenUrl = (result.AuthSetting as OAuthDto)!.RefreshTokenUrl;
        //                         data.RedirectUrl = (result.AuthSetting as OAuthDto)!.RedirectUrl;
        //                     }
        //                 }
        //
        //                 if (result.AuthType === AuthType.APIKey) {
        //                     let apiKey = result.AuthSetting as ApiKeyDto;
        //                     data.APIKeyType = apiKey.APIKeyType;
        //                     setApiKeyValue(apiKey.APIKeyType);
        //                     if (apiKey.APIKeyType === APIKeyType.JWT) {
        //                         let dto = apiKey.APIKeySetting as JWTDto;
        //                         data.HashType = dto.HashType;
        //                         data.ClientId = dto.ClientId;
        //                         data.Secret = dto.Secret;
        //                         if (result.Certificate) {
        //                             let fileName = [{"name": getFileNameByPath(result!.Certificate!)}];
        //                             setFileList(fileName);
        //                             setCertificate(result.Certificate!);
        //                             //console.log(fileName);
        //                         }
        //                     }
        //
        //                     if (apiKey.APIKeyType === APIKeyType.Basic) {
        //                         let dto = apiKey.APIKeySetting as BasicDto;
        //                         data.AuthenticationUserName = dto.UserName;
        //                         data.AuthenticationPassword = dto.Password;
        //                     }
        //
        //                     if (apiKey.APIKeyType === APIKeyType.Constants) {
        //                         let dto = apiKey.APIKeySetting as ConstDto;
        //                         data.ConstKey = dto.ConstKey;
        //                     }
        //                 }
        //                 if (result.AuthType === AuthType.ClientCert) {
        //                     let cert = result.AuthSetting as ClientCertDto;
        //                     data.Host = cert!.Host;
        //                     data.Passphrase = cert!.Passphrase;
        //                     let fileName = [{"name": getFileNameByPath(result.Certificate!)}];
        //                     setCertificate(result.Certificate!);
        //                     setFileList(fileName);
        //                     data.CertFile = fileName;
        //                 }
        //                 if (result.AuthType === AuthType.Customise) {
        //                     let customise = result.AuthSetting as CustomiseDto;
        //                     data.CustomType = customise.CustomType;
        //                     setCustomValue(customise.CustomType);
        //                     if (customise.CustomType === CustomType.MyInfo) {
        //                         let myinfo = customise.CustomiseSetting as MyInfoDto;
        //                         data.ClientId = myinfo.ApplicationID;
        //                         data.Secret = myinfo.EServiceID;
        //                         data.Password = myinfo.Password;
        //                     }
        //                 }
        //                 form.setFieldsValue(data);
        //             }
        //         })
        //         .finally(() => {
        //             setLoading(false);
        //         });
        // };

        const getFileNameByPath = function (path: string) {
            var pos1 = path.lastIndexOf("/");
            var pos2 = path.lastIndexOf("\\");
            var pos = Math.max(pos1, pos2);
            if (pos < 0) {
                return path;
            } else {
                return path.substring(pos + 1);
            }
        };

        const onFailed = (values: any) => {
            console.log("Failed:", values);
        };

        const closeDrawer = (): void => {
            form.resetFields();
            setTypeValue(undefined);
            setCustomValue(undefined);
            props.cancelClick();
        };
        const onTypechange = (value: AuthType): void => {
            setTypeValue(value);
            form.resetFields([
                "ClientId",
                "Secret",
                "AuthenticationUserName",
                "AuthenticationPassword",
            ]);
        };

        const onGranttype = (value: GrantType): void => {
            setGrantTypeEnum(value);
            form.setFieldsValue({"RedirectUrl": `${window.location.protocol}://${window.location.host}/auth-callback`});
        };

        const handleChange = (info: any) => {
            let keyList = [...info.fileList];
            keyList = keyList.slice(-2);
            setFileList(keyList);
        }

        const beforeUpload = (file: any, FileList: UploadFile[]) => {
            const isLt2M = file.size / 1024 / 1024 < 2;
            if (!isLt2M) {
                setFileList([]);
                message.error('file must smaller than 2MB!');
                return false;
            } else {
                setUploadFile(file);
            }
            return true;
        };


        const normFile = (e: any) => {
            if (Array.isArray(e)) {
                return e;
            }
            return e && e.fileList;
        };
        const checkSecretOrCertificate = (
            rule: any,
            value: any,
            callback: any
        ): void => {
            const formFileList = form.getFieldValue("Certificate");
            const secretValue = form.getFieldValue("Secret");
            const hasFile = formFileList && formFileList.length > 0;
            if (secretValue || hasFile) {
                setCheckResult(false);
                callback();
            } else {
                setCheckResult(true);
                callback("error");
            }
        };

        const onRemove = (file: any) => {
            setFileList([]);
            setUploadFile(undefined);
            setCertificate("");
        };

        const onFinish = (values: IDataFrom) => {
            setButtonLoading(true);
            setLoading(true);
            let requestObject = new AuthenticationDto();
            requestObject.Name = values.Name;
            requestObject.Description = values.Description;
            requestObject.FromType = fromType ? FromType.Frontend : FromType.Backend;
            requestObject.AuthType = values.Type;
            if (values.Type === AuthType.OAuth) {
 
                let oauth = new OAuthDto();
                oauth.ClientId = values.ClientId;
                oauth.Secret = values.Secret;
                oauth.Scope = values.Scope;
                oauth.TokenEndpoint = values.TokenEndpoint;
                oauth.GrantType = values.GrantType;
                if(values.GrantType ===GrantType.Code){
                    oauth.AuthorizationUrl = values.AuthorizationUrl;
                    oauth.RefreshTokenUrl= values.RefreshTokenUrl;
                    oauth.RedirectUrl= values.RedirectUrl;
                }
                requestObject.AuthSetting = oauth;
            } else if (
                values.Type === AuthType.APIKey &&
                values.APIKeyType === APIKeyType.JWT
            ) {
                let apikey = new ApiKeyDto();
                let jwt = new JWTDto();
                jwt.HashType = values.HashType;
                jwt.ClientId = values.ClientId;
                jwt.Secret = values.Secret;
                apikey.APIKeyType = values.APIKeyType;
                apikey.APIKeySetting = jwt;
                requestObject.Certificate = certificate;
                requestObject.AuthSetting = apikey;
            } else if (
                values.Type === AuthType.APIKey &&
                values.APIKeyType === APIKeyType.Basic
            ) {
                let apikey = new ApiKeyDto();
                let basic = new BasicDto();
                basic.UserName = values.AuthenticationUserName;
                basic.Password = values.AuthenticationPassword;
                apikey.APIKeyType = values.APIKeyType;
                apikey.APIKeySetting = basic;
                requestObject.AuthSetting = apikey;
            } else if (
                values.Type === AuthType.APIKey &&
                values.APIKeyType === APIKeyType.Constants
            ) {
                let apikey = new ApiKeyDto();
                let constDto = new ConstDto();
                constDto.ConstKey = values.ConstKey;
                constDto.AuthorizationHeader = values.AuthorizationHeader;
                apikey.APIKeyType = values.APIKeyType;
                apikey.APIKeySetting = constDto;
                requestObject.AuthSetting = apikey;
            } else if (values.Type === AuthType.ClientCert) {
                let cert = new ClientCertDto();
                cert.Host = values.Host;
                cert.Passphrase = values.Passphrase;
                requestObject.AuthSetting = cert;
                requestObject.Certificate = certificate;
            } else if (values.Type === AuthType.Customise) {
                let custom = new CustomiseDto();
                custom.CustomType = values.CustomType;
                if (values.CustomType === CustomType.MyInfo) {
                    custom.CustomType = CustomType.MyInfo;
                    let myinfo = new MyInfoDto();
                    myinfo.ApplicationID = values.ClientId;
                    myinfo.EServiceID = values.Secret;
                    myinfo.Password = values.Password;
                    custom.CustomiseSetting = myinfo;
                    requestObject.Certificate = certificate;
                }
                requestObject.AuthSetting = custom;
            }
            if (props.isEdit) {
                requestObject.Id = props.editingId;
            }
            CreateAuthentication(requestObject, uploadFile)
                .then((res) => {
                    setButtonLoading(false);
                    setLoading(false);
                    closeDrawer();
                    props.getTableData();
                })
                .catch((err) => {
                    setButtonLoading(false);
                    setLoading(false);
                });
        };
        
        const renderCode = () =>{
            return (
                <>
                    <Form.Item
                        label="Authorization Url"
                        name="AuthorizationUrl"
                        rules={[
                            {
                                required: true,
                                message: "Please input authorization url!",
                            },
                        ]}
                    >
                        <Input maxLength={256}/>
                    </Form.Item>

                    <Form.Item
                        label="Refresh Token Url"
                        name="RefreshTokenUrl"
                        rules={[
                            {
                                required: true,
                                message: "Please input refresh token url!",
                            },
                        ]}
                    >
                        <Input maxLength={256}/>
                    </Form.Item>

                    <Form.Item
                        label="Redirect Url"
                        name="RedirectUrl"
                        rules={[
                            {
                                required: false,
                                message: "Please input redirect url",
                            },
                        ]}
                    >
                        <Input maxLength={256} disabled={true}/>
                    </Form.Item>
                    
                    
                </>
                );
        }
        

        const renderOAuthItem = () => {
            return (
                <>
                    <Form.Item
                        label="Grant type"
                        name="GrantType"
                        rules={[{required: true, message: "Please select a grant type!"}]}
                    >
                        <Select style={{width: "100%"}} onChange={onGranttype}>
                            {Array.from(GrantTypeMap).map(([key, value]) => (
                                <Option value={value} key={value}>
                                    {key}
                                </Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        label="Client Id"
                        name="ClientId"
                        rules={[
                            {
                                required: true,
                                message: "Please input client id!",
                            },
                        ]}
                    >
                        <Input maxLength={256}/>
                    </Form.Item>
                    <Form.Item
                        label="Client Secret"
                        name="Secret"
                        rules={[
                            {
                                required: true,
                                message: "Please input client secret!",
                            },
                        ]}
                    >
                        <Input maxLength={256}/>
                    </Form.Item>

                    {!fromType &&
                        <>
                            <Form.Item
                                label="Access Token Url"
                                name="TokenEndpoint"
                                rules={[{required: true, message: "Please input Access Token Url!"}]}
                            >
                                <Input maxLength={256}/>
                            </Form.Item>
                        </>
                    }
                    <Form.Item
                        label="Scope"
                        name="Scope"
                        rules={[{required: fromType, message: "Please input scope!"}]}
                    >
                        <Input maxLength={256}/>
                    </Form.Item>
                    { grantTypeEnum=== GrantType.Code && renderCode() }
                </>
            );
        };

        const renderApiKeyItem = () => {
            return (
                <>
                    <Form.Item
                        label="Scheme"
                        name="APIKeyType"
                        rules={[{required: true, message: "Please input API Key Type!"}]}
                    >
                        <Select
                            style={{width: "100%"}}
                            onChange={(e: APIKeyType) => setApiKeyValue(e)}
                        >
                            {Object.keys(APIKeyType)
                                .filter((r) => !isNaN(Number(r)))
                                .map((key) => {
                                    let item = Number(key);
                                    return (
                                        <Option value={item} key={item}>
                                            {APIKeyType[item]}
                                        </Option>
                                    );
                                })}
                        </Select>
                    </Form.Item>
                    {apiKeyValue === APIKeyType.JWT && (
                        <>
                            <Form.Item
                                label="Hash"
                                initialValue={1}
                                name="HashType"
                                rules={[{required: true, message: "Please select HashType!"}]}
                            >
                                <Select style={{width: "100%"}}>
                                    {Array.from(HashTypeMap).map(([key, value]) => (
                                        <Option value={value} key={value}>
                                            {key}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                            <Form.Item
                                label="Client Id"
                                name="ClientId"
                                rules={[{required: true, message: "Please input ClientId!"}]}
                            >
                                <Input maxLength={256}/>
                            </Form.Item>
                            <Form.Item
                                label="Secret"
                                name="Secret"
                                required={false}
                                rules={[
                                    {
                                        required: checkResult,
                                        validator: checkSecretOrCertificate,
                                        message: "Please input Secret Or Certificate!",
                                    },
                                ]}
                            >
                                <Input maxLength={256}/>
                            </Form.Item>
                            <Form.Item
                                name="Certificate"
                                label="Certificate"
                                valuePropName="Certificate"
                                getValueFromEvent={normFile}
                                required={false}
                                rules={[
                                    {
                                        required: checkResult,
                                        validator: checkSecretOrCertificate,
                                        message: "Please input Secret Or Certificate!",
                                    },
                                ]}
                            >
                                <Upload
                                    name="Certificate"
                                    maxCount={1}
                                    beforeUpload={beforeUpload}
                                    fileList={fileList}
                                    multiple={false}
                                    onRemove={onRemove}
                                    onChange={handleChange}
                                    accept={'.pfx,.cert'}
                                >
                                    <Button icon={<UploadOutlined/>}>Click to upload</Button>
                                </Upload>
                            </Form.Item>
                        </>
                    )}
                    {apiKeyValue === APIKeyType.Basic && (
                        <>
                            <Form.Item
                                label="UserName"
                                name="AuthenticationUserName"
                                rules={[{required: true, message: "Please input UserName!"}]}
                            >
                                <Input maxLength={256}/>
                            </Form.Item>
                            <Form.Item
                                label="Password"
                                name="AuthenticationPassword"
                                rules={[{required: true, message: "Please input Password!"}]}
                            >
                                <Input.Password maxLength={256}/>
                            </Form.Item>
                        </>
                    )}
                    {apiKeyValue === APIKeyType.Constants && (
                        <>
                            {
                                !fromType &&
                                <Form.Item
                                    label="Authorization Header"
                                    name="AuthorizationHeader"
                                    initialValue={"Authorization"}
                                    rules={[{required: true, message: "Please input authorization header!"}]}>
                                    <Input/>
                                </Form.Item>
                            }
                            <Form.Item
                                label="Const Key"
                                name="ConstKey"
                                rules={[
                                    {required: true, message: "Please input Const Key!"},
                                ]}
                            >
                                <Input maxLength={256}/>
                            </Form.Item>
                        </>
                    )}
                </>
            );
        };

        const renderCustomise = () => {
            return (
                <>
                    <Form.Item
                        label="Custom Type"
                        name="CustomType"
                        rules={[
                            {required: true, message: "Please select Custom Type!"},
                        ]}
                    >
                        <Select
                            style={{width: "100%"}}
                            onChange={(e: CustomType) => setCustomValue(e)}
                        >
                            {Object.keys(CustomType)
                                .filter((r) => !isNaN(Number(r)))
                                .map((key) => {
                                    let item = Number(key);
                                    return (
                                        <Option value={item} key={item}>
                                            {CustomType[item]}
                                        </Option>
                                    );
                                })}
                        </Select>
                    </Form.Item>

                    {customValue === CustomType.MyInfo && (
                        <>
                            <Form.Item
                                label="Application Id"
                                name="ClientId"
                                rules={[
                                    {
                                        required: true,
                                        message: "Please input Application Id!",
                                    },
                                ]}
                            >
                                <Input maxLength={256}/>
                            </Form.Item>
                            <Form.Item
                                label="EService Id"
                                name="Secret"
                                rules={[
                                    {required: true, message: "Please input EService Id!"},
                                ]}
                            >
                                <Input maxLength={256}/>
                            </Form.Item>
                            <Form.Item
                                label="Certificate Password"
                                name="Password"
                                rules={[
                                    {
                                        required: true,
                                        message: "Please input Certificate Password!",
                                    },
                                ]}
                            >
                                <Input maxLength={256}/>
                            </Form.Item>
                            <Form.Item
                                name="CertFile"
                                label="Certificate"
                                valuePropName="CertFile"
                                getValueFromEvent={normFile}
                                rules={[{required: true, message: "Please upload Certificate!"}]}
                            >
                                <Upload
                                    name="CertFile"
                                    maxCount={1}
                                    beforeUpload={beforeUpload}
                                    fileList={fileList}
                                    multiple={false}
                                    onChange={handleChange}
                                    accept={'.pfx,.cert,.crt'}
                                >
                                    <Button icon={<UploadOutlined/>}>Click to upload</Button>
                                </Upload>
                            </Form.Item>
                        </>
                    )}
                </>);
        }

        const renderClientCertItem = () => {
            return (
                <>
                    {<Form.Item
                        label="Host"
                        name="Host"
                        rules={[{required: false, message: "Please input Host!"}]}
                    >
                        <Input maxLength={256}/>
                    </Form.Item>}
                    <Form.Item
                        label="Passphrase"
                        name="Passphrase"
                        rules={[
                            {
                                required: true,
                                message: "Please input Passphrase!",
                            },
                        ]}
                    >
                        <Input maxLength={256}/>
                    </Form.Item>

                    <Form.Item
                        name="CertFile"
                        label="Certificate"
                        valuePropName="CertFile"
                        getValueFromEvent={normFile}
                        rules={[{required: true, message: "Please upload Certificate!"}]}
                    >
                        <Upload
                            name="CertFile"
                            maxCount={1}
                            beforeUpload={beforeUpload}
                            fileList={fileList}
                            multiple={false}
                            onChange={handleChange}
                            accept={'.pfx,.cert'}
                        >
                            <Button icon={<UploadOutlined/>}>Click to upload</Button>
                        </Upload>
                    </Form.Item>
                </>
            );
        };

        return (
            <Drawer
                visible={props.visible}
                width={720}
                destroyOnClose
                forceRender
                onClose={closeDrawer}
                title={
                    props.isEdit
                        ? "Edit " + (fromType ? "Frontend" : "Backend ") + " Authentication"
                        : "Create a new " + (fromType ? "Frontend" : "Backend ") + " Authentication"
                }
                footer={
                    <div style={{textAlign: "right"}}>
                        <Button
                            type="primary"
                            style={{marginRight: 8}}
                            disabled={!buttonLoading && loading}
                            loading={loading}
                            onClick={() => form.submit()}
                        >
                            Save
                        </Button>
                        <Button onClick={closeDrawer}>Cancel</Button>
                    </div>
                }
            >
                <Spin spinning={loading}>
                    <Form
                        layout="vertical"
                        form={form}
                        onFinish={onFinish}
                        onFinishFailed={onFailed}
                        style={{marginTop: "1.25rem"}}
                    >
                        <Form.Item
                            label="Name"
                            name="Name"
                            rules={[{required: true, message: "Please input name!"}]}
                        >
                            <Input maxLength={256}/>
                        </Form.Item>
                        <Form.Item
                            label="Description"
                            name="Description"
                            rules={[{required: false}]}
                        >
                            <Input.TextArea rows={3}/>
                        </Form.Item>
                        <Form.Item
                            label="Authentication Type"
                            name="Type"
                            rules={[{required: true, message: "Please select a Authentication Type!"}]}
                        >
                            <Select style={{width: "100%"}} onChange={onTypechange}>
                                {Array.from(AuthenticationTypeMap).map(([key, value]) => (
                                    <Option value={value} key={value}>
                                        {key}
                                    </Option>
                                ))}
                            </Select>
                        </Form.Item>
                        {typeValue === AuthType.OAuth && renderOAuthItem()}
                        {typeValue === AuthType.APIKey && renderApiKeyItem()}
                        {typeValue === AuthType.ClientCert && renderClientCertItem()}
                        {typeValue === AuthType.Customise && renderCustomise()}

                    </Form>
                </Spin>
            </Drawer>
        );
    };
export default CreateBackendAuthenticationDrawer;

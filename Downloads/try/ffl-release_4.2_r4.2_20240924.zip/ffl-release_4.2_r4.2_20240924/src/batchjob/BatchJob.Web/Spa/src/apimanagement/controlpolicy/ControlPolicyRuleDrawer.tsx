import React, { FC, useEffect, useRef, useState } from 'react';
import { Drawer, Form, Input, Button, Spin, Select } from 'antd';
import { ControlPolicyRuleDto, RuleTypeMap, LimitTypeMap, BlockTypeMap, BlockTypeEnum, IPAddress, LimitType, RuleTypeEnum, ExtensionRateLimitDto, ExtensionBlockRuleDto } from '../../common/contracts/ModelContracts';
import IPAddressEditTable from "./IPAddressEditTable";
import { CreateControlPolicyRule, GetControlPolicyRuleById } from './ControlPolicyApiService'


interface IFormData {
    RuleType?: RuleTypeEnum;
    LimitType?: LimitType;
    Period?: string;
    Limit?: string;

    BlockType?: BlockTypeEnum;
}

interface IControlPolicyRuleDrawerProps {
    visible: boolean;
    closeDrawer: () => void;
    refresh: (searchText: string) => void;
    policyId: string;
    ruleId?: string;
}


const { Option } = Select;


const ControlPolicyRuleDrawer: FC<IControlPolicyRuleDrawerProps> = (props) => {
    const [loading, setLoading] = useState<boolean>(false);
    const [ruleType, setRuleType] = useState<RuleTypeEnum>(RuleTypeEnum.RateLimite);
    const [ipAddress, setIPAddress] = useState<IPAddress[]>([]);
    const [policyId, setPolicyId] = useState<string>("");
    const [form] = Form.useForm();
    const ipRef = useRef<any>();
    const [notAllowedIPAddress, setNotAllowedIPAddress] = useState<IPAddress[]>([]);
    const [allowedIPAddress, setAllowedIPAddress] = useState<IPAddress[]>([]);

    useEffect(() => {
        if (props.ruleId && props.ruleId.length > 0) {
            handleGetControlPolicyRuleById(props.ruleId);
        } else {
            setRuleType(RuleTypeEnum.RateLimite);
            setPolicyId(props.policyId);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.visible, props.ruleId, props.policyId]);

    const handleGetControlPolicyRuleById = (id: string) => {
        setLoading(true)
        GetControlPolicyRuleById(id).then(res => {
            setPolicyId(res.PolicyID);
            setRuleType(res.RuleType);
            if (res.RuleType === RuleTypeEnum.RateLimite) {
                let RateLimit = res.RateLimit;
                form.setFieldsValue({
                    "RuleType": res.RuleType,
                    "LimitType": RateLimit.LimitType,
                    "Limit": RateLimit.Limit,
                    "Period": RateLimit.Period
                });
            } else {
                let blockRule = res.BlockRule;
                form.setFieldsValue({
                    "RuleType": res.RuleType,
                    "BlockType": blockRule.BlockType
                });
                setIPAddress(blockRule.IPRule); 
                if(blockRule.BlockType === BlockTypeEnum.Allowed){   
                    setAllowedIPAddress(blockRule.IPRule);
                }else{
                    setNotAllowedIPAddress(blockRule.IPRule);
                }
               
            }

            console.log(res);
        }).finally(() => setLoading(false));
    }

    const handleCreateControlPolicyRule = (dto: ControlPolicyRuleDto) => {
        setLoading(true)
        CreateControlPolicyRule(dto).then(res => {
            props.refresh("");
            form.resetFields();
            props.closeDrawer();
        }).finally(() => setLoading(false));
    }


    const onFailed = (values: any) => {
        console.log('Failed:', values);
    }

    const onFinish = (values: IFormData) => {
        let requestObject = new ControlPolicyRuleDto();
        if (props.ruleId && props.ruleId.length > 0) {
            requestObject.Id = props.ruleId;
        }
        requestObject.PolicyID = policyId;
        requestObject.RuleType = values.RuleType;
        if (values.RuleType === RuleTypeEnum.RateLimite) {
            let rateLimitDto = new ExtensionRateLimitDto();
            rateLimitDto.LimitType = values.LimitType;
            rateLimitDto.Limit = values.Limit;
            rateLimitDto.Period = values.Period;
            requestObject.RateLimit = rateLimitDto;
        } else {
            let blockRuleDto = new ExtensionBlockRuleDto();
            blockRuleDto.BlockType = values.BlockType;
            let data = ipRef.current.getTableResult()
            let ipRule = data.map((item: IPAddress) => { return { Id: item.Id, AddressFrom: item.AddressFrom, AddressTo: item.AddressTo } }) || [];
            blockRuleDto.IPRule = ipRule
            requestObject.BlockRule = blockRuleDto;
        }
        handleCreateControlPolicyRule(requestObject);
    }

    const closeDrawer = () => {
        form.resetFields();
        setIPAddress([]);
        setNotAllowedIPAddress([]);
        setAllowedIPAddress([]);
        props.closeDrawer();
    }

    const onFilterTypeChange = (e: BlockTypeEnum) => {
          
           let data = ipRef.current.getTableResult();
            if(e === BlockTypeEnum.NotAllowed){
                setIPAddress(notAllowedIPAddress);
                setAllowedIPAddress(data);

            }
            if(e === BlockTypeEnum.Allowed){
                setIPAddress(allowedIPAddress);
                setNotAllowedIPAddress(data);
            }
            
    }

    return <Drawer
        visible={props.visible}
        width={720}
        destroyOnClose
        forceRender
        onClose={closeDrawer}
        title={(props.ruleId && props.ruleId.length > 0) ? "Edit rule" : "Add rule"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" style={{ marginRight: 8 }} onClick={() => form.submit()}>Save</Button>
                <Button onClick={closeDrawer} >Cancel</Button>
            </div>
        }>
        <Spin spinning={loading}>
            <Form layout="vertical" form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '1.25rem' }}>

                <Form.Item label="RuleType" name="RuleType" initialValue={RuleTypeEnum.RateLimite} rules={[{ required: true, message: 'Please input rule type!' }]}>
                    <Select style={{ minWidth: 120 }} onChange={(e: RuleTypeEnum) => setRuleType(e)}>
                        {
                            Array.from(RuleTypeMap).map(([key, value]) => <Option value={value} key={value}>{key}</Option>)
                        }
                    </Select>
                </Form.Item>
                {ruleType === RuleTypeEnum.RateLimite &&
                    <>
                        <Form.Item label="Type" name="LimitType" initialValue={LimitType.ByCount} rules={[{ required: true, message: 'Please select limitType!' }]}>
                            <Select style={{ minWidth: 120 }} >
                                {
                                    Array.from(LimitTypeMap).map(([key, value]) => <Option value={value} key={value}>{key}</Option>)
                                }
                            </Select>
                        </Form.Item>
                        <Form.Item label="Number of calls" name="Limit" rules={[{ required: true, pattern: new RegExp(/^[0-9]\d*$/, "g"),message: 'Please input number of calls!' }]}>
                            <Input type="text"  />
                        </Form.Item>
                        <Form.Item label="Renewal period (S)" name="Period" rules={[{ required: true,pattern: new RegExp(/^[0-9]\d*$/, "g"), message: 'Please input renewal period (S)!' }]}>
                            <Input type="text"  />
                        </Form.Item>
                    </>
                }
                {ruleType === RuleTypeEnum.IPFilter &&
                    <>
                        <Form.Item label="Type" name="BlockType" initialValue={BlockTypeEnum.Allowed} rules={[{ required: true, message: 'Please select LimitType!' }]}>
                            <Select style={{ minWidth: 120 }} onChange={(e: BlockTypeEnum) => onFilterTypeChange(e)}>
                                {
                                    Array.from(BlockTypeMap).map(([key, value]) => <Option value={value} key={value}>{key}</Option>)
                                }
                            </Select>
                        </Form.Item>
                        <IPAddressEditTable dataSource={ipAddress || []} ref={ipRef} />
                    </>
                }
            </Form>
        </Spin>
    </Drawer>
}
export default ControlPolicyRuleDrawer
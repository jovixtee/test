
import apiservice from '../utils/fetchutil';
import { Recipients } from './Recipients/NotificationManagerContracts';
const serve = apiservice()
export const PagedQuery = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/INotificationService/PagedQuery", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const DeleteProfile = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/INotificationService/DeleteProfile", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}

export const UpdateProfile = (params: Recipients): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/INotificationService/UpdateProfile", {"profile":params}).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}

export const CreateProfile = (params: Recipients): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/INotificationService/CreateProfile", {"profile":params}).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const QueryProfile = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/INotificationService/QueryProfile", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const QuerySetting = (): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/INotificationService/QuerySetting").then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const SaveSetting = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/INotificationService/SaveSetting", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const SendTestEmail = (params: any): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/INotificationService/SendTestEmail", params).then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
export const QueryProfiles = (): Promise<any> => {
    return new Promise((resolve, reject) => {
        serve.post("/INotificationService/QueryNotificationProfiles").then((result) => {
            resolve(result)
        }).catch(error => {
            reject(error)
        })
    })
}
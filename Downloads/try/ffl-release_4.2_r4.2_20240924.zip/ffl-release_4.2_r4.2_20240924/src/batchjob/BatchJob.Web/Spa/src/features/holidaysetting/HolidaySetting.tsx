import React, { useState } from 'react';
import AmpCommonTable, { IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import { HolidayPermissionConstants, HolidaySettingProfile } from './HolidaySettingContract';
import { DeleteOutlined, EditOutlined, ImportOutlined, PlusOutlined } from '@ant-design/icons';
import { hasPermission } from '../../utils/permissionutil';
import DrawerImportForm from './HolidaySettingImport';
import ProfileReadDrawer from './ProfileReadDrawer';
import HolidaySettingApi from './HolidaySettingApi';
import DrawerLinkForm from './HolidaySettingLink';
import ProfileEditDrawer from './ProfileEditDrawer';
import { Button } from 'antd';
import UINotrification from "../../common/UINotrification";

const Holidays = () => {

    const [refresh, setRefresh] = useState(1);
    const [selectedRecords, setSelectedRecords] = useState<HolidaySettingProfile[]>();
    const [profile, setProfile] = useState<HolidaySettingProfile>({});
    const [readProfile, setReadProfile] = useState<HolidaySettingProfile>({});
    const [readDrawerVisable, setReadDrawerVisable] = useState(false);
    const [icsDrawerVisable, setIcsDrawerVisable] = useState(false);
    const [profileDrawerVisable, setProfileDrawerVisable] = useState(false);
    const [holidayDrawerVisable, setHolidayDrawerVisable] = useState(false);

    const refreshTable = () => {
        setRefresh(refresh + 1);
    }

    const openReadDrawer = (record: HolidaySettingProfile) => {
        setReadProfile(record); 
        setReadDrawerVisable(true);
    }

    const openHolidaysDrawer = () => {
        setProfile(selectedRecords![0]);
        setHolidayDrawerVisable(true);
    }

    const openCreateDrawer = () => {
        setProfile({});
        setProfileDrawerVisable(true);
    }

    const openEditDrawer = () => {
        setProfile(selectedRecords![0]);
        setProfileDrawerVisable(true);
    }

    const deleteRecords = async () => {
        // await HolidaySettingApi.DeleteProfiles(selectedRecords.map(r => r.ProfileId));
        // refreshTable();
        UINotrification.confirm(
            "You are about to delete the selected profiles. Are you sure you want to proceed?",
            "Confirm Deletion",
            async () => {
                let ids:any = selectedRecords!.map(r => r.ProfileId);
                const result = await HolidaySettingApi.DeleteProfiles(ids);
                if (result.ProfileOperationResult) {
                    UINotrification.success("The selected records were deleted successfully.");
                } else {
                    UINotrification.error("Failed to delete selected records.");
                }
                refreshTable();
            },
            () => {
                refreshTable();
            });

    }


    const importIcsFile = () => {
        setProfile(selectedRecords![0]);
        setIcsDrawerVisable(true);
    }

    const columns = [{
        title: 'Name',
        dataIndex: 'OrganizationName',
        key: 'OrganizationName',
        sorter: true,
        ellipsis:true,
        render: (name: any, record: any) => (<a onClick={() => openReadDrawer(record)}>{name}</a>),
    },
    {
        title: 'Workday',
        dataIndex: 'WorkdayDisplaynames',
        ellipsis:true,
        key: 'WorkdayDisplaynames',
    },
    {
        title: 'Time',
        dataIndex: 'TimeZoneDisplayName',
        ellipsis:true,
        key: 'TimeZoneDisplayName',
    },
    {
        title: 'Holiday Number',
        dataIndex: 'HolidaysNumber',
        key: 'HolidaysNumber',
    }];

    const buttons: Array<IAmpTableButton> = [{
        Text: "Create",
        Primary: true,
        Icon: <PlusOutlined />,
        OnClick: openCreateDrawer,
        EnableMode: 'always',
        HasPermission: hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Create)
    }, {
        Text: "Edit",
        Icon: <EditOutlined />,
        OnClick: openEditDrawer,
        EnableMode: 'single',
        HasPermission: hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Create)
    }, {
        Text: "Delete",
        Icon: <DeleteOutlined />,
        OnClick: deleteRecords,
        EnableMode: 'multiple',
        HasPermission: hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Delete)
    }
        , {
        Text: "Holidays",
        Icon: <PlusOutlined />,
        OnClick: openHolidaysDrawer,
        EnableMode: 'single',
        HasPermission: hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Delete)
    }, {
        Text: "Import ICS",
        Icon: <ImportOutlined />,
        OnClick: importIcsFile,
        EnableMode: 'single',
        HasPermission: hasPermission(HolidayPermissionConstants.ObjectCode, HolidayPermissionConstants.Create)
    }]

    const ApiPagerQuery = async (exp: PagerExpression) => {
        const result = await HolidaySettingApi.PagerQueryProfile(exp);
        return { total: result!.PagingProfiles!.TotalNumber, records: result!.PagingProfiles!.Result };
    }
    return (
        <>
            <AmpCommonTable Type="checkbox" RowKey="ProfileId" Columns={columns} PagerQuery={ApiPagerQuery} OnSelectedChanged={records => setSelectedRecords(records)}
                SearchKeys={["Name"]} Refresh={refresh} Buttons={buttons} EnableSearch />
            <ProfileReadDrawer visible={readDrawerVisable} onClose={() => setReadDrawerVisable(false)} profile={readProfile} />
            <ProfileEditDrawer Visible={profileDrawerVisable} OnClose={() => { setProfileDrawerVisable(false); refreshTable() }} Profile={profile} />
            <DrawerLinkForm Visible={holidayDrawerVisable} Profile={profile} OnClose={() => setHolidayDrawerVisable(false)} />
            <DrawerImportForm visible={icsDrawerVisable} closeImportDrawer={() => setIcsDrawerVisable(false)} profile={profile} />
        </>
    );
}

export default Holidays;
import React, { useState, useEffect } from "react";
import { ColumnsType } from "antd/lib/table/interface";
import AmpCommonTable, { DatetimeColumnTemplate, IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import { hasPermission } from '../../utils/permissionutil';
import * as ReplicatorContract from '../ReplicatorContract';
import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import { GetApiService } from "../ReplicatorApiService";
import { CorpusDrawer } from "./CorpusDrawer";
import UINotrification from "../../common/UINotrification";

const CorpusMain = () => {
    const [refresh, setRefresh] = useState(1);
    const [replicatorsResult, setReplicatorsResult] =  useState<ReplicatorContract.ReplicatorsResult>({});
    const [visible, setVisible] =  useState<boolean>(false);
    const [selectedRecords, setSelectedRecords] = useState<ReplicatorContract.CorpusDto[]>([]);

    const tableColumn: ColumnsType<ReplicatorContract.CorpusDto> = [
        {
            title: 'Display Name',
            dataIndex: 'DisplayName',
            sorter:true
        },
        {
            title: 'Unique Name',
            dataIndex: 'UniqueName',
            sorter:true
        },{
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
        }, {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }];

        const buttonEvents = {
            createClick: () => {
                setVisible(true);
            },
            editClick: () => {
                let id = selectedRecords[0].Id;
                GetApiService().GetDatamodelingById(id!).then(res=>{
                    setVisible(true);
                    setReplicatorsResult(res);
                }).catch(e=>UINotrification.error(e))
                
            },
            deleteClick: () => {
                UINotrification.confirm(
                    "You are about to delete the selected profiles. Are you sure you want to proceed?",
                    "Confirm Deletion",
                    async () => {
                        let ids = selectedRecords!.map(r => r.Id);
                        GetApiService().DeleteCorpus(ids).finally(() => tableEvents.refreshTable());
                    },
                    () => {}
                );
        
            },
            cancelClick:()=>{
                setVisible(false);
            }
        }
    
        const tableEvents = {
            refreshTable: () => {
                setRefresh(refresh + 1);
            },
            onPagionationChange: (pager: PagerExpression) => {
                return GetApiService().PagerQueryCorpus(pager);
            }
        };
    
        const buttons: Array<IAmpTableButton> = [{
            Text: "Create",
            Primary: true,
            Icon: <PlusOutlined />,
            OnClick: buttonEvents.createClick,
            EnableMode: 'always',
            HasPermission: hasPermission(ReplicatorContract.CorpusPermissions.ObjectCode, ReplicatorContract.CorpusPermissions.Create)
        }, {
            Text: "Edit",
            Icon: <EditOutlined />,
            OnClick: buttonEvents.editClick,
            EnableMode: 'single',
            HasPermission: hasPermission(ReplicatorContract.CorpusPermissions.ObjectCode, ReplicatorContract.CorpusPermissions.Create)
        }, {
            Text: "Delete",
            Icon: <DeleteOutlined />,
            OnClick: buttonEvents.deleteClick,
            EnableMode: 'multiple',
            HasPermission: hasPermission(ReplicatorContract.CorpusPermissions.ObjectCode, ReplicatorContract.CorpusPermissions.Delete)
        }];
 

        const ApiPagerQuery = async (exp: PagerExpression) => {
            let result:any = await tableEvents.onPagionationChange(exp);
            return { total: result!.PageredDatamodelingCorpus!.TotalNumber, records: result!.PageredDatamodelingCorpus!.Result };
        }

    return <React.Fragment>
        <AmpCommonTable
            Type="checkbox"
            RowKey="Id"
            Columns={tableColumn}
            PagerQuery={ApiPagerQuery}
            OnSelectedChanged={(records:any[]) => setSelectedRecords(records)}
            SearchKeys={["DisplayName"]}
            Refresh={refresh}
            Buttons={buttons}
            EnableSearch />
        <CorpusDrawer visible={visible} refreshTable={tableEvents.refreshTable} dataSource={replicatorsResult} onCancel={buttonEvents.cancelClick}/>
       
        
    </React.Fragment>
}

export default CorpusMain;
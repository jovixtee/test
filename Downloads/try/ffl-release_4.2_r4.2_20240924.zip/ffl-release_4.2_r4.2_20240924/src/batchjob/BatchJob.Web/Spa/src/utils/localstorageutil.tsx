const _v = {
    exp: 60 * 60 * 1000
}
export const setItem = function (key: string, value: any, exp?: number) {
    if (exp === 0) {
        try {
            localStorage.setItem(key, JSON.stringify({ data: value }));
        } catch (e) {
            console.log(e);
        }
    } else {
        _v.exp = exp || 60 * 60 * 1000;
        var curTime = new Date().getTime();
        try {
            localStorage.setItem(key, JSON.stringify({ data: value, time: curTime }));
        } catch (e) {
            console.log(e);
        }
    }
}
export const removeItem = function (key: string) {
    try {
        localStorage.removeItem(key);
    } catch (e) {
        console.log(e);
    }
}
export const getItem = function (key: string) {
    try {
        var data = localStorage.getItem(key);
    } catch (e) {
        console.log(e);
        return null;
    }
    var dataObj = data && JSON.parse(data);
    if (dataObj && dataObj.time && new Date().getTime() - dataObj.time > _v.exp) {
        try {
            localStorage.removeItem(key);
        } catch (e) {
            console.log(e);
        }
        return null;
    } else if (dataObj && dataObj.data) {
        return dataObj.data;
    }
    return null;
}
import React, { useEffect, useState } from 'react';
import { Space, Button, Row, Col, Input, Select } from 'antd';
import { CheckCircleOutlined, StopOutlined } from '@ant-design/icons';
import AuthenticationTable from './AuthenticationTable';

const { Search } = Input;
const { Option } = Select;
const Authentication = () => {
    const onSearch = (value: any) => console.log(value);
    const handleChange = (value: any) => {
        console.log(`selected ${value}`);
    }
    const data1 = {
        uuid: "uuid ",
        AuthenticationName: "AuthenticationName",

        Description: "Description",
        AuthenticationType: 'AuthenticationType',
        Status: '',
        createdby: 'createdby',
        createdtime: '2010/05/25',
        modifiedby: "Administror",
        modifiedtime: "2010/05/25",
        Users: 'user1',
        PermissionLevels: 'Level1'

    };
    const getTableData = () => {

        setDataSource([...fetchData()])

    }
    const fetchData = () => {
        return [1, 2, 3, 4, 5, 6, 7, 8, 9].map((value) => {
            return {
                uuid: data1.uuid + value,
                AuthenticationName: data1.AuthenticationName + value,
                Description: data1.Description + value,
                AuthenticationType: data1.AuthenticationType + value,
                Status: value % 2 === 0 ? 'Enable' : 'Disable',
                createdby: 'System',
                createdtime: new Date().toJSON(),
                modifiedby: "Administror",
                modifiedtime: new Date().toJSON()
            }
        })
    }
    const [dataSource, setDataSource] = useState<any>([]);
    const [tempData, setTempData] = useState<any>([]);
    const [selectLength, setSelectLength] = useState<any>(0);
    const [enabled, setEnable] = useState<boolean>(true);
    const [disabled, setDisable] = useState<boolean>(true);
    useEffect(() => {
        getTableData()
    });
    useEffect(() => {
        if (selectLength === 1 && tempData[0].Status === 'Enable') {
            setDisable(false)
        } else {
            setDisable(true)
        }
        if (selectLength === 1 && tempData[0].Status === 'Disable') {
            setEnable(false)
        } else {
            setEnable(true)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [tempData]);
    let enableBtn = () => {
        dataSource.forEach((item: any) => {
            if (item.uuid === tempData[0].uuid) {
                item.Status = 'Enable'
            }
        })
        setDataSource([...dataSource])
        setTempData([])
        setSelectLength(0)
    }
    let disabledBtn = () => {
        dataSource.forEach((item: any) => {
            if (item.uuid === tempData[0].uuid) {
                item.Status = 'Disable'
            }
        })
        setDataSource([...dataSource])
        setTempData([])
        setSelectLength(0)
    }
    const getSelectedRows = (selectedRows: any) => {
        setSelectLength(selectedRows.length)
        setTempData([...selectedRows])
        console.log(selectedRows)
    }
    const getTableChange = (pagination: any, filters: any, sorter: any, extra: any) => {
        console.log(pagination, "+++pagination")
        console.log(filters, "+++filters")
        console.log(sorter, "+++sorter")
    }
    return (
        <div>
            <Row>
                <Col span={18}>
                    <Space size='small'>
                        <Button type='text' icon={<CheckCircleOutlined />} disabled={enabled} onClick={enableBtn}>Enable</Button>
                        <Button type='text' icon={< StopOutlined />} disabled={disabled} onClick={disabledBtn} >Disable</Button>
                    </Space>
                </Col>
                <Col span={6} style={{ textAlign: 'right' }}>
                    <Search placeholder="input search text" onSearch={onSearch} style={{ width: 200 }} />
                    <Select defaultValue="lucy" onChange={handleChange}>
                        <Option value="jack">Jack</Option>
                        <Option value="lucy">Lucy</Option>
                        <Option value="disabled" disabled>
                            Disabled
                        </Option>
                        <Option value="Yiminghe">yiminghe</Option>
                    </Select>

                </Col>
            </Row>
            <AuthenticationTable dataSource={[...dataSource]} selectLength={selectLength} func={getSelectedRows} getTableChange={getTableChange}></AuthenticationTable>
        </div>
    );
};
export default Authentication;
import React, { useState } from "react";
import { Modal, Progress, TablePaginationConfig } from "antd";
import {
  StopOutlined,
  DownloadOutlined,
  DeleteOutlined,
  ExclamationCircleOutlined,
  ReloadOutlined,
  SettingOutlined,
} from "@ant-design/icons";
import { PagerQueryJob, TryStopJob, DeleteJobs } from "./JobMonitorApiServe";
import { JobDto, JobPermissionCostants } from "./JobContract";
import { hasPermission } from "../../utils/permissionutil";
import { PagerExpression } from "../../common/contracts/PagerContracts";
import AmpCommonTable, {
  DatetimeColumnTemplate,
  IAmpTableButton,
} from "../../components/antdx/AmpCommonTable";
import JobUtil from "./JobUtil";
import PathConfig from "../../common/PathConfig";
import { Link, useLocation } from "react-router-dom";
import { FilterValue } from "antd/lib/table/interface";
import apiservice from "../../utils/fetchutil";
import GlobalSettingsDrawer from "./GlobalSettingsDrawer";

const { confirm } = Modal;
const JobMonitor = (props: any) => {
  const [refreshCount, setRefreshCount] = useState<number>(0);
  const [selectedRecords, setSelectedRecords] = useState<JobDto[]>();
  const [visible, setVisible] = useState<boolean>(false);
  const local = useLocation();
  let refreshTable = async () => {
    setRefreshCount(refreshCount + 1);
  };

  let deleteSourceBtn = () => {
    confirm({
      title: "Warning",
      icon: <ExclamationCircleOutlined />,
      content:
        "You are about to delete the selected items. Are you sure you want to proceed?",
      onOk() {
        return new Promise<void>((resolve, reject) => {
          deleteSource().then(() => {
            resolve();
            refreshTable();
          });
        }).catch(() => console.log("Oops errors!"));
      },
      onCancel() {
        console.log("Cancel");
      },
    });
  };

  const downloadBtn = async () => {
    let jobIds: string[] = selectedRecords!.map((e:any) => e.Id);
    apiservice()
      .post(
        "/IJobManagerService/DownloadMultipleJobDetails",
        {
          setting: {
            jobIds: jobIds,
            timeZoneOffSet: 0,
            dateFormat: "dd/MM/yyyy HH:mm:ss",
          },
        },
        { accept: "*/*" }
      )
      .then((response) => {
        response.blob().then((blob: any) => {
          const aLink = document.createElement("a");
          document.body.appendChild(aLink);
          aLink.style.display = "none";
          const objectUrl = window.URL.createObjectURL(blob);
          aLink.href = objectUrl;
          aLink.download = "JobDetails.zip";
          aLink.click();
        });
      });
  };

  const deleteSource = async (): Promise<void> => {
    let ids = selectedRecords!.map((e:any) => e.Id);
    let jobIds: string[] = ids;
    let params = {
      jobIds: [...jobIds],
    };
    await DeleteJobs(params);
    refreshTable();
  };
  const stopBtn = async () => {
    await TryStopJob({ jobId: (selectedRecords![0] as any).Id});
    refreshTable();
  };
  const GlobalSettingBtn = async () => {
    setVisible(true);
  };
  const onCloseFun = () => {
    setVisible(false);
  };
  // const pauseBtn = async () => {
  //     TryPauseJob({ jobId: selectedRecords[0].Id })
  //     refreshTable();
  // }
  // const resumeBtn = async () => {
  //     await TryResumeJob({ jobId: selectedRecords[0].Id });
  //     refreshTable();
  // }
  /*
    const rerunBtn = async () => {
        await RerunJob({ jobId: selectedRecords[0].Id });
        refreshTable();
    }
    */

  const nameTemplate = (text: string, record: any) => {
    return (
      <Link
        to={{
          pathname: PathConfig.addPrefix("/jobmonitor/details"),
          state: { record },
        }}
      >
        {text}
      </Link>
    );
  };

  const progressTemplate = (text: number, record: any, index: number) => {
    return (
      <div>
        <Progress percent={text} style={{ width: "60%" }} />
        <span
          style={{ textAlign: "right", display: "inline-block", width: "30%" }}
        >
          {JobUtil.GetStateString(record.State)}
        </span>
      </div>
    );
  };

  const columns = [
    {
      title: "Job ID",
      dataIndex: "Name",
      key: "Name",
      width: "14%",
      render: nameTemplate,
    },
    {
      title: "Task Title",
      dataIndex: "TaskName",
      key: "TaskName",
      width: "14%",
    },
    {
      title: "Task Group Title",
      dataIndex: "TaskGroupName",
      key: "TaskGroupName",
      width: "14%",
    },
    {
      title: "Status",
      dataIndex: "Progress",
      key: "Progress",
      width: "24%",
      filters: JobUtil.StatusFilter,
      render: progressTemplate,
    },
    {
      title: "Start Time",
      dataIndex: "StartTime",
      key: "StartTime",
      width: "17%",
      sorter: true,
      render: DatetimeColumnTemplate,
    },
    {
      title: "End Time",
      dataIndex: "EndTime",
      key: "EndTime",
      width: "17%",
      render: DatetimeColumnTemplate,
    },
  ];

  const ApiPagerQueryJob = async (exp: PagerExpression) => {
    // const taskId = new URLSearchParams(local.search).get('taskId');
    // if (taskId) {
    //     if (!exp.Filters) {
    //         exp.Filters = [];
    //     }
    //     exp.Filters.push({ ColumnName: 'TaskId', ColumnValues: taskId });
    // }
    const result = await PagerQueryJob(exp);
    return {
      total: result!.JobPagerResult!.TotalNumber,
      records: result!.JobPagerResult!.Result,
    };
  };

  const getTaskIdFromQuery = () => {
    return new URLSearchParams(local.search).get("taskId");
  };

  const getTaskGroupIdFromQuery = () => {
    return new URLSearchParams(local.search).get("taskGroupId");
  };

  const ConvertPager = (
    exp: PagerExpression,
    pagerConfg: TablePaginationConfig,
    filter?: Record<string, FilterValue>,
    sorter?: any
  ): PagerExpression => {
    const taskId = getTaskIdFromQuery();
    if (taskId) {
      exp.Filters = exp!.Filters!.concat([
        { ColumnName: "TaskId", ColumnValues: [taskId] },
      ]);
    }
    const taskGroupId = getTaskGroupIdFromQuery();
    if (taskGroupId) {
      exp.Filters = exp!.Filters!.concat([
        { ColumnName: "TaskGroupId", ColumnValues: [taskGroupId] },
      ]);
    }

    if (filter) {
      if (filter.Progress) {
        exp.Filters = exp!.Filters!.concat([
          { ColumnName: "State", ColumnValues: filter.Progress as string[] },
        ]);
      }
    }

    return exp;
  };

  const buttons: Array<IAmpTableButton> = [
    {
      Text: "Download",
      Primary: true,
      Icon: <DownloadOutlined />,
      OnClick: downloadBtn,
      EnableMode: "multiple",
      HasPermission: true,
    },
    {
      Text: "Delete",
      Icon: <DeleteOutlined />,
      OnClick: deleteSourceBtn,
      EnableMode: "multiple",
      HasPermission: hasPermission(
        JobPermissionCostants.ObjectCode,
        JobPermissionCostants.Delete
      ),
    },
    {
      Text: "Stop",
      Icon: <StopOutlined />,
      OnClick: stopBtn,
      EnableMode: "single",
      HasPermission: hasPermission(
        JobPermissionCostants.ObjectCode,
        JobPermissionCostants.Update
      ),
    },
    // {
    //     Text: "Pause",
    //     Icon: <PauseCircleOutlined />,
    //     OnClick: pauseBtn,
    //     EnableMode: 'single',
    //     HasPermission: hasPermission(JobPermissionCostants.ObjectCode, JobPermissionCostants.Update)
    // },
    // {
    //     Text: "Resume",
    //     Icon: <PlayCircleOutlined />,
    //     OnClick: resumeBtn,
    //     EnableMode: 'single',
    //     HasPermission: hasPermission(JobPermissionCostants.ObjectCode, JobPermissionCostants.Update)
    // },
    // {
    //     Text: "Rerun",
    //     Icon: <RedoOutlined />,
    //     OnClick: rerunBtn,
    //     EnableMode: 'single',
    //     HasPermission: hasPermission(JobPermissionCostants.ObjectCode, JobPermissionCostants.Update)
    // },
    {
      Text: "Refresh",
      Icon: <ReloadOutlined />,
      OnClick: refreshTable,
      EnableMode: "always",
      HasPermission: true,
    },
    {
      Text: "Setting",
      Icon: <SettingOutlined />,
      OnClick: GlobalSettingBtn,
      EnableMode: "always",
      HasPermission: true,
    },
  ];

  return (
    <>
      <AmpCommonTable
        Type="checkbox"
        RowKey="Id"
        Columns={columns}
        OnSelectedChanged={(records) => setSelectedRecords(records)}
        PagerQuery={ApiPagerQueryJob}
        PagerConverter={ConvertPager}
        Refresh={refreshCount}
        SearchKeys={["JobId", "TypeStr", "TaskName"]}
        DefaultSortKey="CreatedOn"
        Buttons={buttons}
        EnableSearch
      />
      <GlobalSettingsDrawer visible={visible} onClose={onCloseFun} />
    </>
  );
};
export default JobMonitor;

import { Button, Descriptions, Drawer, Spin,Radio,Checkbox } from "antd";
import React, { FC, useEffect, useState } from "react";
import './apiAuthentication.css';
import {
  ApiKeyDto,
  APIKeyType,
  AuthType,
  BasicDto,
  ClientCertDto,
  ConstDto,
  CustomiseDto,
  CustomType,
  FromType,
  HashType,
  JWTDto,
  MyInfoDto,
  OAuthDto,
} from "../../common/contracts/ModelContracts";
import { GetAuthenticationViewById } from "./APIAuthenticationService";
interface IProfileReadDrawerProps {
  visible: boolean;
  onClose: () => void;
  Id: any;
}

const ProfileReadDrawer: FC<IProfileReadDrawerProps> = (props) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [data, setData] = useState<any[]>();

  useEffect(() => {
    if (props.Id && props.Id.length > 0) {
      handleGetAuthenticationById(props.Id);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.Id]);

  const handleGetAuthenticationById = (id: string) => {
    setLoading(true);
    GetAuthenticationViewById(id)
      .then((result) => {
        if (result) {
          let profile: any[] = [];
          let item = { "type": "text", "key": "Name", "value": result.Name };
          profile.push(item);
          item = { "type": "text", "key": "Description", "value": result.Description };
          profile.push(item);
          item = { "type": "text", "key": "From Type", "value":FromType[result.FromType!] };
          profile.push(item);
          item = { "type": "text", "key": "Authorization Type", "value":AuthType[result.AuthType!] };
          profile.push(item);
          if (result.AuthType === AuthType.OAuth) {
            item = { "type": "text", "key": "Token Endpoint", "value":(result.AuthSetting as OAuthDto)!.TokenEndpoint };
            profile.push(item);
            item = { "type": "text", "key": "Client Id", "value":(result.AuthSetting as OAuthDto)!.ClientId };
            profile.push(item);
            item = { "type": "text", "key": "Secret", "value":(result.AuthSetting as OAuthDto)!.Secret };
            profile.push(item);
            item = { "type": "text", "key": "Scope", "value":(result.AuthSetting as OAuthDto)!.Scope };
            profile.push(item);
          }

          if (result.AuthType === AuthType.APIKey) {
            let apiKey = result.AuthSetting as ApiKeyDto;
            item = { "type": "text", "key": "Scheme", "value":APIKeyType[apiKey.APIKeyType!] };
            profile.push(item);
            
            if (apiKey.APIKeyType === APIKeyType.JWT) {
              let dto = apiKey.APIKeySetting as JWTDto;
              item = { "type": "text", "key": "Hash", "value":HashType[dto.HashType!] };
              profile.push(item);
              item = { "type": "text", "key": "Client Id", "value": dto.ClientId};
              profile.push(item);
              item = { "type": "text", "key": "Secret", "value": dto.Secret};
              profile.push(item);
            }

            if (apiKey.APIKeyType === APIKeyType.Basic) {
              let dto = apiKey.APIKeySetting as BasicDto;
              item = { "type": "text", "key": "UserName", "value":dto.UserName };
              profile.push(item);
              item = { "type": "text", "key": "Password", "value":dto.Password };
              profile.push(item);
            }

            if (apiKey.APIKeyType === APIKeyType.Constants) {
              let dto = apiKey.APIKeySetting as ConstDto;
              item = { "type": "text", "key": "Authorization Header", "value":dto.AuthorizationHeader };
              profile.push(item);
              item = { "type": "text", "key": "Constants Key", "value":dto.ConstKey };
              profile.push(item);
            }
          }

          if (result.AuthType === AuthType.ClientCert) {
            let cert = result.AuthSetting as ClientCertDto;
            item = { "type": "text", "key": "Host", "value":cert!.Host };
            profile.push(item);
            item = { "type": "text", "key": "Passphrase", "value":cert!.Passphrase };
            profile.push(item);
          }

          if (result.AuthType === AuthType.Customise) {
            let dto = result.AuthSetting as CustomiseDto;
            item = { "type": "text", "key": "Custom Type", "value":CustomType[dto.CustomType!] };
            profile.push(item);
            if (dto.CustomType === CustomType.MyInfo) {
              let myinfo = dto.CustomiseSetting as MyInfoDto;
              item = { "type": "text", "key": "Application Id", "value":myinfo.ApplicationID };
              profile.push(item);
              item = { "type": "text", "key": "EService Id", "value":myinfo.EServiceID };
              profile.push(item);
            }
          }
          if (result.Certificate) {
            item = { "type": "text", "key": "Certificate", "value":getFileNameByPath(result.Certificate!) };
            profile.push(item);
          }
          setData(profile);
        }
      })
      .finally(() => setLoading(false));
  };

  const getFileNameByPath = function (path: string) {
    var pos1 = path.lastIndexOf("/");
    var pos2 = path.lastIndexOf("\\");
    var pos = Math.max(pos1, pos2);
    if (pos < 0) {
      return path;
    } else {
      return path.substring(pos + 1);
    }
  };
  
  const renderItem = (data: any[]) => {
    return (
        <>
            <Descriptions column={1} bordered >
                {
                    data?.map((item: any) => {
                        let obj = null;
                        switch (item.type) {
                            case "text":
                                obj = (<Descriptions.Item label={item.key}>{item.value}</Descriptions.Item>);
                                break;
                            case "radio":
                                obj = (
                                    <Descriptions.Item label={item.key}>
                                        <Radio.Group disabled options={item.data} defaultValue={item.value} />
                                    </Descriptions.Item>
                                );
                                break;
                            case "checkbox":

                                obj = (
                                    <Descriptions.Item label={item.key}>
                                        <Checkbox.Group disabled options={item.data} defaultValue={item.value} />
                                    </Descriptions.Item>
                                );
                                break;
                        }
                        return obj;
                    })
                }
            </Descriptions>
        </>
    );
}

  return (
    <Drawer
      visible={props.visible}
      width={720}
      onClose={(e) => props.onClose()}
      title={"View authentication"}
      footer={
        <div style={{ textAlign: "right" }}>
          <Button type="primary" onClick={(e) => props.onClose()}>
            Close
          </Button>
        </div>
      }
    >
      <Spin spinning={loading}>{renderItem(data!)}</Spin>
    </Drawer>
  );
};

export default ProfileReadDrawer;

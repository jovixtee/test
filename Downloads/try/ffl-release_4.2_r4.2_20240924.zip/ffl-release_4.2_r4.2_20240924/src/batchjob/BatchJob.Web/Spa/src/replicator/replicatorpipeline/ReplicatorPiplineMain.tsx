import React, { useState } from 'react';
import { ColumnsType } from 'antd/lib/table/interface';
import AmpCommonTable, { DatetimeColumnTemplate, IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import { hasPermission } from '../../utils/permissionutil';
import * as ReplicatorContract from '../ReplicatorContract';
import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import { GetApiService } from '../ReplicatorApiService';
import { DataPiplineDrawer } from './ReplicatorPiplineDrawer';
import UINotrification from '../../common/UINotrification';

const DataPiplineMain = () => {
    const [refresh, setRefresh] = useState(1);
    const [id, setId] = useState<string>();
    const [visible, setVisible] = useState<boolean>(false);
    const [selectedRecords, setSelectedRecords] = useState<ReplicatorContract.ReplicatorPipline[]>([]);
    const [piplineData, setPiplineData] = useState<ReplicatorContract.ReplicatorPipline>();

    const tableColumn: ColumnsType<ReplicatorContract.ReplicatorPipline> = [
        {
            title: 'Display Name',
            dataIndex: 'Name'
        },
        {
            title: 'Description',
            dataIndex: 'Description'
        },
        {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy'
        },
        {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        },
        {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy'
        },
        {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }
    ];

    const buttonEvents = {
        createClick: () => {
            setPiplineData(undefined);
            setVisible(true);
        },
        editClick: () => {
            const id = selectedRecords[0].Id;
            GetApiService()
                .GetPiplineById(id!)
                .then((res) => {
                    setVisible(true);
                    setPiplineData(res.Pipline);
                })
                .catch((e) => UINotrification.error(e));
        },
        deleteClick: () => {
            UINotrification.confirm(
                'You are about to delete the selected profiles. Are you sure you want to proceed?',
                'Confirm Deletion',
                async () => {
                    const ids = selectedRecords!.map((r) => r.Id);
                    GetApiService()
                        .DeletePiplineById(ids)
                        .finally(() => tableEvents.refreshTable());
                },
                () => { }
            );
        },
        cancelClick: () => {
            setVisible(false);
        }
    };

    const tableEvents = {
        refreshTable: () => {
            setRefresh(refresh + 1);
        },
        onPagionationChange: (pager: PagerExpression) => {
            return GetApiService().PiplinePagerQuery(pager);
        }
    };

    const buttons: Array<IAmpTableButton> = [
        {
            Text: 'Create',
            Primary: true,
            Icon: <PlusOutlined />,
            OnClick: buttonEvents.createClick,
            EnableMode: 'always',
            HasPermission: hasPermission(
                ReplicatorContract.CorpusPermissions.ObjectCode,
                ReplicatorContract.CorpusPermissions.Create
            )
        },
        {
            Text: 'Edit',
            Icon: <EditOutlined />,
            OnClick: buttonEvents.editClick,
            EnableMode: 'single',
            HasPermission: hasPermission(
                ReplicatorContract.CorpusPermissions.ObjectCode,
                ReplicatorContract.CorpusPermissions.Create
            )
        },
        {
            Text: 'Delete',
            Icon: <DeleteOutlined />,
            OnClick: buttonEvents.deleteClick,
            EnableMode: 'multiple',
            HasPermission: hasPermission(
                ReplicatorContract.CorpusPermissions.ObjectCode,
                ReplicatorContract.CorpusPermissions.Delete
            )
        }
    ];

    const ApiPagerQuery = async (exp: PagerExpression) => {
        const result: any = await tableEvents.onPagionationChange(exp);
        return { total: result!.PageredReplicatorPipline!.TotalNumber, records: result!.PageredReplicatorPipline!.Result };
    };

    return (
        <React.Fragment>
            <AmpCommonTable
                Type="checkbox"
                RowKey="Id"
                Columns={tableColumn}
                PagerQuery={ApiPagerQuery}
                OnSelectedChanged={(records: A) => setSelectedRecords(records)}
                SearchKeys={['FrontendName']}
                Refresh={refresh}
                Buttons={buttons}
                EnableSearch
            />

            <DataPiplineDrawer
                visible={visible}
                refresh={tableEvents.refreshTable}
                dataSource={piplineData}
                onCancel={buttonEvents.cancelClick}
            />
        </React.Fragment>
    );
};

export default DataPiplineMain;

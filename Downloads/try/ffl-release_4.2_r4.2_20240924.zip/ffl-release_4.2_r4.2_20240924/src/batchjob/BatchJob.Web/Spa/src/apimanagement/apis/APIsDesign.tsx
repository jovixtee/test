import React, { FC, useEffect, useState } from "react";
import { Row, Col, Card, Layout, Descriptions, Tag, Table, message, Empty, Spin } from 'antd';
import "./APIsContent.css";
import APIOperations from "./APIOperations";
import { ArrowDownOutlined, EditOutlined } from '@ant-design/icons';
import { GetOperations, GetMethodContent, DeleteMethod, CloneOperation } from './APIsService';
import { MethodMenuDto, ViewFrontendDto, ViewControlPolicyDto, ViewParameter, ViewHeader, ViewBackendDto, MethodTypeColor } from '../../common/contracts/ModelContracts';
import CreateOperationDrawer from "./CreateOperationDrawer";
import "./APIsContent.css";
const { Content, Sider } = Layout;


interface IAPIsDesignProps {
    id?: string,
    refs?: any;
}
const APIsDesign: FC<IAPIsDesignProps> = (props) => {
    const [baseAddress, setBaseAddress] = useState<string>("");
    const [tableLoading, setTableLoading] = useState<boolean>(false);
    const [isFrontend, setIsFrontend] = useState<boolean>(true);
    const [methodMenu, setMethodMenu] = useState<MethodMenuDto[]>([]);
    const [frontend, setFrontend] = useState<ViewFrontendDto>();
    const [backend, setBackend] = useState<ViewBackendDto>();
    const [controlPolicy, setControlPolicy] = useState<ViewControlPolicyDto>();
    const [methodId, setMethodId] = useState<string>("");
    const [selectKey, setSelectKey] = useState<string>("");
    const [operationVisible, setOperationVisible] = useState<boolean>(false);
    const columns = [
        {
            title: 'Rule',
            dataIndex: 'Rule',
        },
        {
            title: 'Type',
            dataIndex: 'Type',
        }
    ];

    useEffect(() => {
        if (props.id) {
            handleGetOperations(props.id, "");
        }
    }, [props.id]);

    useEffect(() => {
        if (methodMenu.length > 0) {
            let methodId = methodMenu[0].Id || "";
            setSelectKey(methodId);
            setMethodId(methodId);
            handleGetMethodContent(methodId);
        } else {
            setMethodId("");
            setSelectKey("");
            setFrontend(undefined);
            setControlPolicy(undefined);
            setBackend(undefined);
        }
    }, [methodMenu]);

    const handleGetOperations = (versionId: string, path: string) => {
        GetOperations(versionId, path).then(res => {
            setMethodMenu(res);
        })
    }

    const handleDeleteMethod = (id: string) => {
        DeleteMethod(id).then(res => {
            handleGetOperations(props.id||"", "");
        })
    }


    const onEditMethod = (): void => {
        if (frontend?.Id && frontend?.Id.length > 0) {
            setIsFrontend(true);
            setMethodId(frontend?.Id);
            setBaseAddress(frontend.BaseAddress!);
            setOperationVisible(true);
        }else{
            message.error("Not found select method");
        }
    }

    const onEditBackEndMethod = (): void => {
        if (backend?.Id && backend?.Id.length > 0) {
            setBaseAddress(backend.BaseAddress!);
            setMethodId(backend?.Id);
            setIsFrontend(false);
            setOperationVisible(true);
        }else{
            message.error("Not found select method");
        }
    }

    const menuItemClick = (item: any) => {
        setSelectKey(item.key);
        setMethodId(item.key);
        handleGetMethodContent(item.key);
    }

    const handleGetMethodContent = (MethodId: string) => {
        setTableLoading(true);
        GetMethodContent(MethodId).then(res => {
            setFrontend(res.Frontend);
            setControlPolicy(res.Policy);
            setBackend(res.Backend);
            console.log(res);
        }).finally(() => setTableLoading(false));
    }

    const renderUrl = (frontend?: ViewFrontendDto) => {
        if (frontend != null) {
            return (
                <div>
                    <Tag color={MethodTypeColor.get(frontend.MethodName || "GET")}>{frontend?.MethodName}</Tag>
                    <span className="content">{frontend?.BaseAddress}{frontend?.Path}</span>
                </div>
            );
        }
    }

    const renderParam = (params?: ViewParameter[]) => {
        return (
            params?.map((item) =>
                <Row style={{marginTop:"3px"}}>
                    <Col>
                        <Tag style={{ background: '#D9D9D9' }} color="default">{item.Name}</Tag>
                    </Col>
                    <Col>
                        <Tag style={{ background: '#FFFFFF' }} color="default">{item.ParameterType}</Tag>
                    </Col>
                </Row>
            )
        )
    }

    const renderHeader = (header?: ViewHeader[]) => {
        return (
            header?.map((item) =>
                <Row style={{marginTop:"3px"}}>
                    <Col>
                        <Tag style={{ background: '#D9D9D9' }} color="default">{item.Name}</Tag>
                    </Col>
                    <Col>
                        <Tag style={{ background: '#FFFFFF' }} color="default">{item.Type}</Tag>
                    </Col>
                </Row>
            )
        )
    }

    const closeOperationDrawer = (): void => {
        setOperationVisible(false);
    }


    const onSearchAPI = (searchText: string): void => {
        handleGetOperations(props.id || "", searchText);
    }

    const onCloneOperations = (id: string) => {
        CloneOperation(id).then(e => handleGetOperations(props.id || "", "")).finally(() => setTableLoading(false));
    }

    const onDeleteOperations = (id: string) => {
        handleDeleteMethod(id);
    }

    const addOperation = () => {
        setMethodId("");
        setIsFrontend(true);
        setOperationVisible(true);
    }
  
    return (
        <>
            <Content style={{ marginBottom: "24px" }}>

                <Layout >
                    <Sider width={260} style={{ background: 'white' }} >
                        <APIOperations
                            title="Operations"
                            addOperation={addOperation}
                            menuItemClick={menuItemClick}
                            data={methodMenu}
                            onSearchAPI={onSearchAPI}
                            onDeleteOperations={onDeleteOperations}
                            onCloneOperations={onCloneOperations}
                            selectedKeys={selectKey}
                        />
                    </Sider>
                    <Layout>
                        <Spin spinning={tableLoading}>
                            <div style={{ background: "white" }}>
                                <Content style={{ padding: "24px" }}>
                                    <Card type="inner" title="Frontend" extra={<EditOutlined onClick={onEditMethod} />}>
                                        {renderUrl(frontend)}
                                        {frontend?.Parameters && frontend?.Parameters.length > 0 && <><div className="ant-drawer-title" style={{ marginTop: "15px" }}>Query parameters</div></>}
                                        {renderParam(frontend?.Parameters)}
                                        {frontend?.Headers && frontend?.Headers.length > 0 && <div className="ant-drawer-title" style={{ marginTop: "15px" }}>Header</div>}
                                        {renderHeader(frontend?.Headers)}
                                    </Card>
                                    <div style={{ textAlign: "center" }}>
                                        <ArrowDownOutlined />
                                    </div>

                                    <Card type="inner" title="Control policy" >
                                        {!controlPolicy && <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />}
                                        {controlPolicy &&
                                            <>
                                                {controlPolicy?.Description}
                                                <Descriptions title="Policy name">
                                                    <Descriptions.Item>{controlPolicy?.Name}</Descriptions.Item>
                                                </Descriptions>
                                                <Descriptions title="Policy details"></Descriptions>
                                                <Table columns={columns} pagination={false} dataSource={controlPolicy?.Rule} />
                                            </>
                                        }
                                    </Card>
                                    <div style={{ textAlign: "center" }}>
                                        <ArrowDownOutlined />
                                    </div>
                                    <Card type="inner" title="Backend" extra={<EditOutlined onClick={onEditBackEndMethod} />}>
                                        <Descriptions title="Https endpoint">
                                            <Descriptions.Item><span className="content">{backend?.BaseAddress}{backend?.Path}</span></Descriptions.Item>
                                        </Descriptions>
                                    </Card>
                                </Content>
                            </div>
                        </Spin>
                    </Layout>
                </Layout>

            </Content>
            <CreateOperationDrawer
                baseAddress={baseAddress}
                operationVisibile={operationVisible}
                closeDrawer={closeOperationDrawer}
                methodId={methodId}
                isFrontend={isFrontend}
                versionId={props.id!}
                refreshMethod={handleGetOperations}
            />
        </>
    );
}

export default APIsDesign

import React, { FC, useState, useEffect } from 'react';
import { Table, Space } from 'antd';
import { ColumnsType } from "antd/lib/table";
import { ViewControlRulePolicy } from '../../common/contracts/ModelContracts';
import { EditOutlined, DeleteOutlined, ArrowUpOutlined, ArrowDownOutlined, } from '@ant-design/icons';
import { SortControlRulePolicyRule } from './ControlPolicyApiService';
import { LimitType } from '../../common/contracts/ModelContracts';
import { BlockTypeEnum } from '../../common/contracts/ModelContracts';

interface IViewVersionTableProps {
    ruleData: ViewControlRulePolicy[];
    visibleDrawer: (ruleId: string) => void;
    deleteRule: (ruleId: string) => void;
}


const ControlPolicyRuleTable: FC<IViewVersionTableProps> = (props) => {
    const [dataSource, setDataSource] = useState<ViewControlRulePolicy[]>([]);

    useEffect(() => {
        setDataSource(props.ruleData);
    }, [props.ruleData])

    const GetType = (text: any, record: ViewControlRulePolicy) => {
        console.debug(record);
        const json = JSON.parse(record.ExtensionJSON!);
        let str = "";
        const type = record.RuleType?.toString();
        if (type ===  "RateLimite" ) {
            str = LimitType[json.LimitType]
        }
        else {
            str = BlockTypeEnum[json.BlockType] + " IPS"
        }
        return str;
    }

    const columns: ColumnsType<ViewControlRulePolicy> = [
        {
            title: 'Priority',
            dataIndex: 'SN',
        },
        {
            title: 'Rule',
            dataIndex: 'RuleType',
        },
        {
            title: 'Type',
            render: (text, record) => GetType(text, record)//将当前行数据传个方法返回一个字符串
        },
        {
            title: 'Action(s)',
            dataIndex: 'Action',
            width:1,
            render: (text, record, index) =>
                <>
                    <Space size="middle">
                        <EditOutlined onClick={() => { props.visibleDrawer(record.Id) }} />
                        <DeleteOutlined onClick={() => { props.deleteRule(record.Id) }} />
                        {index === 0 ? <ArrowDownOutlined onClick={() => { downGo(index) }} /> : <ArrowUpOutlined onClick={() => { upGo(index) }} />}
                    </Space>
                </>
        }
    ]

    const upGo = (index: number) => {
        let data = [...dataSource];
        if (index !== 0) {
            data[index] = data.splice(index - 1, 1, data[index])[0];
            data.forEach((item, index) => item.SN = index + 1);
            SortControlRulePolicyRule(data).then(res => setDataSource(data));
        }
    };

    const downGo = (index: number) => {
        let data = [...dataSource];
        if (index !== data.length) {
            data[index] = data.splice(index + 1, 1, data[index])[0];
            data.forEach((item, index) => item.SN = index + 1);
            SortControlRulePolicyRule(data).then(res => setDataSource(data));
        }
    };

    return <React.Fragment>
        <Table
            rowKey={(record) => record.Id}
            columns={columns}
            dataSource={dataSource}
            pagination={false}

        />
    </React.Fragment>

}
export default ControlPolicyRuleTable


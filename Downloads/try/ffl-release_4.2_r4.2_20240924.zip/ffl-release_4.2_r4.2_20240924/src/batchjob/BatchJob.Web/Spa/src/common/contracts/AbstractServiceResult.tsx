/**
 * name
 */
 export class AbstractServiceResult {
    public static Type: ServiceResultType;
    public static Message: string;
    public static EventCode: number;
}

export enum ServiceResultType
{
    Success = 0,
    Failed = 1,
    Error = 2,
    Exception = 3,
}
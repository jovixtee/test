import React from 'react';
import { Collapse, Row, Col } from 'antd';
import { convertTicksToFormatDate } from '../../utils/dateconvert';
import JobUtil from './JobUtil';
const { Panel } = Collapse;
const DetailsSummary = (props: any) => {
    const record:any = props.record;
    return (
        <>
            <Collapse defaultActiveKey={['1']}>
                <Panel header="Job Information" key="1">
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>Job Id:</span></Col>
                        <Col span={6}><span>{record?.Name}</span></Col>
                    </Row>
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>Task Title:</span></Col>
                        <Col span={6}><span>{record?.TaskName}</span></Col>
                    </Row>
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>Description:</span></Col>
                        <Col span={6}><span>{record?.Description}</span></Col>
                    </Row>
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>Tag:</span></Col>
                        <Col span={6}><span>{record?.Tag}</span></Col>
                    </Row>
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>Start Time:</span></Col>
                        <Col span={6}><span>{convertTicksToFormatDate(record?.StartTime!, 'YYYY-MM-DD HH:mm:ss')}</span></Col>
                    </Row>
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>End Time:</span></Col>
                        <Col span={6}><span>{convertTicksToFormatDate(record?.EndTime, 'YYYY-MM-DD HH:mm:ss')}</span></Col>
                    </Row>
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>Triggered By:</span></Col>
                        <Col span={6}><span>{record?.CreatedBy}</span></Col>
                    </Row>
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>Executing On:</span></Col>
                        <Col span={6}><span>{record?.ExecuteHostName}</span></Col>
                    </Row>
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>Status:</span></Col>
                        <Col span={6}>
                            <span>
                                {JobUtil.GetStateString(record?.State)}
                            </span></Col>
                    </Row>
                    <Row style={{ marginBottom: '20px' }}>
                        <Col span={3}><span>Comment:</span></Col>
                        <Col span={21}>
                            <span>{record?.Comment}</span>
                        </Col>
                    </Row>
                </Panel>
            </Collapse>
        </>
    );
};

export default DetailsSummary;
import { CaretRightOutlined, CheckCircleOutlined, CloseCircleOutlined, DeleteOutlined, DownloadOutlined, EditOutlined, FundViewOutlined, ImportOutlined, PlusOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import { Modal, Button, message } from 'antd';
import React, { useState } from 'react';
import TaskFormDrawer from './TaskFormDrawer';
import { TaskDto, TaskPermissionConstants } from './TaskManagerContract';
import TaskManagerApiService from './TaskManagerApiService';
import { hasPermission } from '../../utils/permissionutil';
import ImportDocument from '../../components/ImportDocument'
import { useHistory } from 'react-router-dom';
import PathConfig from '../../common/PathConfig';
import AmpCommonTable, { IAmpTableButton, DatetimeColumnTemplate } from '../../components/antdx/AmpCommonTable';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import ProfileReadDrawer from "./ProfileReadDrawer";
import { NextRunTimeTemplate } from './TaskManagerUtil';
import UINotrification from '../../common/UINotrification';

const { confirm } = Modal;
const TaskTable = () => {
    const [profileVisable, setProfileVisable] = useState<boolean>(false);
    const [drawerTask, setDrawerTask] = useState<TaskDto>(new TaskDto());
    const [drawerVisable, setDrawerVisable] = useState<boolean>(false);
    // const [selectTaskIds, setSelectTaskIds] = useState<string[]>([]);
    const [selectRecords, setSelectRecords] = useState<TaskDto[]>([]);
    const [importVisable, setImportVisable] = useState<boolean>(false);
    const [canRun, setCanRun] = useState<boolean>(true);
    const history = useHistory();
    const [refresh, setRefresh] = useState(1);

    const onCreateClick = () => {
        setDrawerTask(new TaskDto());
        setDrawerVisable(true);
    };
    const onEditClick = (record: any) => {
        TaskManagerApiService.getInstance().LoadTask(record.Id, result => {
            setDrawerTask(result?.Task as TaskDto);
            setDrawerVisable(true);
        });
    };

    const onProfileClick = (record: any) => {
        TaskManagerApiService.getInstance().LoadTask(record.Id, result => {
            setDrawerTask(result?.Task as TaskDto);
            setProfileVisable(true);
        });
    };

    const tableCols = [
        {
            title: 'Task Title',
            dataIndex: 'Name',
            key: 'Name',
            sorter: true,
            ellipsis: true,
            // eslint-disable-next-line jsx-a11y/anchor-is-valid
            render: (text: any, record: any) => <a onClick={() => onProfileClick(record)}>{text}</a>
        },
        {
            title: 'Description',
            dataIndex: 'Description',
            key: 'Description',
            ellipsis: true
        }, {
            title: 'Next Run Time',
            dataIndex: 'NextTime',
            key: 'NextTime',
            sorter: true,
            render: NextRunTimeTemplate
        }, {
            title: 'Status',
            dataIndex: 'State',
            key: 'State',
            filtered: true,
            filters: [{ text: 'Enabled', value: 0 }, { text: 'Disabled', value: 1 }],
            render: (text: any, record: any) => <label>{text === 0 ? "Enabled" : "Disabled"}</label>
        }, {
            title: 'Action',
            dataIndex: 'ActionDisplayName',
            key: 'ActionDisplayName',
        }, {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
            ellipsis: true
        }, {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
            ellipsis: true
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }];



    const buttonEvents = {
        deleteTasks: function () {
            confirm({
                title: 'Warning',
                icon: <ExclamationCircleOutlined />,
                content: 'You are about to delete the selected items. Are you sure you want to proceed?',
                onOk() {
                    TaskManagerApiService.getInstance().DeleteTasks(selectRecords.map(r => r.Id!), (result) => {
                        UINotrification.success("Task(s) successfully deleted.");
                        RefreshTable();
                    });
                },
                onCancel() {
                    console.log('Cancel');
                },
            })
        },
        viewHistory: function () {
            // history.push({
            //     pathname: PathConfig.addPrefix("/jobmonitor") + "?taskId=" + selectRecords[0].Id,
            // });
            history.push(PathConfig.addPrefix("/jobmonitor") + "?taskId=" + selectRecords[0].Id)
        },
        runTask: function () {

            TaskManagerApiService.getInstance().RunTask(selectRecords[0].Id!, (result) => {
                UINotrification.success(`Successfully run the task '${selectRecords[0].Name}'.`);
            });
        },
        enableTask: function () {
            TaskManagerApiService.getInstance().UpdateState(selectRecords.map(r => r.Id).join(), 0, (result) => {
                UINotrification.success(`Successfully enabled the task.`);
                RefreshTable();

            });
        },
        disableTask: function () {
            TaskManagerApiService.getInstance().UpdateState(selectRecords.map(r => r.Id).join(), 1, (result) => {
                UINotrification.success(`Successfully disable the task.`);
                RefreshTable();

            });
        },
        importSubmit: (fileList: any[]) => {
            TaskManagerApiService.getInstance().ImportTask(fileList[0], (result) => {
                if (result.Type === 1) {
                    UINotrification.error("This file type is not supported. You must select a zip (.zip) file.");
                } else {
                    UINotrification.success("Operation successfully.");
                }
                RefreshTable();
            });
            setImportVisable(false);
        },
        import: function () {
            setImportVisable(true)
        },
        export: function () {
            TaskManagerApiService.getInstance().ExportTask(selectRecords.map(r => r.Id!));
        }
    };

    const RefreshTable = () => {
        setRefresh(refresh + 1);
    };

    const drawerEvents = {
        onClose: () => {
            setDrawerVisable(false);
            setProfileVisable(false);
        },
        onFinished: (task: TaskDto, type?: number) => {  
            if (type === 1) {
                UINotrification.error("Duplicate name, task '" + task.Name + "' failed " + (task.Id ? "updated" : "created") + ".");
            } else {
                UINotrification.success("Task '" + task.Name + "' successfully " + (task.Id ? "updated" : "created") + ".");
                setDrawerVisable(false);
                RefreshTable();
            }
        }
    }

    const buttons: Array<IAmpTableButton> = [{
        Text: "Create",
        Primary: true,
        Icon: <PlusOutlined />,
        OnClick: onCreateClick,
        EnableMode: 'always',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Create)
    }, {
        Text: "Edit",
        Icon: <EditOutlined />,
        OnClick: () => onEditClick(selectRecords[0]),
        EnableMode: 'single',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Create)
    }, {
        Text: "Delete",
        Icon: <DeleteOutlined />,
        OnClick: buttonEvents.deleteTasks,
        EnableMode: 'multiple',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Delete)
    }, {
        Text: "View History",
        Icon: <FundViewOutlined />,
        OnClick: buttonEvents.viewHistory,
        EnableMode: 'single',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Read)
    }, {
        Text: "Run",
        Icon: <CaretRightOutlined />,
        OnClick: buttonEvents.runTask,
        EnableMode: 'single',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Create) && canRun
    }, {
        Text: "Enable",
        Icon: <CheckCircleOutlined />,
        OnClick: buttonEvents.enableTask,
        EnableMode: 'multiple',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Update)
    }, {
        Text: "Disable",
        Icon: <CloseCircleOutlined />,
        OnClick: buttonEvents.disableTask,
        EnableMode: 'multiple',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Update)
    }, {
        Text: "Import",
        Icon: <ImportOutlined />,
        OnClick: buttonEvents.import,
        EnableMode: 'always',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Create)
    }, {
        Text: "Export",
        Icon: <DownloadOutlined />,
        OnClick: buttonEvents.export,
        EnableMode: 'multiple',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Read)
    }];

    const ApiPagerQueryJob = async (exp: PagerExpression) => {
        const result = await TaskManagerApiService.getInstance().PagerQuery(exp);
        return { total: result.PageredTasks!.TotalNumber, records: result.PageredTasks!.Result };
    }

    const SelectRecords = (records: TaskDto[]) => {
        setSelectRecords(records);
        records.forEach((item: TaskDto) => {
            if (item.State === 1) {
                setCanRun(false);
                return;
            } else {
                setCanRun(true);
            }
        })
    }

    return (<>
        <TaskFormDrawer task={drawerTask} onFinished={drawerEvents.onFinished} onClose={drawerEvents.onClose} visible={drawerVisable}></TaskFormDrawer>
        <AmpCommonTable Type="checkbox" RowKey="Id" Columns={tableCols} PagerQuery={ApiPagerQueryJob} OnSelectedChanged={SelectRecords}
            SearchKeys={["Name"]} Refresh={refresh} Buttons={buttons} EnableSearch />
        <ImportDocument
            show={importVisable} 
            cancel={() => setImportVisable(false)}
            submit={buttonEvents.importSubmit}
            accept='.zip'
            message='Supported file type: .zip'
        />
        <ProfileReadDrawer
            visible={profileVisable}
            dataSource={drawerTask}
            onClose={drawerEvents.onClose}
        />


    </>)
}

export default TaskTable;
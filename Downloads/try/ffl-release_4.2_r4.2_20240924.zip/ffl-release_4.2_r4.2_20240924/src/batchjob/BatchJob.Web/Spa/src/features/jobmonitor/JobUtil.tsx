const getStateString = (state: number): string => {
    switch (state) {
        case 0:
            return 'Wait';
        case 1:
            return 'In Progress';
        case 2:
            return 'Finished';
        case 3:
            return 'Failed';
        case 4:
            return 'Exception';
        case 5:
            return 'Stopped';
        case 6:
            return 'Skipped';
        case 7:
            return 'Stopping';
        case 8:
            return 'Starting';
        case 9:
            return 'Pausing';
        case 10:
            return 'Paused';
        default:
            return 'NA';
    }
};

const statusArray = [
    { text: "Wait", value: 0 },
    { text: "In Progress", value: 1 },
    { text: "Finished", value: 2 },
    { text: "Failed", value: 3 },
    { text: "Exception", value: 4 },
    { text: "Stopped", value: 5 },
    { text: "Skipped", value: 6 },
    { text: "Stopping", value: 7 },
    { text: "Starting", value: 8 },
    { text: "Pausing", value: 9 },
    { text: "Paused", value: 10 },
];

const JobUtil = {
    GetStateString: getStateString,
    StatusFilter: statusArray
}

export default JobUtil;
import React, { useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import { Table, Checkbox } from 'antd';
import { QueryPrivilegeAll } from './permissionLevelApiServe';
export interface Provider {
    Feature: string;
    Description: string;
    uuid: any;
}
const PermissionLevelForm = (props: any, ref: any) => {
    const [selectedRows, setSelectedRows] = useState<any>([])
    const [selectedRowKeys, setSelectedRowKeys] = useState<any>([])
    const [dataSource, setDataSource] = useState<any>([])
    const [sendData, setSendData] = useState<any>([...props.EditFormData.Privileges])
    const columns = [
        {
            title: 'Name',
            dataIndex: 'Name',
            key: 'Name',
            width: '25%',

        }, {
            title: 'Feature ',
            dataIndex: 'DepthMask',
            key: 'DepthMask',
            width: '75%',
            render: (text: number, record: any) => {
                let defaultValue: number[] = []
                if (props.EditFormData.Privileges.length > 0) {
                    props.EditFormData.Privileges.forEach((value: any) => {
                        if (value.ObjectCode === record.ObjectCode) {
                            let temp = [value.AccessRight & 1, value.AccessRight & 2, value.AccessRight & 4, value.AccessRight & 8]
                            defaultValue = temp

                        }
                    })
                }
                let disab = selectedRowKeys.indexOf(record.PrivilegeId) > -1
                return <Checkbox.Group disabled={!disab} options={record.options} defaultValue={defaultValue} onChange={(checkedValues) => { onChange(checkedValues, record) }} />
            }
        }];

    useEffect(() => {
        getInitData();
    },[])
    const getInitData = async () => {
        if (sendData) {
            sendData.forEach((value: any) => {
                let defaultValue: number[] = []
                defaultValue = [value.AccessRight & 1, value.AccessRight & 2, value.AccessRight & 4, value.AccessRight & 8]
                value.checkedValues = defaultValue

            })
            setSendData([...sendData])
        }
        let result = await QueryPrivilegeAll()
        result.Result.forEach((item: any) => {
            item.options = [
                { label: 'Read', value: 1, disabled: !!!(item.DepthMask & 1) },
                { label: 'Create', value: 2, disabled: !!!(item.DepthMask & 2) },
                { label: 'Update', value: 4, disabled: !!!(item.DepthMask & 4) },
                { label: 'Delete', value: 8, disabled: !!!(item.DepthMask & 8) }
            ]
        })
        setDataSource(result.Result)
    }
    useImperativeHandle(ref, () => ({
        onSubmit: () => {
            props.onLevelFormData({ selectedRows: sendData })
        }
    }));
    const rowSelection = {
        onChange: (selectedRowKeys: any, selectedRows: any) => {
            setSelectedRows(selectedRows)
            setSelectedRowKeys(selectedRowKeys)
        },

    };
    const onChange = (checkedValues: any, record: any) => {
        console.log(props.EditFormData.Privileges)
        if (props.EditFormData.Privileges.length > 0) {
            let data = props.EditFormData.Privileges
            for (let i = 0; i < data.length; i++) {
                if (selectedRowKeys.indexOf(data[i].PrivilegeId) !== -1 && record.PrivilegeId === data[i].PrivilegeId) {
                    console.log('exist')
                    props.EditFormData.Privileges[i].checkedValues = checkedValues
                    break
                } else {
                    if (data.length - 1 === i) {
                        // 最后一条数据执行完毕之后进入这个里面
                        console.log('not exist')
                        record.checkedValues = checkedValues
                        props.EditFormData.Privileges.push(record)
                        break
                    }
                }
            }
            setSendData([...props.EditFormData.Privileges])
        } else {
            console.log(selectedRows)
            selectedRows.forEach((item: any) => {
                if (record.PrivilegeId === item.PrivilegeId) {
                    item.checkedValues = checkedValues
                }
            })
            setSendData([...selectedRows])
        }
    }
    return (
        <React.Fragment>
            <Table
                rowSelection={{ type: 'checkbox', ...rowSelection }}
                columns={columns}
                dataSource={dataSource}
                rowKey='PrivilegeId'
                pagination={false}
            >
            </Table>
        </React.Fragment>
    )
}
export default forwardRef(PermissionLevelForm);
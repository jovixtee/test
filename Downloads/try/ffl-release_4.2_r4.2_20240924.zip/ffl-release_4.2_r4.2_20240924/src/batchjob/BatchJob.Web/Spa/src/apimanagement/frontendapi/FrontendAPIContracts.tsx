import { Pager } from "../node/NodeContract";
import { BackendDetailsDto,FrontendAPIDto,VersionStatusType,VersionDto } from "../../common/contracts/ModelContracts";


// export class FrontendAPIVersionDetail {
//     Id?: string;
//     Endpoint?: string;
//     ControlPolicyID?: string;
//     AuthenticationID?: string;
//     Authentication?: string;
//     FrontendID?: string;
//     Status?: VersionStatusType;
//     BackendID?:string;
// }

export class FrontendAPIVersionMethodDetail {
    Id: string = "";
    Path?: string;
    MethodName?: MethodTypeEnum;
    param?: VersionMethodParameter[];
    MethodType?: VersionMethodTypeEnum;
    Header?: string;
    VersionId?: string;
    version?:VersionDto;
    frontend?:FrontendAPIDto;
    method?:FrontendAPIVersionMethodDetail;
    Backend?:BackendDetailsDto;
}
export class ParameterObject {
    addData?: VersionMethodParameter[];
    updateData?: VersionMethodParameter[];
    deleteData?: VersionMethodParameter[];

}


export class VersionMethodParameter {
    Id: string = "";
    Key?: string;
    DefaultValue?: string | number;
    ParamterTypeID?: string;

}

export class EditTableData extends VersionMethodParameter {
    IsEdit: boolean = false;
    IsNewData: boolean = false;
}


export interface IEditTableRef {
    getTableResult: () => {
        addData: VersionMethodParameter[];
        updateData: VersionMethodParameter[];
        deleteData: VersionMethodParameter[];
        isEditing: boolean;
    }
}

export interface IPaginationC {
    currentPage: number;
    currentPageSize: number;
    total?: number;
}


export interface VoidCallBackFunction {
    (): void
}
export interface ISelectOption {
    key: string,
    value: string
}
export interface IGetSelectResult {
    [name: string]: ISelectOption[]
}
export interface IDictionary {
    key?: string,
    value?: string
}


export enum TypeEnum {
    Http = 1,
    Https = 2

}

export enum ParameterTypeEnum {
    String = 1,
    Number = 2,
    Boolean = 3
}

export enum MethodTypeEnum {
    GET = 0,
    POST = 1,
    PUT = 2,
    PATCH = 3,
    DELETE = 4,
    COPY = 5,
    HEAD = 6,
    OPTIONS = 7,
    LINK = 8,
    UNLINK = 9,
    PURGE = 10,
    LOCK = 11,
    UNLOCK = 12,
    PROPFIND = 13,
    VIEW = 14
}

export enum VersionMethodTypeEnum {
    None = 0,
    AuthenticationIssue = 1,
    AuthenticationRevoke = 2,
    ServiceMethod = 3
}

export enum FromType {
    Frontend = 0,
    Backend = 1
}


export const StatusMap = new Map<string, VersionStatusType>([
    ["Active", VersionStatusType.Active],
    ["Draft", VersionStatusType.Draft],
    ["Deprecate", VersionStatusType.Deprecate],
])

export const TypeMap = new Map<string, TypeEnum>([
    ["Http", TypeEnum.Http],
    ["Https", TypeEnum.Https]
])

export const ParameterTypeMap = new Map<string, ParameterTypeEnum>([
    ["String", ParameterTypeEnum.String],
    ["Number", ParameterTypeEnum.Number],
    ["Boolean", ParameterTypeEnum.Boolean],
])

export const MethodTypeMap = new Map<string, MethodTypeEnum>([
    ["GET", MethodTypeEnum.GET],
    ["POST", MethodTypeEnum.POST],
    ["PUT", MethodTypeEnum.PUT],
    ["PATCH", MethodTypeEnum.PATCH],
    ["DELETE", MethodTypeEnum.DELETE],
    ["COPY", MethodTypeEnum.COPY],
    ["HEAD", MethodTypeEnum.HEAD],
    ["OPTIONS", MethodTypeEnum.OPTIONS],
    ["LINK", MethodTypeEnum.LINK],
    ["UNLINK", MethodTypeEnum.UNLINK],
    ["PURGE", MethodTypeEnum.PURGE],
    ["LOCK", MethodTypeEnum.LOCK],
    ["UNLOCK", MethodTypeEnum.UNLOCK],
    ["PROPFIND", MethodTypeEnum.PROPFIND],
    ["VIEW", MethodTypeEnum.VIEW],
])


export const ContentTypeDefault: string[] = [
    "application/xhtml+xml",
    "application/xml",
    "application/atom+xml",
    "application/json",
    "application/octet-stream",
    "application/x-www-form-urlencoded",
    "multipart/form-data",
    "text/html",
    "text/xml"
]

export const VersionthodTypeMap = new Map<string, VersionMethodTypeEnum>([
    ["Authentication Issue", VersionMethodTypeEnum.AuthenticationIssue],
    ["Authentication Revoke", VersionMethodTypeEnum.AuthenticationRevoke],
    ["Service Method", VersionMethodTypeEnum.ServiceMethod],
])


export class QueryFrontendPager extends Pager {
    constructor(pageSize: number, jumpPage: number, SearchValue: string) {
        super(
            pageSize,
            jumpPage,
            "Name",
            SearchValue, ["Name"],
            []
        )
    }
}
export class QueryFrontendMethodPager extends Pager {
    constructor(pageSize: number, jumpPage: number, SearchValue: string, VersionId?: string) {
        super(
            pageSize,
            jumpPage,
            "ModifiedOn",
            SearchValue, [],
            [
                {
                    "ColumnName": "VersionId",
                    "ColumnValues": [VersionId!]
                }
            ]
        )
    }
}
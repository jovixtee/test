import React, { FC } from "react";
import { Drawer, Form, Button, Upload } from 'antd';
import { UploadOutlined, } from '@ant-design/icons';
import { UploadFile } from 'antd/lib/upload/interface';
import UINotrification from '../../common/UINotrification';
import { HolidayProfileBase } from "./HolidaySettingContract";
import HolidaySettingApi from './HolidaySettingApi';
interface IDrawerImportFormProps {
    visible: boolean;
    profile: HolidayProfileBase;
    closeImportDrawer: () => void;
}

const DrawerImportForm: FC<IDrawerImportFormProps> = (props) => {
    const upload = async (file: any) => {
        const fd = new FormData();
        let args: any = { ProfileId: props.profile.ProfileId };
        args._streamLength = file.size;
        args.importArguments = { FileName: file.name };
        fd.set('arg', JSON.stringify(args));
        fd.set('file', file);
        return HolidaySettingApi.ImportPublicSG(fd);
    }

    const beforeUpload = (file: any, FileList: UploadFile[]) => {
        const isLt5M = file.size / 1024 / 1024 < 5;
        if (!isLt5M) {
            UINotrification.error('file must smaller than 5MB!');
            return false;
        }
        upload(file).then(res => UINotrification.success("Import success"));
        return true;
    }


    return (
        <>
            <Drawer
                title="Basic Drawer"
                closable={false}
                width={720}
                onClose={props.closeImportDrawer}
                visible={props.visible}>
                <Form name="import-modal" layout="vertical" >
                    <Form.Item name="name" label="Profile Name" rules={[{ required: true }]}>
                        <Upload name="files" beforeUpload={beforeUpload} multiple={false} accept=".ics">
                            <Button icon={<UploadOutlined />}>Upload</Button>
                        </Upload>
                    </Form.Item>
                </Form>
            </Drawer>
        </>
    );
}
export default DrawerImportForm;


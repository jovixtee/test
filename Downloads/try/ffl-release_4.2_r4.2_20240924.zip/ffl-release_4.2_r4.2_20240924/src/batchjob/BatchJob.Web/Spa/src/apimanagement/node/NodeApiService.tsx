import apiservice from '../../utils/fetchutil';
import { PagerResult } from '../../common/contracts/PagerContracts';
import {NodeDetail,ViewNode} from '../../common/contracts/ModelContracts';
const serve = apiservice();

export const PagerQueryNode =(params :any):Promise<PagerResult<NodeDetail>>=>{
    return new Promise((res,rej)=>{
        serve.post("/IAPIManagementService/PagerQueryNode", params).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}
export const GetNodeDetailById =(id :any):Promise<NodeDetail>=>{
    return new Promise((res,rej)=>{
        serve.post("/IAPIManagementService/GetNodeDetailById", {id}).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

export const GetViewNode =(name :string):Promise<ViewNode[]>=>{
    return new Promise((res,rej)=>{
        serve.post("/IAPIManagementService/ViewNode",{name}).then((result) => {
            res(result.Result)
        }).catch(error => {
            rej(error)
        })
    })
}

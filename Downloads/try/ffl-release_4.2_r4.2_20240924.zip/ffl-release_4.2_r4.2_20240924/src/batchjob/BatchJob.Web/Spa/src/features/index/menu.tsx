import React from 'react';
import PathConfig from '../../common/PathConfig';

import {
  UserAddOutlined,
  EyeOutlined,
  DashboardOutlined,
  WindowsOutlined,
  ScheduleOutlined,
  DatabaseOutlined,
  SecurityScanOutlined,
  TeamOutlined,
  SettingOutlined,
  ClockCircleOutlined,
  SafetyOutlined,
  ProfileOutlined
} from '@ant-design/icons';

export interface MenuItemDto {
  title: string,
  icon: any,
  key: string,
  subs?: Array<MenuItemDto>,
}

export const menus: Array<MenuItemDto> = [
  {
    title: 'Dashboard',
    icon: <DashboardOutlined />,
    key: '/home'
  },
  {
    title: 'Features',
    icon: <WindowsOutlined />,
    key: '/features',
    subs: [
      { key: '/taskmanager', title: 'Task Manager', icon: <ScheduleOutlined />},
      { key: '/jobmonitor', title: 'Job Monitor', icon: <EyeOutlined />, },
      { key: '/connections', title: 'Connections', icon: <DatabaseOutlined />, },
      { key: '/holidaysetting', title: 'Holiday Setting', icon: <ClockCircleOutlined />, },
      { key: '/transfer/profile', title: 'Transfer Profile', icon: <ProfileOutlined />, },
	{ key: '/dataPipeline/main', title: 'Data Pipeline', icon: <ScheduleOutlined />},
    ]
  },
  {
    title: 'Account Manager',
    icon: <TeamOutlined />,
    key: '/home/account',
    subs: [
      { key: '/home/account/user', title: 'User', icon: <UserAddOutlined />, },
      // { key: '/home/account/Group', title: 'Group', icon: <UsergroupAddOutlined />,},
      { key: '/home/account/permission', title: 'Permission Level', icon: <SafetyOutlined />, },
      // { key: '/home/account/authentication', title: 'Authentication', icon: <SafetyCertificateOutlined />,},      
    ]
  },
  // {
  //   title: 'Security Manager',
  //   icon: <SecurityScanOutlined />,
  //   key: '/home/security',
  //   subs: [
  //     { key: '/home/security/securitypofile', title: 'Security Pofile', icon: <ProfileOutlined />, },
  //     //{key: '/home/security/passwordpolicy', title: 'Account Password Policy', icon:'',},
  //     //{key: '/home/security/information', title: 'Security Information', icon:'',}    
  //   ]
  // },
  {
    title: 'Notification Manager',
    icon: <SecurityScanOutlined />,
    key: '/home/Recipients',
    subs: [
      { key: '/home/Recipients/RecipientsManager', title: 'Recipients', icon: <ProfileOutlined />, },
      { key: '/home/Recipients/NotificationSetting', title: 'Notification Setting', icon: <ProfileOutlined />, },
      // { key: '/home/Recipients/EmailServerSetting', title: 'E-mail Settings', icon: <ProfileOutlined />, },

    ]
  },
  {
    title: 'API Management',
    icon: <SecurityScanOutlined />,
    key: '/home/apimanagement',
    subs: [
      { key: '/home/apimanagement/node', title: 'Node', icon: <ProfileOutlined />, },
      { key: '/home/apimanagement/APIsContent', title: 'APIs', icon: <ProfileOutlined />, },
      // { key: '/home/apimanagement/backendapi', title: 'Backend API', icon: <ProfileOutlined />, },
      //{ key: '/home/apimanagement/frontendapi', title: 'Frontend API', icon: <ProfileOutlined />, },
      { key: '/home/apimanagement/apiauthentication', title: 'Authentication', icon: <ProfileOutlined />, },
      { key: '/home/apimanagement/controlpolicy', title: 'Control Policy', icon: <ProfileOutlined />, },
      { key: '/home/apimanagement/analysticreport', title: 'Analystic & Report', icon: <ProfileOutlined />, },
    ]
  },
  // {
  //   title: 'About',
  //   icon: <SettingOutlined />,
  //   key: '/home/about'
  // }
];

const prunQuery = (pathname: string): string => {
  if (pathname.indexOf('?') !== -1) {
    pathname = pathname.substr(0, pathname.indexOf('?'));
  }
  return pathname;
}

export const findUrl = (items: Array<MenuItemDto>, pathname: string): Array<string> => {
  pathname = prunQuery(pathname);

  for (let i = 0; i < items.length; i++) {
    let item = items[i];
    if (item && item.subs && item.subs.length) {
      for (let i = 0; i < item.subs.length; i++) {
        let keyarr: Array<string> = findUrl(item.subs, pathname);
        if (keyarr && keyarr.length > 0) {
          let newPath = PathConfig.addPrefix(item.key);
          keyarr.push(newPath);
          return keyarr;
        }
        continue;
      }
    } else {
      let newPath = PathConfig.addPrefix(item.key);
      if (pathname === newPath) {
        return [newPath];
      }
      continue;
    }
  }
  return [];
};

export const findItmes = (items: Array<MenuItemDto>, pathname: string): Array<MenuItemDto> => {
  pathname = prunQuery(pathname);

  for (let i = 0; i < items.length; i++) {
    let item = items[i];
    if (item && item.subs && item.subs.length) {
      for (let i = 0; i < item.subs.length; i++) {
        let keyarr: Array<MenuItemDto> = findItmes(item.subs, pathname);
        if (keyarr && keyarr.length > 0) {
          keyarr.push({ ...item });
          return keyarr;
        }
        continue;
      }
    } else {
      let newPath = PathConfig.addPrefix(item.key);
      if (pathname === newPath) {
        return [{ ...item }];
      }
      continue;
    }
  }
  return [];
};
import { Drawer, Form, Input, Button, Select, Divider, Cascader, Tooltip, Space, Spin } from 'antd';
import React, { FC, useEffect, useRef, useState } from 'react';
import { VoidCallBackFunction, FrontendAPIVersionMethodDetail, IEditTableRef, IDictionary, VersionMethodParameter, MethodTypeMap, MethodTypeEnum, ContentTypeDefault, VersionMethodTypeEnum, ParameterObject } from './FrontendAPIContracts';
import EditTable from './EditTable';
import useCascader from "./useCascader";
//import { CascaderValueType } from 'antd/lib/cascader';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { CreateMethod, GetMethodById, GetMethodByBackendIDFrontendIDVersionID, GetParameterByBackendID } from './FrontendAPIApiService';

interface IManageMethodDrawerProps {
    visible: boolean;
    cancelClick: VoidCallBackFunction;
    isEdit: boolean;
    defaultData: FrontendAPIVersionMethodDetail;
    versionId: string;
    apiId: string;
    parmData: Map<string, string>;
    getTableData: VoidFunction;
}
type Header = {
    key?: string;
    value?: string;
}
interface IMethodFrom {
    Type?: MethodTypeEnum,
    Path?: string,
    MethodType?: VersionMethodTypeEnum,
    Header?: Header[]
}

interface IMethodData {
    label?: string;
    value: string;
}

interface IMethodItem {
    key: string;
    value: string;
    MethodName?: string;
}

const { Option } = Select;

const layout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 14 },
};
const ManageMethodDrawer: FC<IManageMethodDrawerProps> = (props) => {
    const [selectContentTypeData, setSelectContentTypeData] = useState<string[]>([]);
    const [newSelectItemName, setNewSelectItemName] = useState<string>("");
    const [methodSelectVisible, setMethodSelectVisible] = useState<boolean>(false);
    const [methodData, setMethodData] = useState<IMethodData[]>([]);
    const [methodId, setMethodId] = useState<string>();
    const [apiVersionData, setApiVersionData] = useState<any>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [buttonLoading, setButtonLoading] = useState<boolean>(false);
    const [params, setParams] = useState<VersionMethodParameter[]>([]);
    const [paramsData, setParamsData] = useState<Map<string, string>>(new Map());

    const [form] = Form.useForm();
    const tableRef = useRef<IEditTableRef>();
    const [{ cascaderVaule, cascaderOptions, cascaderLoadData, cascaderOnChange }] = useCascader();

    useEffect(() => {
        if (props.isEdit) {
            setMethodSelectVisible(false);
            setMethodId(undefined);
        }
        if (props.visible) {
            initData(props.defaultData, true);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.defaultData, props.visible])

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };
    const initData = (data: FrontendAPIVersionMethodDetail, changeNoByFill: boolean = false): void => {
        if (data) {
            let header = conversionHeaderString(data.Header!)
            if (header[0]?.value) {
                if (ContentTypeDefault.includes(header[0]?.value)) {
                    setSelectContentTypeData([...ContentTypeDefault])
                } else {
                    setSelectContentTypeData([...ContentTypeDefault, header[0]?.value])
                }
            } else {
                setSelectContentTypeData([...ContentTypeDefault])
            }
            form.setFieldsValue({
                Type: (data.MethodName) ? Number(data.MethodName) : undefined,
                Path: data.Path,
                Header: header,
                MethodType: data.MethodType
            })
            setParams(data.param || []);
            setParamsData(props.parmData);
            if (changeNoByFill) {
                setApiVersionData([data.Backend?.Name ? data.Backend?.Name : "", data.version?.Endpoint ? data.version?.Endpoint : ""]);
                if (data.method?.Id) {
                    setMethodSelectVisible(true);
                    setMethodId(data.method?.Path);
                }
            }

        }
    }

    const conversionHeaderString = (headerString: string): Header[] => {
        let defaultArray = [{ key: "Content-Type", value: "" }];
        let header: Header[] = headerString ? JSON.parse(headerString) : defaultArray;
        let result: Header[] = [];
        if (!Array.isArray(header)) {
            header = defaultArray
        }
        header.forEach(item => {
            if (item.hasOwnProperty('key') && item.hasOwnProperty('value')) {
                if (!(typeof (item["key"]) == 'string')) {
                    item["key"] = JSON.stringify(item["key"]);
                }
                if (!(typeof (item["value"]) == 'string')) {
                    item["value"] = JSON.stringify(item["value"]);
                }
                result.push(item)
            }
        });
        return result
    }


    const addSelectItem = (): void => {
        if (newSelectItemName) {
            setSelectContentTypeData([...selectContentTypeData, newSelectItemName])
            setNewSelectItemName("");
        }

    }
    const inputChange = (event: any): void => {
        setNewSelectItemName(event.target.value)
    }
    const methodCascaderChange = (value: any, selectedOptions: any): void => {
        cascaderOnChange(value, selectedOptions, (changeValue) => {
            if (changeValue && changeValue.length > 0) {
                setMethodSelectVisible(true);
                setLoading(true);
                resetForm();
                GetMethodByBackendIDFrontendIDVersionID(props.apiId, changeValue[0] as string, changeValue[1] as string)
                    .then(res => {
                        const methodReqeustData = res.Method || [];
                        let methodDataList = methodReqeustData.map((item: IMethodItem) => {
                            return {
                                value: item.key,
                                label: item.value
                            }
                        })
                        setMethodData(methodDataList);

                        setLoading(false);
                    })
                    .catch(err => {
                        setLoading(false);
                    })
            } else {
                resetMethodState();
            }


        })
    }
    const resetForm = (): void => {
        let header = conversionHeaderString("");
        form.resetFields();
        form.setFieldsValue({
            Header: header,
        })
        setParams([]);
        setParamsData(props.parmData);
        setMethodId(undefined);
    }
    const resetMethodState = (): void => {
        setMethodSelectVisible(false);
        setMethodData([]);
        setMethodId(undefined)
    }
    const methodSelectChange = async (value: string): Promise<void> => {
        setLoading(true);
        setMethodId(value);
        try {
            let backendParameter = await reqeustGetParameterByBackendID();
            let methodDetail = await GetMethodById(value);
            if (methodDetail) {
                initData(methodDetail);
            }
            if (backendParameter) {
                let newArray = props.parmData ? [...Array.from(props.parmData)] : [];
                let oldMapKeyArray = props.parmData ? Array.from(props.parmData.keys()) : [];
                Array.from(backendParameter).forEach(([key, value]) => {
                    if (!~oldMapKeyArray.indexOf(key)) {
                        newArray.push([key, value]);
                    }
                })
                setParamsData(new Map(newArray))

            }
        } catch (err) {

        }
        setLoading(false);
    }
    const reqeustGetParameterByBackendID = (): Promise<Map<string, string>> => {
        return new Promise((resolve, reject) => {
            if (cascaderVaule && cascaderVaule[0]) {
                GetParameterByBackendID(String(cascaderVaule[0]))
                    .then(res => {
                        let ParamTypeData: IDictionary[] = res.ParamType || [];
                        let ParamTypeDataMap = new Map<string, string>();
                        ParamTypeData.forEach(item => {
                            ParamTypeDataMap.set(item.key as string, item.value as string)
                        })
                        resolve(ParamTypeDataMap);

                    })
                    .catch(err => {
                        reject(err)
                    })
            } else {
                reject("Id is Null");
            }

        })


    }
    const onFinish = (values: IMethodFrom) => {
        if (tableRef.current?.getTableResult().isEditing) {
            console.log("discard confirm");
        }
        showLoading()
        let tableResult = tableRef.current?.getTableResult();
        let requestObject: any = {};
        let methodObject = new FrontendAPIVersionMethodDetail();
        methodObject.Header = JSON.stringify(values.Header);
        methodObject.MethodName = values.Type;
        methodObject.MethodType = values.MethodType;
        methodObject.VersionId = props.versionId;
        methodObject.Path = values.Path;

        let parmObject = new ParameterObject();
        parmObject.addData = tableResult?.addData.map(item => { return { DefaultValue: item.DefaultValue, ParamterTypeID: item.ParamterTypeID, Key: item.Key, Id: "" } }) || [];
        if (props.isEdit) {
            methodObject.Id = props.defaultData.Id;
            parmObject.updateData = tableResult?.updateData.map(item => { return { DefaultValue: item.DefaultValue, ParamterTypeID: item.ParamterTypeID, Key: item.Key, Id: item.Id } }) || [];
            parmObject.deleteData = tableResult?.deleteData.map(item => { return { Id: item.Id } }) || [];
        }
        requestObject.method = methodObject;
        requestObject.param = parmObject;
        if (methodId) {
            requestObject.backendMethodId = methodId
        }
        CreateMethod(requestObject)
            .then(res => {
                endLoading()
                closeDrawer();
                props.getTableData();
            })
            .catch(err => {
                endLoading()
            })
    }
    const closeDrawer = (): void => {
        form.resetFields();
        setApiVersionData([])
        resetMethodState()
        props.cancelClick()
    }
    const showLoading = (): void => {
        setLoading(true);
        setButtonLoading(true);
    }
    const endLoading = (): void => {
        setLoading(false);
        setButtonLoading(false)
    }
    return <Drawer
        visible={props.visible}
        width={720}
        destroyOnClose
        forceRender
        onClose={props.cancelClick}
        title={props.isEdit ? "Edit Method" : "Create a new Method"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" style={{ marginRight: 8 }} loading={buttonLoading} onClick={() => form.submit()}>Save</Button>
                <Button onClick={props.cancelClick} >Cancel</Button>
            </div>
        }
    >
        <Spin spinning={loading}>
            <Form {...layout} form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '20px' }}>

                <Form.Item label={`API&Version`} >
                    <Cascader
                        style={{ width: "100%" }}
                        disabled={props.isEdit ? true : false}
                        value={props.isEdit ? apiVersionData : cascaderVaule}
                        options={cascaderOptions}
                        loadData={cascaderLoadData}

                        onChange={methodCascaderChange} />
                </Form.Item>
                {
                    methodSelectVisible && <Form.Item label={`Method`} >
                        <Select
                            style={{ minWidth: 120 }}
                            disabled={props.isEdit ? true : false}
                            value={methodId}
                            onChange={methodSelectChange}

                        >
                            {
                                methodData && methodData.map(item => <Option value={item.value} key={item.value}>{item.label}</Option>)
                            }
                        </Select>
                    </Form.Item>
                }
                <Form.Item label="Type" name="Type" rules={[{ required: true, message: 'Please input type!' }]}>
                    <Select style={{ minWidth: 120 }}>
                        {
                            Array.from(MethodTypeMap).map(([key, value]) => <Option value={key} key={key}>{value}</Option>)
                        }
                    </Select>
                </Form.Item>

                <Form.Item label="Path" name="Path" rules={[{ required: true, message: 'Please input Path!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Header" required={true}>
                    <Form.List name="Header">
                        {(fields, { add, remove }) => (
                            <>
                                {fields.map(({ key, name, fieldKey, ...restField }, index) => {
                                    if (index === 0) {
                                        return <Space key={key} style={{ display: 'flex' }} align="baseline">
                                            <Form.Item
                                                {...restField}
                                                name={[name, 'key']}
                                                //fieldKey={[fieldKey, 'key']}
                                                rules={[{ required: true, message: 'Missing Key' }]}
                                            >
                                                <Input placeholder="Key" style={{ width: 172 }} disabled />
                                            </Form.Item>
                                            <Form.Item
                                                {...restField}
                                                name={[name, 'value']}
                                                //fieldKey={[fieldKey, 'value']}
                                                rules={[{ required: true, message: 'Missing Value' }]}
                                            >
                                                <Select style={{ width: 172 }}
                                                    dropdownRender={menu => (
                                                        <div>
                                                            {menu}
                                                            <Divider style={{ margin: '4px 0' }} />
                                                            <div style={{ display: 'flex', flexWrap: 'nowrap', padding: 8 }}>
                                                                <Input style={{ flex: 'auto' }} value={newSelectItemName} onChange={inputChange} />
                                                                <Button type="link"
                                                                    style={{ flex: 'none', padding: '8px', display: 'block', cursor: 'pointer' }}
                                                                    onClick={addSelectItem}
                                                                >Add item</Button>
                                                            </div>
                                                        </div>
                                                    )}
                                                >
                                                    {
                                                        selectContentTypeData.map((value) => <Option value={value} key={value}>
                                                            <Tooltip placement="top" title={value}>
                                                                <span>{value}</span>
                                                            </Tooltip>
                                                        </Option>)
                                                    }
                                                </Select>
                                            </Form.Item>
                                        </Space>
                                    } else {
                                        return <Space key={key} style={{ display: 'flex' }} align="baseline">
                                            <Form.Item
                                                {...restField}
                                                name={[name, 'key']}
                                                //fieldKey={[fieldKey, 'key']}
                                                rules={[{ required: true, message: 'Missing Key' }]}
                                            >
                                                <Input style={{ width: 172 }} placeholder="Key" />
                                            </Form.Item>
                                            <Form.Item
                                                {...restField}
                                                name={[name, 'value']}
                                                //fieldKey={[fieldKey, 'value']}
                                                rules={[{ required: true, message: 'Missing Value' }]}
                                            >
                                                <Input style={{ width: 172 }} placeholder="Value" />
                                            </Form.Item>
                                            <MinusCircleOutlined onClick={() => remove(name)} />
                                        </Space>
                                    }

                                })}
                                <Form.Item>
                                    <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>Add Header</Button>
                                </Form.Item>
                            </>
                        )}
                    </Form.List>

                </Form.Item>

            </Form>
            <EditTable
                dataSource={params || []}
                ref={tableRef}
                parmData={paramsData}
                isEdit={props.isEdit}
            />
        </Spin>
    </Drawer>
}
export default ManageMethodDrawer
import React, {
  useImperativeHandle,
  forwardRef,
  useState,
  useEffect,
} from "react";
import { Form, Upload, Tree } from "antd";
import { InboxOutlined } from "@ant-design/icons";
import { UploadFile } from "antd/lib/upload/interface";
import { DownOutlined } from "@ant-design/icons";
import { DataNode } from "antd/lib/tree";
import { GetApiService } from "../ReplicatorApiService";
import * as ReplicatorContract from "../ReplicatorContract";
import UINotrification from "../../common/UINotrification";

var path  = require('path');
const { Dragger } = Upload;
interface IUploadCorpusProps {
  saveSuccess:Function;
  corpus?:ReplicatorContract.CorpusDto,
  treeData?:any[]
}

const UploadCorpus = (props: IUploadCorpusProps, ref: any) => {
  const [form] = Form.useForm();
  const [fileList, setFileList] = useState<any[]>([]);
  const [treeData, setTreeData] = useState<DataNode[]>([]);
  const [dataSource, setDataSource] = useState<any[]>([]);
  useImperativeHandle(ref, () => ({
    save: () => {
      form.submit();
    },
  }));

  function generateMixed(n:number) {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const prime = 31;
    let res = '';
    let x = 1;
    for (let i = 0; i < n; i++) {
      x = (x * prime) % 36;
      const id = (i + x) % 36;
      res += chars[id];
    }
    return res;
  }

  useEffect(() => {
    if(props.treeData && props.corpus){
      let tree = [
        {
          key: generateMixed(22),
          title:props.corpus.DisplayName,
          children:props.treeData,
          filePath:props.corpus.DisplayName
        }

      ];
      setTreeData(tree);
      setDataSource(tree)
    }
     
 }, [props.treeData,props.corpus]);

  const onFinish = async (values: any) => {
    if(dataSource.length>0){
      let data = readTreeNode(dataSource);
      if(data.length === 0){
        UINotrification.error("Please upload the file");
      }
      let result = new ReplicatorContract.DataModeing();
      result.corpus = props.corpus;
      result.Document = data;
      props.saveSuccess(true,result);
    }else{
      UINotrification.error("Please upload the file");
    }
  };


  const readTreeNode =  (nodes:any[] = [], treeData :any[]= []) =>{
    for (let item of nodes) {
        if(item.title.toLowerCase().endsWith(".json")){
          let result = new ReplicatorContract.DatamodelingDocument();
          result.FileName = item.title;
          result.FolderPath = item.filePath;
          result.Type = item.title.toLowerCase().endsWith("manifest.cdm.json") ? ReplicatorContract.FileType.Manfest : ReplicatorContract.FileType.Corpus;
          result.DisplayName = props!.corpus!.DisplayName;
          treeData.push(result);
        }
        if (item.children && item.children.length > 0 ){
          readTreeNode(item.children, treeData);
        } 
    }
    return treeData;
}
;

  const onFinishFailed = (errorInfo: any) => {};


  const beforeUpload = (file: any, FileList: UploadFile[]) => {
    const isZip = file.type === 'application/x-zip-compressed';
    if (!isZip) {
        UINotrification.error('You can only upload zip file!');
        return false;
    }
    const isLt10M = file.size / 1024 / 1024 > 10;
    if (isLt10M) {
      UINotrification.error('file must smaller than 10MB!');
      return false;
    }
    GetApiService().CorpusUploadZipFile(props.corpus!,file).then(res=>{
      setTreeData(res);
      setDataSource(res);
    });
    return true;
  };

  const onRemove = (file: any) => {
    setFileList([]);
  };
 
  return (
    <Form
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      form={form}
      layout="vertical"
    >
      <Form.Item  rules={[{ required: true, message: "Please select an action." }]}>
        <Dragger
          beforeUpload={beforeUpload}
          multiple={false}
          onRemove={onRemove}
          fileList={fileList}
          accept="application/zip"
          maxCount={1}
        >
          <p className="ant-upload-drag-icon">
            <InboxOutlined />
          </p>
          <p className="ant-upload-text">
            Click or drag file to this area to upload
          </p>
          <p className="ant-upload-hint">(max size 10 MiB)</p>
        </Dragger>
      </Form.Item>
      {treeData.length > 0 && (
        <Form.Item>
          <Tree showLine switcherIcon={<DownOutlined />} treeData={treeData} />
        </Form.Item>
      )}
    </Form>
  );
};
export default forwardRef(UploadCorpus);

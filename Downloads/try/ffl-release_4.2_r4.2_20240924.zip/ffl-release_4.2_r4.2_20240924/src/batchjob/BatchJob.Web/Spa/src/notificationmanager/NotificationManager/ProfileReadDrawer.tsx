import React, { useEffect, useState } from 'react';
import { Button, Checkbox, Drawer, Radio, Table, Row, Col, Descriptions } from 'antd';
import { ReportTypeMap } from './NotificationManagerContracts';
import { ProtocolType, ProtocolTypeMap} from "../NotificationSetting/NotificationSettingContracts";
interface IProfileReadDrawerProps {
    visible: boolean;
    closeDrawer: () => void;
    refresh: (searchText: string) => void;
    data: any;
}

const ProfileReadDrawer = (props: IProfileReadDrawerProps) => {
   
    const emailColumns = [
        {
            title: 'Report Type',
            dataIndex: 'ReportType',
            key: 'ReportType',
            width: '40%',
            render: (key: number) => {
                return ReportTypeMap.get(key);
            },
        }, {
            title: 'E-mail Address',
            dataIndex: 'Address',
            key: 'Address',
            width: '50%',
        }]

    const smsColumns = [
        {
            title: 'Contact Number',
            dataIndex: 'PhoneNumber',
            key: 'PhoneNumber',
            width: '100%'
        }]
    const [emailSource, setEmailSource] = useState<any>([]);
    const [smsSource, setSmsSource] = useState<any>([]);
    const [address, setAddress] = useState<any>(1);

    useEffect(() => {
        const InitSmsProfile = () => {
            let SmsProfile = props.data.SmsProfile
            let array = SmsProfile.Mobiles.map((item: any, index: number) => {
                return {
                    PhoneNumber: item,
                    id: index
                }
            })
            setSmsSource([...array])
        }

        const InitEmailProfile = async () => {
            let EmailProfile = props.data.EmailProfile
            let array2 = EmailProfile.Recipients.map((item: any, index: number) => {
                return {
                    ReportType: item.ReportType,
                    Address: item.Email,
                    id: index
                }
            })
            setEmailSource(array2)
        }
        if (props.data) {
            let data = props.data;
            let address = data?.EmailProfile?.Recipients?.length > 0 ? 1 : 2;
            setAddress(address);
            if (address === 1) {
                InitEmailProfile();
            } else {
                InitSmsProfile();
            }
        }
    }, [props.visible, props.data])

    return (
        <Drawer
            forceRender
            title="View profile"
            width={720}
            onClose={() => { props.closeDrawer() }}
            visible={props.visible}
            bodyStyle={{ paddingBottom: 80 }}
            footer={
                <div style={{ textAlign: 'right' }}>
                    <Button type="primary" onClick={() => { props.closeDrawer() }} >Cancel</Button>
                </div>
            }>

            <Descriptions column={1} bordered>
                <Descriptions.Item label="Display Name">{props.data.Name}</Descriptions.Item>
                <Descriptions.Item label="Description">{props.data.Description}</Descriptions.Item>
                <Descriptions.Item label="ProtocolType">{ProtocolTypeMap.get(props.data.EmailProfile.ProtocoIType)}</Descriptions.Item>
                {/* <Descriptions.Item label="Notification Address">{address === 1 ? "E-mail Item" : "SMS item"}</Descriptions.Item> */}
            </Descriptions>
            {/* {address === 1 &&
                <>
                    <Descriptions title="E-mail" style={{ marginTop: "24px" }} />
                    <Table
                        columns={emailColumns}
                        dataSource={emailSource}
                        pagination={false}
                        rowKey='id' />
                    <Descriptions title="Summary Report Level(s)" style={{ marginTop: "24px" }} />
                    <Checkbox.Group style={{ width: "100%" }} defaultValue={props.data.SummaryLevel} disabled={true}>
                        <Row>
                            <Col span={8}><Checkbox value={1} >Succsss</Checkbox> </Col>
                            <Col span={8}><Checkbox value={2} >Failure</Checkbox> </Col>
                            <Col span={8}><Checkbox value={4} >Warning</Checkbox> </Col>
                        </Row>
                    </Checkbox.Group>

                    <Descriptions title="Detail Report Level(s)" style={{ marginTop: "24px" }} />
                    <Checkbox.Group style={{ width: "100%" }} disabled={true} defaultValue={props.data.DetailLevel}>
                        <Row>
                            <Col span={8}><Checkbox value={1} >Succsss</Checkbox> </Col>
                            <Col span={8}><Checkbox value={2} >Failure</Checkbox> </Col>
                            <Col span={8}><Checkbox value={4} >Warning</Checkbox> </Col>
                        </Row>
                    </Checkbox.Group>


                    <Descriptions title="LogLevel" style={{ marginTop: "24px" }} />
                    <Checkbox.Group style={{ width: "100%" }} disabled={true} defaultValue={props.data.LogLevel}>
                        <Row>
                            <Col span={8}><Checkbox value={1} >Succsss</Checkbox> </Col>
                            <Col span={8}><Checkbox value={2} >Failure</Checkbox> </Col>
                            <Col span={8}><Checkbox value={4} >Warning</Checkbox> </Col>
                        </Row>
                    </Checkbox.Group>

                    <Descriptions title="Message Format" style={{ marginTop: "24px" }} />
                    <Radio.Group disabled={true} defaultValue={props.data.Format}>
                        <Radio value={0}>HTML</Radio>
                        <Radio value={1}>Plain text</Radio>
                    </Radio.Group>
                </>
            } */}

            {
                // address === 2 &&
                <>
                    <Descriptions title="Contact" style={{ marginTop: "24px" }} />
                    <Table
                        columns={smsColumns}
                        dataSource={smsSource}
                        pagination={false}
                        rowKey='id'
                    ></Table>
                    {/* <Descriptions title="Summary Report Level(s)" style={{ marginTop: "24px" }} />
                    <Checkbox.Group style={{ width: "100%" }} disabled={true} defaultValue={props.data.SMSSummaryLevel}>
                        <Row>
                            <Col span={8}><Checkbox value={1} >Succsss</Checkbox> </Col>
                            <Col span={8}><Checkbox value={2} >Failure</Checkbox> </Col>
                            <Col span={8}><Checkbox value={4} >Warning</Checkbox> </Col>
                        </Row>
                    </Checkbox.Group> */}
                </>
            }
        </Drawer >
    )
}
export default ProfileReadDrawer;
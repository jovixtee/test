import React, { FC } from "react";
import { Menu, Input, Row, Col, Dropdown, Modal, Button, Tooltip } from 'antd';
import { EllipsisOutlined, ExclamationCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { APIsMenuDto } from '../../common/contracts/ModelContracts';
const { Search } = Input;


interface IAPIsListProps {

    title: string,
    menuItemClick: any,
    onTitleClick: any,
    data: APIsMenuDto[],
    onSearchAPI: (searchText: string) => void;
    onCloneVersion: (id: string) => void;
    onDeleteVersion: (id: string) => void;
    onOpenBlank: () => void;
    onOpenAPI: () => void;
    openKeys: string,
    selectedKeys: string
}

const APIsList: FC<IAPIsListProps> = (props) => {

    const handleAddAPIClick = (event: any): void => {
        switch (event.key) {
            case "black":
                props.onOpenBlank();
                break;
            case "open":
                props.onOpenAPI();
                break;
        }
    }


    const menu = (
        <Menu onClick={handleAddAPIClick}>
            <Menu.Item key="black">Create a blank API</Menu.Item>
            <Menu.Item key="open">Create a openAPI</Menu.Item>
        </Menu>
    );


    const handleMenuClick = (event: any): void => {
        let eventKey = event.key.split(":");
        let key = eventKey[0];
        let id = eventKey[1];
        let title = eventKey[2];
        switch (key) {
            case "Clone":
                Modal.confirm({
                    title: 'Confirmation',
                    icon: <ExclamationCircleOutlined />,
                    content: 'Are you sure you want to clone API "' + title + '"?',
                    okText: 'Confirm',
                    cancelText: 'Cancel',
                    onOk: () => props.onCloneVersion(id)
                });
                break;
            case "Delete":
                Modal.confirm({
                    title: 'Confirmation',
                    icon: <ExclamationCircleOutlined />,
                    content: 'Are you sure you want to delete API "' + title + '"?',
                    okText: 'Yes',
                    cancelText: 'No',
                    onOk: () => props.onDeleteVersion(id)
                });

                break;
        }
    }

    const renderMenuItem = (data: APIsMenuDto[]) => {
        return (
            data.map((item) => <Menu.SubMenu onTitleClick={props.onTitleClick} key={item.Id} title={
                <>
                    <Tooltip placement="topLeft" title={item.Name}>{item.Name}</Tooltip>
                </>
            }>
                {item.Versions?.map(i => {
                    let menu = (
                        <Menu onClick={handleMenuClick}>
                            <Menu.Item key={"Clone:" + i.Id + ":" + i.DisplayName}>Clone</Menu.Item>
                            <Menu.Item key={"Delete:" + i.Id + ":" + i.DisplayName}>Delete</Menu.Item>
                        </Menu>
                    );
                    let menuItem = <Menu.Item key={i.Id}>
                        <Tooltip placement="topLeft" title={i.DisplayName}>  {i.DisplayName}</Tooltip>
                        <div onClick={(e) => e.stopPropagation()}>
                            <Dropdown placement="bottomRight" overlay={menu} trigger={["click"]}>
                                <EllipsisOutlined className="right" />
                            </Dropdown>
                        </div>
                    </Menu.Item>

                    return menuItem;
                })
                }
            </Menu.SubMenu>)
        );
    }

    const onOpenChangeSubItem = (keys: any[]) => {
        //let open = keys.filter(item => item !== openKeys[0]);
        //setOpenKeys(open);
    }

    // const menuItemClick = (item: any) => {
    //     //setSelectedKeys([item.key]);
    //     //props.menuItemClick(item);
    // }


    return (
        <>
            <div style={{ background: 'white' }}>
                <Row style={{ height: "50px", alignContent: "center" }}>
                    <Col span={18}>
                        <div className="ant-drawer-title" style={{ float: "left", paddingLeft: "10px" }}>{props.title}</div>
                    </Col>
                    <Col span={6} >

                        <Dropdown placement="bottomRight" overlay={menu} trigger={['click']}>
                            <Button type="text" style={{ float: 'right'}}  icon={<PlusOutlined />}/>
                        </Dropdown>

                    </Col>
                </Row>
                <Search placeholder="Input search text" allowClear style={{ paddingLeft: "5px", paddingRight: "5px" }} onSearch={(value) => props.onSearchAPI(value)} />

                <Menu
                    mode="inline"
                    onClick={props.menuItemClick}
                    selectedKeys={[props.selectedKeys]}
                    onOpenChange={onOpenChangeSubItem}
                    openKeys={[props.openKeys]}>
                    {props.data.length > 0 && renderMenuItem(props.data)}
                </Menu>
            </div>
        </>
    )
}

export default APIsList
import React, { useEffect, useState, useRef } from 'react';
import { Button, Input, Radio, Select, Form, Drawer } from 'antd';
import { convertMomentToTicks } from '../../utils/dateconvert';
import { TaskGroupDto,ScheduleActionDto, ScheduleDto, TaskGroupStep, ScheduleSequence, ScheduleRuleDto, WeekDay, ScheduleMonth, ScheduleDay, TaskManagerServiceResult, ServiceResultType } from './TaskManagerContract';
import TaskApiService from './TaskManagerApiService';
import moment from 'moment';
import { Transfer } from 'antd';
import { TransferItem } from 'antd/lib/transfer';
import TaskRepository from './TaskRepository';
import TaskScheduleRule from './TaskScheduleRule';
 
const monthInYear = new Array<any>();
const dayInMonth = new Array<any>();
const sequenceInMonth = new Array<any>();
const weekDays = new Array<any>();
if (dayInMonth.length === 0) {
    for (let d in ScheduleDay) {
        if (parseInt(d)) {
            dayInMonth.push({ value: parseInt(d), label: d });
        }
    }
}
if (monthInYear.length === 0) {
    for (let d in ScheduleMonth) {
        if (parseInt(d)) {
            monthInYear.push({ value: parseInt(d), label: ScheduleMonth[d] });
        }
    }
}
if (sequenceInMonth.length === 0) {
    for (let d in ScheduleSequence) {
        if (parseInt(d)) {
            sequenceInMonth.push({ value: parseInt(d), label: ScheduleSequence[d] });
        }
    }
}
if (weekDays.length === 0) {
    for (let d in WeekDay) {
        if (parseInt(d)) {
            weekDays.push({ value: parseInt(d), label: WeekDay[d] });
        }
    }
}

let initStartTime = convertMomentToTicks(moment().add(5, 'minutes'));

interface ITaskGroupFormDrawerProps {
    task: TaskGroupDto;
    visible: boolean;
    onClose: () => void;
    onFinished: (task: TaskGroupDto, type?: ServiceResultType) => void;
}
const TaskGroupFormDrawer = (props: ITaskGroupFormDrawerProps) => {
    const ruleRef = useRef<any>();
    const [enableHolidaySetting, setEnableHolidaySetting] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [taskType, setTaskType] = useState<number>(0);
    const [taskFrom] = Form.useForm();
    //const [jobActions, setJobActions] = useState<Array<JobAction>>(new Array<JobAction>({ HandlerId: '_JobActionHandlerId1', DisplayName: 'Action1' }, { HandlerId: '_JobActionHandlerId2', DisplayName: 'Action2' }));
    const [selectJobActions, setSelectJobActions] = useState<string[]>(new Array<string>());
    const [targetTasks, setTargetTasks] = useState<string[]>(new Array<string>());

    const [sourceTasks, setSourceTasks] = useState<Array<TaskGroupStep>>(new Array<TaskGroupStep>());
    const [selectTasks, setSelectTasks] = useState<string[]>(new Array<string>());
    const [scheduleRule, setScheduleRule] = useState<ScheduleRuleDto>(new ScheduleRuleDto());

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };
    const jobActions = TaskRepository.getInstance().ActionSettings;
    const tasks = new Array<TaskGroupStep>();
    const onChangeActions = (value: any, options: any) => {
        var tas = [];
        setSelectJobActions(value);
        setSourceTasks([]);
        for (let i = 0; i < value.length; i++) {
            tas.push(new Promise((a, b) => {
                TaskApiService.getInstance().QueryTasksByHandlerId(value[i], (result?: TaskManagerServiceResult) => {
                    
                    console.log( result?.Tasks);
                    
                    result?.Tasks?.map((data, index) => (tasks.push({ Disabled:data.State===1, Order: index, Task: data, ActionDisplayName: data.ActionDisplayName })))
                    a(1);
                })
            }));
        }
        Promise.all(tas).then(() => {
            setSourceTasks(tasks);
        });
    };
    const onChangeSteps = (nextTargetKeys: string[], direction: string, moveKeys: string[]) => {
        let target = [...targetTasks];
        console.log('direction:', direction);
        console.log('moveKeys:', moveKeys);
        console.log('targetKeys:', nextTargetKeys);
        if(direction==="right"){
            target.push.apply(target,moveKeys);
        }else{
            target = target.filter(e=>moveKeys.indexOf(e) === -1);
        }
        setTargetTasks(target);
    };

    const onSelectChange = (sourceSelectedKeys: string[], targetSelectedKeys: string[]) => {
        console.log('sourceSelectedKeys:', sourceSelectedKeys);
        console.log('targetSelectedKeys:', targetSelectedKeys);
        setSelectTasks([...sourceSelectedKeys, ...targetSelectedKeys]);
        console.log('setSelectTasks:', selectTasks);
    };
    const onFinish = (values: any) => {
        const nameArray = new Array<any>();
        //console.log('Success:', values);
        var dto = new TaskGroupDto();
        dto.JobAction = new ScheduleActionDto();
        dto.Schedule = new ScheduleDto();
        dto.Steps = new Array<TaskGroupStep>();
        dto.Schedule.ScheduleRule = new ScheduleRuleDto();
        dto.Id = props.task.Id;
        dto.State = props.task.State;
        targetTasks.forEach((v, i, a) => { 
            let task = sourceTasks.find(e=>e.Task?.Id === v);
            task!.Order = i;
            dto.Steps?.push(task!);
        });
        dto.Name = values.Name;
        dto.Description = values.Description;
        dto.JobAction.HandlerId = values.ActionId.toString();
        jobActions?.forEach(j => {
            values.ActionId?.forEach((a: string | undefined) => {
                if (j?.Id === a) {
                  nameArray.push(j.DisplayName);
                }
            })
       
        })
        dto.ActionDisplayName = nameArray.join(",");
        dto.Type = values.Type;
        if (values.Type === 0) {
            //Start Time
            dto.Schedule.StartTime = values.ScheduleStartTime;
            dto.Schedule.StartTime = values.ScheduleStartTime;
            let scheduleRule = ruleRef.current.getFormData();
            dto.Schedule.ScheduleRule = scheduleRule;
            // enable Holidays
            if (enableHolidaySetting) {
                dto.Schedule.HolidayProfileId = values.HolidayProfileId;
            }
        }
        if (isEdit) {
            TaskApiService.getInstance().UpdateGroup(dto, (result) => { props.onFinished(dto, result.Type!) });
        } else {
            TaskApiService.getInstance().CreateGroup(dto, (result) => { props.onFinished(dto, result.Type!) });
        }

    };

    const setupForm = (dto: TaskGroupDto) => {
        taskFrom.resetFields();
        setIsEdit(dto.Id !== undefined);
        setTaskType(dto.Type);
        taskFrom.setFieldsValue({ Type: dto.Type })
        var actions = new Set<string>();
        var targetIds = new Array<string>();
        dto.Steps?.sort(e=>e.Order).forEach(s => {
            targetIds.push(s.Task?.Id || '');
        })
        jobActions?.forEach(j => {
            dto.Steps?.forEach(s => {
                if (j?.Id === s.Task?.JobAction?.HandlerId) {
                    actions.add(j.Id!);
                    return false;
                }
            })
        })
        onChangeActions(Array.from(actions), null);
        setTargetTasks(targetIds);
        if (dto.Id) {
            taskFrom.setFieldsValue({
                Name: dto.Name,
                Description: dto.Description,
                Steps: dto.Steps,
                Tasks: targetIds,
                ActionId: dto.JobAction?.HandlerId?.split(","),
                HolidayProfileId: dto.Schedule?.HolidayProfileId,
                ScheduleStartTime: dto.Schedule?.StartTime ? dto.Schedule.StartTime : initStartTime
            });
            if (dto.Schedule?.HolidayProfileId) {
                setEnableHolidaySetting(true);
            }
            //设置公共数据
            if (dto?.Schedule?.ScheduleRule) {
                setScheduleRule(dto?.Schedule?.ScheduleRule as ScheduleRuleDto);
            }
        } else {
            defaultValue();
        }
    };

    const defaultValue = () => {
        let rule = new ScheduleRuleDto();
        rule.RuleType = 0;
        setScheduleRule(rule);
        setEnableHolidaySetting(false);
        taskFrom.setFieldsValue({
            ScheduleStartTime: initStartTime,
        });
    };

    useEffect(() => {
        setupForm(props.task)
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.task]);

    //解决二次打开抽屉，控件记录上次加载项目
    useEffect(() => {
        if (props.visible === false) {
            defaultValue();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.visible]);


   

    return (
        <Drawer 
            forceRender 
            visible={props.visible} 
            width={720} 
            onClose={(e) => props.onClose()}
            title={isEdit ? "Edit group" : "Create a new group"}
            footer={
                <div style={{ textAlign: 'right', }}>
                    <Button type="primary" style={{ marginRight: 8 }} onClick={() => taskFrom.submit()}>Save</Button>
                    <Button onClick={props.onClose} >Cancel</Button>
                </div>
            }>
            <Form layout="vertical"  form={taskFrom} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '1.25rem' }}>
                <Form.Item label="Group Name" name="Name" rules={[{ required: true, message: 'Please input Group Name!' }]}>
                    <Input />
                </Form.Item>

                <Form.Item label="Description" name="Description">
                    <Input.TextArea />
                </Form.Item>
                <Form.Item label="Action" name="ActionId" rules={[{ required: true, message: 'Please select a Action!' }]}>
                    <Select mode="multiple" allowClear placeholder="Select Actions" onChange={onChangeActions} value={selectJobActions}>
                        {jobActions?.map(action => (
                            <Select.Option value={action.Id as string || ''} key={action.Id}>{action.DisplayName}</Select.Option>
                        ))}
                    </Select>
                </Form.Item>
                <Form.Item label="Tasks" name="Tasks" rules={[{ required: true, message: 'Please select your Tasks!' }]}>
                    <Transfer
                        dataSource={sourceTasks.map(t => ({ key: t.Task?.Id, title: t.Task?.Name,disabled:t.Disabled })) as TransferItem[]}
                        titles={['Source', 'Target']}
                        targetKeys={targetTasks as string[]}
                        //selectedKeys={selectTasks}
                        //onSelectChange={onSelectChange}
                        onChange={onChangeSteps}
                        render={item => item.title!}
                    />
                </Form.Item>
                <Form.Item label="Run the Task" name="Type">
                    <Radio.Group onChange={(e) => setTaskType(e.target.value)}>
                        <Radio value={0}>On Schedule</Radio>
                        <Radio value={1}>Manually</Radio>
                    </Radio.Group>
                </Form.Item>

                {taskType === 0 &&
                    <>
                        <TaskScheduleRule
                            scheduleRule={scheduleRule}
                            taskForm={taskFrom}
                            ruleRef={ruleRef}
                            enableHolidaySetting={enableHolidaySetting}
                            setEnableHolidaySetting={setEnableHolidaySetting}
                        />
                    </>
                }
            </Form>
        </Drawer>
    );
};


export default TaskGroupFormDrawer;
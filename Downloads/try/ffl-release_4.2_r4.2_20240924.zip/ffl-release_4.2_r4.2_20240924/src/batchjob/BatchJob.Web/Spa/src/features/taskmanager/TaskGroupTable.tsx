import { CaretRightOutlined, CheckCircleOutlined, CloseCircleOutlined, EditOutlined,DeleteOutlined, DownloadOutlined, FundViewOutlined, ImportOutlined, PlusOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import { Modal, message } from 'antd';
import React, { useState } from 'react';
import TaskGroupFormDrawer from './TaskGroupFormDrawer';
import { TaskGroupDto, TaskPermissionConstants } from './TaskManagerContract';
import TaskManagerApiService from './TaskManagerApiService';
import ImportDocument from '../../components/ImportDocument'
import { hasPermission } from '../../utils/permissionutil';
import AmpCommonTable, { DatetimeColumnTemplate, IAmpTableButton } from '../../components/antdx/AmpCommonTable';
import ProfileReadDrawer from '../../components/antdx/ProfileReadDrawer';
import { PagerExpression } from '../../common/contracts/PagerContracts';
import { NextRunTimeTemplate,GetTaskGroupProfileReader } from './TaskManagerUtil';
import PathConfig from '../../common/PathConfig';
import { useHistory } from 'react-router-dom';


const { confirm } = Modal;
const TaskGroupTable = () => {
    const [drawerTaskGroup, setDrawerTaskGroup] = useState<TaskGroupDto>(new TaskGroupDto());
    const [profileReadData, setProfileReadData] = useState<any[]>([]);
    
    const [drawerVisable, setDrawerVisable] = useState<boolean>(false);
    const [profileVisable, setProfileVisable] = useState<boolean>(false);
    const [importVisable, setImportVisable] = useState<boolean>(false);
    const [selectTaskGroupIds, setSelectTaskGroupIds] = useState<string[]>([]);
    const [refresh, setRefresh] = useState(1);
    const [canRun, setCanRun] = useState<boolean>(true);
    const history = useHistory();
    const onCreateClick = () => {
        setDrawerTaskGroup(new TaskGroupDto());
        setDrawerVisable(true);
    };
    const onEditClick = (record: any) => {
        console.info("info:", record);
        TaskManagerApiService.getInstance().GetGroupById(record.Id, result => {
            setDrawerTaskGroup(result?.TaskGroup as TaskGroupDto);
            setDrawerVisable(true);
        });
    };

    const onProfileClick = (record: any) => {
        TaskManagerApiService.getInstance().GetGroupById(record.Id, result => {
            let dataSource = result?.TaskGroup as TaskGroupDto;
            GetTaskGroupProfileReader(dataSource).then(profileData=>{
                setProfileReadData(profileData);
                setProfileVisable(true);
            })
        });
    };

    const drawerEvents = {
        onClose: () => {
            setDrawerVisable(false);
            setProfileVisable(false);
        },
        onFinished: (task: TaskGroupDto, type?: number) => {         
            if (type === 1) {
                message.error("Duplicate name, task group '" + task.Name + "' failed " + (task.Id ? "updated" : "created") + ".");
            } else {
                message.info("Task Group '" + task.Name + "' successfully " + (task.Id ? "updated" : "created") + ".");
                setDrawerVisable(false);
                setRefresh(refresh + 1);
            }
        },
    }
    const buttonEvents = {
        deleteTasks: function () {
            confirm({
                title: 'Warning',
                icon: <ExclamationCircleOutlined />,
                content: 'You are about to delete the selected items. Are you sure you want to proceed?',
                onOk() {
                    TaskManagerApiService.getInstance().DeleteGroupByIds(selectTaskGroupIds, (result) => {
                        message.info("Task Group(s) successfully deleted.");
                        setRefresh(refresh + 1);        
                    });
                },
                onCancel() {
                    console.log('Cancel');
                },
            })
        },
        editTask: function () {
            TaskManagerApiService.getInstance().GetGroupById(selectTaskGroupIds[0], result => {
                setDrawerTaskGroup(result?.TaskGroup as TaskGroupDto);
                setDrawerVisable(true);
            });
        },
        viewHistory: function () {
            history.push(PathConfig.addPrefix("/jobmonitor") + "?taskGroupId=" + selectTaskGroupIds[0])
        },
        runTask: function () {
            TaskManagerApiService.getInstance().RunTaskGroup(selectTaskGroupIds[0], (result) => {
                message.info("Operation successfully.");
            });
        },
        enableTask: function () {
            TaskManagerApiService.getInstance().EnableTaskGroup(selectTaskGroupIds.join(), (result) => {
                message.info("Operation successfully.");
                setRefresh(refresh + 1);

            });
        },
        disableTask: function () {
            TaskManagerApiService.getInstance().DisableTaskGroup(selectTaskGroupIds.join(), (result) => {
                message.info("Operation successfully.");
                setRefresh(refresh + 1);

            });
        },
        import: function () {
            setImportVisable(true)
        },
        export: function () {
            TaskManagerApiService.getInstance().ExportTaskGroup(selectTaskGroupIds);
        },
        importSubmit: (fileList: any[]) => {
            TaskManagerApiService.getInstance().ImportTaskGroup(fileList[0], (result) => {
                if (result.Type === 1) {
                    message.error("This file type is not supported. You must select a zip (.zip) file.");
                } else {
                    message.info("Operation successfully.");
                }
                setRefresh(refresh + 1);

            });
            setImportVisable(false);
        }
    };
    const tableCols = [
        {
            title: 'Group Name',
            dataIndex: 'Name',
            key: 'Name',
            sorter: true,
            ellipsis: true,
            render: (text: any, record: any) => <a onClick={() => onProfileClick(record)}>{text}</a>
        }, {
            title: 'Description',
            dataIndex: 'Description',
            key: 'Description',
            ellipsis: true
        }, {
            title: 'Next Run Time',
            dataIndex: 'NextTime',
            key: 'NextTime',
            sorter: true,
            render: NextRunTimeTemplate
        }, {
            title: 'Status',
            dataIndex: 'State',
            key: 'State',
            filtered: true,
            filters: [{ text: 'Enabled', value: 0 }, { text: 'Disabled', value: 1 }],
            render: (text: any, record: any) => <label>{text === 0 ? "Enabled" : "Disabled"}</label>
        }, {
            title: 'Action',
            dataIndex: 'ActionDisplayName',
            key: 'ActionDisplayName',
        }, {
            title: 'Created By',
            dataIndex: 'CreatedBy',
            key: 'CreatedBy',
            ellipsis: true
        }, {
            title: 'Created Time',
            dataIndex: 'CreatedOn',
            key: 'CreatedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }, {
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
            ellipsis: true
        }, {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            render: DatetimeColumnTemplate
        }];

    const buttons: Array<IAmpTableButton> = [{
        Text: "Create",
        Primary: true,
        Icon: <PlusOutlined />,
        OnClick: onCreateClick,
        EnableMode: 'always',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Create)
    }, {
        Text: "Edit",
        Icon: <EditOutlined />,
        OnClick: buttonEvents.editTask,
        EnableMode: 'single',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Create)
    }, {
        Text: "Delete",
        Icon: <DeleteOutlined />,
        OnClick: buttonEvents.deleteTasks,
        EnableMode: 'multiple',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Delete)
    }, {
        Text: "View History",
        Icon: <FundViewOutlined />,
        OnClick: buttonEvents.viewHistory,
        EnableMode: 'single',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Read)
    }, {
        Text: "Run",
        Icon: <CaretRightOutlined />,
        OnClick: buttonEvents.runTask,
        EnableMode: 'single',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Create) && canRun
    }, {
        Text: "Enable",
        Icon: <CheckCircleOutlined />,
        OnClick: buttonEvents.enableTask,
        EnableMode: 'multiple',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Update)
    }, {
        Text: "Disable",
        Icon: <CloseCircleOutlined />,
        OnClick: buttonEvents.disableTask,
        EnableMode: 'multiple',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Update)
    }, {
        Text: "Import",
        Icon: <ImportOutlined />,
        OnClick: buttonEvents.import,
        EnableMode: 'always',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Create)
    }, {
        Text: "Export",
        Icon: <DownloadOutlined />,
        OnClick: buttonEvents.export,
        EnableMode: 'single',
        HasPermission: hasPermission(TaskPermissionConstants.ObjectCode, TaskPermissionConstants.Read)
    }];

    const ApiPagerQueryJob = async (exp: PagerExpression) => {
        const result = await TaskManagerApiService.getInstance().PagerQueryGroup(exp);
        return { total: result.PageredTaskGroups!.TotalNumber, records: result.PageredTaskGroups!.Result };
    }
    
    const SelectTaskGroup = (records: TaskGroupDto[]) => {
        setSelectTaskGroupIds(records.map(r => r.Id!))
        records.forEach((item: TaskGroupDto) => {
            if (item.State === 1) {
                setCanRun(false);
                return;
            } else {
                setCanRun(true);
            }
        })
    }

    return (<div>
        <TaskGroupFormDrawer task={drawerTaskGroup} onFinished={drawerEvents.onFinished} onClose={drawerEvents.onClose} visible={drawerVisable}></TaskGroupFormDrawer>
        <AmpCommonTable Type="checkbox" RowKey="Id" Columns={tableCols} PagerQuery={ApiPagerQueryJob} OnSelectedChanged={SelectTaskGroup}
            SearchKeys={["Name"]} Refresh={refresh} Buttons={buttons} EnableSearch />
        <ImportDocument
            show={importVisable} cancel={() => setImportVisable(false)}
            submit={buttonEvents.importSubmit}
            accept='.zip'
            message='Supported file type: .zip'
        />
        
        <ProfileReadDrawer
            visible={profileVisable}
            dataSource={profileReadData}
            onClose={drawerEvents.onClose}
        />


    </div>);
}

export default TaskGroupTable;
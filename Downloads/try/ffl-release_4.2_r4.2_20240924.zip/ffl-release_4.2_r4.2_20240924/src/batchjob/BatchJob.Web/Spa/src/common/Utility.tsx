export const EnumToArray = (enumme: any): number[] => {
    return Object.keys(enumme).filter(value => isNaN(Number(value)) === false).map(key => enumme[key] as number);
}
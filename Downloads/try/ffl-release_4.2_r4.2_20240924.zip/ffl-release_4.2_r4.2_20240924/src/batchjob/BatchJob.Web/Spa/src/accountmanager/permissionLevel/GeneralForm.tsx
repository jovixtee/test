import React, { useEffect, useImperativeHandle, forwardRef,useState } from 'react';
import { Input, Form } from 'antd';
import { AddCheckDisplayName,EditCheckDisplayName } from './permissionLevelApiServe';
import { AnyRecord } from 'dns';
const GeneralForm = (props: any, ref: any) => {
    const [form] = Form.useForm();
    useImperativeHandle(ref, () => ({
        onNext: () => {
            form.submit();
        }
    }));
    const onFinish = async (values: any) => {
        props.nextIsSuccess(true, {...Object.assign(props.EditFormData,values)})      
        props.EditFormData.Role.Name = values.Name
        props.EditFormData.Role.PermissionLevelName = values.PermissionLevelName
        props.EditFormData.Role.Description = values.Description
        props.EditFormData.Role.PermissionLevelType = values.PermissionLevelType
    };
    const onFinishFailed = (errorInfo: any) => {
        props.nextIsSuccess(false)
    };
    useEffect(() => {
        form.resetFields()
    }, [form,props.EditFormData])
    const onChange = (e: any) => {
        form.setFieldsValue({ PermissionLevelName: e.target.value });
    };
    return (
        <Form
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            initialValues={props.EditFormData.Role}
            form={form}
            layout="vertical"
        >
                    <Form.Item
                        name="Name"
                        label="Display Name"
                        dependencies={['DisplayName']}
                            hasFeedback
                            rules={[
                                {
                                    required: true,
                                    message: 'Display Name is required!',
                                },
                                ({ getFieldValue }) => ({
                                    async validator(rule, value) {  
                                         let params = {
                                            roleDetail: {
                                                Role: {
                                                    Name: value,
                                                    RoleId: props?.EditFormData?.Role?.RoleId
                                                }
                                            }
                                        }        
                                         if (!value || getFieldValue('DisplayName') === value) {
                                            return Promise.resolve();
                                        }else{
                                            if(props?.EditFormData?.Role?.RoleId){
                                                await EditCheckDisplayName(params).then(res => {
                                                    if (res === true) {
                                                        return Promise.reject('duplicate display name');
                                                    }
                                                })
                                            }else{
                                                await AddCheckDisplayName(params).then(res => {
                                                    if (res === true) {
                                                        return Promise.reject('duplicate display name');
                                                    }
                                                }) 
                                            }
                                            return Promise.resolve();
                                        }
                                       
                                       
                                    },
                                }),
                            ]}
                    >
                        <Input onChange={onChange} />
                    </Form.Item>
                    {/* <Form.Item
                        name="PermissionLevelName"
                        label="Permission Level Name"
                        rules={[{ required: true, message: 'Permission Level Name is required!' }]}
                    >
                        <Input />
                    </Form.Item> */}
                    <Form.Item
                        name="Description"
                        label="Description"
                    >
                        <Input.TextArea />
                    </Form.Item>
        </Form>


    )
}
export default forwardRef(GeneralForm);


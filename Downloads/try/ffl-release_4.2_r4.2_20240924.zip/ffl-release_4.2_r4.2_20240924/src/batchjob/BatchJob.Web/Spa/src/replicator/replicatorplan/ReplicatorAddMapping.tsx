import React, { useEffect, useImperativeHandle, forwardRef,useState,useRef } from "react";
import { Input, Form, Select, Button, Table, Divider, Space } from "antd";
import * as ReplicatorContract from "../ReplicatorContract";
import AttributeMappingTable from "./AttributeMappingTable";
import {
  ArrowDownOutlined,
  ArrowUpOutlined,
  EditOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
import { GetApiService } from "../ReplicatorApiService";
import FieldMappingsTable from "./FieldMappingsTable";
import { IEditTableRef } from "../ReplicatorContract";


interface IReplicatorAddMappingProps {
  onNextSetting:Function;
  dataSource?:ReplicatorContract.ReplicatorPlan,
}

const ReplicatorAddMapping = (props: IReplicatorAddMappingProps, ref: any) => {
  const [form] = Form.useForm();
  const tableRef = useRef<IEditTableRef>();

  const [attributeData, setAttributeData] = useState<Array<ReplicatorContract.FieldMappings>>([]);


  const [sourceEntitys, setSourceEntitys] = useState<Array<ReplicatorContract.DatamodelingEntity>>([]);
  const [targetEntitys, setTargetEntitys] = useState<Array<ReplicatorContract.DatamodelingEntity>>([]);

  const [sourceAttributes, setSourceAttributes] = useState<Array<ReplicatorContract.EntityAttributes>>([]);
  const [targetAttributes, setTargetAttributes] = useState<Array<ReplicatorContract.EntityAttributes>>([]);

  const [mappingData, setMappingData] = useState<Array<ReplicatorContract.ReplicatorMapping>>([]);

  

  useImperativeHandle(ref, () => ({
    onAddMappingNext: () => {
      let plan = props.dataSource;
      plan!.EntityMapping = mappingData;
      props.onNextSetting(true, plan);
    },
  }));


  useEffect(() => {
    if(props.dataSource!.SourceDocumentId){
        let dto = new ReplicatorContract.DocumentIds();
        dto.SourceDocumentId =props.dataSource!.SourceDocumentId;
        dto.TargetDocumentId =props.dataSource!.TargetDocumentId;
        GetApiService().GetEntityMappingById(dto).then(e=>{
          setSourceEntitys(e.SourceEntities!);
          setTargetEntitys(e.TargetEntities!)
        });
    }
 }, [props.dataSource]);


  const onFinish = async (values: any) => {
    let data = [...mappingData];
    let mapping = new ReplicatorContract.ReplicatorMapping();
    mapping.Query = values.Query;
    mapping.Source = values.SourceEntity.split("/")[1];
    mapping.Target = values.TargetEntity.split("/")[1];
    let paramTableResult = tableRef.current?.getTableResult();
    let addData = paramTableResult?.addData.map(item => { return { TargetAttribute: item.TargetAttribute, TargetDataType: item.TargetDataType, SourceAttribute: item.SourceAttribute,SourceDataType:item.SourceDataType, Id: "" } }) || [];
    mapping.Mappings = addData;
    data.push(mapping);
    data.forEach((item,index)=>item.Order = index+1);
    setAttributeData([]);
    setMappingData(data);
  };
  const onFinishFailed = (errorInfo: any) => {
    props.onNextSetting(false, "");
  };

  const onEntitySourceChanged = (item: string) => {
    if (item) {
      GetApiService().GetEntityField(item,props.dataSource!.SourceDocumentId!,ReplicatorContract.ServiceType.Source).then(e=>setSourceAttributes(e!.EntityAttributes!))
    }
  };

  const onEntityTargetChanged = (item: string) => {
    if (item) {
      GetApiService().GetEntityField(item,props.dataSource!.TargetDocumentId!,ReplicatorContract.ServiceType.Target).then(e=>setTargetAttributes(e!.EntityAttributes!))
    }
  };
  
 

  const tableColumn: any = [
    {
      title: "Target Entity",
      dataIndex: "Target",
      ellipsis: true,
    },
    {
      title: "Source Entity",
      dataIndex: "Source",
      ellipsis: true,
    },
    {
      title: "Query",
      dataIndex: "Query",
      ellipsis: true,
    },
    {
      title: "Action(s)",
      render: (text: any, record: any, index: any) => (
        <>
          <Space size="middle">
            <DeleteOutlined
              onClick={() => {
                let data = [...mappingData];
                data.splice(index, 1); 
                setMappingData(data);
              }}
            />
            {index === 0 ? (
              <ArrowDownOutlined
                onClick={() => {
                  downGo(index);
                }}
              />
            ) : (
              <ArrowUpOutlined
                onClick={() => {
                  upGo(index);
                }}
              />
            )}
          </Space>
        </>
      ),
    },
  ];

 

  const downGo = (index: number) => {};

  const upGo = (index: number) => {};

  return (
    <Form
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      form={form}
      layout="vertical"
    >
      <Form.Item
        label="Target Entity"
        name="TargetEntity"
        rules={[{ required: true, message: "Please select a Target Entity." }]}
      >
        <Select placeholder="Select One" onChange={onEntityTargetChanged} allowClear>
                {sourceEntitys.map((item) => (
                    <Select.Option key={item.EntityPath} value={item.EntityPath as string} label={item.EntityName}>
                        {item.EntityName}
                    </Select.Option>
                ))}
        </Select>
      </Form.Item>

      <Form.Item
        label="Source Entity"
        name="SourceEntity"
        rules={[{ required: true, message: "Please select a Source Entity." }]}
      >
        <Select placeholder="Select One" onChange={onEntitySourceChanged}  allowClear>
              {targetEntitys.map((item) => (
                  <Select.Option key={item.EntityPath} value={item.EntityPath as string} label={item.EntityName}>
                      {item.EntityName}
                  </Select.Option>
              ))}
        </Select>
      </Form.Item>

      <Form.Item>
          <FieldMappingsTable  
                dataSource={attributeData}
                sourceAttributes={sourceAttributes}
                targetAttributes={targetAttributes}
                ref={tableRef} />
      </Form.Item>

      <Form.Item
        name="Query"
        label="Query"
        rules={[{ required: true, message: "Please input query" }]}
      >
        <Input />
      </Form.Item>

      
      <Form.Item>
        <Button onClick={e=>form.submit()}>Save Entity Mapping</Button>
      </Form.Item>
      <Divider />

      <Table
        rowKey={(record) => record.Order!}
        columns={tableColumn}
        dataSource={mappingData}
        expandable={{
          rowExpandable: (record) =>
            record.Mappings && record.Mappings.length > 0 ? true : false,
          expandedRowRender: (record) => <AttributeMappingTable  dataSource={record.Mappings!}/>,
        }}
        pagination={false}
      />
    </Form>
  );
};
export default forwardRef(ReplicatorAddMapping);

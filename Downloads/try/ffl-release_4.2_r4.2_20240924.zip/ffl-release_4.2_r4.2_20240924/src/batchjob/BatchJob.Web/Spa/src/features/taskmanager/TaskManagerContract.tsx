import { PagerResult } from '../../common/contracts/PagerContracts';
export class TaskDto {
    Id?: string;
    Name?: string;
    Description?: string;
    Tag?: string;
    Type: number = 0; // 0: Schedule   1:manually
    Schedule?: ScheduleDto;
    JobAction?: ScheduleActionDto;
    ActionDisplayName?: string;
    RelatedGroupNames?: Array<any>;
    NotificationProfileId?: string;
    NotificationType: number = 0; /// flags: 2 finish 4 exception 8 failed
    State: number = 0;
    NextTime: number = 0;
    Endpoints?: string;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
};
export class TaskGroupDto {
    Id?: string;
    Name?: string;
    Description?: string;
    ActionDisplayName?: string;
    JobAction?: ScheduleActionDto;
    Type: number = 0; // 0: Schedule   1:manually
    Schedule?: ScheduleDto;
    Steps?: Array<TaskGroupStep>;
    NotificationProfileId?: string;
    State: number = 0;
    ContinueOnException?: boolean;
    NextTime: number = 0;
    Endpoints?: string;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
};
export class TaskGroupStep {
    Id?: string;
    Order: number = 0;
    Task?: TaskDto;
    Disabled?:boolean;
    ActionDisplayName?: string;
    CreatedOn?: number = 0;
    CreatedBy?: string;
    ModifiedOn?: number = 0;
    ModifiedBy?: string;
}
export class ScheduleActionDto {
    DisplayName?: string;
    HandlerId?: string;
    PartsAndValues?: Array<string>; /// [{string,[]}]
};
export class ScheduleDto {
    Id?: string;
    JobTitle?: string;
    EmailId?: string;
    ///    JobStatus: ScheduleState;
    ///    State: StatusEnum;
    ScheduleRule?: ScheduleRuleDto;
    StartTime: number = 0;
    NextTime: number = 0;
    TimeZoneId?: string;
    ///    EndType: ScheduleEndType;
    EndTime: number = 0;
    EndTimeZoneId?: string;
    Occurrences: number = 0;
    OccurrencesTotal: number = 0;
    ///    DaylightSavingTimeType: DayLightSavingTimeTypes ;
    HolidayProfileId?: string;
    Description?: string;
    SkipCount: number = 0;
    CreatedOn: number = 0;
    CreatedBy?: string;
    ModifiedOn: number = 0;
    ModifiedBy?: string;
    TimeZone?: number;
};
export class ScheduleRuleDto {
    RuleType?: ScheduleRuleType;
    Interval: number = 0;
    DayOfWeekSpecifies?: Array<number>;
    MonthlySubType?: MonthlyRuleType;
    DayOfMonth?: ScheduleDay;
    WeekSequence?: ScheduleSequence;
    SpecifyMonth?: ScheduleMonth;
    WorkingHoursOption?: WorkingHourOptions;
    WorkingHourStartTime: number = 0;
    WorkingHourEndTime: number = 0;
    WorkingDays?: Array<number>;
};
export enum ScheduleRuleType {
    OnlyOnce = 0,
    Hourly = 1,
    Daily = 2,
    Weekly = 3,
    Monthly = 4,
    Minutely = 5,
};

export const ScheduleRuleTypeMap = new Map<ScheduleRuleType,string >([
    [ ScheduleRuleType.OnlyOnce,"Only once"],
    [ScheduleRuleType.Hourly,"By hour"],
    [ScheduleRuleType.Daily,"By day"],
    [ ScheduleRuleType.Weekly,"By week"],
    [ScheduleRuleType.Monthly,"By month"],
    [ScheduleRuleType.Minutely,"By minute"]
])

export enum MonthlyRuleType {
    DayAndMonth = 0,
    DayByInterval = 1,
    DayOfWeekByInterval = 2,
    DayOfWeekAndMonth = 3,
    DayofLastAndMonth = 4
};
export enum ScheduleMonth {
    January = 1,
    February = 2,
    March = 3,
    April = 4,
    May = 5,
    June = 6,
    July = 7,
    August = 8,
    September = 9,
    October = 10,
    November = 11,
    December = 12
};
export enum ScheduleDay {
    Day_1 = 1,
    Day_2 = 2,
    Day_3 = 3,
    Day_4 = 4,
    Day_5 = 5,
    Day_6 = 6,
    Day_7 = 7,
    Day_8 = 8,
    Day_9 = 9,
    Day_10 = 10,
    Day_11 = 11,
    Day_12 = 12,
    Day_13 = 13,
    Day_14 = 14,
    Day_15 = 15,
    Day_16 = 16,
    Day_17 = 17,
    Day_18 = 18,
    Day_19 = 19,
    Day_20 = 20,
    Day_21 = 21,
    Day_22 = 22,
    Day_23 = 23,
    Day_24 = 24,
    Day_25 = 25,
    Day_26 = 26,
    Day_27 = 27,
    Day_28 = 28,
    Day_29 = 29,
    Day_30 = 30,
    Day_31 = 31
};
export enum ScheduleSequence {
    First = 1,
    Second = 2,
    Third = 3,
    Fourth = 4,
    Fifth = 5
};
export enum WorkingHourOptions {
    None = 0,
    WorkingHours = 1,
    NonworkingHours = 2,
};
export enum ServiceResultType {
    Success = 0,
    Failed = 1,
    Error = 2,
    Exception = 3,
};
export enum WeekDay {
    Sunday = 0,
    Monday = 1,
    Tuesday = 2,
    Wednesday = 3,
    Thursday = 4,
    Friday = 5,
    Saturday = 6,
}
export class TaskManagerServiceResult {
    Type?: ServiceResultType;
    Message?: string;
    EventCode?: number;
    Id?: string;
    Task?: TaskDto;
    TaskGroup?: TaskGroupDto;
    Tasks?: Array<TaskDto>;
    // Job?:JobDto;
    ActionSettings?: Array<TaskActionSettingDto>;
    PageredTasks?: PagerResult<TaskDto>;
    PageredTaskGroups?: PagerResult<TaskGroupDto>;
    IsSucceed?: boolean;
};
export class JobAction {
    HandlerId?: string;
    DisplayName?: string;
}

export class TaskActionSettingDto {
    Id?: string;
    DisplayName?: string;
    ActionParameterSettings?: ActionParameterSettingDto[]
}
export class ActionParameterSettingDto {
    Type?: ControlType;
    Label?: string;
    Key?: string;
    ItemsSourceLink?: string;
    Data?:any;
}
export enum ControlType {
    None,
    Combo,
    Input,
    MultiCombo
}
export class ActionElementDto {
    Id?: string;
    Name?: string;
}
export const TaskPermissionConstants = {
    ObjectCode: 201001,
    Read: 1,
    Create: 2,
    Update: 4,
    Delete: 8
};

// export {
//     TaskDto, ScheduleActionDto, MonthlyRuleType, ScheduleMonth,
//     ScheduleDto, ScheduleRuleDto, ScheduleDay, ScheduleSequence,
//     ScheduleRuleType, WorkingHourOptions, TaskManagerServiceResult, TaskGroupStep, TaskGroupDto, JobAction,
//     WeekDay,TaskActionSettingDto,ActionParameterSettingDto,ControlType,TaskPermissionConstants
// };
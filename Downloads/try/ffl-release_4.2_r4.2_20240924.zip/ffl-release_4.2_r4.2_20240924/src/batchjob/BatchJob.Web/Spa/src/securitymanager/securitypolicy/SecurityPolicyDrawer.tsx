import React from 'react';
import { Drawer, Form, Button, Input } from 'antd';
import apiservice from '../../utils/fetchutil';
import { SecurityPofileDto, SecurityPermissionConstants } from './SecurityPofileContract';
import { hasPermission } from '../../utils/permissionutil';

const layout =
{
    labelCol: {
        span: 8
    },
    wrapperCol: { span: 12 },
};


class DrawerForm extends React.Component<any, any> {
    private formRef = React.createRef<any>();
    constructor(props: any) {
        super(props);
        console.log(this.props.formData1);
        this.state = {
            showWidth: '100%',
            formData: null,
            visible: false,
        }
    }

    onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };
    onClose = () => {
        this.closeNewEvent();
    };
    closeNewEvent = () => {
        this.props.closeDrawerEvent();
    };
    onChangeType = () => {
    };
    //new

    apiService = apiservice();
    onGetSymmetricKey = () => {
        this.apiService.post('/ISecuritySetting/GenerateSymmetricKey').then(
            (result: any) => {
                this.formRef.current.setFieldsValue({
                    SK_Name: result.Result?.Name,
                    SK_EncryptionKey: result?.Result?.EncryptionKey,
                    SK_MatchPassphrase: result?.Result?.MatchPassphrase
                })
            }
        ).catch((e) => {
            console.log(e);
        })
    };

    onGetAsymmetricKey = () => {
        this.apiService.post('/ISecuritySetting/GenerateAsymmetricKey').then(
            (result: any) => {
                this.formRef.current.setFieldsValue({
                    AK_Name: result.Result?.Name,
                    AK_PublicKey: result?.Result?.PublicKey,
                    AK_PrivateKey: result?.Result?.PrivateKey,
                })
            }
        ).catch((e) => {
            console.log(e);
        })
    };

    onFinish = (viewModel: any) => {
        let model1: any = {}
        let AsymmetricKey: any = {};
        let SymmetricKey: any = {};
        let KeyVaultConfig: any = {};

        if (viewModel.SK_Name) {
            SymmetricKey.Name = viewModel.SK_Name;
        }
        if (viewModel.SK_EncryptionKey) {
            SymmetricKey.EncryptionKey = viewModel.SK_EncryptionKey;
        }
        if (viewModel.SK_MatchPassphrase) {
            SymmetricKey.MatchPassphrase = viewModel.SK_MatchPassphrase;
        }
        if (viewModel.AK_Name) {
            AsymmetricKey.Name = viewModel.AK_Name;
        }
        if (viewModel.AK_PrivateKey) {
            AsymmetricKey.PrivateKey = viewModel.AK_PrivateKey;
        }
        if (viewModel.AK_PublicKey) {
            AsymmetricKey.PublicKey = viewModel.AK_PublicKey;
        }
        if (viewModel.KC_Name) {
            KeyVaultConfig.Name = viewModel.KC_Name;
        }
        if (viewModel.KC_ClientId) {
            KeyVaultConfig.ClientId = viewModel.KC_ClientId;
        }
        if (viewModel.KC_ClientSecret) {
            KeyVaultConfig.ClientSecret = viewModel.KC_ClientSecret;
        }
        if (viewModel.KC_KeyIdentity) {
            KeyVaultConfig.KeyIdentity = viewModel.KC_KeyIdentity;
        }

        if (Object.keys(AsymmetricKey).length > 0) {
            model1.AsymmetricKey = AsymmetricKey;
        }
        if (Object.keys(SymmetricKey).length > 0) {
            model1.SymmetricKey = SymmetricKey;
        }
        if (Object.keys(KeyVaultConfig).length > 0) {
            model1.KeyVaultConfig = KeyVaultConfig;
        }
        this.saveFormData(model1);
    }
    saveFormData = (model: SecurityPofileDto) => {
        this.apiService.post('/ISecuritySetting/UpdateSecurityProfile', { dto: model }).then(
            (result: any) => {

                if (result.Type === 0) {
                    console.log('Success', result)
                    this.onClose();
                }
                if (result.Type !== 0) {
                    var code = result.EventCode;
                    var message = result.Message;
                    alert(message + "," + code);
                }
            }
        ).catch((e) => {
            console.log(e);
        });
    }
    onSubmitForm = () => {
        this.formRef.current?.submit();
    }
    render() {
        return (
            <>
                <Drawer
                    title="Update a new Key"
                    width={720}
                    onClose={this.onClose}
                    visible={this.props.visible}
                    footer={
                        <div style={{ textAlign: 'right', }}>
                            <Button type="primary" onClick={this.onSubmitForm} >
                                Save
                            </Button>
                            <Button onClick={this.onClose} style={{ marginLeft: '10px' }}>
                                Cancel
                            </Button>
                        </div>
                    }
                >
                    {this.props.tab === "1" && <Form name="validate_other"
                        {...layout}
                        onFinish={this.onFinish}
                        ref={this.formRef}
                        initialValues={{}}
                    >
                        <Button type="primary" disabled={!hasPermission(SecurityPermissionConstants.ObjectCode, SecurityPermissionConstants.Update)} onClick={this.onGetSymmetricKey}>Generate New Key</Button>
                        <Form.Item
                            label="Name"
                            labelAlign="right"
                            name="SK_Name"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your Name!',
                                },
                            ]}
                        >
                            <Input placeholder="Please enter user name" />
                        </Form.Item>
                        <Form.Item
                            label="Encryption Key"
                            name="SK_EncryptionKey"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your Encryption Key!',
                                },
                            ]}
                        >
                            <Input placeholder="Please enter user name"
                                name='ClientSecret'
                            />
                        </Form.Item>
                        <Form.Item
                            label="Match Passphrase"
                            labelAlign="right"
                            name="SK_MatchPassphrase"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your Match Passphrase!',
                                },
                            ]}
                        >
                            <Input placeholder="Please enter user name"

                            />
                        </Form.Item>

                        {/* <div className="footLine">
                            <Button type="primary" htmlType="submit">
                                Save
                            </Button>
                            <Button onClick={this.onClose} style={{ marginLeft: '10px' }}>
                                Cancel
                            </Button>
                        </div> */}
                    </Form>
                    }

                    {/* {this.props.tab === 2 &&
                        <Form name="validate_other"
                            {...layout}
                            onFinish={this.onFinish}
                            ref={this.formRef}
                            initialValues={{}}
                        >
                            <Form.Item
                                label="Name"
                                labelAlign="right"
                                name="KC_Name"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your Name!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                            <Form.Item
                                label="Client Id"
                                name="KC_ClientId"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                            <Form.Item
                                label="Client Secret"
                                labelAlign="right"
                                name="KC_ClientSecret"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your Client Secret!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                            <Form.Item
                                label="Key Identity"
                                name="KC_KeyIdentity"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your Key Identity!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>

                        </Form>
                    } */}

                    {this.props.tab === "3" &&
                        <Form name="validate_other"
                            {...layout}
                            onFinish={this.onFinish}
                            ref={this.formRef}
                            initialValues={{}}
                        >
                            <Button type="primary" onClick={this.onGetAsymmetricKey}>Generate New Key</Button>
                            <Form.Item
                                label="Name"
                                labelAlign="right"
                                name="AK_Name"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your Name!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                            <Form.Item
                                label="Public Key"
                                name="AK_PublicKey"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your Public Key!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"
                                />
                            </Form.Item>
                            <Form.Item
                                label="Private Key"
                                labelAlign="right"
                                name="AK_PrivateKey"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your Private Key!',
                                    },
                                ]}
                            >
                                <Input placeholder="Please enter user name"

                                />
                            </Form.Item>

                            {/* <div style={{ textAlign: 'right',position:'fixed',bottom:10,right:10}}>
                            <Button type="primary" htmlType="submit">
                                Save
                            </Button>
                            <Button onClick={this.onClose} style={{ marginLeft: '10px' }}>
                                Cancel
                            </Button>
                        </div> */}
                        </Form>
                    }
                </Drawer>
            </>
        );
    }
}

export default DrawerForm;

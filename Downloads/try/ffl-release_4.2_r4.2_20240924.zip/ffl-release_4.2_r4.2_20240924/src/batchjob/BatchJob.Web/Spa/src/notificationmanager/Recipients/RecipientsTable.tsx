import React, { useState } from "react";
import { Modal, message } from "antd";
import { PagedQuery, DeleteProfile } from "../ManagerApiserve";
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  ExclamationCircleOutlined,
} from "@ant-design/icons";
import { convertTicksToFormatDate } from "../../utils/dateconvert";
import { hasPermission } from "../../utils/permissionutil";
import { PagerExpression } from "../../common/contracts/PagerContracts";
import AmpCommonTable, {IAmpTableButton} from "../../components/antdx/AmpCommonTable";
import { QueryProfile } from "../ManagerApiserve";
import ProfileReadDrawer from "./ProfileReadDrawer";
import RecipientsFormDrawer from "./RecipientsFormDrawer";
import { PermissionConstants } from "./NotificationManagerContracts";
import { ProtocolTypeMap } from "../NotificationSetting/NotificationSettingContracts";


const { confirm } = Modal;
const RecipientsTable = () => {
  const [refresh, setRefresh] = useState(1);
  const [selectedRecords, setSelectedRecords] = useState<any[]>();
  const [EditFormData, setEditFormData] = useState<any>({});
  const [visible, setVisible] = useState<boolean>(false);
  const [profileVisible, setProfileVisible] = useState<boolean>(false);

  const columns = [
    {
      title: "Notification Name",
      dataIndex: "Name",
      key: "Name",
      sorter: true,
      width: "16%",
      ellipsis: true,
      render: (name: any, obj: any, index: any) => {
        return (
          // eslint-disable-next-line jsx-a11y/anchor-is-valid
          <a
            onClick={async () => {
              let res = await QueryProfile({ id: obj.Id });
              setEditFormData({ ...res.Result });
              setProfileVisible(true);
            }}
          >
            {name}
          </a>
        );
      },
    },
    {
      title: "Connection Type ",
      dataIndex: "ConnectionType",
      key: "ConnectionType",
      width: "16%",
      render: (connectionType: any, obj: any, index: any) => {
        return <span>{ProtocolTypeMap.get(connectionType!) }</span>
      }
    },
    {
      title: "Description ",
      dataIndex: "Description",
      key: "Description",
      width: "16%",
      ellipsis: true,
    },
    {
      title: "Created By",
      dataIndex: "CreatedBy",
      key: "CreatedBy",

    },
    {
      title: "Created Time",
      dataIndex: "CreatedOn",
      key: "CreatedOn",
      width: "16%",
      sorter: true,
      render: (text: number) => {
        return (
          <span>{convertTicksToFormatDate(text, "YYYY-MM-DD HH:mm:ss")}</span>
        );
      },
    },
    {
      title: "Modified By",
      dataIndex: "ModifiedBy",
      key: "ModifiedBy",
    },
    {
      title: "Modified Time",
      dataIndex: "ModifiedOn",
      width: "16%",
      sorter: true,
      key: "ModifiedOn",
      render: (text: number) => {
        return (
          <span>{convertTicksToFormatDate(text, "YYYY-MM-DD HH:mm:ss")}</span>
        );
      },
    },
  ];

  const onCloseFun = () => {
    setEditFormData({});
    setVisible(false);
    setProfileVisible(false);
  };

  let addSourceBtn = () => {
    setVisible(true);
  };

 
  let deleteSourceBtn = () => {
    let deleteIdArr = selectedRecords!.map(e=>e.Id);
    confirm({
      title: "Warning",
      icon: <ExclamationCircleOutlined />,
      content:
        "You are about to delete the selected items. Are you sure you want to proceed?",
      onOk() {
        DeleteProfile({
          ids: deleteIdArr,
        })
          .then((res) => {
            if (res.Type === 0) {
              message.success("delete succeed");
            }
          })
          .finally(() => setRefresh(refresh + 1));
      },
      onCancel() {
        console.log("Cancel");
      },
    });
  };

  const buttons: Array<IAmpTableButton> = [
    {
      Text: "Create",
      Primary: true,
      Icon: <PlusOutlined />,
      OnClick: addSourceBtn,
      EnableMode: "always",
      HasPermission: hasPermission(
        PermissionConstants.ObjectCode,
        PermissionConstants.Create
      ),
    },
    {
      Text: "Edit",
      Icon: <EditOutlined />,
      OnClick:async()=>{
          let res = await QueryProfile({ id: selectedRecords![0].Id });
          setEditFormData({ ...res.Result });
          setVisible(true)
      },
      EnableMode: "single",
      HasPermission: hasPermission(
        PermissionConstants.ObjectCode,
        PermissionConstants.Update
      ),
    },
    {
      Text: "Delete",
      Icon: <DeleteOutlined />,
      OnClick: deleteSourceBtn,
      EnableMode: "multiple",
      HasPermission: hasPermission(
        PermissionConstants.ObjectCode,
        PermissionConstants.Delete
      ),
    },
  ];

  const ApiPagerQuery = async (exp: PagerExpression) => {
    let obj = { expression: { ...exp } };
    let result = await PagedQuery(obj);
    return {
      total: result!.Result.TotalNumber,
      records: result!.Result.Result,
    };
  };

  return (
    <>
      <AmpCommonTable
        Type="checkbox"
        RowKey="Id"
        Columns={columns}
        PagerQuery={ApiPagerQuery}
        OnSelectedChanged={(records) => setSelectedRecords(records)}
        SearchKeys={["Name"]}
        Refresh={refresh}
        Buttons={buttons}
        EnableSearch
      />

      {profileVisible && (
        <ProfileReadDrawer
          visible={profileVisible}
          closeDrawer={onCloseFun}
          refresh={() => setRefresh(refresh + 1)}
          data={EditFormData}
        />
      )}

      {visible && (
        <RecipientsFormDrawer
          visible={visible}
          closeDrawer={onCloseFun}
          refresh={() => setRefresh(refresh + 1)}
          data={EditFormData}
        />
      )}
    </>
  );
};
export default RecipientsTable;

import { Drawer, Form, Input, Button, Spin } from 'antd';
import React, { FC, useEffect, useState } from 'react';
import { VoidCallBackFunction } from './FrontendAPIContracts';
import { FrontendAPIDto } from '../../common/contracts/ModelContracts';
import { CreateFrontend } from './FrontendAPIApiService';

interface IAPIForm {
    Name?: string;
    BaseAddress?: string;
    Description?: string;
}

interface IManageAPIDrawerProps {
    visibile: boolean;
    cancelClick: VoidCallBackFunction;
    isEdit: boolean;
    defaultData: FrontendAPIDto;
    getTableData: VoidFunction;
}

const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 12 },
};

const ManageAPIDrawer: FC<IManageAPIDrawerProps> = (props) => {
    const [loading, setLoading] = useState<boolean>(false);
    const [form] = Form.useForm();

    useEffect(() => {
        if (props.visibile) {
            form.setFieldsValue({
                Name: props.defaultData.Name,
                BaseAddress: props.defaultData.BaseAddress,
                Description: props.defaultData.Description,
            })
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.visibile, props.defaultData])

    const onFailed = (values: any) => {
        console.log('Failed:', values);
    };
    const onFinish = (values: IAPIForm) => {
        setLoading(true);
        let requestObject = new FrontendAPIDto();
        requestObject.Name = values.Name;
        requestObject.BaseAddress = values.BaseAddress;
        requestObject.Description = values.Description;
        if (props.isEdit && props.defaultData.Id) {
            requestObject.Id = props.defaultData.Id;
        }
        CreateFrontend(requestObject)
            .then(res => {
                setLoading(false);
                closeDrawer();
                props.getTableData();
            })
            .catch(err => {
                setLoading(false);
            })

    }
    const closeDrawer = (): void => {
        form.resetFields();
        props.cancelClick();
    }

    return <Drawer
        visible={props.visibile}
        width={720}
        destroyOnClose
        forceRender
        onClose={closeDrawer}
        title={props.isEdit ? "Edit API" : "Create a new API"}
        footer={
            <div style={{ textAlign: 'right', }}>
                <Button type="primary" style={{ marginRight: 8 }} loading={loading} onClick={() => form.submit()}>Save</Button>
                <Button onClick={closeDrawer} >Cancel</Button>
            </div>
        }
    >
        <Spin spinning={loading}>


            <Form {...layout} form={form} onFinish={onFinish} onFinishFailed={onFailed} style={{ marginTop: '20px' }}>
                <Form.Item label="Name" name="Name" rules={[{ required: true, message: 'Please input name!' }]}>
                    <Input />
                </Form.Item>
                {/* <Form.Item label="Node" name="Node" rules={[{ required: true, message: 'Please input node!' }]}>
                <Input />
            </Form.Item> */}
                <Form.Item label="BaseAddress" name="BaseAddress" rules={[{ required: true, message: 'Please input base address!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Description" name="Description" >
                    <Input.TextArea rows={3} />
                </Form.Item>
            </Form>
        </Spin>
    </Drawer>
}
export default ManageAPIDrawer
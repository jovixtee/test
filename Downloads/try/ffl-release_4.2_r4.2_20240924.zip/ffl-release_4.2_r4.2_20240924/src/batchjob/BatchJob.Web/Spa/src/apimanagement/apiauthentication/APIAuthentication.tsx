import {Button, Col, Dropdown, Input, Menu, Row, Space, Table} from "antd";
import React, {FC, useEffect, useState} from "react";
import {ColumnsType, FilterValue, TableCurrentDataSource, TablePaginationConfig} from "antd/lib/table/interface";
import {AuthenticationDto, AuthType, FromType} from '../../common/contracts/ModelContracts';
import "./apiAuthentication.css";
import {DeleteOutlined, EditOutlined, PlusOutlined,Html5Outlined} from "@ant-design/icons";
import {convertTicksToMoment} from "../../utils/dateconvert";
import CreateBackendAuthenticationDrawer from './CreateBackendAuthenticationDrawer';
import CreateFrontendAuthenticationDrawer from './CreateFrontendAuthenticationDrawer';
import {DeleteAuthentications, GetAuthenticationById, PagerAuthentication} from './APIAuthenticationService';
import ProfileReadDrawer from './ProfileReadDrawer';
import {FilterCondition, PagerExpression} from "../../common/contracts/PagerContracts";
import UINotrification from "../../common/UINotrification";
import TokenStoreDrawer from "./TokenStoreDrawer";

const { Search } = Input;
const CommonPager: TablePaginationConfig = {
    current: 1,
    pageSize: 10,
    pageSizeOptions: ["10", "20", " 50", "100"],
    showQuickJumper: true,
    showSizeChanger: true,
};

const APIAuthentication: FC = () => {
    const [pager, setPager] = useState<TablePaginationConfig>({ ...CommonPager });
    const [sortColumn, setSortColumn] = useState<any>({ column: 'ModifiedOn', isDesc: true });
    const [filters, setFilters] = useState<Array<FilterCondition>>([]);
    const [tableLoading, setTableLoading] = useState<boolean>(false);
    const [dataSource, setDataSource] = useState<AuthenticationDto[]>(new Array<AuthenticationDto>());
    const [searchText, setSearchText] = useState<string>("");
    const [isEditMode, setIsEditMode] = useState<boolean>(false);
    const [selectAuthenticationKey, setSelectAuthenticationKey] = useState<string[]>([]);
    const [editingId, setEditingId] = useState<string>("");
    const [createBackendAuthenticationDrawerVisible, setCreateBackendAuthenticationDrawerVisible] = useState<boolean>(false);
    const [createFrontendAuthenticationDrawerVisible, setCreateFrontendAuthenticationDrawerVisible] = useState<boolean>(false);
    const [showProfile, setShowProfile] = useState<boolean>(false);
    const [authentication, setAuthentication] = useState<string>();
    const [editData, setEditData] = useState<AuthenticationDto>();
    const [showTokenStore, setShowTokenStore] = useState<boolean>(false);

    useEffect(() => {
        setSelectAuthenticationKey([]);
        requestPagerAuthentication()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchText, pager]);
 
    const tableColumn: ColumnsType<AuthenticationDto> = [
        {
            title: "Name",
            dataIndex: "Name",
            ellipsis: true,
            width:"15%",
            sorter: true,
            render: (text: any, record: AuthenticationDto) => <a onClick={() => viewProfile(record)}>{text}</a>
        },
        {
            title: "FromType",
            dataIndex: "FromType",
            ellipsis: true,
            width:"15%",
            sorter: true,
            render: (_: any, record: AuthenticationDto) => (record.FromType) ? FromType[record.FromType] : FromType[FromType.Frontend]
        },
        {
            title: "Type",
            dataIndex: "AuthenticationType",
            ellipsis: true,
            width:"15%",
            sorter: true,
            render: (_: any, record: AuthenticationDto) => (record.AuthType) ? AuthType[record.AuthType] : ""
        },
        {
            title: "Created Time",
            dataIndex: "CreatedOn",
            sorter: true,
            render: (_: any, record: AuthenticationDto) => record.CreatedOn && record.CreatedOn !== 0 ? convertTicksToMoment(record.CreatedOn as number).format('YYYY-MM-DD HH:mm:ss') : "NA"
        },
        {
            title: "Created By",
            dataIndex: "CreatedBy"
        },  {
            title: 'Modified Time',
            dataIndex: 'ModifiedOn',
            key: 'ModifiedOn',
            sorter: true,
            render: (_: any, record: AuthenticationDto) => record.ModifiedOn && record.ModifiedOn !== 0 ? convertTicksToMoment(record.ModifiedOn as number).format('YYYY-MM-DD HH:mm:ss') : "NA"
        },{
            title: 'Modified By',
            dataIndex: 'ModifiedBy',
            key: 'ModifiedBy',
            ellipsis: true
        }
    ]

    const getPagerExpression = (pagination?: TablePaginationConfig, flt?: Record<string, FilterValue>, sorter?: any): PagerExpression => {
        if (!pagination) pagination = pager;
        let exp: PagerExpression = {
            PageSize: pagination.pageSize,
            JumpPage: pagination.current,
            Filters: filters,
            SearchValue: searchText,
            SearcheKeys: ["Name"],
            SortBy: sortColumn.column,
            IsDesc: sortColumn.isDesc,
        };
        return exp;
    }

     

    const requestPagerAuthentication = (pagerExp?: PagerExpression) => {
        if (!pagerExp){
            pagerExp = getPagerExpression();
        }
        setTableLoading(true);
        PagerAuthentication({"pager":pagerExp}).then(res => {
           // console.log(res)
            if (res.Result) {
                setDataSource(res.Result);
            }
            setTableLoading(false)
        }).catch(err => {
            setTableLoading(false)
        }).finally(()=>{
            setSelectAuthenticationKey([]);
        })
    }

    const onSearch = (value: string): void => {
        setSearchText(value);
        //requestPagerAuthentication()
    }

    const viewProfile = (record: AuthenticationDto) => {
        setAuthentication(record.Id);
        setShowProfile(true);
    }

    const tablePageChange = (pagination?: TablePaginationConfig, filters?: Record<string, FilterValue>, sorter?: any, extra?: TableCurrentDataSource<any>) => {
        switch (extra!.action) {
            case 'paginate': break;
            case 'filter':
                const flt = [];
                for (var f in filters) {
                    flt.push({ ColumnName: f, ColumnValues: filters[f] });
                }
                setFilters(flt as Array<FilterCondition>);
                break;
            case 'sort':
                setSortColumn({ column: sorter.field, isDesc: sorter.order !== 'ascend' });
                break;
        }
        setPager({ ...pagination });
    }



    const onDeleteAuthenticationsClick = (): void => {
        //requestDeleteAuthentications(selectAuthenticationKey)
        UINotrification.confirm(
            "You are about to delete the selected profiles. Are you sure you want to proceed?",
            "Confirm Deletion",
            async () => {
                requestDeleteAuthentications(selectAuthenticationKey)
            },
            () => {
            }
        );
    }
    const requestDeleteAuthentications = (Ids: string[]): void => {
        setTableLoading(true);
        DeleteAuthentications(Ids)
            .then(res => {
                requestPagerAuthentication();
            })
            .catch(err => {
                setTableLoading(false);
            })
    }

    const onEditAuthenticationsClick = (): void => {
        const editingId = selectAuthenticationKey[0];
        setEditingId(editingId as string);
        setIsEditMode(true);
        if (1) {
            GetAuthenticationById(editingId)
            .then((result) => {
                setEditData(result);
                setCreateBackendAuthenticationDrawerVisible(true);
            })
            .finally(() => {
           
            });
        } else {
            setCreateFrontendAuthenticationDrawerVisible(true)
        }
    }
    const handleCreateMenuClick = (event: any): void => {
        switch (event.key) {
            case "Backend":
                createBackEndAuthentication();
                break;
            case "Frontend":
                createFrontendAuthentication();
                break;
        }
    }
    const createBackEndAuthentication = (): void => {
        setEditingId("");
        setIsEditMode(false);
        setCreateBackendAuthenticationDrawerVisible(true);
    }
    const closeBackEndAuthenticationDrawer = (): void => {
        setCreateBackendAuthenticationDrawerVisible(false);
        setIsEditMode(false);
        setEditingId("");
    }
    const createFrontendAuthentication = (): void => {
        setEditingId("");
        setIsEditMode(false);
        setCreateFrontendAuthenticationDrawerVisible(true)
    }
    const closeFrontendAuthenticationDrawer = (): void => {
        setCreateFrontendAuthenticationDrawerVisible(false);
        setIsEditMode(false);
        setEditingId("");
    }

    const closeProfile = (): void => {
        setAuthentication("");
        setShowProfile(false);
    }
 
    const menu = (
        <Menu onClick={handleCreateMenuClick}>
            <Menu.Item key="Backend">
                Backend
            </Menu.Item>
            <Menu.Item key="Frontend">
                Frontend
            </Menu.Item>
        </Menu>
    );


    return <React.Fragment>
        <Row style={{ margin: '16px 0' }}>
            <Col span={18}>
                <Space size='small'>
                    <Dropdown overlay={menu} trigger={["click"]} disabled={tableLoading}>
                        <Button icon={<PlusOutlined />} type="primary">Create</Button>
                    </Dropdown>
                    <Button type="text" disabled={selectAuthenticationKey.length !== 1} onClick={onEditAuthenticationsClick}><EditOutlined />Edit</Button>
                    <Button type='text' disabled={selectAuthenticationKey.length === 0} icon={<DeleteOutlined />} onClick={onDeleteAuthenticationsClick}>Delete</Button>
                    <Button type='text' disabled={
                        selectAuthenticationKey.length !== 1 ||
                        dataSource!.find(e=>e.Id === selectAuthenticationKey[0])?.FromType !== FromType.Backend ||
                        dataSource!.find(e=>e.Id === selectAuthenticationKey[0])?.AuthType !== AuthType.OAuth
                    } icon={<Html5Outlined />} onClick={()=>setShowTokenStore(true)}>Token Store</Button>
                </Space>
            </Col>
            <Col span={6}>
                <Search placeholder="input search text" allowClear onSearch={onSearch} style={{ width: 200, float: 'right' }} />
            </Col>
        </Row>

        <Table
            rowKey={record => record.Id}
            dataSource={dataSource}
            columns={tableColumn}
            pagination={pager}
            onChange={tablePageChange as any}
            rowSelection={{
                selectedRowKeys: selectAuthenticationKey,
                type: "checkbox",
                onChange: (selectedRowKeys: React.Key[]) => {
                    setSelectAuthenticationKey(selectedRowKeys as string[])
                }
            }}
        />

        <CreateBackendAuthenticationDrawer
            cancelClick={closeBackEndAuthenticationDrawer}
            editingId={editingId}
            editData={editData}
            visible={createBackendAuthenticationDrawerVisible}
            isEdit={isEditMode}
            getTableData={() => { requestPagerAuthentication() }}
        />
        <CreateFrontendAuthenticationDrawer
            cancelClick={closeFrontendAuthenticationDrawer}
            editingId={editingId}
            visible={createFrontendAuthenticationDrawerVisible}
            isEdit={isEditMode}
            getTableData={() => { requestPagerAuthentication() }}
        />



        <ProfileReadDrawer
            visible={showProfile}
            onClose={closeProfile}
            Id={authentication}
        />
        
        <TokenStoreDrawer
            visibile={showTokenStore}
            profile = {dataSource.find(e=>e.Id ===selectAuthenticationKey[0])!}
            cancelClick={()=>setShowTokenStore(false)}
        />
        

    </React.Fragment>

}

export default APIAuthentication
import { PagerExpression } from "../../common/contracts/PagerContracts";
import apiservice from "../../utils/fetchutil";
import { HolidayDto, HolidaySettingProfile, HolidaySettingServiceResult } from "./HolidaySettingContract";

const HolidaySettingApi = {
    PagerQueryProfile: (pagerExp: PagerExpression): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/PagerQueryProfile", { pager: pagerExp });
    },
    DeleteProfiles: (ids: string[]): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/DeleteProfiles", { profileIds: ids });
    },
    LoadTimeZoneInfos: (): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/LoadTimeZoneInfos");
    },
    QueryProfileById: (id: string): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/QueryProfileById", { id: id });
    },
    QueryAllHolidaysByProfileId: (id: string): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/QueryAllHolidaysByProfileId", { profileId: id });
    },
    ImportPublicSG: (fd: FormData): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/ImportPublicSG", fd);
    },
    DeleteHolidays: (profileId: string, ids: string[]): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/DeleteHolidays", { profileId: profileId, holidayIds: ids });
    },
    UpdateProfile: (profile: HolidaySettingProfile): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/UpdateProfile", { profile: profile });
    },
    SaveProfile: (profile: HolidaySettingProfile): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/SaveProfile", { profile: profile });
    },
    SaveHolidays: (dto: HolidayDto): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/SaveHolidays", { holiday: dto });
    },
    UpdateHolidays: (dto: HolidayDto): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/UpdateHolidays", { holiday: dto });
    },
    QueryHolidayById: (profileId: string, id: string): Promise<HolidaySettingServiceResult> => {
        return apiservice().post("/IHolidaySettingService/QueryHolidayById", { profileId: profileId, holidayId: id });
    },

}

export default HolidaySettingApi;
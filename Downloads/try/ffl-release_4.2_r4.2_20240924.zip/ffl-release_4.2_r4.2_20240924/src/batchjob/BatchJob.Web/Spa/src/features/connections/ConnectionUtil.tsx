
import { AdapterType } from './ConnectionContract';

const getAdapterTypeStr = (typ: AdapterType) => {
    switch(typ){
        case AdapterType.Dynamics: return "Dynamics CRM";
        case AdapterType.SFTP: return "SFTP";
        case AdapterType.SMTP: return "SMTP";
        case AdapterType.Exchange: return "Exchange";
        case AdapterType.SQLServer: return "SQL Server";
        case AdapterType.Web: return "Web Service";
        case AdapterType.Dataverse: return "Dataverse";
    }
};

const ConnectionUtil = {
    getAdapterTypeStr: getAdapterTypeStr
};

export default ConnectionUtil;
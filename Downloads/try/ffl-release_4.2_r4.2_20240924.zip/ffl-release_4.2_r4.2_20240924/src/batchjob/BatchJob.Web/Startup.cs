﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using AccountManagerService;
using APIManager.Domain;
//using ApplicationService.Container.Core;
using Authentication.Interface;
using AuthenticationService.Domain;
using BatchJob.Web;
using BatchJob.Web.Config;
using CentralAdmin.Container;
using CentralAdmin.Container.InitDb;
using ConnectionAdapterService;
using Framework.Cache.Redis;
using Framework.CommonUtility.Features;
using Framework.ContainerRuntime;
using Framework.ContainerRuntime.Authentication;
using Framework.ContainerRuntime.ExInterceptor;
using Framework.ContainerRuntime.SecretManagers;
using Framework.MarsDatabase;
using Framework.MarsDatabase.Configuration;
using HolidaySetting.Domain;
using JobManager.Domain;
using JobService.Container.Core;
using MarsRpc.Http.Client;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using NotificationService;
using Replicator.Domain;
using SecuritySetting.Domain;
using TaskManager.Domain;
using Transfer.Domain;

namespace DataBroker.Web
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton<IConfigSet, ConfigSet>();
            services.Configure<EnvConfig>(Configuration.GetSection("EnvConfig"));
            services.AddControllers().AddJsonOptions(opt =>
            {
                opt.JsonSerializerOptions.PropertyNamingPolicy = null;
            });

            #region Central Admin Part
            var config = Configuration.GetSection("DBSettings").Get<MarsDbConfiguration>();
            services.EnsureDatabase(config);
            services.AddDbContext<DbContext>(options => options.UseSqlServer(config.GetConnectionString("CentralDbContext")));
            services.AddSingleton<IInitDB, InitDB>();
            services.AddEntityFrameworkSqlServer();
            services.AddMarsDatabaseFrameworks(this.Configuration.GetSection("DBSettings"));
            #endregion

            #region Application Part
            services.Configure<SecretManager>(Configuration.GetSection("SecretManager"));
            var rootPath = this.Configuration.GetValue("ApiRootPath", "api");
            services.AddMarsRpcHttpService(i =>
            {
                i.ApiRootPath = rootPath;
                i.IgnoreWhenNotMatched = true;
            });

            services.AddMarsRpcHttpClient();
            services.AddMarsRuntime(this.Configuration.GetSection("Runtime"));
            services.AddCache(this.Configuration.GetSection("CacheSetting"));

            services.AddSecuritySetting();
            services.AddAuthenticationService();
            services.AddAccountService();
            services.AddConnectionAdapterWithoutImport();

            services.AddNotificationServiceWithoutImport();
            services.AddAPIManagement();
            services.AddTaskManager();

            services.AddJobMonitor(Configuration.GetSection("TimerSetting"));
            services.AddJobManagerMarsEventRebus(Configuration.GetSection("ServiceBusSetting"));
            services.AddHolidaySettingService();
            services.AddTransfer();
            services.AddReplicatorServiceWithoutImport();

            //services.AddSingleton<IActivator, AppContainerInitializer>();
            services.AddSingleton<IActivator, JobContainerActivator>();

            services.AddAuthentication(option =>
            {
                option.DefaultAuthenticateScheme = AuthenticationDefaults.CookieAuthenticationScheme;
                option.DefaultScheme = AuthenticationDefaults.CookieAuthenticationScheme;
            })
            .AddCookie(AuthenticationDefaults.CookieAuthenticationScheme, option =>
            {
                option.ExpireTimeSpan = TimeSpan.FromMinutes(int.Parse(this.Configuration.GetSection("Authentication:CookieExpiration").Value));
                option.SlidingExpiration = true;
                option.Cookie.Name = AuthenticationConstants.TokenKey;
                option.Cookie.HttpOnly = true;
                //option.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                option.TicketDataFormat = new MarsJwtDataFormat();
                option.Events.OnRedirectToLogin = context =>
                {
                    context.Response.StatusCode = 401;
                    return Task.CompletedTask;
                };
            })
            .AddJwtBearer(AuthenticationDefaults.JwtBearerAuthenticationScheme, options =>
            {
                var issuers = Configuration.GetSection("Authentication:Issuers").Value;
                var audience = Configuration.GetSection("Authentication:Audience").Value;
                options.Authority = this.Configuration.GetSection("Authentication:APMAuthority").Value;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                };

                if (!string.IsNullOrEmpty(audience))
                {
                    options.TokenValidationParameters.ValidAudiences = audience.Split(",");
                }

                if (!string.IsNullOrEmpty(issuers))
                {
                    options.TokenValidationParameters.ValidIssuers = issuers.Split(",");
                }

                if (bool.TryParse(Configuration.GetSection("Authentication:RequireHttpsMetadata").Value, out bool requireHttps))
                {
                    options.RequireHttpsMetadata = requireHttps;
                }
            });

            services.AddCors(build => build.AddPolicy(RuntimeConstants.CORS_POLICY_NAME, builder =>
            {
                var origins = this.Configuration.GetSection("Cors:AllowedOrigins").Value.Split(';');
                builder.WithOrigins(origins)
                .AllowAnyHeader()
                .AllowAnyMethod()
                .AllowCredentials();
            }));
            services.AddSingleton<ISecretManager, SecretManagerUtils>();
            #endregion

            services.Configure<KestrelServerOptions>(x => x.AllowSynchronousIO = true);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory factory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler(builder => builder.Use(new ExceptionHandler(factory).Intercept));
                app.UseHsts();
            }
            app.UseRouting();

            app.ApplicationServices.GetServices<IInitDB>().ToList().ForEach(d => d.Init());
            app.UseMiddleware<AuthenticationMiddleware>();
            app.UseMarsRuntime("mars.webapp");
            app.UseMarsRpcHttp();

            app.StartMarsEventRebus();
            app.UseJobProvider();
            app.RegisterJobLogFactory(factory);

            app.ApplicationServices.GetServices<IActivator>().OrderBy(i => i.Level).ToList().ForEach(d => d.Active());
            app.UseSecuritySettingProvider();

            app.UseCors(RuntimeConstants.CORS_POLICY_NAME);

            var webRootPath = Configuration.GetSection("WebRootPath").Value;

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.Map("/", async http => { http.Response.Redirect(webRootPath, false); });
            });

            var location = new FileInfo(Assembly.GetExecutingAssembly().Location).Directory.ToString();
            var path = Path.Combine(location, "wwwroot");
            var fileOtp = new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(path)
            };
            app.Map(webRootPath, appBuilder =>
            {
                appBuilder.UseSpaStaticFiles(fileOtp);
                appBuilder.UseStaticFiles();
                appBuilder.UseSpa(options =>
                {
                    options.Options.DefaultPageStaticFileOptions = fileOtp;
                });
            });

            var healthz = "/healthz";
            var basePath = Configuration.GetValue<string>("ApiRootPath");
            if (!string.IsNullOrEmpty(basePath))
            {
                string[] segments = basePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
                if (segments.Length > 1)
                {
                    healthz = $"{segments[0]}/healthz";
                }
            }

            app.Map(healthz, appconfig =>
            {
                appconfig.Run(async context =>
                {
                    await context.Response.WriteAsync($"Ok. Package Version: {Configuration.GetValue("PackageImage_Version", "None")}");
                });
            });

            app.Map("/availablespace", appconfig =>
            {
                appconfig.Run(async context =>
                {
                    string driveInfoString = default;
                    DriveInfo[] driveInfos = DriveInfo.GetDrives();
                    if (driveInfos != null)
                    {
                        StringBuilder builder = new StringBuilder();
                        foreach (var item in driveInfos)
                        {
                            if (item.DriveType == DriveType.Fixed)
                            {
                                string infoString = $"Name: {item.Name}, DriveType: {item.DriveType}, DriveFormat: {item.DriveFormat} RootDirectory: {item.RootDirectory?.FullName}, AvailableFreeSpace: {item.AvailableFreeSpace}, TotalFreeSpace: {item.TotalFreeSpace}, TotalSize: {item.TotalSize}";
                                builder.Append(infoString);
                            }
                        }
                        driveInfoString = builder.ToString();
                    }
                    await context.Response.WriteAsync($"Drive infos: {driveInfoString}");
                });
            });

            Aspose.Email.License license = new Aspose.Email.License();
            license.SetLicense("Aspose.Total.NET.lic");
        }
    }
}
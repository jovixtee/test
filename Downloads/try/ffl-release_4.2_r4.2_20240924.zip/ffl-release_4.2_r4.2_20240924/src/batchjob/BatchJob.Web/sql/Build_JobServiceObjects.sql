IF OBJECT_ID(N'[dbo].[TaskManager_Tasks]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TaskManager_Tasks] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Tag] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [NotificationProfileId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [NotificationType] int  NOT NULL,
  [ActionDisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [NextTime] bigint  NOT NULL,
  [Type] int  NOT NULL,
  [State] int  NOT NULL,
  [Endpoints] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
CREATE NONCLUSTERED INDEX [NCIndex_TaskManager_Tasks_ModifiedOn] ON [dbo].[TaskManager_Tasks]([ModifiedOn] DESC)
END;
GO

IF OBJECT_ID(N'[dbo].[TaskManager_Schedules]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TaskManager_Schedules] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [JobTitle] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [State] int  NOT NULL,
  [ScheduleRule] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [JobAction] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [StartTime] bigint  NOT NULL,
  [NextTime] bigint  NOT NULL,
  [TimeZoneId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [EndType] int  NOT NULL,
  [EndTime] bigint  NOT NULL,
  [EndTimeZoneId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Occurrences] int  NOT NULL,
  [OccurrencesTotal] int  NOT NULL,
  [EmailId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DaylightSavingTimeType] int  NOT NULL,
  [HolidayProfileId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [PickedTimestamp] bigint  NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[TaskManager_ScheduleRelations]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TaskManager_ScheduleRelations] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ScheduleId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [OwnerId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [OwnerType] int  NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[TaskManager_TaskActions]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TaskManager_TaskActions] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [TaskId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [HandlerId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [String1] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [String2] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [String3] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Int1] int  NOT NULL,
  [Int2] int  NOT NULL,
  [Int3] int  NOT NULL,
  [Long1] bigint  NOT NULL,
  [Long2] bigint  NOT NULL,
  [Long3] bigint  NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[TaskManager_TaskGroups]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TaskManager_TaskGroups] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [NextTime] bigint  NOT NULL,
  [State] int  NOT NULL,
  [ContinueOnException] int  NOT NULL,
  [Mode] int  NOT NULL,
  [Type] int  NOT NULL,
  [NotificationProfileId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ActionDisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
CREATE NONCLUSTERED INDEX [NCIndex_TaskManager_TaskGroups_ModifiedOn] ON [dbo].[TaskManager_TaskGroups]([ModifiedOn] DESC)
END;
GO

IF OBJECT_ID(N'[dbo].[TaskManager_TaskGroupSteps]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TaskManager_TaskGroupSteps] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [GroupId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [TaskId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ActionDisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Order] int  NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[TaskManager_TaskActionSettings]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TaskManager_TaskActionSettings] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [DisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [SettingString] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[Job]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Job] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [JobType] int  NOT NULL,
  [EndTime] bigint  NOT NULL,
  [TaskName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [TaskId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [TypeStr] nvarchar(512) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [State] int  NOT NULL,
  [Progress] int  NOT NULL,
  [StartTime] bigint  NOT NULL,
  [FinishTime] bigint  NOT NULL,
  [Stamp] bigint  NOT NULL,
  [JobControl] int  NOT NULL,
  [Comment] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [LocalAddress] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [HostName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Level] int  NOT NULL,
  [TaskGroupId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [TaskGroupName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [JobHandlerId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [NotificationId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [NotificationType] int  NOT NULL,
  [JobDependencies] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ExecuteHostName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Parameters] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
CREATE NONCLUSTERED INDEX [NCIndex_Job_ModifiedOn] ON [dbo].[Job]([ModifiedOn] DESC)
END;
GO

IF OBJECT_ID(N'[dbo].[JobDetail]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[JobDetail] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [JobId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [State] int  NOT NULL,
  [Comment] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [JsonDetail] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DetailContext] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO

CREATE OR ALTER PROC [dbo].[AquireRunnableSchedule]
@Timestamp BIGINT,
@NextRunTime BIGINT
AS
DECLARE @Sql NVARCHAR(2000)
BEGIN TRAN
BEGIN
UPDATE [TaskManager_Schedules] with(TABLOCKX) SET [PickedTimestamp] = @Timestamp WHERE [PickedTimestamp] < @Timestamp - 100000000 AND [NextTime] <@NextRunTime AND [State] = 0
END
BEGIN
SELECT * FROM [TaskManager_Schedules] where [NextTime] <@NextRunTime and [PickedTimestamp] =@Timestamp AND [State] = 0
END
COMMIT TRAN
GO

IF OBJECT_ID(N'[dbo].[HolidaySetting_Profiles]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[HolidaySetting_Profiles] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Connection] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BusinessUnit] nvarchar(512) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Workdays] int  NULL,
  [TimeZoneInfoId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
CREATE NONCLUSTERED INDEX [HolidaySetting_Profiles] ON [dbo].[HolidaySetting_Profiles]([ModifiedOn] DESC)
END;
GO

IF OBJECT_ID(N'[dbo].[HolidaySetting_Holidays]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[HolidaySetting_Holidays] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [HolidayId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Profile] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [TimeZoneInfoId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Type] int  NULL,
  [Year] int  NULL,
  [Month] int  NULL,
  [Day] int  NULL,
  [TimeRange] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [TimeRangeId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[__FTPErrorRecord]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[__FTPErrorRecord] (
  [File] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Number] int  NULL,
  [Data] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Error] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Job] uniqueidentifier  NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[LMS]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[LMS] (
  [CaseRefNumber] nvarchar(40) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [EvaluationCompletionStatus] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [EvaluationCompletionDate] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [EvaluationScore] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [EvaluationStartDateForTBD] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CourseCompletionStatus] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CourseCompletionDate] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [QuizCompletionStatus] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [QuizScore] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [QuizCompletionDate] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [NoofAttemptsForQuiz] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [PGSIRevoke] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CourseRevoke] nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [__JobId] uniqueidentifier  NULL,
  [__FieldCount] smallint  NULL
)
END;


IF OBJECT_ID(N'[dbo].[Notification]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Notification] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [DisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ProtocolType] int  NULL,
  [SyncType] int  NULL,
  [IsDefault] int  NULL,
  [ConnectionId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(512) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(512) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[Transfer_Actions]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Transfer_Actions] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Arguments] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [SchemaXml] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DestType] int  NOT NULL,
  [SourceType] int  NOT NULL,
  [ActionType] int DEFAULT 1 NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[NotificationProfile]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[NotificationProfile] (
[Id] nvarchar(256) NOT NULL ,
[CreatedOn] bigint NOT NULL ,
[CreatedBy] nvarchar(256) NULL ,
[ModifiedOn] bigint NOT NULL ,
[ModifiedBy] nvarchar(256) NULL ,
[Description] nvarchar(1024) NULL ,
[Name] nvarchar(256) NULL ,
[Contact] ntext NULL ,
[ConnectionType] int NULL 
)

END;
GO

IF OBJECT_ID(N'[dbo].[Transfer_Profiles]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Transfer_Profiles] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DataSyncXml] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DataSyncXmlName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DestinationAdapterName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DestinationAdapterId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [MappingDBId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [MappingDBName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ActionId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Confliction] int  NOT NULL,
  [ProfileXml] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [SourceAdapterId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [SourceAdapterName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [SyncOption] int  NOT NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DocumentServiceId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DocumentServiceName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO

IF COL_LENGTH('[dbo].[NotificationProfile]', 'EmailContent') IS NOT NULL BEGIN
   ALTER TABLE [dbo].[NotificationProfile] DROP COLUMN [EmailContent]
END;
GO

IF COL_LENGTH('[dbo].[NotificationProfile]', 'SmsContent') IS NOT NULL BEGIN
   ALTER TABLE [dbo].[NotificationProfile] DROP COLUMN [SmsContent]
END;
GO

IF COL_LENGTH('[dbo].[NotificationProfile]', 'Contact') IS NULL BEGIN
   ALTER TABLE [dbo].[NotificationProfile] ADD [Contact] ntext NULL 
END;
GO

IF COL_LENGTH('[dbo].[NotificationProfile]', 'ConnectionType') IS NULL BEGIN
 ALTER TABLE [dbo].[NotificationProfile] ADD [ConnectionType] int NULL
END;
GO

IF COL_LENGTH('[dbo].[Job]', 'Tag') IS NULL BEGIN
   ALTER TABLE [dbo].[Job] ADD [Tag] nvarchar(100)  NULL 
END;
GO

IF NOT EXISTS(SELECT DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='Job' AND COLUMN_NAME='Comment' AND DATA_TYPE='ntext')
BEGIN
ALTER TABLE [dbo].[Job] ALTER COLUMN [Comment] ntext
END
GO

IF COL_LENGTH('[dbo].[Notification]', 'OnBehalf') IS NULL BEGIN
 ALTER TABLE [dbo].[Notification] ADD [OnBehalf] nvarchar(100) NULL
END;
GO

IF NOT EXISTS ( SELECT * FROM sysindexes WHERE id = object_id( 'Job' ) AND name = 'Index_Job_Id' )
BEGIN
	CREATE UNIQUE CLUSTERED INDEX [Index_Job_Id] ON [dbo].[Job] ([Id])
END;
GO
    
IF NOT EXISTS ( SELECT * FROM sysindexes WHERE id = object_id( 'Job' ) AND name = 'Index_Job_StartTime' )
BEGIN
	CREATE NONCLUSTERED INDEX [Index_Job_StartTime] ON [dbo].[Job] ([StartTime])
END;
GO
    
IF NOT EXISTS ( SELECT * FROM sysindexes WHERE id = object_id( 'Job' ) AND name = 'Index_Job_Tag' )
BEGIN
	CREATE NONCLUSTERED INDEX [Index_Job_Tag] ON [dbo].[Job] ([Tag])
END;

GO
IF NOT EXISTS ( SELECT * FROM sysindexes WHERE id = object_id( 'JobDetail' ) AND name = 'index_JobDetail_Id' )
BEGIN
	CREATE UNIQUE CLUSTERED INDEX [index_JobDetail_Id]ON [dbo].[JobDetail] ([Id])
END;

GO
IF NOT EXISTS ( SELECT * FROM sysindexes WHERE id = object_id( 'Job' ) AND name = 'Index_Job_State' )
BEGIN
	CREATE NONCLUSTERED INDEX [Index_Job_State] ON [dbo].[Job] ([State])
END;
GO
IF NOT EXISTS(select * from sysindexes where id=object_id('JobDetail') and name='index_job_id')
BEGIN
	CREATE NONCLUSTERED INDEX [index_job_id] ON [JobDetail] ([JobId])
END;
GO

IF OBJECT_ID(N'[dbo].[DataPipeline]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[DataPipeline] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ConnManager] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ActionId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ProfileJSON] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ProfileJsonName] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [UniqueName] nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)  
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
END;
GO


IF OBJECT_ID(N'[dbo].[DataPipeline_Actions]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[DataPipeline_Actions] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Description] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Arguments] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [SchemaJson] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ActionType] int DEFAULT 1 NOT NULL,
  [RunnerType] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ConnManager] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  CONSTRAINT [PK__Transfer__3214EC0715A640F0] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
)  
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
END;
GO


IF OBJECT_ID(N'[dbo].[Datamodeling_Corpus]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Datamodeling_Corpus](
	[Id] [nvarchar](256) NOT NULL,
	[CreatedOn] [bigint] NOT NULL,
	[CreatedBy] [nvarchar](256) NULL,
	[ModifiedOn] [bigint] NOT NULL,
	[ModifiedBy] [nvarchar](256) NULL,
	[DisplayName] [nvarchar](256) NULL,
	[UniqueName] [nvarchar](256) NULL,
	[Description] [nvarchar](1024) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[Datamodeling_CorpusFolder]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Datamodeling_CorpusFolder](
	[Id] [nvarchar](256) NOT NULL,
	[CreatedOn] [bigint] NOT NULL,
	[CreatedBy] [nvarchar](256) NULL,
	[ModifiedOn] [bigint] NOT NULL,
	[ModifiedBy] [nvarchar](256) NULL,
	[FolderPath] [nvarchar](1024) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[Datamodeling_Document]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Datamodeling_Document](
	[Id] [nvarchar](256) NOT NULL,
	[CreatedOn] [bigint] NOT NULL,
	[CreatedBy] [nvarchar](256) NULL,
	[ModifiedOn] [bigint] NOT NULL,
	[ModifiedBy] [nvarchar](256) NULL,
	[CorpusId] [nvarchar](256) NULL,
	[FolderId] [nvarchar](256) NULL,
	[Type] [int] NULL,
	[FileName] [nvarchar](1024) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
END;
GO


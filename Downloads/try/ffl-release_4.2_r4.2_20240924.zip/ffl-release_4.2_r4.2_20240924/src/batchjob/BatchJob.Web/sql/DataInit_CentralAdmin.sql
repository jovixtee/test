Declare @DateTime datetime2=GETUTCDATE()
Declare @Ticks bigint= DATEDIFF_BIG( microsecond, '00010101', @DateTime ) * 10 + ( DATEPART( NANOSECOND, @DateTime ) % 1000 ) / 100

INSERT INTO [Privileges]([PrivilegeId],[CreatedOn],[CreatedBy],[ModifiedOn],[ModifiedBy],[Name],[DepthMask],[ObjectCode],[Description])
VALUES (NEWID(),@Ticks,'System',@Ticks,'System','Account Service',15,101001,null)

INSERT INTO [Privileges]([PrivilegeId],[CreatedOn],[CreatedBy],[ModifiedOn],[ModifiedBy],[Name],[DepthMask],[ObjectCode],[Description])
VALUES (NEWID(),@Ticks,'System',@Ticks,'System','Connections',15,102001,null)

INSERT INTO [Privileges]([PrivilegeId],[CreatedOn],[CreatedBy],[ModifiedOn],[ModifiedBy],[Name],[DepthMask],[ObjectCode],[Description])
VALUES (NEWID(),@Ticks,'System',@Ticks,'System','Security Service',15,103001,null)

INSERT INTO [Privileges]([PrivilegeId],[CreatedOn],[CreatedBy],[ModifiedOn],[ModifiedBy],[Name],[DepthMask],[ObjectCode],[Description])
VALUES (NEWID(),@Ticks,'System',@Ticks,'System','Task Manager',15,201001,null)

INSERT INTO [Privileges]([PrivilegeId],[CreatedOn],[CreatedBy],[ModifiedOn],[ModifiedBy],[Name],[DepthMask],[ObjectCode],[Description])
VALUES (NEWID(),@Ticks,'System',@Ticks,'System','Job Monitor',15,202001,null)

INSERT INTO [Privileges]([PrivilegeId],[CreatedOn],[CreatedBy],[ModifiedOn],[ModifiedBy],[Name],[DepthMask],[ObjectCode],[Description])
VALUES (NEWID(),@Ticks,'System',@Ticks,'System','Holiday Settings',15,203001,null)

Declare @TenantId nvarchar(256)='238df12e-a6e3-48fa-9f35-4cbce1c27ca4'
IF NOT EXISTS (SELECT * FROM [dbo].[Tenants] WHERE [Id] = @tenantId)
BEGIN
   -- INSERT HERE
   INSERT INTO [dbo].[Tenants]
           ([Id]
           ,[CreatedOn]
           ,[CreatedBy]
           ,[ModifiedOn]
           ,[ModifiedBy]
           ,[Name]
           ,[Status]
           ,[DbSchema]
           ,[DbUser]
           ,[DbPassword])
     VALUES
           (@TenantId
           ,@Ticks
           ,'System'
           ,@Ticks
           ,'System'
           ,'AdminTenant'
           ,0
           ,'dbo'
           ,'sa'
           ,'qt/OtVwwTU5bwO5HubVvCT68iSCwEY2cdHnOa2QZClk=')
END

Declare @AdminId nvarchar(256)='fd847d3b-e893-4c8e-8946-5fe9a8ab6760'
IF NOT EXISTS (SELECT * FROM [dbo].[TenantUsers] WHERE [Id] = @adminId)
BEGIN
INSERT INTO [dbo].[TenantUsers]([Id],[CreatedOn],[CreatedBy],[ModifiedOn],[ModifiedBy],[DisplayName],[TenantId],[Email],[Description],[Username],[Authentication],[Password],[UserRole],[Status])
     VALUES (@AdminId,@Ticks,'System',@Ticks,'System','admin',@TenantId,'admin@admin.com','default user','admin',1,'qt/OtVwwTU5bwO5HubVvCT68iSCwEY2cdHnOa2QZClk=',1,1)
END


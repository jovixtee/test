
IF OBJECT_ID(N'[dbo].[APIManage_API]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_API] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
ALTER TABLE [dbo].[APIManage_API] ADD CONSTRAINT [PK_APIManage_API] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO



IF OBJECT_ID(N'[dbo].[APIManage_APIAuthentication]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_APIAuthentication] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [AuthSetting] varchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Cert] varbinary(max)  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [AuthType] int  NULL,
  [FromType] int  NULL,
  [Certificate] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)

ALTER TABLE [dbo].[APIManage_APIAuthentication] ADD CONSTRAINT [PK__APIManag__3214EC0787E2A7C0] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO


IF OBJECT_ID(N'[dbo].[APIManage_APIHistory]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_APIHistory] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [FrontendName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Node] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Method] nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Header] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Body] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BackendName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BackendMethod] nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BackendHeader] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BackendBody] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Status] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Credential] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [IncomeTimestamp] bigint  NOT NULL,
  [OutgoTimestamp] bigint  NOT NULL,
  [RequestMessage] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ReponseMessage] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
CREATE NONCLUSTERED INDEX [NCIndex_APIManage_APIHistory_ModifiedOn]
ON [dbo].[APIManage_APIHistory] (
  [IncomeTimestamp] DESC
)
END;
GO

IF COL_LENGTH('[dbo].[APIManage_APIHistory]', 'Tag') IS NULL BEGIN
   ALTER TABLE [dbo].[APIManage_APIHistory] ADD [Tag] nvarchar(100) NULL 
END;
GO

IF NOT EXISTS(SELECT CHARACTER_MAXIMUM_LENGTH FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='APIManage_APIHistory' AND COLUMN_NAME='BackendName' AND CHARACTER_MAXIMUM_LENGTH < 2000)
BEGIN
   ALTER TABLE [dbo].[APIManage_APIHistory] ALTER COLUMN [BackendName] nvarchar(2000) 
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_APIMethod]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_APIMethod] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [LocalName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Path] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [MethodName] int  NOT NULL,
  [MethodType] int  NULL,
  [VersionID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Description] nvarchar(2048) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
ALTER TABLE [dbo].[APIManage_APIMethod] ADD CONSTRAINT [PK__APIManag__3214EC077A9A39AE] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_APIPipeline]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_APIPipeline] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [FrontendID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [BackendID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [FrondendVersionID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [BackendVersionID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [FrontendAuthID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BackendAuthID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [FrontendPolicyID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BackendPolicyID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_APIVersion]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_APIVersion] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [DisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [LocalName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Status] int  NOT NULL,
  [FrontendID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BackendID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Endpoint] nvarchar(2048) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Scheme] int  NULL,
  [BaseAddress] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(2048) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [AuthenticationID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ControlPolicyID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
ALTER TABLE [dbo].[APIManage_APIVersion] ADD CONSTRAINT [PK__APIManag__3214EC07E1A96B08] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF COL_LENGTH('[dbo].[APIManage_APIVersion]', 'Tag') IS NULL BEGIN
   ALTER TABLE [dbo].APIManage_APIVersion ADD [Tag] nvarchar(100) NULL 
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_BackendAPI]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_BackendAPI] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [BaseAddress] nvarchar(2048) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Protocol] int  NOT NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)

CREATE NONCLUSTERED INDEX [NCIndex_APIManage_BackendAPI_ModifiedOn]
ON [dbo].[APIManage_BackendAPI] (
  [ModifiedOn] DESC
)
ALTER TABLE [dbo].[APIManage_BackendAPI] ADD CONSTRAINT [PK__APIManag__3214EC073269A1F8] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_ControlPolicy]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_ControlPolicy] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Notification] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
CREATE NONCLUSTERED INDEX [NCIndex_APIManage_ControlPolicy_ModifiedOn]
ON [dbo].[APIManage_ControlPolicy] (
  [ModifiedOn] DESC
)
ALTER TABLE [dbo].[APIManage_ControlPolicy] ADD CONSTRAINT [PK__APIManag__3214EC0785F0384F] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_ControlPolicyRule]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_ControlPolicyRule] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [RuleType] int  NOT NULL,
  [SN] int  NOT NULL,
  [PolicyID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ExtensionJSON] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
ALTER TABLE [dbo].[APIManage_ControlPolicyRule] ADD CONSTRAINT [PK__APIManag__3214EC071668889F] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_FrontendAPI]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_FrontendAPI] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [NodeID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BaseAddress] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
CREATE NONCLUSTERED INDEX [NCIndex_APIManage_FrontendAPI_ModifiedOn]
ON [dbo].[APIManage_FrontendAPI] (
  [ModifiedOn] DESC
)
ALTER TABLE [dbo].[APIManage_FrontendAPI] ADD CONSTRAINT [PK__APIManag__3214EC071BB234B1] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_MethodHeader]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_MethodHeader] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [MethodID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Type] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [DefaultValue] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_MethodParameter]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_MethodParameter] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [MethodID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ParamterType] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [DefaultValue] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
ALTER TABLE [dbo].[APIManage_MethodParameter] ADD CONSTRAINT [PK__APIManag__3214EC071B949D63] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_MethodRelationship]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_MethodRelationship] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [FrontendID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [BackendID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [FrontendMethodID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [BackendMethodID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
ALTER TABLE [dbo].[APIManage_MethodRelationship] ADD CONSTRAINT [PK__APIManag__3214EC07F3A5BC33] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_Node]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_Node] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Host] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [HostName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Schema] nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Port] int  NULL,
  [Status] int  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
CREATE NONCLUSTERED INDEX [NCIndex_APIManage_Node_ModifiedOn]
ON [dbo].[APIManage_Node] (
  [ModifiedOn] DESC
)
ALTER TABLE [dbo].[APIManage_Node] ADD CONSTRAINT [PK__APIManag__3214EC07B28D5F8A] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[APIManage_NodeRelationship]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_NodeRelationship] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [VersionID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [NodeID] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
ALTER TABLE [dbo].[APIManage_NodeRelationship] ADD CONSTRAINT [PK_APIManage_NodeRelationship] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO
 

IF OBJECT_ID(N'[dbo].[APIManage_ParameterType]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[APIManage_ParameterType] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ExtensionJSON] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [FrontendId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [BackendId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
ALTER TABLE [dbo].[APIManage_ParameterType] ADD CONSTRAINT [PK__APIManag__3214EC07F79CF752] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO


IF OBJECT_ID(N'[dbo].[ConnectionAdapter]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[ConnectionAdapter] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [AdapterName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Status] int  NOT NULL,
  [AdapterSetting] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [AdapterType] int  NOT NULL,
  [DestinationInfo] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
CREATE NONCLUSTERED INDEX [NCIndex_ConnectionAdapter_ModifiedOn]
ON [dbo].[ConnectionAdapter] (
  [ModifiedOn] DESC
)
ALTER TABLE [dbo].[ConnectionAdapter] ADD CONSTRAINT [PK__Connecti__3214EC0725031162] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[SecuritySetting]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[SecuritySetting] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CryptoType] int  NOT NULL,
  [SecretKeyInfo] nvarchar(2048) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [IsDefault] bit  NOT NULL,
  [IsDelete] bit  NOT NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
ALTER TABLE [dbo].[SecuritySetting] ADD CONSTRAINT [PK__Security__3214EC073D9497C8] PRIMARY KEY CLUSTERED ([Id])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF OBJECT_ID(N'[dbo].[SPPLScreen]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[SPPLScreen] (
  [RecordType] nvarchar(1) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [NRICorFIN] nvarchar(9) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [PassportNo] nvarchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ActiveExclusion] nvarchar(1) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [__JobId] uniqueidentifier  NULL,
  [__FieldCount] smallint  NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[sysdiagrams]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[sysdiagrams] (
  [name] sysname  NOT NULL,
  [principal_id] int  NOT NULL,
  [diagram_id] int  IDENTITY(1,1) NOT NULL,
  [version] int  NULL,
  [definition] varbinary(max)  NULL
)
ALTER TABLE [dbo].[sysdiagrams] ADD CONSTRAINT [UK_principal_name] UNIQUE NONCLUSTERED ([principal_id] ASC, [name] ASC)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)  
ON [PRIMARY]
END;
GO

IF NOT EXISTS ( SELECT * FROM sysindexes WHERE id = object_id( 'APIManage_APIHistory' ) AND name = 'NCIndex_APIManage_APIHistory_Tag' )
BEGIN
	CREATE NONCLUSTERED INDEX [NCIndex_APIManage_APIHistory_Tag] ON [dbo].[APIManage_APIHistory] ( [Tag] )
END;
GO
IF NOT EXISTS ( SELECT * FROM sysindexes WHERE id = object_id( 'APIManage_APIHistory' ) AND name = 'index_histoty_id' )
BEGIN
	CREATE UNIQUE CLUSTERED INDEX [index_histoty_id] ON [dbo].[APIManage_APIHistory] ([Id])
END;
GO
IF NOT EXISTS ( SELECT * FROM sysindexes WHERE id = object_id( 'APIManage_APIHistory' ) AND name = 'NCIndex_APIManage_APIHistory_Tag' )
BEGIN
	CREATE NONCLUSTERED INDEX [NCIndex_APIManage_APIHistory_Tag] ON [APIManage_APIHistory] ( [Tag] )
END;
GO
IF NOT EXISTS ( SELECT * FROM sysindexes WHERE id = object_id( 'APIManage_APIHistory' ) AND name = 'index_histoty_start' )
BEGIN
	CREATE NONCLUSTERED INDEX [index_histoty_start] ON [APIManage_APIHistory] ( [IncomeTimestamp] )
END;
GO
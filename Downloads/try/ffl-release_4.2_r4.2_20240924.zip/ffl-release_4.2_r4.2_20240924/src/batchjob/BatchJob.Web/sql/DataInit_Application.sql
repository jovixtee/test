Declare @DateTime datetime2=GETUTCDATE()
Declare @Ticks bigint= DATEDIFF_BIG( microsecond, '00010101', @DateTime ) * 10 + ( DATEPART( NANOSECOND, @DateTime ) % 1000 ) / 100

INSERT INTO [SecuritySetting]([Id],[Name],[CryptoType],[SecretKeyInfo],[IsDefault],[IsDelete],[Description],[CreatedOn],[CreatedBy],[ModifiedOn],[ModifiedBy])
VALUES (LOWER(NEWID()),'KeyVaultConfig',2,'<?xml version="1.0" encoding="utf-16"?>
<KeyVaultConfig xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <Name>DBP3Dev</Name>
  <ClientId>281e6b00-c1c6-4f33-b2e8-97e2e191be51</ClientId>
  <ClientSecret>K_0~W-Pq94gowI3Dn1p3Yzk73z2_rnoQMn</ClientSecret>
  <KeyIdentity>https://dbp3dev.vault.azure.net/keys/DBP3Key/dba98cb4adac4a7e94d4ceccdfbe6cf4</KeyIdentity>
</KeyVaultConfig>',1,0,'',@Ticks,'Administrator',@Ticks,'Administrator')

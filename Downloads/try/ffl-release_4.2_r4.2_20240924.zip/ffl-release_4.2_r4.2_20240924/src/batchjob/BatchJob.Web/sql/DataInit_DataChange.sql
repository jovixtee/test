MERGE INTO Transfer_Actions AS a USING (
	SELECT 'DataSyncJob.Runner' AS Id,'DataSyncJob'  AS Name,'DataSyncJob'  AS DisplayName,'' AS Arguments,'' AS SchemaXml,'6' AS DestType,'6' AS SourceType,'2' AS ActionType UNION ALL
	SELECT 'DocumentSecurity.Runner' AS Id,'DocumentSecurity'  AS Name,'DocumentSecurity'  AS DisplayName,'' AS Arguments,'' AS SchemaXml,'6' AS DestType,'6' AS SourceType,'2' AS ActionType UNION ALL
	SELECT 'DocumentSyncJob.Runner' AS Id,'DocumentSyncJob'  AS Name,'DocumentSyncJob'  AS DisplayName,'' AS Arguments,'' AS SchemaXml,'6' AS DestType,'6' AS SourceType,'2' AS ActionType
) AS b ON a.Id = b.Id
WHEN Matched THEN
	UPDATE
		SET 
			a.Name=b.Name,
			a.DisplayName=b.DisplayName,
			a.Arguments=b.Arguments,
			a.SchemaXml=b.SchemaXml,
			a.DestType=b.DestType,
			a.SourceType=b.SourceType,
			a.ActionType=b.ActionType
WHEN NOT Matched THEN
	INSERT (
			Id,
			Name,
			DisplayName,
			Arguments,
			SchemaXml,
			DestType,
			SourceType,
			ActionType
			)
	VALUES
		(
			b.Id,
			b.Name,
			b.DisplayName,
			b.Arguments,
			b.SchemaXml,
			b.DestType,
			b.SourceType,
			b.ActionType
		);
GO

IF NOT EXISTS (SELECT * FROM [TaskManager_TaskActionSettings] WHERE [Id] = N'Transfer.JobHandler.TransferJobHandler')
BEGIN
INSERT INTO TaskManager_TaskActionSettings([Id],[DisplayName],[SettingString]) values(N'Transfer.JobHandler.TransferJobHandler',N'Data Transfer',N'[{"Key":"transfer argument","Label":"Transfer Profile","Type":1,"ItemsSourceLink":"/ITransferService/GetTaskManagerElements"}]')
END

GO

IF NOT EXISTS (SELECT * FROM [TaskManager_TaskActionSettings] WHERE [Id] = N'DataPipeline.JobHandler.DataPipelineJobHandler')
BEGIN
INSERT INTO TaskManager_TaskActionSettings([Id],[DisplayName],[SettingString]) values(N'DataPipeline.JobHandler.DataPipelineJobHandler',N'Replicator Pipline',N'[{"Key":"Replicator Pipline Profiles","Label":"Replicator Pipline Profiles","Type":1,"ItemsSourceLink":"/IReplicatorsService/GetPipline","Data": {}}]')
END

GO

IF NOT EXISTS (SELECT * FROM [TaskManager_TaskActionSettings] WHERE [Id] = N'Replicator.JobHandler.ReplicatorJobHandler')
BEGIN
INSERT INTO TaskManager_TaskActionSettings([Id],[DisplayName],[SettingString]) values(N'Replicator.JobHandler.ReplicatorJobHandler',N'Replicator Plan',N'[{"Key":"Replicator Plan Profiles","Label":"Replicator Plan Profiles","Type":1,"ItemsSourceLink":"/IReplicatorsService/GetPlan","Data": {}}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.DataSyncTask.DataSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_Data_Sync_Event','FFL_Data_Sync_Event',null,null, '1', 'FFL.DataSyncTask.DataSyncRunner','[{"ConnectionName":"SQLSERVER","ConnectionType":0},{"ConnectionName":"Web","ConnectionType":6},{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.DocumentSyncTask.DocumentSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_Document_Sync_Event','FFL_Document_Sync_Event',null,null, '1', 'FFL.DocumentSyncTask.DocumentSyncRunner','[{"ConnectionName":"Web","ConnectionType":6},{"ConnectionName":"SFTP","ConnectionType":2}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.EventSubmissionEmailTrigger.EventSubmissionEmailRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_Event_Submission_Email_Event','FFL_Event_Submission_Email_Event',null,null, '1', 'FFL.EventSubmissionEmailTrigger.EventSubmissionEmailRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.UserStatusSync.UserStatusSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_UserStatus_Sync_Event','FFL_UserStatus_Sync_Event',null,null, '1', 'FFL.UserStatusSync.UserStatusSyncRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.UserRoleSync.UserRoleSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_UserRole_Sync_Event','FFL_UserRole_Sync_Event',null,null, '1', 'FFL.UserRoleSync.UserRoleSyncRunner','[{"ConnectionName":"Web","ConnectionType":6},{"ConnectionName":"SFTP","ConnectionType":2}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.NewsletterEmailTask.NewsletterEmailRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_Newsletter_Email_Event','FFL_Newsletter_Email_Event',null,null, '1', 'FFL.NewsletterEmailTask.NewsletterEmailRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.NewsletterEmailEnhanceTask.NewsletterEmailEnhanceRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_Newsletter_Email_Enhance_Event','FFL_Newsletter_Email_Enhance_Event',null,null, '1', 'FFL.NewsletterEmailEnhanceTask.NewsletterEmailEnhanceRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.ErrorTrackEmailTask.ErrorTrackEmailRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_ErrorTrack_Email_Event','FFL_ErrorTrack_Email_Event',null,null, '1', 'FFL.ErrorTrackEmailTask.ErrorTrackEmailRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.DataCleanTask.DataCleanTaskRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_DataClean_Task_Event','FFL_DataClean_Task_Event',null,null, '1', 'FFL.DataCleanTask.DataCleanTaskRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.ParentingMessageSyncTask.ParentingMessageSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_ParentingMessageSync_Task_Event','FFL_ParentingMessageSync_Task_Event',null,null, '1', 'FFL.ParentingMessageSyncTask.ParentingMessageSyncRunner','[{"ConnectionName":"Web","ConnectionType":6}, {"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.ParentingMessageDeathSyncTask.ParentingMessageDeathSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_ParentingMessageDeathSync_Task_Event','FFL_ParentingMessageDeathSync_Task_Event',null,null, '1', 'FFL.ParentingMessageDeathSyncTask.ParentingMessageDeathSyncRunner','[{"ConnectionName":"Web","ConnectionType":6}, {"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.ParentingMessageSMSTask.ParentingMessageSMSRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_ParentingMessageSMS_Task_Event','FFL_ParentingMessageSMS_Task_Event',null,null, '1', 'FFL.ParentingMessageSMSTask.ParentingMessageSMSRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.DataSyncTask.AuditDataSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_Audit_Data_Sync_Event','FFL_Audit_Data_Sync_Event',null,null, '1', 'FFL.DataSyncTask.AuditDataSyncRunner','[{"ConnectionName":"SQLSERVER","ConnectionType":0},{"ConnectionName":"Web","ConnectionType":6},{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.BSGDataSyncTask.BSGDataSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values(NEWID(), 'FFL_BSGDataSync_Task_Event', 'FFL_BSGDataSync_Task_Event', NULL, NULL, '1', 'FFL.BSGDataSyncTask.BSGDataSyncRunner', '[{"ConnectionName":"Web","ConnectionType":6}, {"ConnectionName":"Web","ConnectionType":6}]')
END

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.ProgrammeSettingsSyncTask.ProgrammeSettingsSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values(NEWID(), 'FFL_ProgrammeSettingsSync_Task_Event', 'FFL_ProgrammeSettingsSync_Task_Event', NULL, NULL, '1', 'FFL.ProgrammeSettingsSyncTask.ProgrammeSettingsSyncRunner', '[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.DashboardDataGeneratingTask.DashboardDataGeneratingRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_DashboardDataGenerating_Event','FFL_DashboardDataGenerating_Event',null,null, '1', 'FFL.DashboardDataGeneratingTask.DashboardDataGeneratingRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.VisitDashboardSyncTask.VisitDashboardSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_VisitDashboardSync_Task_Event','FFL_VisitDashboardSync_Task_Event',null,null, '1', 'FFL.VisitDashboardSyncTask.VisitDashboardSyncRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.NotCompletedQuizEmail.NotCompletedQuizEmailRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_NotCompletedQuizEmail_Task_Event','FFL_NotCompletedQuizEmail_Task_Event',null,null, '1', 'FFL.NotCompletedQuizEmail.NotCompletedQuizEmailRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.CommonNotificationEmailTask.CommonNotificationEmailRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_CommonNotificationEmail_Task_Event','FFL_CommonNotificationEmail_Task_Event',null,null, '1', 'FFL.CommonNotificationEmailTask.CommonNotificationEmailRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.RegionMappingSyncTask.RegionMappingSyncRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values(NEWID(), 'FFL_RegionMappingSync_Task_Event', 'FFL_RegionMappingSync_Task_Event', NULL, NULL, '1', 'FFL.RegionMappingSyncTask.RegionMappingSyncRunner', '[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF NOT EXISTS (SELECT * FROM [DataPipeline_Actions] WHERE [RunnerType] = N'FFL.WrongPostalCodeNotificationEmailTask.WrongPostalCodeNotificationEmailRunner')
BEGIN
INSERT INTO [DataPipeline_Actions] ([Id],[Description],[DisplayName],[Arguments],[SchemaJson],[ActionType],[RunnerType],[ConnManager]) values (NEWID(), 'FFL_WrongPostalCodeNotificationEmail_Task_Event','FFL_WrongPostalCodeNotificationEmail_Task_Event',null,null, '1', 'FFL.WrongPostalCodeNotificationEmailTask.WrongPostalCodeNotificationEmailRunner','[{"ConnectionName":"Web","ConnectionType":6}]')
END

GO

IF OBJECT_ID(N'[dbo].[Global_Settings]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Global_Settings] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [GlobalType] int  NULL,
  [ProfileJson] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;

GO

MERGE INTO TaskManager_TaskActionSettings AS a USING (
	SELECT 'CleanUp.JobHandler.CleanUpJobHandler' AS Id,'Job Retention' AS DisplayName,'[{"Key":"Job Retention","Label":"Job Retention","Type":1,"ItemsSourceLink":"/INotificationService/QueryProfileByConnType","Data": {"protocolType":3}}]' AS SettingString
	)
 AS b ON a.Id = b.Id
WHEN Matched THEN
	UPDATE
		SET 
			a.DisplayName=b.DisplayName,
			a.SettingString=b.SettingString
WHEN NOT Matched THEN
	INSERT (
			Id,
			DisplayName,
			SettingString
		)
	VALUES
			(
			b.Id,
			b.DisplayName,
			b.SettingString
		);

GO

IF NOT EXISTS (SELECT * FROM [Global_Settings] WHERE [Id] = N'fe5ade65-312a-4198-ba6e-0419a5cc9b4f')
BEGIN
    MERGE INTO Global_Settings AS a USING ( SELECT 'fe5ade65-312a-4198-ba6e-0419a5cc9b4f' AS Id, '0' AS GlobalType, '{"days":"14","status":126}' AS ProfileJson ) AS b ON a.Id = b.Id
WHEN Matched THEN
UPDATE 
        SET a.GlobalType= b.GlobalType,
        a.ProfileJson= b.ProfileJson 
        WHEN NOT Matched THEN
        INSERT ( Id, GlobalType, ProfileJson )
VALUES
        ( b.Id, b.GlobalType, b.ProfileJson );
END

GO

IF EXISTS ( SELECT * FROM TenantUsers WHERE DisplayName = 'System Admin' ) BEGIN
	UPDATE TenantUsers 
	SET DisplayName = 'System Service Account'
	WHERE
	DisplayName = 'System Admin';
END;

GO
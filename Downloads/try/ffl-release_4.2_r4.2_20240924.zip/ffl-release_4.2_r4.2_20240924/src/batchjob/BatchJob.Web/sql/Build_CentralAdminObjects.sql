IF OBJECT_ID(N'[dbo].[Migration]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Migration] (
  [Id] int  IDENTITY(1,1) NOT NULL,
  [ContextName] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModelJson] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Timestamp] bigint  NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[TenantDbs]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TenantDbs] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Server] nvarchar(512) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Port] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DbName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DbContextName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[Tenants]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Tenants] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Status] int  NOT NULL,
  [DbSchema] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DbUser] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DbPassword] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
);
END;
GO

IF OBJECT_ID(N'[dbo].[TenantUsers]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TenantUsers] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DisplayName] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [TenantId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Password] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Email] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Status] int  NOT NULL,
  [Username] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [Authentication] int  NOT NULL,
  [UserRole] int  NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[TenantDbRelations]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[TenantDbRelations] (
  [TenantDbId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [TenantId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[UserRoles]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[UserRoles] (
  [UserRoleId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [UserId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [RoleId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[Roles]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Roles] (
  [RoleId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [TenantId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[RolePrivileges]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[RolePrivileges] (
  [RolePrivilegeId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [PrivilegeId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [RoleId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [AccessRight] int  NULL
)
END;
GO

IF OBJECT_ID(N'[dbo].[Privileges]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Privileges] (
  [PrivilegeId] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [CreatedOn] bigint  NOT NULL,
  [CreatedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [ModifiedOn] bigint  NOT NULL,
  [ModifiedBy] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [Name] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
  [DepthMask] int  NULL,
  [ObjectCode] int  NULL,
  [Description] nvarchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO

IF COL_LENGTH('[dbo].[TenantUsers]', 'LoginErrorCount') IS NULL BEGIN
   ALTER TABLE [dbo].[TenantUsers] ADD [LoginErrorCount] int NOT NULL DEFAULT 0 
END;
GO

IF COL_LENGTH('[dbo].[TenantUsers]', 'LoginErrorOn') IS NULL BEGIN
   ALTER TABLE [dbo].[TenantUsers] ADD [LoginErrorOn] bigint DEFAULT 0 NOT NULL
END;
GO

IF OBJECT_ID(N'[dbo].[Global_Settings]', N'U') IS NULL BEGIN
CREATE TABLE [dbo].[Global_Settings] (
  [Id] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
  [GlobalType] int  NULL,
  [ProfileJson] ntext COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
)
END;
GO
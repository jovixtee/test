/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using AccountManagerService.Core;
using APIManager.Domain.Dao;
using ConnectionAdapterService.Common;
using Framework.MarsDatabase;
using Framework.MarsDatabase.Context;
using Framework.MarsDatabase.Partial;
using Framework.MarsDatabase.Web;
using HolidaySetting.Domain.Common;
using JobManager.Domain.Common;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NLog.Web;
using NotificationService.Core;
using Replicator.Domain.Common;
using SecuritySetting.Domain.Core;
using TaskManager.Domain;
using Transfer.Domain.Dao;
using FFL.BatchJob.Common.Options;
using FFL.BatchJob.Common.Security.AwsSecretManager;
using System;

namespace DataBroker.Web
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseKestrel();
                    webBuilder.UseNLog();
                    webBuilder.UseMarsDatabase(BuildDbContextOptions());

                    webBuilder.ConfigureAppConfiguration((hostingContext, config) =>
                    {
                        //config.AddEnvironmentVariables("FFLBatchJobWebApplication_");

                        var securityOptions = new SecurityOptions();
                        var configration = config.Build();
                        configration.GetSection("SecurityOptions").Bind(securityOptions);
                        if (securityOptions.AwsSecretManagerOptions != null)
                        {
                            config.AddAmazonSecretsManager(securityOptions.AwsSecretManagerOptions.Region,
                                securityOptions.AwsSecretManagerOptions.SecretName.Split(','),
                                securityOptions.AwsSecretManagerOptions.AccessKey,
                                securityOptions.AwsSecretManagerOptions.SecretKey,
                                configration["AWS_WEB_IDENTITY_TOKEN_FILE"]?.ToString(),
                                configration["AWS_ROLE_ARN"]?.ToString());
                        }

                    }).UseStartup<Startup>();
                    //webBuilder.UseStartup<Startup>();
                }).ConfigureServices((hostContext, services) =>
                {
                    services.AddHostedService<Worker>();
                });

        private const string AppServiceContext = "AppServiceContext";
        private const string JobManagerContext = "JobManagerContext";

        private static MarsDbContextOptions BuildDbContextOptions()
        {
            MarsDbContextOptions options = new MarsDbContextOptions();

            options.Settings.Add(MarsDbConstants.CentralDbContext, new MarsDbContextSetting() { ContextName = MarsDbConstants.CentralDbContext, IsPartial = true, IsTenancy = false });
            options.Settings.Add(AppServiceContext, new MarsDbContextSetting() { ContextName = AppServiceContext, IsPartial = true, IsTenancy = false });
            options.Settings.Add(JobManagerContext, new MarsDbContextSetting() { ContextName = JobManagerContext, IsPartial = true, IsTenancy = false });

            options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(ICentralPartialContext), typeof(CentralPartialContext));

            #region Application Part
            options.Settings[AppServiceContext].PartialContextDic.Add(typeof(IAccountPartialContext), typeof(AccountPartialContext));
            options.Settings[AppServiceContext].PartialContextDic.Add(typeof(IAdapterPartialContext), typeof(AdapterPartialContext));
            options.Settings[AppServiceContext].PartialContextDic.Add(typeof(ISecurityPartialContext), typeof(SecurityPartialContext));
            options.Settings[AppServiceContext].PartialContextDic.Add(typeof(INotificationPartialContext), typeof(NotificationPartialContext));
            options.Settings[AppServiceContext].PartialContextDic.Add(typeof(IAPIManagementDbContext), typeof(APIManagementDbContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(IAccountPartialContext), typeof(AccountPartialContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(IAdapterPartialContext), typeof(AdapterPartialContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(ISecurityPartialContext), typeof(SecurityPartialContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(INotificationPartialContext), typeof(NotificationPartialContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(IAPIManagementDbContext), typeof(APIManagementDbContext));
            #endregion

            #region Job Service Part
            options.Settings[JobManagerContext].PartialContextDic.Add(typeof(ITaskPartialContext), typeof(TaskPartialContext));
            options.Settings[JobManagerContext].PartialContextDic.Add(typeof(IJobPartialContext), typeof(JobDbContextConstraint));
            options.Settings[JobManagerContext].PartialContextDic.Add(typeof(IHolidaySettingPartialDbContext), typeof(HolidaySettingDbContext));
            options.Settings[JobManagerContext].PartialContextDic.Add(typeof(ITransferDbContext), typeof(TransferDbContext));
            options.Settings[JobManagerContext].PartialContextDic.Add(typeof(IGlobalSettingPartialContext), typeof(GlobalSettingPartialContext));
            options.Settings[JobManagerContext].PartialContextDic.Add(typeof(DataPipelinePartialContext), typeof(DataModelingPartialContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(ITaskPartialContext), typeof(TaskPartialContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(IJobPartialContext), typeof(JobDbContextConstraint));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(IHolidaySettingPartialDbContext), typeof(HolidaySettingDbContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(ITransferDbContext), typeof(TransferDbContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(IGlobalSettingPartialContext), typeof(GlobalSettingPartialContext));
            //options.Settings[MarsDbConstants.CentralDbContext].PartialContextDic.Add(typeof(DataPipelinePartialContext), typeof(DataModelingPartialContext));
            #endregion

            return options;
        }
    }
}
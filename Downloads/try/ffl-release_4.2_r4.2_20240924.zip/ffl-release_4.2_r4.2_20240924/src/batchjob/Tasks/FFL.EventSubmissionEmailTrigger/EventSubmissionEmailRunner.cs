﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using APM.SDK;
using PipelineJob.Base;
using Replicator.Interface.Model;
using Replicator.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using APM.SDK.Messages;
using Job.Interface;
using System.Net.Http;
using Microsoft.Extensions.Logging;
using APM.SDK.Services;

namespace FFL.EventSubmissionEmailTrigger
{
    public class EventSubmissionEmailRunner : PipelineJobRunner
    {
        private APMClient2 _APMClient;
        private CancellationToken _cancellationToken;
        private readonly ILogger _logger;
        private string jobId { get; set; }

        const string SERVICEPATHEvent = "api/v1/eventemailadminapi/SendSubmissionSuccessEmail"; // apm service path
        const string SERVICEPATHVolunteer = "api/v1/volunteerstoryemailapi/SendStoryPublishSuccessEmail"; // apm service path
        const string SERVICEPATHNewsletter = "api/v1/subscriptionemailapi/SendSubscriptionSuccessEmail"; // apm service path
        const string SERVICEPATHFamilyProgrammeInterest = "/api/v1/programmeinterestemailapi/sendemail"; // apm service path
        const string SERVICEPATHQuiz = "api/v1/quizemail/sendemail"; // apm service path

        public EventSubmissionEmailRunner(            
            JobExecutionContext jobContext,
            IReplicatorsService replicatorsService,
            CancellationToken cancellationToken,
            List<ConnectionAdapter> adapters) : base(jobContext, replicatorsService, cancellationToken, adapters)
        {
            //_APMClient = CreateAPMService(adapters[0]);
            _cancellationToken = cancellationToken;
            _logger = jobContext.LoggerFactory.CreateLogger(typeof(EventSubmissionEmailRunner).FullName);
            jobId = jobContext.Job.Name;
            _logger.LogWarning($"Job id:{jobId}");

            
            var config = adapters[0];
            _APMClient = new APMClient2(new APMSettings
            {
                AuthEndpoint = config.Parameters["authority"],
                ClientId = config.Parameters["clientid"],
                Secret = config.Parameters["secret"],
                ServiceEndpoint = config.ConnectionStr.StartsWith("WebUrl=", StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(7) : config.ConnectionStr
            });
        }

        //private APMClient CreateAPMService(ConnectionAdapter config)
        //{
        //    return new APMClient(new APMSettings
        //    {
        //        AuthEndpoint = config.Parameters["authority"],
        //        ClientId = config.Parameters["clientid"],
        //        Secret = config.Parameters["secret"],
        //        ServiceEndpoint = config.ConnectionStr.StartsWith("WebUrl=", StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(7) : config.ConnectionStr
        //    });
        //}

        public override void Run()
        {
            _logger.LogInformation($"Email trigger job start.");
            UpsertJobDetail($"Start run email trigger job: {ExeContext.Job.Id}", JobState.Starting);
            try
            {
                UpsertJobDetail($"Start run email trigger job event: {ExeContext.Job.Id}", JobState.InProgress);
                var apmResponse = _APMClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATHEvent, Method = HttpMethod.Post });
                _logger.LogInformation($"email trigger job event: {apmResponse}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"User status sync job event failed. {ex}");
                UpsertJobDetail($"Run email trigger event job: {ExeContext.Job.Id}", JobState.Failed);
            }

            try
            {
                UpsertJobDetail($"Start run email trigger job volunteer: {ExeContext.Job.Id}", JobState.InProgress);
                var apmResponse = _APMClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATHVolunteer, Method = HttpMethod.Post });
                _logger.LogInformation($"email trigger job volunteer: {apmResponse}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"User status sync job volunteer failed. {ex}");
                UpsertJobDetail($"Run email trigger volunteer job: {ExeContext.Job.Id}", JobState.Failed);
            }

            try
            {
                UpsertJobDetail($"Start run email trigger job newsletter: {ExeContext.Job.Id}", JobState.InProgress);
                var apmResponse = _APMClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATHNewsletter, Method = HttpMethod.Post });
                _logger.LogInformation($"email trigger job newsletter: {apmResponse}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"User status sync job newsletter failed. {ex}");
                UpsertJobDetail($"Run email trigger newsletter job: {ExeContext.Job.Id}", JobState.Failed);
            }
            try
            {
                UpsertJobDetail($"Start run email trigger job family 365 interest: {ExeContext.Job.Id}", JobState.InProgress);
                var apmResponse = _APMClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATHFamilyProgrammeInterest, Method = HttpMethod.Post });
                _logger.LogInformation($"email trigger job family 365 interest: {apmResponse}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"User status sync job family 365 interest failed. {ex}");
                UpsertJobDetail($"Run email trigger family 365 interest job: {ExeContext.Job.Id}", JobState.Failed);
            }
			try
			{
				UpsertJobDetail($"Start run email trigger job family 365 interest: {ExeContext.Job.Id}", JobState.InProgress);
				var apmResponse = _APMClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATHQuiz, Method = HttpMethod.Post });
				_logger.LogInformation($"email trigger job family 365 interest: {apmResponse}");
			}
			catch (Exception ex)
			{
				_logger.LogError($"User status sync job family 365 interest failed. {ex}");
				UpsertJobDetail($"Run email trigger family 365 interest job: {ExeContext.Job.Id}", JobState.Failed);
			}
			UpsertJobDetail($"Email trigger job finished: {ExeContext.Job.Id}", JobState.Finished);
        }

        public override void Init()
        {
        }

        public override void CleanUp()
        {

        }

        public override void Finish()
        {
        }

        private void UpsertJobDetail(string Comment, JobState jobState, bool needRecordJobDetail = false)
        {
            if (jobState == JobState.Exception)
            {
                _logger.LogError("common error {Comment}:", Comment);
                ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 100);
                ExeContext.JobManagerService.UpdateJobState(ExeContext.Job.Id, jobState);
            }
            else
            {
                _logger.LogInformation("common Infomation {Comment}:", Comment);
            }

            if (jobState == JobState.Exception || needRecordJobDetail)
            {
                try
                {
                    JobDetailDto jobDetail = new JobDetailDto(ExeContext.Job.Id, jobState, Comment);
                    ExeContext.JobManagerService.UpsertJobDetails(new JobDetailDto[] { jobDetail.Convert2BaseDto() });
                }
                catch (Exception ex)
                {
                    _logger.LogError($"An error occurred while upsertting job detail: {ex}");
                }
            }
        }

    }
}

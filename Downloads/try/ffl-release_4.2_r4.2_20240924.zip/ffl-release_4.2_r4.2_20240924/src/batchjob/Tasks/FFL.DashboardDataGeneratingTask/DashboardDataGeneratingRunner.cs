﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using APM.SDK;
using APM.SDK.Messages;
using APM.SDK.Services;
using Job.Interface;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PipelineJob.Base;
using Replicator.Interface;
using Replicator.Interface.Model;

namespace FFL.DashboardDataGeneratingTask
{
    public class DashboardDataGeneratingRunner : PipelineJobRunner
    {
        private APMClient2 apmClient;
        private CancellationToken cancellationToken;
        private readonly ILogger _logger;
        private string jobId;
        private string jobName;

        const string SERVICEPATH = "api/DashboardTimerApi/OverviewTimer"; // apm service path

        public DashboardDataGeneratingRunner(
            JobExecutionContext jobContext,
            IReplicatorsService replicatorsService,
            CancellationToken cancellationToken,
            List<ConnectionAdapter> adapters) : base(jobContext, replicatorsService, cancellationToken, adapters)
        {
            this.cancellationToken = cancellationToken;
            _logger = jobContext.LoggerFactory.CreateLogger(typeof(DashboardDataGeneratingRunner).FullName);

        }

        public override void Run()
        {
            _logger.LogInformation($"Dashboard data generating job start.");
            try
            {
                UpsertJobDetail($"Start to run the Dashboard data generating job: {ExeContext.Job.Id}", JobState.Starting);
                var apmResponse = apmClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATH, Method = HttpMethod.Post });
                _logger.LogInformation($"{apmResponse}");
                UpsertJobDetail($"Finish to run the Dashboard data generating job: {ExeContext.Job.Id}", JobState.Finished);
            }
            catch (Exception ex)
            {
                _logger.LogError($"The Dashboard data generating job failed. {ex}");
                UpsertJobDetail($"The Dashboard data generating job failed: {ExeContext.Job.Id}", JobState.Failed);
            }
        }

        public override void Init()
        {
            jobId = ExeContext.Job.Id;
            jobName = ExeContext.Job.Name;
            _logger.LogWarning($"Initialization for event Dashboard data generating job: {jobName}");
            try
            {
                var config = Adapters[0];
                string endpointPrefix = "WebUrl=";
                apmClient = new APMClient2(new APMSettings
                {
                    AuthEndpoint = config.Parameters.GetValueOrDefault("authority"),
                    ClientId = config.Parameters.GetValueOrDefault("clientid"),
                    Secret = config.Parameters.GetValueOrDefault("secret"),
                    ServiceEndpoint = config.ConnectionStr.StartsWith(endpointPrefix, StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(endpointPrefix.Length) : config.ConnectionStr
                });
            }
            catch (Exception ex)
            {
                string errorMsg = $"Failed to initialize apm for event Dashboard data generating job: {jobName}, error: {ex}";
                UpsertJobDetail(errorMsg, JobState.Failed);
                throw new Exception(errorMsg);
            }
        }

        public override void CleanUp()
        {

        }

        public override void Finish()
        {
        }

        private void UpsertJobDetail(string comment, JobState jobState, bool needRecordJobDetail = false)
        {
            if (jobState == JobState.Exception)
            {
                _logger.LogError("The Dashboard data generating job error: {Comment}", comment);
                ExeContext.JobManagerService.UpdateJobProgress(jobId, 100);
                ExeContext.JobManagerService.UpdateJobState(jobId, jobState);
            }
            else
            {
                _logger.LogInformation("The Dashboard data generating job info: {Comment}", comment);
            }

            if (jobState == JobState.Exception || jobState == JobState.Failed || needRecordJobDetail)
            {
                try
                {
                    DashboardDataGeneratingJobDetail jobDetail = new DashboardDataGeneratingJobDetail(jobId, jobState, comment);
                    ExeContext.JobManagerService.UpsertJobDetails(new JobDetailDto[] { jobDetail.Convert2BaseDto() });
                }
                catch (Exception ex)
                {
                    _logger.LogError($"An error occurred while upsertting job detail: {ex}");
                }
            }
        }
    }

    public class DashboardDataGeneratingJobDetail : JobDetailDto
    {
        public DashboardDataGeneratingJobDetail(string id, JobState jobState, string comment) : base(id, jobState, comment)
        {
            long utcTicks = DateTime.UtcNow.Ticks;
            StartTime = utcTicks;
            EndTime = utcTicks;
        }

        [CustomColumn(DisplayName = "Start time", InternalName = "StartTime", Type = CustomColumnType.UTCTicks)]
        public long StartTime { get; set; }

        [CustomColumn(DisplayName = "End time", InternalName = "EndTime", Type = CustomColumnType.UTCTicks)]
        public long EndTime { get; set; }
    }
}
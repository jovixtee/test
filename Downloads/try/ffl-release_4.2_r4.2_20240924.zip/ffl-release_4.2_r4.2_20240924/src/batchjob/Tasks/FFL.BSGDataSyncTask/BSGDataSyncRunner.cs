﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Microsoft.Extensions.Logging;
using APM.SDK;
using APM.SDK.Messages;
using APM.SDK.Services;
using Job.Interface;
using Newtonsoft.Json;
using PipelineJob.Base;
using Replicator.Interface;
using Replicator.Interface.Model;
using FFL.BSGDataSyncTask.Models;
using System.Diagnostics;

namespace FFL.BSGDataSyncTask
{
    public class BSGDataSyncRunner : PipelineJobRunner
    {
        private APMClient2 apmClient;
        private CancellationToken cancellationToken;
        private readonly ILogger _logger;
        private string jobId;
        private string jobName;
        private APMClient2 apmClient2 { get; set; }
        //private APMClient2 apmClient3 { get; set; }
        //private APMClient2 apmClient4 { get; set; }
        //private APMClient2 apmClient5 { get; set; }

        const string SERVICEPATH = "api/v1/BSG/SyncBSGData"; // apm service path
        const string CREATEPOSTALCODEPATH = "api/v1/PostalCodeApi/TryCreate";
        const string UPDATEATTENDANCEINFOPATH = "api/v1/BSG/UpdateAttendanceInfo";
        const string GETPROCESSMODELPATH = "api/v1/BSG/GetProcessModel";
        const string GETATTENDANCEINFOPATH = "api/v1/BSG/GetAttendanceInfoModel";
        public static string DataSourceHeader { get; internal set; } = "X-DataSource";
        public static string CDataSourceDataSync { get; internal set; } = "DataSync";
        public static string ExecuteJobId { get; internal set; } = "ExecuteJobId";
        public BSGDataSyncRunner(
            JobExecutionContext jobContext,
            IReplicatorsService replicatorsService,
            CancellationToken cancellationToken,
            List<ConnectionAdapter> adapters) : base(jobContext, replicatorsService, cancellationToken, adapters)
        {
            this.cancellationToken = cancellationToken;
            _logger = jobContext.LoggerFactory.CreateLogger(typeof(BSGDataSyncRunner).FullName);
        }

        private APMClient2 CreateDocumentService(ConnectionAdapter config)
        {
            var finallyEndpoint = config.ConnectionStr.StartsWith("WebUrl=", StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(7) : config.ConnectionStr;
            finallyEndpoint = finallyEndpoint.TrimEnd('/');
            var authority = config.Parameters["authority"];
            var clientid = config.Parameters["clientid"];
            var secret = config.Parameters["secret"];
            var apmSettings = new APMSettings
            {
                AuthEndpoint = authority,
                ClientId = clientid,
                Secret = secret,
                ServiceEndpoint = finallyEndpoint
            };
            apmSettings.CustomHeaders = new Dictionary<string, string?>();
            apmSettings.CustomHeaders.Add(DataSourceHeader, CDataSourceDataSync);
            apmSettings.CustomHeaders.Add(ExecuteJobId, ExeContext.Job.Id);
            return new APMClient2(apmSettings);
        }

        public override void Init()
        {
            jobId = ExeContext.Job.Id;
            jobName = ExeContext.Job.Name;
            _logger.LogWarning($"Initialization for BSGDataSync job: {jobName}");
            try
            {
                var config = Adapters[0];
                string endpointPrefix = "WebUrl=";
                apmClient = CreateDocumentService(Adapters[0]);
                apmClient2 = CreateDocumentService(Adapters[1]);
                //apmClient3 = CreateDocumentService(Adapters[0]);
                //apmClient4 = CreateDocumentService(Adapters[0]);
                //apmClient5 = CreateDocumentService(Adapters[0]);
            }
            catch (Exception ex)
            {
                string errorMsg = $"Failed to initialize apm for BSGDataSync job: {jobName}, error: {ex}";
                UpsertJobDetail(errorMsg, JobState.Failed);
                throw new Exception(errorMsg);
            }
        }

        public override async void Run()
        {
            _logger.LogInformation($"BSGDataSync job start.");
            UpsertJobDetail($"Start run BSGDataSync job: {ExeContext.Job.Id}", JobState.Starting);
            
            try
            {
                var postalCodes = new List<string>();
                var apmResponse = apmClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATH, Method = HttpMethod.Post });
                var startTime = DateTime.Now.Ticks;
                var retrySyncCount = 0;
                bool isSucceed = false;
                while (new TimeSpan(DateTime.Now.Ticks - startTime).TotalMinutes < 90 && !isSucceed && retrySyncCount <= 3)
                {
                    //if(new TimeSpan(DateTime.Now.Ticks - startTime).TotalMinutes > 90)
                    //{
                    //    break;
                    //}
                    Thread.Sleep(20000);
                    //await Task.Delay(30000);
                    _logger.LogInformation("Start to Get process model.");
                    try
                    {
                        var response = apmClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = GETPROCESSMODELPATH, Method = HttpMethod.Get });
                        if (response.IsSuccess)
                        {
                            var respContent = await response.Content.ReadAsStringAsync();
                            var processModel = JsonConvert.DeserializeObject<BSGJobProcessModel>(respContent);
                            if (processModel != null && string.IsNullOrEmpty(processModel.ExceptionComment))
                            {
                                retrySyncCount = 0;
                                if (processModel.TotalProgrammesCount == 0)
                                {
                                    isSucceed = true;
                                }
                                else if (processModel.TotalProgrammesCount == processModel.CompletedProgrammesCount && processModel.IsFinished)
                                {
                                    postalCodes = processModel.PostalCodes;
                                    isSucceed = true;
                                }
                                else
                                {
                                    if(processModel.TotalProgrammesCount > 0)
                                    {
                                        ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, Convert.ToInt32((processModel.CompletedProgrammesCount * 1.0 / processModel.TotalProgrammesCount / 3) * 100));
                                    }
                                    continue;
                                }
                            }
                            else
                            {
                                _logger.LogError($"An error ocurred when sync bsg data, ex: {(processModel != null ? processModel.ExceptionComment : string.Empty)}");
                                UpsertJobDetail("An error ocurred when sync bsg data.", JobState.Failed, true);
                                isSucceed = false;
                                break;
                            }
                        }
                        else
                        {
                            _logger.LogError($"An error ocurred when getting process.");
                            continue;
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning($"An error occured when retry getting process model, ex: {ex},retryCount: {retrySyncCount + 1}");
                        if(retrySyncCount >= 3)
                        {
                            isSucceed = false;
                            _logger.LogError($"Getting process model retry failed.");
                            UpsertJobDetail("An error ocurred when sync bsg data.", JobState.Failed, true);
                            retrySyncCount += 1;
                        }
                        else
                        {
                            retrySyncCount += 1;
                            continue;
                        }
                    }
                    
                }
                ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, Convert.ToInt32(33));
                _logger.LogInformation($"Sync bsg data finished.");

                _logger.LogInformation("Start to Create PostalCode.");
                //List<PostalCodeViewModel> models = new List<PostalCodeViewModel>();
                //foreach(var postalCode in postalCodes)
                //{
                //    models.Add(new PostalCodeViewModel
                //    {
                //        Code = postalCode
                //    });
                //}
                if (postalCodes != null && postalCodes.Any())
                {
                    var apmResponse1 = apmClient2.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = CREATEPOSTALCODEPATH, Method = HttpMethod.Post, InputParameters = postalCodes });
                    if(!apmResponse1.IsSuccess)
                    {
                        _logger.LogError("An error occured during Creating PostalCode, ex: {0}", apmResponse1.ErrorMessage);
                    }
                    ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, Convert.ToInt32(67));
                }
                else
                {
                    _logger.LogInformation($"No postal code need to create.");
                }
                _logger.LogInformation($"Create PostalCode finished.");
                _logger.LogInformation($"Start to update attendance info.");
                apmClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = UPDATEATTENDANCEINFOPATH, Method = HttpMethod.Post });
                var attendanceStartTime = DateTime.Now.Ticks;
                var isAttendanceupdatedSucceed = false;
                var attendanceInfoRetryCount = 0;
                while (!isAttendanceupdatedSucceed && new TimeSpan(DateTime.Now.Ticks - attendanceStartTime).TotalMinutes < 120 && attendanceInfoRetryCount <= 3)
                {
                    //if(new TimeSpan(DateTime.Now.Ticks - attendanceStartTime).TotalMinutes > 120)
                    //{
                    //    break;
                    //}
                    Thread.Sleep(20000);
                    //await Task.Delay(30000);
                    _logger.LogInformation($"Start to get attendance info model.");
                    try
                    {
                        var attendResponse = apmClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = GETATTENDANCEINFOPATH, Method = HttpMethod.Get });
                        if (attendResponse.IsSuccess)
                        {
                            var attendContent = await attendResponse.Content.ReadAsStringAsync();
                            var attendanceInfos = JsonConvert.DeserializeObject<BSGAttendanceInfoModel>(attendContent);
                            if (attendanceInfos != null && string.IsNullOrEmpty(attendanceInfos.ExceptionComment))
                            {
                                attendanceInfoRetryCount = 0;
                                if (attendanceInfos.TotalCount > 0)
                                {
                                    ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, Convert.ToInt32(66 + (attendanceInfos.CompletedCount * 1.0 / attendanceInfos.TotalCount / 3) * 100));
                                    if (attendanceInfos.CompletedCount == attendanceInfos.TotalCount || attendanceInfos.IsFinished)
                                    {
                                        isAttendanceupdatedSucceed = true;
                                    }
                                }
                                else
                                {
                                    isAttendanceupdatedSucceed = true;
                                }
                            }
                            else
                            {
                                _logger.LogError($"An error occured when getting attendance info, ex: {((attendanceInfos != null ? attendanceInfos.ExceptionComment : string.Empty))}");
                                UpsertJobDetail("An error occured when getting attendance info.", JobState.Failed, true);
                                isAttendanceupdatedSucceed = false;
                                break;
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning($"An error occured when retry getting attendance info, exception: {ex}, retryCount: {attendanceInfoRetryCount + 1}");
                        if(attendanceInfoRetryCount >= 3)
                        {
                            isAttendanceupdatedSucceed = false;
                            _logger.LogError($"Getting attendance info retry failed.");
                            UpsertJobDetail("An error occured when getting attendance info.", JobState.Failed, true);
                            attendanceInfoRetryCount += 1;
                        }
                        else
                        {
                            attendanceInfoRetryCount += 1;
                            continue;
                        }
                    }
                }
                _logger.LogInformation($"Updating attendance info finished.");
                //var apmResponse2 = apmClient3.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATH2, Method = HttpMethod.Post });
                //if(!apmResponse2.IsSuccess)
                //{
                //    _logger.LogError("An error occured when UpdateAttendanceInfo, ex: {0}", apmResponse2.ErrorMessage);
                //}
                if (isSucceed && isAttendanceupdatedSucceed)
                {
                    UpsertJobDetail($"Finish run BSGDataSync job: {ExeContext.Job.Id}", JobState.Finished);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"BSGDataSync failed. {ex}");
                UpsertJobDetail($"BSGDataSync job failed: {ExeContext.Job.Id}", JobState.Failed);
            }
        }

        public override void CleanUp()
        {

        }

        public override void Finish()
        {

        }

        private void UpsertJobDetail(string comment, JobState jobState, bool needRecordJobDetail = false)
        {
            if (jobState == JobState.Exception || jobState == JobState.Failed)
            {
                _logger.LogError("BSGDataSync job error: {Comment}", comment);
                ExeContext.JobManagerService.UpdateJobProgress(jobId, 100);
                ExeContext.JobManagerService.UpdateJobState(jobId, jobState);
            }
            else
            {
                _logger.LogInformation("BSGDataSync job info: {Comment}", comment);
            }

            if (jobState == JobState.Exception || jobState == JobState.Failed || needRecordJobDetail)
            {
                try
                {
                    BSGDataSyncJobDetail jobDetail = new BSGDataSyncJobDetail(jobId, jobState, comment);
                    ExeContext.JobManagerService.UpsertJobDetails(new JobDetailDto[] { jobDetail.Convert2BaseDto() });
                }
                catch (Exception ex)
                {
                    _logger.LogError($"An error occurred while upsertting job detail: {ex}");
                }
            }
        }
    }

    public class BSGDataSyncJobDetail : JobDetailDto
    {
        public BSGDataSyncJobDetail(string id, JobState jobState, string comment) : base(id, jobState, comment)
        {
            long utcTicks = DateTime.UtcNow.Ticks;
            StartTime = utcTicks;
            EndTime = utcTicks;
        }

        [CustomColumn(DisplayName = "Start time", InternalName = "StartTime", Type = CustomColumnType.UTCTicks)]
        public long StartTime { get; set; }

        [CustomColumn(DisplayName = "End time", InternalName = "EndTime", Type = CustomColumnType.UTCTicks)]
        public long EndTime { get; set; }
    }
}
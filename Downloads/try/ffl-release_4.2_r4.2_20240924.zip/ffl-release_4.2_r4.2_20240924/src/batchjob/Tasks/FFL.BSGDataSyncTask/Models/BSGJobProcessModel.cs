﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FFL.BSGDataSyncTask.Models
{
    public class BSGJobProcessModel
    {
        public List<string> PostalCodes { get; set; }
        public int TotalProgrammesCount { get; set; }
        public int CompletedProgrammesCount { get; set; }
        public string ExceptionComment { get; set; }
        public bool IsFinished { get; set; }
    }
    public class BSGAttendanceInfoModel
    {
        public int TotalCount { get; set; }
        public int CompletedCount { get; set; }
        public string ExceptionComment { get; set; }
        public bool IsFinished { get; set; }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using DataPipeline.Base.Job;
using FFL.DataSyncTask.Middleware;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Npgsql;
using PipelineJob.Base;
using PipelineJob.Base.Mapping;
using PipelineJob.Base.Pipelines;
using Replicator.Interface;
using Replicator.Interface.Model;
using APM.SDK;
using APM.SDK.DataContract.SyncJob;
using APM.SDK.Messages.WebApi.SyncData;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;
using Camps.FFL.Sync.Common;
using System.Threading.Tasks;
using static PipelineJob.Base.Constants;
using Job.Interface;
using APM.SDK.Services;

namespace FFL.DataSyncTask
{
    public class DataSyncRunner : PipelineJobRunner
    {
        private APMClient2 SourceAPMClient { get; set; }
        private APMClient2 DestAPMClient { get; set; }
        private CancellationToken CancellationToken { get; set; }
        private readonly ILogger Logger;
        private string jobId { get; set; }
        public DataSyncRunner(           
            JobExecutionContext jobContext,
            IReplicatorsService replicatorsService,
            CancellationToken cancellationToken,
            List<ConnectionAdapter> adapters) : base(jobContext, replicatorsService, cancellationToken, adapters)
        {
            CancellationToken = cancellationToken;
            Logger = jobContext.LoggerFactory.CreateLogger(typeof(DataSyncRunner).FullName);
            jobId = jobContext.Job.Name;
            Logger.LogWarning($"Job id:{jobId}");
            SourceAPMClient = CreateDocumentService(adapters[0], "internet");
            DestAPMClient = CreateDocumentService(adapters[1], "intranet");
        }
        private APMClient2 CreateDocumentService(ConnectionAdapter config, string label)
        {
            var finallyEndpoint = config.ConnectionStr.StartsWith("WebUrl=", StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(7) : config.ConnectionStr;
            finallyEndpoint = finallyEndpoint.TrimEnd('/');
            var authority = config.Parameters["authority"];
            var clientid = config.Parameters["clientid"];
            var secret = config.Parameters["secret"];
            var apmSettings = new APMSettings
            {
                AuthEndpoint = authority,
                ClientId = clientid,
                Secret = secret,
                ServiceEndpoint = finallyEndpoint
            };
            apmSettings.CustomHeaders = new Dictionary<string, string?>();
            apmSettings.CustomHeaders.Add(Constants.DataSourceHeader, Constants.CDataSourceDataSync);

            return new APMClient2(apmSettings);
        }
        public ServiceCollection Services { get; private set; }

        public override void CleanUp()
        {
            try
            {
                Directory.Delete(this.ExeContext.TempFolder, true);
            }
            catch (Exception) { }
        }

        public override void Finish()
        {
        }

        public override void Init()
        {
            this.Services = new ServiceCollection();
            this.Services.UsePipelineJob(this.ExeContext).
                UseBulkPipelineJob<MappingDataRecord>(this.ExeContext);

            this.Services.TryAddSingleton<DataSyncMappingMiddleware>();
            this.Descriptor = new TableDescriptor("Table_Name");
            this.Descriptor.Columns.Add("Columns1", new ColumnDescriptor("CourseCode", "ntext"));
            this.Descriptor.Columns.Add("Columns2", new ColumnDescriptor("CourseName", "ntext", true));
        }
        private int GetProgressPercent(int current, int total)
        {
            if (current >= total)
            {
                return 100;
            }
            if (current <= 0)
            {
                return 1;
            }
            return Convert.ToInt32((double)current / total * 100);
        }
        public override void Run()
        {
            Logger.LogInformation($"Data sync job start.[0204]");
            var total = Constants.SyncToIntranetEntities.Count + Constants.SyncToInternetEntities.Count;
            var index = 0;
            Constants.SyncToIntranetEntities.ForEach(dataType =>
            {

                var detail = new DocSyncJobDetail(ExeContext.Job.Id, JobState.Finished, dataType.ToString(), dataType.ToString());
                detail.SyncCount = 0;
                try
                {
                    if (CancellationToken.IsCancellationRequested)
                    {
                        return;
                    }

                    var resultCount = ProcessEntityForIntranet(dataType).GetAwaiter().GetResult();
                    detail.SyncCount = resultCount;
                }
                catch (Exception ex)
                {
                    Logger.LogInformation($"Failed to sync intranet to internet for entity:{dataType}, exception:{ex}");
                    detail.Comment += ex.Message;
                    detail.State = JobState.Failed;
                }
                finally
                {
                    if (detail.SyncCount > 0 || detail.State == JobState.Failed)
                    {
                        ExeContext.JobManagerService.UpsertJobDetails(new JobDetailDto[] { detail.Convert2BaseDto() });
                    }
                    ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, GetProgressPercent(++index, total));
                }
            });

            Constants.SyncToInternetEntities.ForEach(dataType =>
            {
                var detail = new DocSyncJobDetail(ExeContext.Job.Id, JobState.Finished, dataType.ToString(), dataType.ToString());
                detail.SyncCount = 0;
                try
                {
                    if (CancellationToken.IsCancellationRequested)
                    {
                        return;
                    }
                    var resultCount = ProcessEntityForInternet(dataType).GetAwaiter().GetResult();
                    detail.SyncCount = resultCount;
                }
                catch (Exception ex)
                {
                    Logger.LogInformation($"Failed to sync internet to intranet for entity:{dataType}, exception:{ex}");
                    detail.Comment += ex.Message;
                    detail.State = JobState.Failed;
                }
                finally
                {
                    if (detail.SyncCount > 0 || detail.State == JobState.Failed)
                    {
                        ExeContext.JobManagerService.UpsertJobDetails(new JobDetailDto[] { detail.Convert2BaseDto() });
                    }
                    ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, GetProgressPercent(++index, total));
                }
            });
            Logger.LogInformation($"Data sync job finish.");
            ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 100);
            ExeContext.JobManagerService.UpdateJobState(ExeContext.Job.Id, Job.Interface.JobState.Finished);
        }
        public async Task<Int32> ProcessEntityForIntranet(DataType dt)
        {
            Logger.LogInformation($"Start to process entity {dt} intranet to internet.");
            await Task.CompletedTask;
            var jobCount = 0;
            Int32 totalSyncCount = 0;
            while (jobCount < Constants.RunJobCount)
            {
                //scan intranet db
                jobCount++;
                var dsr = new DataSyncRequest()
                {
                    DataMode = DataMode.ScanData,
                    DataType = dt,
                    SyncMode = SyncMode.ToIntranet,
                    Data = new List<Object>(),
                    SyncJobCount = GetOnceCount(dt),
                    SyncJobPage = 1
                };
                var scanIntranetResponse = HttpClientPost(DestAPMClient, dsr);
                if (scanIntranetResponse == null || scanIntranetResponse.Result == null)
                {
                    Logger.LogInformation($"Failed to scan entity, dataType:{dt}");
                    break;
                }
                if (scanIntranetResponse.State == ResponseState.Ok)
                {
                    var syncToInternetRequest = JsonConvert.DeserializeObject<DataSyncRequest>(scanIntranetResponse.Result.ToString());

                    if (syncToInternetRequest == null || syncToInternetRequest.Data == null || syncToInternetRequest.Data.Count() == 0)
                    {
                        Logger.LogInformation($"Not found need sync entity, dataType:{dt}");
                        break;
                    }
                    var onceCount = syncToInternetRequest.Data.Count();
                    Logger.LogInformation($"Sync data once count:{onceCount}, dataType:{dt}");
                    //sync to internet db
                    syncToInternetRequest.DataMode = DataMode.SyncData;
                    syncToInternetRequest.SyncMode = SyncMode.ToInternet;
                    syncToInternetRequest.DataType = dt;
                    var syncToInternetReponse = HttpClientPost(SourceAPMClient, syncToInternetRequest);
                    if (syncToInternetReponse == null || syncToInternetReponse.Result == null)
                    {
                        Logger.LogInformation($"Failed to sync entity , dataType:{dt}");
                        break;
                    }
                    if (syncToInternetReponse.State == ResponseState.Ok)
                    {
                        //Update result to intranet db
                        var UpdateResultToIntranetRequest = JsonConvert.DeserializeObject<DataSyncRequest>(syncToInternetReponse.Result.ToString());
                        if (UpdateResultToIntranetRequest == null || UpdateResultToIntranetRequest.DataResult == null || UpdateResultToIntranetRequest.DataResult.Count() == 0)
                        {
                            Logger.LogInformation($"Not found need update entity");
                            break;
                        }
                        var onceResultCount = UpdateResultToIntranetRequest.DataResult.Count();
                        totalSyncCount += onceResultCount;
                        Logger.LogInformation($"Update result data once count:{onceResultCount}, dataType:{dt}");
                        UpdateResultToIntranetRequest.DataMode = DataMode.SyncResult;
                        UpdateResultToIntranetRequest.SyncMode = SyncMode.ToIntranet;
                        UpdateResultToIntranetRequest.DataType = dt;
                        HttpClientPost(DestAPMClient, UpdateResultToIntranetRequest);
                    }
                    else
                    {
                        Logger.LogInformation($"Sync data failed, dataType:{dt}");
                    }

                    if (onceCount < dsr.SyncJobCount)
                    {//last reqeust
                        break;
                    }
                }
                else
                {
                    Logger.LogInformation($"Scan data failed, dataType:{dt}");
                }
            }
            Logger.LogInformation($"End to process entity {dt} intranet to internet.");
            return totalSyncCount;
        }
        private Int32 GetOnceCount(DataType type)
        {
            return type switch
            {
                DataType.ViewPage => Constants.PageOnceCount,
                DataType.QuizEntity => Constants.PageOnceCount,
                DataType.PostalCodeTown => Constants.PostalCodeTownOnceCount,
                _ => Constants.OnceCount
            };
        }
        public async Task<int> ProcessEntityForInternet(DataType dt)
        {
            Logger.LogInformation($"Start to process entity {dt} internet to intranet.");
            await Task.CompletedTask;
            Int32 jobCount = 0;
            Int32 totalSyncCount = 0;
            while (jobCount < Constants.RunJobCount)
            {
                //scan internet db
                jobCount++;
                var dsr = new DataSyncRequest()
                {
                    DataMode = DataMode.ScanData,
                    DataType = dt,
                    SyncMode = SyncMode.ToInternet,
                    Data = new List<object>(),
                    SyncJobCount = GetOnceCount(dt),
                    SyncJobPage = 1
                };
                var scanInternetResponse = HttpClientPost(SourceAPMClient, dsr);
                if (scanInternetResponse == null || scanInternetResponse.Result == null)
                {
                    Logger.LogInformation($"Failed to scan entity, dataType:{dt}");
                    break;
                }
                if (scanInternetResponse.State == ResponseState.Ok)
                {
                    var syncToIntranetRequest = JsonConvert.DeserializeObject<DataSyncRequest>(scanInternetResponse.Result.ToString());
                    if (syncToIntranetRequest == null || syncToIntranetRequest.Data == null || syncToIntranetRequest.Data.Count() == 0)
                    {
                        Logger.LogInformation($"Not found need sync entity, dataType:{dt}");
                        break;
                    }
                    Logger.LogInformation($"Sync data once count:{syncToIntranetRequest.Data.Count()}, dataType:{dt}");
                    //sync to intranet db
                    syncToIntranetRequest.DataMode = DataMode.SyncData;
                    syncToIntranetRequest.SyncMode = SyncMode.ToIntranet;
                    syncToIntranetRequest.DataType = dt;
                    var syncToIntranetReponse = HttpClientPost(DestAPMClient, syncToIntranetRequest);
                    if (syncToIntranetReponse == null || syncToIntranetReponse.Result == null)
                    {
                        Logger.LogInformation($"Failed to sync entity , dataType:{dt}");
                        break;
                    }
                    if (syncToIntranetReponse.State == ResponseState.Ok)
                    {
                        //Update result to internet db
                        var UpdateResultToInternetRequest = JsonConvert.DeserializeObject<DataSyncRequest>(syncToIntranetReponse.Result.ToString());
                        if (UpdateResultToInternetRequest == null || UpdateResultToInternetRequest.DataResult == null || UpdateResultToInternetRequest.DataResult.Count() == 0)
                        {
                            Logger.LogInformation($"Not found need update entity");
                            break;
                        }
                        var onceResultCount = UpdateResultToInternetRequest.DataResult.Count();
                        totalSyncCount += onceResultCount;
                        Logger.LogInformation($"Update result data once count:{onceResultCount}, dataType:{dt}");
                        UpdateResultToInternetRequest.DataMode = DataMode.SyncResult;
                        UpdateResultToInternetRequest.SyncMode = SyncMode.ToInternet;
                        UpdateResultToInternetRequest.DataType = dt;
                        HttpClientPost(SourceAPMClient, UpdateResultToInternetRequest);
                    }
                    else
                    {
                        Logger.LogInformation($"Sync data failed, dataType:{dt}");
                    }
                    if (syncToIntranetRequest.Data != null && syncToIntranetRequest.Data.Count() < dsr.SyncJobCount)
                    {
                        break;
                    }
                }
                else
                {
                    Logger.LogInformation($"Scan data failed, dataType:{dt}");
                }
            }
            Logger.LogInformation($"End to process entity {dt} internet to intranet.");
            return totalSyncCount;
        }

        private BaseResponse<string> HttpClientPost(APMClient2 apmclient, DataSyncRequest syncRequest)
        {
            SyncDataResponse result = null;
            try
            {
                syncRequest.TaskJobId = jobId;
                result = apmclient.Execute<SyncDataRequest, SyncDataResponse>(new SyncDataRequest(new SyncDataRequest.FFLExternalSyncRequest() { ExternalRequest = JsonConvert.SerializeObject(syncRequest) }));
                ChekApmError(result);
            }
            catch (Exception ex)
            {
                Logger.LogWarning($"Faile to post request for apm, exception:{ex}");
                if (ex.Message != null && ex.Message.Contains("Response status code does not indicate success: 504 (Gateway Timeout)"))
                {
                    result = apmclient.Execute<SyncDataRequest, SyncDataResponse>(new SyncDataRequest(new SyncDataRequest.FFLExternalSyncRequest() { ExternalRequest = JsonConvert.SerializeObject(syncRequest) }));
                    ChekApmError(result);
                }
                else if (syncRequest != null && syncRequest.DataMode == DataMode.ScanData)
                {
                    syncRequest.SyncJobCount = syncRequest.SyncJobCount / 2;
                    Logger.LogWarning($"Reduce the number of queries to {syncRequest.SyncJobCount}");
                    result = apmclient.Execute<SyncDataRequest, SyncDataResponse>(new SyncDataRequest(new SyncDataRequest.FFLExternalSyncRequest() { ExternalRequest = JsonConvert.SerializeObject(syncRequest) }));
                    ChekApmError(result);
                }
                else
                {
                    throw;
                }
            }
            try
            {
                //Logger.LogInformation($"Request info:{result.Response}");
                var bresult = JsonConvert.DeserializeObject<BaseResponse<string>>(result.Response);
                return bresult;
            }
            catch (Exception e)
            {
                Logger.LogWarning($"DeserializeObject Error: {e}, {result.Response}");
                throw;
            }
        }

        private void ChekApmError(SyncDataResponse result)
        {
            if (result != null && !result.IsSuccess)
            {
                Logger.LogError($"the apm error is {result.ErrorMessage}");
            }
        }
        string CetQuery = @"
SELECT 
cime.[Id] as Id,
'' as DepartmentofLecturer,
m.[Code] as SubjectCode, 
mv.[Name] as SubjectName, 
clz.[Sessions]
FROM [CET_CourseIntakeModuleEnrolment] cime
LEFT JOIN [CET_CourseIntakeModule] cim on cime.[CourseIntakeModuleId] = cim.[Id]
LEFT JOIN [CET_CourseIntakeEnrolment] cie ON cime.[CourseIntakeEnrolmentId] = cie.[Id]
LEFT JOIN [CET_Module] m on cim.[ModuleId] = m.[Id]
LEFT JOIN [CET_ModuleVersion] mv on cim.[ModuleId] = mv.[Id] and cim.[ModuleVersion] = mv.[Version]
,JSONB_TO_RECORDSET(cim.[TimetablingProperty]#>'{Classes}') as clz([Name] text,[Sessions] json)
WHERE cime.[IHLFlag] = '2' 
AND cie.[Status] =1 -- Status is Enrolled
and m.[Code] =@Code";

        TableDescriptor Descriptor { get; set; }

        Func<NpgsqlDataReader, MappingDataRecord> Reader = new Func<NpgsqlDataReader, MappingDataRecord>(reader =>
        {
            var data = new MappingDataRecord();

            data.Data.Add("CourseCode", reader.GetString(reader.GetOrdinal("PK")));
            data.Data.Add("MERBanks", reader.GetString(reader.GetOrdinal("MERBanks")));
            data.Data.Add("CourseCatalogue", reader.GetString(reader.GetOrdinal("CourseCatalogue")));
            data.Data.Add("CourseVersions", reader.GetString(reader.GetOrdinal("CourseVersions")));
            data.Data.Add("Modules", reader.GetString(reader.GetOrdinal("Modules")));
            data.Data.Add("CourseIntakes", reader.GetString(reader.GetOrdinal("CourseIntakes")));
            data.Data.Add("Action", reader.GetString(reader.GetOrdinal("Action")));
            data.Data.Add("Modified", reader.GetDateTime(reader.GetOrdinal("Modified")));

            return data;
        });
    }
}

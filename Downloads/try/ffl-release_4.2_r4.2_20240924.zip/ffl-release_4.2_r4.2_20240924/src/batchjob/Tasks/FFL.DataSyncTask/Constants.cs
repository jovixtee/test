﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.FFL.Sync.Common;
using Job.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FFL.DataSyncTask
{
    internal class Constants
    {
        internal static Int32 RunJobCount = 10;
        internal static Int32 OnceCount = 500;
        internal static Int32 PageOnceCount = 10;
        internal static Int32 PostalCodeTownOnceCount = 1000;
        internal static List<DataType>  SyncToIntranetEntities = new List<DataType>() { DataType.SiteSettings, DataType.ViewPage, DataType.TaxonomyEntity, DataType.TermRelationshipsEntity, DataType.TermMetaEntity, DataType.TermEntity, DataType.TaxonomyMetaEntity, DataType.ActivityTermRelationships, DataType.Activity,
                                                                                        DataType.ArticleTermRelationships, DataType.Article, DataType.RotatingBanner, DataType.MaintenanceBanner, DataType.NewsletterTermRelationships, DataType.Newsletter, DataType.Configuration,  
                                                                                        DataType.EventTermRelationships, DataType.Event, DataType.EventDateProvidor, DataType.EventSubmission, 
                                                                                        DataType.SiteUser, DataType.UserClaim, DataType.UserLogin, DataType.UserRole,
                                                                                        DataType.Group, DataType.GroupClaim, DataType.GroupRole,DataType.UserGroupInfo,
                                                                                        DataType.VolunteerOpportunityTermRelationships, DataType.VolunteerOpportunity, DataType.VolunteerStory, DataType.PhotoGalleryModel, DataType.News, 
                                                                                        DataType.NewsletterEmail, DataType.NewsletterEmailTermRelationship, DataType.NewsletterEmailHistoryEntity,
                                                                                        DataType.ProgrammeTermRelationships,DataType.Programme, DataType.ProgrammeProviderRelationship,DataType.FamilyProgrammeTermRelationships, DataType.FamilyProgramme, DataType.FamilyProgrammeInterest,
        DataType.FFLPGroup, DataType.FFLPActivityGroupRelationshipsEntity, DataType.FFLPStepGroupRelationshipsEntity, DataType.FFLPTipsGroupRelationshipsEntity ,DataType.FFLPActivity, DataType.FFLPArticleTermRelationship, DataType.FFLPArticle, DataType.FFLPGuide, DataType.FFLPRotatingBanner, DataType.FFLPSteps, DataType.FFLPTips, DataType.FFLPVideoGroupRelationshipsEntity, DataType.FFLPVideoEntity, DataType.SchemeBenefit,
        DataType.QuizEntity, DataType.QuizResponse, DataType.QuizResponseAnswer, DataType.QuizResponseSection, DataType.ParentInfo, 
        DataType.ProgrammesRunSession,DataType.ProgrammesRun, DataType.ProgrammesRegistration, DataType.PostalCode,DataType.PostalCodeTown, DataType.ProgrammeSettings,
        /*DataType.CourseAssessmentQuestion, DataType.CourseComponent, DataType.CourseComponentScorm, DataType.CourseComponentAssessment, DataType.CourseCertificateTemplate, DataType.CourseSection, DataType.CourseAssessmentQuestionOptionChoice, DataType.CourseAssessmentQuestionOptionMapping, DataType.CourseEntity*/};
        internal static List<DataType>  SyncToInternetEntities = new List<DataType>() { DataType.ViewPage, DataType.TermRelationshipsEntity, DataType.NewsletterTermRelationships, DataType.Newsletter, DataType.EventSubmission, 
																						DataType.SiteUser, DataType.UserClaim, DataType.UserLogin, DataType.UserRole, 
                                                                                        DataType.VolunteerStory, DataType.Programme, DataType.ProgrammeInterest,DataType.FamilyProgrammeInterestEmail, DataType.FamilyProgrammeInterest,
                                                                                        DataType.NewsletterEmail, DataType.NewsletterEmailTermRelationship, DataType.NewsletterEmailLinkClickRecord, DataType.NewsletterEmailOpenRecord, DataType.NewsletterEmailHistoryEntity,
                                                                                        DataType.QuizResponseAnswer, DataType.QuizResponseSection, DataType.QuizResponse, DataType.ParentInfo,
                                                                                        DataType.ProgrammesRunSession,DataType.ProgrammesRun, DataType.ProgrammesRegistration, DataType.ProgrammesRegAttendInfo, DataType.PostalCode, DataType.QuizAgreementRespRelationships,
        /*DataType.CourseScormCommentFromLearner, DataType.CourseScormCommentFromLMS, DataType.CourseScormData, DataType.CourseScormInteractions, DataType.CourseScormLearnerPreference, DataType.CourseScormObjectives, DataType.CourseAssessmentResponseAnswer, DataType.CourseEnrolment, DataType.ModuleProfile*/DataType.ExportReportExtend};

        public static string DataSourceHeader { get; internal set; } = "X-DataSource";
        public static string CDataSourceDataSync { get; internal set; } = "DataSync";
    }
    public class DocSyncJobDetail : JobDetailDto
    {
        public DocSyncJobDetail(string id, JobState jobState, string title, string comment) : base(id, jobState, comment)
        {
            long utcTicks = DateTime.UtcNow.Ticks;
            StartTime = utcTicks;
            EndTime = utcTicks;
            EntityTitle = title;
        }

        [CustomColumn(DisplayName = "Sync Count", InternalName = "SyncCount", Type = CustomColumnType.String)]
        public int SyncCount { get; set; }
        [CustomColumn(DisplayName = "Entity Title", InternalName = "EntityTitle", Type = CustomColumnType.String)]
        public string EntityTitle { get; set; }
        [CustomColumn(DisplayName = "Start time", InternalName = "StartTime", Type = CustomColumnType.UTCTicks)]
        public long StartTime { get; set; }

        [CustomColumn(DisplayName = "End time", InternalName = "EndTime", Type = CustomColumnType.UTCTicks)]
        public long EndTime { get; set; }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using APM.SDK;
using APM.SDK.Messages;
using APM.SDK.Services;
using Job.Interface;
using Microsoft.CommonDataModel.ObjectModel.Persistence.ModelJson.types;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PipelineJob.Base;
using Replicator.Interface;
using Replicator.Interface.Model;
using System.Diagnostics;

namespace FFL.NewsletterEmailEnhanceTask
{
    public class NewsletterEmailEnhanceRunner : PipelineJobRunner
    {
        private APMClient2 apmClient;
        private CancellationToken cancellationToken;
        private readonly ILogger _logger;
        private string jobId;
        private string jobName;
        public static string ExecuteJobId { get; internal set; } = "ExecuteJobId";
        const string SERVICEPATH = "api/v1/NewsletterEmailScheduleSendApi/SendEmail"; // apm service path
        const string GETSENDSTATUSMODEL = "api/v1/NewsletterEmailScheduleSendApi/GetSendStatusModel";

        public NewsletterEmailEnhanceRunner(           
            JobExecutionContext jobContext,
            IReplicatorsService replicatorsService,
            CancellationToken cancellationToken,
            List<ConnectionAdapter> adapters) : base(jobContext, replicatorsService, cancellationToken, adapters)
        {
            this.cancellationToken = cancellationToken;
            _logger = jobContext.LoggerFactory.CreateLogger(typeof(NewsletterEmailEnhanceRunner).FullName);
            
        }

        public override async void Run()
        {
            _logger.LogInformation($"Newsletter email enhance job start.");
            var startTime = DateTime.Now.Ticks;
            UpsertJobDetail($"Start run newsletter email enhance job: {ExeContext.Job.Id}", JobState.Starting);
            try
            {
                var apmResponse = apmClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATH, Method = HttpMethod.Post });
                //_logger.LogInformation($"{apmResponse}");
                var retryCount = 0;
                var isSucceed = false;
                while (!(new TimeSpan(DateTime.Now.Ticks - startTime).TotalMinutes > 20) && retryCount <= 3 && !isSucceed)
                {
                    
                    //if(new TimeSpan(DateTime.Now.Ticks - startTime).TotalMinutes > 20)
                    //{
                    //    break;
                    //}
                    Thread.Sleep(10000);
                    _logger.LogInformation("Start to get send email status model.");
                    try
                    {
                        var apmResponse1 = apmClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = GETSENDSTATUSMODEL, Method = HttpMethod.Get });
                        if(apmResponse1.IsSuccess)
                        {
                            _logger.LogInformation("Getting send email status model finished.");
                            var content = await apmResponse1.Content.ReadAsStringAsync();
                            var model = JsonConvert.DeserializeObject<NewsletterEmailSendStatusModel>(content);
                            if (model != null)
                            {
                                if (!string.IsNullOrEmpty(model.ExceptionComment))
                                {
                                    isSucceed = false;
                                    _logger.LogError($"An error ocurred when sending newsletteremail, ex: {model.ExceptionComment}");
                                    UpsertJobDetail("An error ocurred when sending newsletteremail.", JobState.Failed, true);
                                    break;
                                }
                                if (!model.HasFinished)
                                {
                                    ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 50);
                                    continue;
                                }
                                else
                                {
                                    isSucceed = true;
                                }
                            }
                            retryCount = 0;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning($"An error ocurred when sending newsletteremail, ex: {ex}. retryCount: {retryCount + 1}");
                        if(retryCount >= 3)
                        {
                            isSucceed = false;
                            _logger.LogError($"Getting send status model retry failed.");
                            UpsertJobDetail("An error ocurred when sending newsletteremail.", JobState.Failed, true);
                            retryCount += 1;
                        }
                        else
                        {
                            retryCount += 1;
                            continue;
                        }
                        
                    }
                    
                }
                if(isSucceed)
                {
                    UpsertJobDetail($"Finish run newsletter email enhance job: {ExeContext.Job.Id}", JobState.Finished);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Newsletter email enhance job failed. {ex}");
                UpsertJobDetail($"Newsletter email enhance job failed: {ExeContext.Job.Id}", JobState.Failed);
            }
        }

        public override void Init()
        {
            jobId = ExeContext.Job.Id;
            jobName = ExeContext.Job.Name;
            _logger.LogWarning($"Initialization for newsletter email enhance job: {jobName}");
            try
            {
                var config = Adapters[0];
                string endpointPrefix = "WebUrl=";
                var apmSetting = new APMSettings
                {
                    AuthEndpoint = config.Parameters.GetValueOrDefault("authority"),
                    ClientId = config.Parameters.GetValueOrDefault("clientid"),
                    Secret = config.Parameters.GetValueOrDefault("secret"),
                    ServiceEndpoint = config.ConnectionStr.StartsWith(endpointPrefix, StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(endpointPrefix.Length) : config.ConnectionStr
                };
                apmSetting.CustomHeaders = new Dictionary<string, string?>();
                apmSetting.CustomHeaders.Add(ExecuteJobId, ExeContext.Job.Id);
                apmClient = new APMClient2(apmSetting);
                //apmClient = new APMClient2(new APMSettings
                //{
                //    AuthEndpoint = config.Parameters.GetValueOrDefault("authority"),
                //    ClientId = config.Parameters.GetValueOrDefault("clientid"),
                //    Secret = config.Parameters.GetValueOrDefault("secret"),
                //    ServiceEndpoint = config.ConnectionStr.StartsWith(endpointPrefix, StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(endpointPrefix.Length) : config.ConnectionStr
                //});
            }
            catch (Exception ex)
            {
                string errorMsg = $"Failed to initialize apm for newsletter email enhance job: {jobName}, error: {ex}";
                UpsertJobDetail(errorMsg, JobState.Failed);
                throw new Exception(errorMsg);
            }
        }

        //private APMClient CreateAPMService(ConnectionAdapter config)
        //{
        //    string endpointPrefix = "WebUrl=";
        //    APMSettings settings = new APMSettings
        //    {
        //        AuthEndpoint = config.Parameters.GetValueOrDefault("authority"),
        //        ClientId = config.Parameters.GetValueOrDefault("clientid"),
        //        Secret = config.Parameters.GetValueOrDefault("secret"),
        //        ServiceEndpoint = config.ConnectionStr.StartsWith(endpointPrefix, StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(endpointPrefix.Length) : config.ConnectionStr
        //    };
        //    //UpsertJobDetail($"APM configuration: {JsonConvert.SerializeObject(settings)}", JobState.Finished);
        //    return new APMClient(settings);
        //}

        public override void CleanUp()
        {

        }

        public override void Finish()
        {
        }

        private void UpsertJobDetail(string comment, JobState jobState, bool needRecordJobDetail = false)
        {
            if (jobState == JobState.Exception || jobState == JobState.Failed)
            {
                _logger.LogError("Newsletter email enhance job error: {Comment}", comment);
                ExeContext.JobManagerService.UpdateJobProgress(jobId, 100);
                ExeContext.JobManagerService.UpdateJobState(jobId, jobState);
            }
            else
            {
                _logger.LogInformation("Newsletter email enhance info: {Comment}", comment);
            }

            if (jobState == JobState.Exception || jobState == JobState.Failed || needRecordJobDetail)
            {
                try
                {
                    NewsletterEmailEnhanceJobDetail jobDetail = new NewsletterEmailEnhanceJobDetail(jobId, jobState, comment);
                    ExeContext.JobManagerService.UpsertJobDetails(new JobDetailDto[] { jobDetail.Convert2BaseDto() });
                }
                catch (Exception ex)
                {
                    _logger.LogError($"An error occurred while upsertting job detail: {ex}");
                }
            }
        }
    }

    public class NewsletterEmailEnhanceJobDetail : JobDetailDto
    {
        public NewsletterEmailEnhanceJobDetail(string id, JobState jobState, string comment) : base(id, jobState, comment)
        {
            long utcTicks = DateTime.UtcNow.Ticks;
            StartTime = utcTicks;
            EndTime = utcTicks;
        }

        [CustomColumn(DisplayName = "Start time", InternalName = "StartTime", Type = CustomColumnType.UTCTicks)]
        public long StartTime { get; set; }

        [CustomColumn(DisplayName = "End time", InternalName = "EndTime", Type = CustomColumnType.UTCTicks)]
        public long EndTime { get; set; }
    }

    public class NewsletterEmailSendStatusModel
    {
        public bool HasFinished { get; set; }
        public string ExceptionComment { get; set; }
    }
}
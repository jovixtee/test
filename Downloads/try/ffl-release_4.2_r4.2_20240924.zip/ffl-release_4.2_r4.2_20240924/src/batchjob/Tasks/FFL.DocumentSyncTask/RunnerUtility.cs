﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Job.Interface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Extensions.Logging;
using Transfer.Base;
using System.Threading;
using Transfer.Base.FTP;

namespace FFL.DocumentSyncTask
{
    public partial class DocumentSyncRunner
    {
        private void CreateFolder(string path)
        {
            try
            {
                if (!ftpClient.Exist(path))
                {
                    var folders = new List<string>();
                    if (IsWindows)
                    {
                        folders = path.Split("\\").ToList();
                    }
                    else
                    {
                        folders = path.Split(@"/").ToList();
                    }
                    var sonpath = string.Empty;
                    bool f = true;
                    folders.ForEach(p =>
                    {
                        sonpath = f ? p : $@"{sonpath}/{p}";
                        if (!ftpClient.Exist(sonpath))
                        {
                            ftpClient.CreateDirectory(sonpath);
                        }
                        f = false;
                    });
                }
            }
            catch (Exception ex)
            {
                UpsertJobDetail($"An error occurred while creating folder: {path}, error: {ex}", JobState.Exception);
                throw;
            }
        }

        private void CreateFolder(List<string> paths)
        {
            paths.ForEach(path =>
            {
                CreateFolder(path);
            });
        }

        private void SliftcProcessExecute(string args)
        {
            try
            {

                System.Diagnostics.ProcessStartInfo start = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = FileEncryptAppPath,
                    Arguments = args,
                    UseShellExecute = false,
                    RedirectStandardOutput = true
                };
                using System.Diagnostics.Process process = System.Diagnostics.Process.Start(start);
                while (!process.HasExited)
                {
                    process.WaitForExit();
                }
                process.Kill();
                Thread.Sleep(100);
            }
            catch (Exception e)
            {
                UpsertJobDetail($"SliftcProcessExecute error: {e.Message}", JobState.Exception);
            }
        }

        public void DeleteSFTPFolder(SftpProvider sftpProvider, string folderPath)
        {
            try
            {
                sftpProvider.DeleteDirectory(folderPath);
            }
            catch (Exception ex)
            {
                UpsertJobDetail($"An error occurred while DeleteSFTPFolder.{ex}", JobState.Exception);
            }
        }

        public void DeleteSFTPFile(SftpProvider sftpProvider, string filePath)
        {
            try
            {
                sftpProvider.DeleteFile(filePath);
            }
            catch (Exception ex)
            {
                UpsertJobDetail($"An error occurred while DeleteSFTPFile.{ex}", JobState.Exception);
            }
        }

        private void UpsertJobDetail(string comment, JobState jobState, bool needRecordJobDetail = false)
        {
            if (jobState == JobState.Exception)
            {
                JobHasError = true;
                ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 100);
                ExeContext.JobManagerService.UpdateJobState(ExeContext.Job.Id, jobState);
            }
            else
            {
                logger.LogInformation("Infomation");
            }

            if (jobState == JobState.Exception || jobState == JobState.Failed || needRecordJobDetail)
            {
                try
                {
                    DocSyncJobDetail jobDetail = new DocSyncJobDetail(ExeContext.Job.Id, jobState, comment);
                    ExeContext.JobManagerService.UpsertJobDetails(new JobDetailDto[] { jobDetail.Convert2BaseDto() });
                }
                catch (Exception ex)
                {
                    logger.LogError($"An error occurred while upsertting job detail: {ex}");
                }
            }
        }

        private void ReadSecretCode(ref string secretcode)
        {
            try
            {
                if (this.OpenEncryption)
                {
                    if (File.Exists(secretcode))
                    {
                        var textContent = File.ReadAllText(secretcode);
                        secretcode = textContent;
                    }
                    else
                    {
                        JobHasError = true;
                        UpsertJobDetail("can't find secretcode file", JobState.Exception);
                        throw new FFLSyncDependencyException("can't find secretcode file");
                    }
                }
            }
            catch (Exception e)
            {
                UpsertJobDetail("ReadSecretCode error" + e.Message, JobState.Exception);
            }
        }

        private static string AddMask(string FileName)
        {
            try
            {
                var h = FileName.LastIndexOf('_');
                if (h == -1) return FileName;
                var realName = FileName[0..h];
                if (realName.Length <= 4) return FileName;
                var newRealName = realName[0..4].PadRight(realName.Length, '*');
                var l = FileName[h..^0];
                return newRealName + l;
            }
            catch (Exception)
            {
                return FileName;
            }
        }
    }
}

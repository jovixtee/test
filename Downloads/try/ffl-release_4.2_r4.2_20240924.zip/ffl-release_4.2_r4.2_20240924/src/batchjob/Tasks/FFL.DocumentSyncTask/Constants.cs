﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Job.Interface;
using Newtonsoft.Json;
using PipelineJob.Base.Internal;
using System.Configuration;
using System.Xml;

namespace FFL.DocumentSyncTask
{

    internal class Constants
    {
        internal static string MediaFileMetaName = "Media_Metadata.json";
        internal static string MetaNamesuffix = "_Metadata.json";
        internal static string Media = "MediaInfo";
        public static string DataSourceHeader { get; internal set; } = "X-DataSource";
        public static string CDataSourceDataSync { get; internal set; } = "DataSync";
    }

    public class DocSyncExecutionSetting
    {
        [JsonProperty(PropertyName = "FileEncryptAppPath")]
        public string FileEncryptAppPath { get; set; }
        [JsonProperty(PropertyName = "FilePathToBeEncrypt")]
        public string FilePathToBeEncrypt { get; set; }
        [JsonProperty(PropertyName = "FilePathPfx")]
        public string FilePathPfx { get; set; }
        [JsonProperty(PropertyName = "SecretCode")]
        public string SecretCode { get; set; }
        [JsonProperty(PropertyName = "FilePathCerUsedEncrypted")]
        public string FilePathCerUsedEncrypted { get; set; }
        [JsonProperty(PropertyName = "FilePathToBeDecrypt")]
        public string FilePathToBeDecrypt { get; set; }
        [JsonProperty(PropertyName = "System")]
        public string System { get; set; }
        [JsonProperty(PropertyName = "EntityName")]
        public string EntityName { get; set; }
        [JsonProperty(PropertyName = "PushFolderName")]
        public string PushFolderName { get; set; }
        [JsonProperty(PropertyName = "PullFolderName")]
        public string PullFolderName { get; set; }
        [JsonProperty(PropertyName = "DocSyncFolderPath")]
        public string DocSyncFolderPath { get; set; }
        [JsonProperty(PropertyName = "DocSyncFolderPathLinux")]
        public string DocSyncFolderPathLinux { get; set; }
        [JsonProperty(PropertyName = "OpenEncryption")]
        public bool OpenEncryption { get; set; }
    }

    public class DocSyncJobDetail : JobDetailDto
    {
        public DocSyncJobDetail(string id, JobState jobState, string comment) : base(id, jobState, comment)
        {
            long utcTicks = DateTime.UtcNow.Ticks;
            StartTime = utcTicks;
            EndTime = utcTicks;
        }

        [CustomColumn(DisplayName = "Push media count", InternalName = "PushMediaCount", Type = CustomColumnType.String)]
        public int PushMediaCount { get; set; }
        [CustomColumn(DisplayName = "Pull media count", InternalName = "PullMediaCount", Type = CustomColumnType.String)]
        public int PullMediaCount { get; set; }
        [CustomColumn(DisplayName = "Start time", InternalName = "StartTime", Type = CustomColumnType.UTCTicks)]
        public long StartTime { get; set; }

        [CustomColumn(DisplayName = "End time", InternalName = "EndTime", Type = CustomColumnType.UTCTicks)]
        public long EndTime { get; set; }
    }
}

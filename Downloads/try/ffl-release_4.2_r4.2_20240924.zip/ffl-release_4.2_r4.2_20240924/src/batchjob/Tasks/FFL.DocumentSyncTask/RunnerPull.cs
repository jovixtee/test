﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using APM.SDK;
using APM.SDK.DataContract.CaseDocuments;
using APM.SDK.Messages.WebApi.CaseDocumentSync;
using APM.SDK.Services;
using Job.Interface;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using Transfer.Base.FTP;

namespace FFL.DocumentSyncTask
{
    public partial class DocumentSyncRunner
    {
        private string PullFolderPath = string.Empty;
        public async Task PullDataFromSFTP(SftpProvider sftpProvider, APMClient2 client)
        {
            UpsertJobDetail($"Entered method PullDataFromSFTP.", JobState.Finished);
            PullFolderInit();
            var folders = sftpProvider.ListDirectory(PullFolderPath).Where(item => item.IndexOf("_finish") > -1).ToList();
            if (folders == null || !folders.Any())
            {
                UpsertJobDetail($"There is no folders need to pull from sftp.", JobState.Finished, true);
                ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 50);
                return;
            }
            UpsertJobDetail($"Need to pull {folders.Count} folder(s) from sftp", JobState.Finished, true);
            var folderIndex = 0;
            foreach (var folder in folders)
            {
                string currentFinishFolder = IsWindows ? $@"{PullFolderPath}\{folder}" : $@"{PullFolderPath}/{folder}";
                var fileIndexInFolder = 0;
                folderIndex++;
                try
                {
                    UpsertJobDetail($"Start to pull folder, folder index: {folderIndex}, total folder: {folders.Count}, path: {currentFinishFolder}", JobState.Finished, true);
                    var files = sftpProvider.ListDirectory(currentFinishFolder).ToList();
                    var fileCount = files.Count > 0 ? files.Count - 1 : 0;//exclude Metadata folder
                    foreach (var fileitem in files)
                    {
                        var file = fileitem;
                        try
                        {
                            if (Cts.IsCancellationRequested)
                            {
                                throw new FFLSyncStopException("The job has stopped");
                            }
                            if (!string.Equals(file, "Metadata"))
                            {
                                fileIndexInFolder++;
                                UpsertJobDetail($"Start pull file: {file}, file index: {fileIndexInFolder}, total file: {fileCount}, folder index: {folderIndex}, total folder: {folders.Count}", JobState.Finished);
                                file = FileNameDropExtionsionName(file);
                                var nameWithoutExtension = Path.GetFileNameWithoutExtension(file);
                                var metaDirectoryPath = Path.Combine(currentFinishFolder, "Metadata");
                                var metadataFilePullPath = Path.Combine(metaDirectoryPath, $"{nameWithoutExtension}_{Constants.MediaFileMetaName}");
                                var filePullPath = Path.Combine(currentFinishFolder, file);
                                if (!IsWindows)
                                {
                                    metadataFilePullPath = metadataFilePullPath.Replace(@"\", @"/");
                                    filePullPath = filePullPath.Replace(@"\", @"/");
                                    metaDirectoryPath = metaDirectoryPath.Replace(@"\", @"/");
                                }
                                UpsertJobDetail($"metadataFilePullPath: {metadataFilePullPath}, filePullPath: {filePullPath}", JobState.Finished);

                                var mediaInfo = await GetMeidaMetadata(metadataFilePullPath, sftpProvider);
                                if (mediaInfo != null)
                                {
                                    UpsertJobDetail($"Get file media metadata finish, file index: {fileIndexInFolder}, total file: {fileCount}, folder index: {folderIndex}, total folder: {folders.Count}, MediaId: {mediaInfo.Id}, FileVersionId:{mediaInfo.VersionId}," +
                                        $"MediaFileName: {AddMask(mediaInfo.FileName)}", JobState.Finished, true);
                                    var relativeMetadatas = new Dictionary<string, string>();
                                    var needDeleteFiles = new List<string>();
                                    relativeMetadatas[Constants.Media] = JsonConvert.SerializeObject(mediaInfo);
                                    if (mediaInfo.HasDocument)
                                    {
                                        string mediaId = mediaInfo.Id.ToString();
                                        var metaFiles = sftpProvider.ListDirectory(metaDirectoryPath).Where(item => item.StartsWith(mediaId, StringComparison.InvariantCultureIgnoreCase)).ToList();
                                        foreach (var metaFile in metaFiles)
                                        {
                                            if (metaFile.EndsWith(Constants.MediaFileMetaName, StringComparison.InvariantCultureIgnoreCase))
                                            {
                                                continue;
                                            }
                                            var metaFilePath = Path.Combine(metaDirectoryPath, metaFile);
                                            if (!IsWindows) metaFilePath = metaFilePath.Replace(@"\", @"/");
                                            needDeleteFiles.Add(metaFilePath);
                                            var dataType = metaFile.Replace($"{mediaId}_", "").Replace(Constants.MetaNamesuffix, "");
                                            var content = await GetMetadata(metaFilePath, sftpProvider);
                                            relativeMetadatas[dataType] = content;
                                        }
                                    }
                                    List<byte> fileByteList;
                                    if (OpenEncryption && sftpProvider.Exist($"{filePullPath}.p7"))
                                    {
                                        var fileBytes = sftpProvider.DownloadBytes($"{filePullPath}.p7");
                                        fileByteList = new List<byte>(fileBytes);
                                        fileByteList = DecryptFile(fileByteList, file);
                                        filePullPath += ".p7";
                                    }
                                    else
                                    {
                                        var fileBytes = sftpProvider.DownloadBytes(filePullPath);
                                        fileByteList = new List<byte>(fileBytes);
                                    }
                                    UpsertJobDetail($"Download file finish, file index: {fileIndexInFolder}, total file: {fileCount}, folder index: {folderIndex}, total folder: {folders.Count}", JobState.Finished);
                                    using var stream = new MemoryStream(fileByteList.ToArray());
                                    await UploadFileToAPMWithMetadata(stream, relativeMetadatas, client, mediaInfo.IsDeleted ? $"{mediaInfo.Id}.mediadeleted" : mediaInfo.FileName);
                                }
                                UpsertJobDetail($"Delete file from sftp finish, file index: {fileIndexInFolder}, total file: {fileCount}, folder index: {folderIndex}, total folder: {folders.Count}", JobState.Finished);
                                var utrd = Math.Ceiling(50.0 * (folderIndex - 1) + 50.0 / folders.Count * fileIndexInFolder / fileCount) + 50;
                                ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, Convert.ToInt32(utrd));
                            }
                        }
                        catch (Exception ex) when (!(ex is FFLSyncDependencyException))
                        {
                            UpsertJobDetail($"An error occurred while PullDataFromSFTP: {ex}", JobState.Exception);
                        }
                    }
                    DeleteSFTPFolder(sftpProvider, currentFinishFolder);
                }
                catch (Exception ex)
                {
                    UpsertJobDetail($"An error occurred while pull folder index: {folderIndex}, total folder: {folders.Count}, path: {currentFinishFolder}, error: {ex}", JobState.Exception);
                }
            }
        }

        private async Task UploadFileToAPMWithMetadata(Stream fileStream, Dictionary<string, string> metadatas, APMClient2 Apmclient, string fileName)
        {
            UpsertJobDetail($"Entered method UploadFileToAPMWithMetadata", JobState.Finished);
            try
            {
                await Apmclient.ExecuteAsync<SyncFileToMediaRequest, SyncFileToMediaResponse>
                    (new SyncFileToMediaRequest(metadatas, fileStream, fileName));
                UpsertJobDetail($"UploadFileToAPMWithMetadata complete", JobState.Finished);
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while UploadFileToAPMWithMetadata, error: {ex}", JobState.Exception);
            }
        }

        private async Task<NeedSyncMediaInfo> GetMeidaMetadata(string metadataFilePath, SftpProvider client)
        {
            try
            {
                var metadataJson = await GetMetadata(metadataFilePath, client);
                var media = string.IsNullOrEmpty(metadataJson) ? null : JsonConvert.DeserializeObject<NeedSyncMediaInfo>(metadataJson);
                return media;
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while GetMeidaMetadata, path: {metadataFilePath}, error: {ex}", JobState.Exception);
                return null;
            }
        }

        private async Task<string> GetMetadata(string metadataFilePath, SftpProvider Client)
        {
            try
            {
                var metadataJson = string.Empty;
                using (Stream metadataFileStream = new MemoryStream())
                {
                    string metadataFileData = Client.DownloadFile(metadataFilePath);
                    using StreamWriter writer = new StreamWriter(metadataFileStream);
                    writer.Write(metadataFileData);
                    writer.Flush();
                    
                    metadataFileStream.Position = 0;
                    using StreamReader streamReader = new StreamReader(metadataFileStream);
                    return await streamReader.ReadToEndAsync();
                }
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while GetMetadata, path: {metadataFilePath}, error: {ex}", JobState.Exception);
                return null;
            }
        }
        private List<byte> DecryptFile(List<byte> filebyte, string fileNameAndExtension)
        {
            try
            {
                using MemoryStream stream = new MemoryStream(filebyte.ToArray());
                if (!Directory.Exists(FilePathToBeDecrypt))
                {
                    Directory.CreateDirectory(FilePathToBeDecrypt);
                }
                var pathAndName = $"{FilePathToBeDecrypt}/{fileNameAndExtension}.p7";
                using (var decryptStream = File.Create(pathAndName))
                {
                    stream.CopyTo(decryptStream);
                }
                SliftcProcessExecute($"/d {pathAndName} /pfx {FilePathPfx} {SecretCode}");
                if (File.Exists($"{pathAndName}"))
                {
                    UpsertJobDetail("Exists" + $"{pathAndName}", JobState.Finished);
                    using FileStream fs = new FileStream($"{FileNameDropExtionsionName(pathAndName)}", FileMode.Open);
                    byte[] data = new byte[fs.Length];
                    fs.Read(data, 0, data.Length);
                    fs.Close();
                    File.Delete(pathAndName);
                    File.Delete(FileNameDropExtionsionName(pathAndName));
                    return new List<byte>(data);
                }
                else
                {
                    UpsertJobDetail("Not Exists" + $"{pathAndName}.p7", JobState.Exception);
                    return filebyte;
                }
            }
            catch
            {
                return filebyte;
            }
        }
        private static string FileNameDropExtionsionName(string filename)
        {
            Regex regex = new Regex(@"(?<name>.*).p7$", RegexOptions.None, TimeSpan.FromSeconds(2));
            if (regex.IsMatch(filename))
            {
                return regex.Match(filename).Groups["name"].Value;
            }
            else
            {
                return filename;
            }
        }

        private void PullFolderInit()
        {
            try
            {
                var pullFolderName = executionSetting.PullFolderName;
                var docSyncFolderPath = executionSetting.DocSyncFolderPath;
                PullFolderPath = Path.Combine(docSyncFolderPath, pullFolderName);
                if (!IsWindows)
                {
                    docSyncFolderPath = executionSetting.DocSyncFolderPathLinux;
                    PullFolderPath = Path.Combine(docSyncFolderPath, pullFolderName).Replace(@"\", @"/");
                }
                CreateFolder(docSyncFolderPath);
                UpsertJobDetail($"Doc sync folder: {docSyncFolderPath}", JobState.Finished, true);
                CreateFolder(PullFolderPath);
                UpsertJobDetail($"Pull folder: {PullFolderPath}", JobState.Finished, true);
            }
            catch (Exception e)
            {
                UpsertJobDetail($"PullFolderInit error: {e}", JobState.Exception);
            }
        }
    }
}

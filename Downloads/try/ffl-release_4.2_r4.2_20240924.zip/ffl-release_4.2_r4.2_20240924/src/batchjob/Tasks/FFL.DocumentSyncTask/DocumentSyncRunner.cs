﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System.Reflection;
using APM.SDK;
using APM.SDK.DataContract.CaseDocument;
using APM.SDK.Messages.WebApi.CaseDocumentSync;
using APM.SDK.Services;
using ConnectionAdapterService.Interface.Model;
using Job.Interface;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PipelineJob.Base;
using Replicator.Interface;
using Replicator.Interface.Model;
using Transfer.Base.FTP;

namespace FFL.DocumentSyncTask
{
    public partial class DocumentSyncRunner : PipelineJobRunner
    {
        private SftpProvider ftpClient;
        private Guid currentUserId;
        private APMClient2 apmClient;
        private CRMDataModel crmDataModel;
        private ILogger logger => Logger;
        private bool OpenEncryption = false;
        private string FileEncryptAppPath;
        private string FilePathToBeEncrypt;
        private string FilePathPfx;
        private string SecretCode;
        private string FilePathCerUsedEncrypted;
        private string FilePathToBeDecrypt;
        private string NowTicks = DateTimeOffset.UtcNow.ToString("yyyyMMddHHmmss");
        private string SystemType;
        private bool IsWindows
        {
            get
            {
                return string.Equals(SystemType, "windows", StringComparison.InvariantCultureIgnoreCase);
            }
        }
        private bool JobHasError = false;
        private DocSyncExecutionSetting executionSetting;
        public DocumentSyncRunner(
            
            JobExecutionContext jobContext,
            IReplicatorsService replicatorsService,
            CancellationToken cancellationToken,
            List<ConnectionAdapter> adapters) : base(jobContext, replicatorsService, cancellationToken, adapters)
        {
            
        }

        public ServiceCollection Services { get; private set; }

        public override void CleanUp()
        {
            try
            {
                Directory.Delete(this.ExeContext.TempFolder, true);
            }
            catch (Exception)
            {

            }

            try
            {
                ftpClient?.Dispose();
            }
            catch (Exception)
            {

            }
        }

        public override void Finish()
        {
        }

        public override void Init()
        {
            this.Services = new ServiceCollection();

            try
            {
                var config = Adapters[0];
                string endpointPrefix = "WebUrl=";
                var settings = new APMSettings
                {
                    AuthEndpoint = config.Parameters.GetValueOrDefault("authority"),
                    ClientId = config.Parameters.GetValueOrDefault("clientid"),
                    Secret = config.Parameters.GetValueOrDefault("secret"),
                    ServiceEndpoint = config.ConnectionStr.StartsWith(endpointPrefix, StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(endpointPrefix.Length) : config.ConnectionStr
                };
                
                settings.CustomHeaders = new Dictionary<string, string?>
                {
                    { Constants.DataSourceHeader, Constants.CDataSourceDataSync }
                };

                apmClient = new APMClient2(settings);
            }
            catch (Exception ex)
            {
                string errorMsg = $"Failed to initialize apm for document sync job: {ExeContext.Job.Id}, error: {ex}";
                UpsertJobDetail(errorMsg, JobState.Failed);
                throw new Exception(errorMsg);
            }

            try
            {
                ftpClient = CreateSFTP(Adapters[1]);
            }
            catch (Exception ex)
            {
                string errorMsg = $"Failed to initialize sftp for document sync job: {ExeContext.Job.Id}, error: {ex}";
                UpsertJobDetail(errorMsg, JobState.Failed);
                throw new Exception(errorMsg);
            }

            var contentJson = ExeContext.Job.ProfileJSON;
            if (string.IsNullOrEmpty(contentJson))
            {
                UpsertJobDetail($"There is no profile json for document sync job: {ExeContext.Job.Id}", JobState.Finished);
                contentJson = ReadResourceFile(GetType().Namespace + ".DocumentSyncSetting.json");
            }
            else
            {
                UpsertJobDetail($"Successful get profile json for document sync job: {ExeContext.Job.Id}, json: {contentJson}", JobState.Finished);
            }
            if (!string.IsNullOrEmpty(contentJson))
            {
                this.executionSetting = JsonConvert.DeserializeObject<DocSyncExecutionSetting>(contentJson);
                if (this.executionSetting == null)
                {
                    throw new Exception("Failed to initialize document sync execution setting.");
                }
                InitCrmDataModel();
#if DEBUG
                this.SystemType = "windows";
#else
                this.SystemType = this.executionSetting.System;
#endif
                this.OpenEncryption = this.executionSetting.OpenEncryption;
                this.FileEncryptAppPath = this.executionSetting.FileEncryptAppPath;
                this.FilePathToBeEncrypt = this.executionSetting.FilePathToBeEncrypt;
                this.FilePathPfx = this.executionSetting.FilePathPfx;
                this.SecretCode = this.executionSetting.SecretCode;
                this.FilePathCerUsedEncrypted = this.executionSetting.FilePathCerUsedEncrypted;
                this.FilePathToBeDecrypt = this.executionSetting.FilePathToBeDecrypt;
            }
            else
            {
                throw new Exception("Failed to get document sync profile json.");
            }
        }

        private string ReadResourceFile(string filename)
        {
            var thisAssembly = Assembly.GetExecutingAssembly();
            using (var stream = thisAssembly.GetManifestResourceStream(filename))
            {
                using (var reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }
        }

        private void InitCrmDataModel()
        {
            try
            {
                currentUserId = Guid.Empty;
                var entityName = this.executionSetting.EntityName;
                var orid = GetPortalCRMOrgIdConfig(apmClient);
                UpsertJobDetail("orid: " + orid, JobState.Finished);
                crmDataModel = new CRMDataModel()
                {
                    OrganizationId = orid,
                    Entity = entityName,
                    RecordId = Guid.Empty.ToString()
                };
            }
            catch (Exception ex)
            {
                UpsertJobDetail("InitCrmDataModel error: " + ex.Message, JobState.Exception);
                throw;
            }
        }

        //private APMClient CreateDocumentService(ConnectionAdapter config)
        //{
        //    string endpointPrefix = "WebUrl=";
        //    APMSettings settings = new APMSettings
        //    {
        //        AuthEndpoint = config.Parameters.GetValueOrDefault("authority"),
        //        ClientId = config.Parameters.GetValueOrDefault("clientid"),
        //        Secret = config.Parameters.GetValueOrDefault("secret"),
        //        ServiceEndpoint = config.ConnectionStr.StartsWith(endpointPrefix, StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(endpointPrefix.Length) : config.ConnectionStr
        //    };
        //    //UpsertJobDetail($"APM configuration: {JsonConvert.SerializeObject(settings)}", JobState.Finished);
        //    settings.CustomHeaders = new Dictionary<string, string?>();
        //    settings.CustomHeaders.Add(Constants.DataSourceHeader, Constants.CDataSourceDataSync);
        //    return new APMClient(settings);
        //}

        private SftpProvider CreateSFTP(ConnectionAdapter config)
        {
            SftpConfig sftpConfig = new SftpConfig()
            {
                Host = config.Parameters.GetValueOrDefault("Host"),
                SecretPhase = config.Parameters.GetValueOrDefault("SecretPhase"),
                SecretCode = config.Parameters.GetValueOrDefault("SecretCode"),
                Port = Convert.ToInt32(config.Parameters.GetValueOrDefault("Port")),
                PrivateKey = config.Parameters.GetValueOrDefault("PrivateKey"),
                UserName = config.Parameters.GetValueOrDefault("UserName")
            };
            string authType = config.Parameters.GetValueOrDefault("AuthType");
            if (Enum.TryParse(authType, out SFTPAuthenticationType sftpAuthType))
            {
                switch (sftpAuthType)
                {
                    case SFTPAuthenticationType.PrivateKey:
                        sftpConfig.AuthType = SftpAuthType.PrivateKey;
                        break;
                    case SFTPAuthenticationType.SecureCode:
                        sftpConfig.AuthType = SftpAuthType.SecureCode;
                        break;
                    case SFTPAuthenticationType.PrivateKeyAndSecureCode:
                        sftpConfig.AuthType = SftpAuthType.PrivateKeySecureCode;
                        break;
                }
            }
            //UpsertJobDetail($"SFTP configuration: {JsonConvert.SerializeObject(sftpConfig)}", JobState.Finished);
            SftpProvider provider = new SftpProvider(sftpConfig);
            return provider;
        }

        public override void Run()
        {
            try
            {
                UpsertJobDetail($"Start run document sync job: {ExeContext.Job.Id}", JobState.Finished, true);
                ReadSecretCode(ref this.SecretCode);
                PushDataToSFTP(apmClient, ftpClient).GetAwaiter().GetResult();
                UpsertJobDetail($"PushDataToSFTP complete document sync job: {ExeContext.Job.Id}", JobState.Finished, true);
                PullDataFromSFTP(ftpClient, apmClient).GetAwaiter().GetResult();
                UpsertJobDetail($"PullDataFromSFTP complete document sync job: {ExeContext.Job.Id}", JobState.Finished, true);
                UpsertJobDetail($"Run document sync job complete: {ExeContext.Job.Id}", JobState.Finished, true);
            }
            catch (FFLSyncStopException)
            {
                logger.LogInformation("The job has stopped.");
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"Failed to run document sync job, error: {ex}", JobState.Failed);
            }
        }

        private string GetPortalCRMOrgIdConfig(APMClient2 Apmclient)
        {
            try
            {
                var response = Apmclient.Execute<GetPortalCRMOrgIdConfigRequest, GetPortalCRMOrgIdConfigResponse>
                    (new GetPortalCRMOrgIdConfigRequest());
                return response.Response.ToString();
            }
            catch (Exception e) when (!(e is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while GetPortalCRMOrgIdConfig.{e}", JobState.Exception);
                throw;
            }
        }
    }
}

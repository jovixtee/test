﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System.Text;
using System.Web;
using APM.SDK;
using APM.SDK.DataContract.CaseDocument;
using APM.SDK.DataContract.CaseDocuments;
using APM.SDK.Messages;
using APM.SDK.Messages.WebApi;
using APM.SDK.Messages.WebApi.CaseDocumentSync;
using APM.SDK.Messages.WebApi.Media;
using APM.SDK.Services;
using Job.Interface;
using Newtonsoft.Json;
using Transfer.Base.FTP;

namespace FFL.DocumentSyncTask
{
    public partial class DocumentSyncRunner
    {
        private string pushFolderPath = string.Empty;
        private string currentPushFolderPath = string.Empty;
        private string metadataPushFolderPath = string.Empty;
        private int pushMediaIndex = 0;
        private int totalMediaCount = 0;
        private async Task PushDataToSFTP(APMClient2 client, SftpProvider sftpProvider)
        {
            UpsertJobDetail($"Entered method PushDataToSFTP.", JobState.Finished);
            PushFolderInit();
            var mediaInfoList = await GetNeedSyncMediaInfoList(client, crmDataModel);
            if (mediaInfoList == null || mediaInfoList.Count == 0)
            {
                UpsertJobDetail("There is no need sync media information.", JobState.Finished, true);
                DeleteSFTPFolder(ftpClient, currentPushFolderPath);
                return;
            }
            else
            {
                UpsertJobDetail($"There are {mediaInfoList.Count} media(s) pending to be synced.", JobState.Finished, true);
                totalMediaCount = mediaInfoList.Count;
            }
            foreach (var media in mediaInfoList)
            {
                if (Cts.IsCancellationRequested)
                {
                    throw new FFLSyncStopException("The job has stopped");
                }
                pushMediaIndex++;
                try
                {
                    CRMDataModel crmDataView = new CRMDataModel()
                    {
                        ConnectionId = crmDataModel.ConnectionId,
                        OrganizationId = crmDataModel.OrganizationId,
                        UserId = currentUserId.ToString(),
                        UserType = "SystemUser",
                        RecordId = media.RecordId,
                        Entity = media.Entity
                    };
                    UpsertJobDetail($"Start push file. index: {pushMediaIndex}, total count: {totalMediaCount}, MediaId: {media.Id}, FileVersionId:{media.VersionId}," +
                        $"MediaFileName: {AddMask(media.FileName)}", JobState.Finished, true);
                    var fileContent = new byte[0];
                    if (media.IsDeleted)
                    {
                        fileContent = new byte[3] { 1, 2, 3 };
                        UpsertJobDetail($"Media is deleted, MediaId: {media.Id}, MediaFileName: {AddMask(media.FileName)}", JobState.Finished, true);
                    }
                    else
                    {
                        fileContent = await GetMediaFileContent(media, client, crmDataView);
                        if (fileContent == null)
                        {
                            continue;
                        }
                    }
                    var ifFileUpload = UploadFileContentToSFTP(media, fileContent, sftpProvider);
                    var ifMetaJsonUpload = UploadMediaMetadataFileToSFTP(media, sftpProvider);
                    if (media.HasDocument)
                    {
                        var metadatas = await GetMediaRelatedMetadata(client, media);
                        foreach (var pair in metadatas)
                        {
                            bool uploadMetadataResult = UploadRelatedMetadataFileToSFTP(media, pair.Key, pair.Value, sftpProvider);
                            ifMetaJsonUpload &= uploadMetadataResult;
                        }
                    }
                    if (ifFileUpload && ifMetaJsonUpload)
                    {
                        await UpdateDocumentRelatedRecordSyncStatus(media, client, crmDataModel);
                        await UpdateMediaRecordSyncStatus(media, client, crmDataModel);
                    }
                    var utrd = Math.Ceiling(50.0 * pushMediaIndex / totalMediaCount);
                    ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, Convert.ToInt32(utrd));
                }
                catch (Exception ex) when (!(ex is FFLSyncDependencyException))
                {
                    JobHasError = true;
                    UpsertJobDetail($"An error occurred while PushDataToSFTP. Error: {ex}", JobState.Exception);
                }
            }
            SetJobFolderFinish();
        }

        public async Task<Dictionary<string, List<object>>> GetMediaRelatedMetadata(APMClient2 client, NeedSyncMediaInfo media)
        {
            try
            {
                var response = await client.ExecuteAsync<GetRelativeMetadataRequest, GetRelativeMetadataResponse>(new GetRelativeMetadataRequest(media));
                var mediaRelatedMetadata = response.Response;
                if (mediaRelatedMetadata != null && mediaRelatedMetadata.Count > 0)
                {
                    UpsertJobDetail($"Get media related metadata for: {media.Id}, metadatas: {string.Join('|', mediaRelatedMetadata.Keys)}, index: {pushMediaIndex}, total: {totalMediaCount}", JobState.Finished);
                    return mediaRelatedMetadata;
                }
                else
                {
                    ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 50);
                    return new Dictionary<string, List<object>>();
                }
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"Failed to get relative metadata.{ex}", JobState.Exception);
                ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 50);
                return new Dictionary<string, List<object>>();
            }
        }

        public async Task<List<NeedSyncMediaInfo>> GetNeedSyncMediaInfoList(APMClient2 client, CRMDataModel crmData)
        {
            try
            {
                var response = await client.ExecuteAsync<GetNeedSyncMediasRequest, GetNeedSyncMediasResponse>(new GetNeedSyncMediasRequest(crmData));
                var mediaInfoList = response.Response;
                if (mediaInfoList != null && mediaInfoList.Count() > 0)
                {
                    UpsertJobDetail($"Need sync media count: {mediaInfoList.Count}.", JobState.Finished);
                    return response.Response;
                }
                else
                {
                    ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 50);
                    return new List<NeedSyncMediaInfo>();
                }
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while GetNeedSyncMediaInfoList.{ex}", JobState.Exception);
                ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 50);
                return new List<NeedSyncMediaInfo>();
            }
        }
        private async Task<byte[]> GetMediaFileContent(NeedSyncMediaInfo media, APMClient2 client, CRMDataModel crmData)
        {
            try
            {
                if (media.HasDocument)
                {
                    var response = await client.ExecuteAsync<DownloadFileVersionRequest, DownloadFileVersionResponse>(new DownloadFileVersionRequest(crmData, media.VersionId.ToString()));
                    UpsertJobDetail($"Download file version finish, index: {pushMediaIndex}, total: {totalMediaCount}", JobState.Finished);
                    return response.Response;
                }
                else
                {
                    var response = await client.ExecuteAsync<MediaDownloadRequest, MediaDownloadResponse>(new MediaDownloadRequest(HttpUtility.UrlEncode(media.FilePath)));
                    UpsertJobDetail($"Download file content finish, index: {pushMediaIndex}, total: {totalMediaCount}", JobState.Finished);
                    return response.Response;
                }
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while GetMediaFileContent: {ex}", JobState.Exception);
                return null;
            }
        }

        private bool UploadFileContentToSFTP(NeedSyncMediaInfo media, byte[] fileContent, SftpProvider sftpProvider)
        {
            try
            {
                var fileNameAndExtension = media.IsDeleted ? $"{media.Id}.mediadeleted" : $"{media.Id}.{media.FileType.TrimStart('.')}";
                var filePath = string.Empty;
                filePath = IsWindows
                    ? Path.Combine(currentPushFolderPath, fileNameAndExtension)
                    : Path.Combine(currentPushFolderPath, fileNameAndExtension).Replace(@"\", @"/");

                UpsertJobDetail($"UploadFileContentToSFTP Path: {filePath}", JobState.Finished);

                using var stream = new MemoryStream(fileContent);
                if (OpenEncryption)
                {
                    using var encryptStream = EncryptFile(stream, fileNameAndExtension, ref filePath);
                    sftpProvider.UploadFile(filePath, encryptStream);
                }
                else
                {
                    sftpProvider.UploadFile(filePath, stream);
                }
                UpsertJobDetail($"Upload file content to sftp finish, path: {filePath}, index: {pushMediaIndex}, total: {totalMediaCount}", JobState.Finished);
                return true;
            }
            catch (Exception ex)
            {
                UpsertJobDetail($"An error occurred while UploadFileContentToSFTP.{ex}", JobState.Exception);
                return false;
            }
        }

        private bool UploadMediaMetadataFileToSFTP(NeedSyncMediaInfo media, SftpProvider sftpProvider)
        {
            try
            {
                var metaDirectoryPath = metadataPushFolderPath;//Path.Combine(MetadataPushFolderPath, media.Id.ToString());
                var filePath = Path.Combine(metaDirectoryPath, $"{media.Id}_Media_Metadata.json");
                if (!IsWindows)
                {
                    filePath = filePath.Replace(@"\", @"/");
                    metaDirectoryPath = metaDirectoryPath.Replace(@"\", @"/");
                }
                CreateFolder(metaDirectoryPath);
                UpsertJobDetail($"UploadMediaMetadataFileToSFTP Path:{filePath}", JobState.Finished);
                var metadataStr = JsonConvert.SerializeObject(media);
                using var stream = new MemoryStream(Encoding.UTF8.GetBytes(metadataStr));
                sftpProvider.UploadFile(filePath, stream);
                UpsertJobDetail($"Upload file metadta file to sftp finish, media id: {media.Id}, index: {pushMediaIndex}, total: {totalMediaCount}", JobState.Finished);
                return true;
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while UploadMediaMetadataFileToSFTP, path: {metadataPushFolderPath}, media id: {media.Id}, error: {ex}", JobState.Exception);
                return false;
            }
        }

        private bool UploadRelatedMetadataFileToSFTP(NeedSyncMediaInfo media, string dataType, List<object> dataObject, SftpProvider sftpProvider)
        {
            try
            {
                var filePath = Path.Combine(metadataPushFolderPath, $"{media.Id}_{dataType}_Metadata.json");
                if (!IsWindows)
                {
                    filePath = filePath.Replace(@"\", @"/");
                }
                UpsertJobDetail($"UploadMediaMetadataFileToSFTP: dataType: {dataType}, Path: {filePath}", JobState.Finished);
                var metadataStr = JsonConvert.SerializeObject(dataObject);
                using var stream = new MemoryStream(Encoding.UTF8.GetBytes(metadataStr));
                sftpProvider.UploadFile(filePath, stream);
                UpsertJobDetail($"Upload metadata file to sftp finish, dataType: {dataType}, index: {pushMediaIndex}, total: {totalMediaCount}", JobState.Finished);
                return true;
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while UploadMediaMetadataFileToSFTP.{ex}", JobState.Exception);
                return false;

            }
        }

        private async Task UpdateDocumentRelatedRecordSyncStatus(NeedSyncMediaInfo media, APMClient2 client, CRMDataModel crmData)
        {
            try
            {
                if (media.Id != default)
                {
                    await client.ExecuteAsync<APMRequest, APMResponse>(new APMRequest { RequestPath = $"api/CaseDocumentSync/UpdateDocRelatedSyncStatusByMediaId?mediaId={media.Id}", Method = HttpMethod.Post, InputParameters = crmData });
                    UpsertJobDetail($"Update document related record sync status finish, index: {pushMediaIndex}, total: {totalMediaCount}", JobState.Finished);
                }
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while UpdateDocumentRelatedRecordSyncStatus.{ex}", JobState.Exception);
            }
        }

        private async Task UpdateMediaRecordSyncStatus(NeedSyncMediaInfo media, APMClient2 client, CRMDataModel crmData)
        {
            try
            {
                if (media.Id != default)
                {
                    await client.ExecuteAsync<UpdateMediaSyncStatusRequest, UpdateMediaSyncStatusResponse>
                        (new UpdateMediaSyncStatusRequest(crmData, media.Id.ToString()));
                    UpsertJobDetail($"Update media sync status finish, index: {pushMediaIndex}, total: {totalMediaCount}", JobState.Finished);
                }
            }
            catch (Exception ex) when (!(ex is FFLSyncDependencyException))
            {
                UpsertJobDetail($"An error occurred while UpdateMediaRecordSyncStatus.{ex}", JobState.Exception);
            }
        }

        private MemoryStream EncryptFile(MemoryStream stream, string fileNameAndExtension, ref string filePath)
        {
            try
            {
                if (!Directory.Exists(FilePathToBeEncrypt))
                {
                    Directory.CreateDirectory(FilePathToBeEncrypt);
                }
                var pathAndName = $"{FilePathToBeEncrypt}/{fileNameAndExtension}";
                using (var encryptStream = File.Create(pathAndName))
                {

                    stream.CopyTo(encryptStream);
                }
                SliftcProcessExecute($"/e {pathAndName} /pfx {FilePathPfx} {SecretCode} /cer {FilePathCerUsedEncrypted}");
                if (File.Exists($"{pathAndName}.p7"))
                {
                    UpsertJobDetail("Exists" + $"{pathAndName}.p7", JobState.Finished);
                    using FileStream fs = new FileStream($"{pathAndName}.p7", FileMode.Open);
                    byte[] data = new byte[fs.Length];
                    fs.Read(data, 0, data.Length);
                    fs.Close();
                    File.Delete(pathAndName);
                    File.Delete($"{pathAndName}.p7");
                    MemoryStream ms = new MemoryStream(data);
                    filePath += ".p7";
                    UpsertJobDetail("Push work " + pathAndName + "Encrypt Success", JobState.Finished);
                    return ms;
                }
                else
                {
                    UpsertJobDetail("Not Exists" + $"{pathAndName}.p7", JobState.Finished);
                    return stream;
                }
            }
            catch (Exception e)
            {
                UpsertJobDetail($"Return original stream,An error occurred while EncryptFile.{e}", JobState.Exception);
                return stream;
            }
        }

        private void PushFolderInit()
        {
            try
            {
                var docSyncFolderPath = executionSetting.DocSyncFolderPath;
                pushFolderPath = Path.Combine(docSyncFolderPath, executionSetting.PushFolderName);
                currentPushFolderPath = Path.Combine(pushFolderPath, $"{NowTicks}_inprogress");
                metadataPushFolderPath = Path.Combine(currentPushFolderPath, "Metadata");
                if (!IsWindows)
                {
                    docSyncFolderPath = executionSetting.DocSyncFolderPathLinux;
                    pushFolderPath = Path.Combine(docSyncFolderPath, executionSetting.PushFolderName).Replace(@"\", @"/");
                    currentPushFolderPath = Path.Combine(pushFolderPath, $"{NowTicks}_inprogress").Replace(@"\", @"/");
                    metadataPushFolderPath = Path.Combine(currentPushFolderPath, "Metadata").Replace(@"\", @"/");
                }
                CreateFolder(new List<string>()
                {
                    docSyncFolderPath,
                });
                UpsertJobDetail($"Doc sync folder: {docSyncFolderPath}", JobState.Finished, true);
                CreateFolder(new List<string>()
                {
                    pushFolderPath,
                });
                UpsertJobDetail($"Push folder: {pushFolderPath}", JobState.Finished, true);
                CreateFolder(new List<string>()
                {
                    currentPushFolderPath,
                });
                UpsertJobDetail($"Current push folder: {currentPushFolderPath}", JobState.Finished, true);
                CreateFolder(new List<string>()
                {
                    metadataPushFolderPath,
                });
                UpsertJobDetail($"Push metadata folder: {metadataPushFolderPath}", JobState.Finished, true);
            }
            catch (Exception e)
            {
                UpsertJobDetail($"PushFolderInit error: {e}", JobState.Exception);
            }
        }

        private void SetJobFolderFinish()
        {
            try
            {
                var oldName = currentPushFolderPath;
                var newName = currentPushFolderPath.Replace("inprogress", "finish");
                if (!IsWindows)
                {
                    oldName = oldName.Replace(@"\", @"/");
                    newName = newName.Replace(@"\", @"/");
                }
                UpsertJobDetail($"Rename push folder finish, from {oldName} to {newName}", JobState.Finished);
                ftpClient.RenameFile(oldName, newName);
            }
            catch (Exception e)
            {
                UpsertJobDetail($"SetJobFolderFinish error: {e}", JobState.Exception);
            }
        }
    }
}

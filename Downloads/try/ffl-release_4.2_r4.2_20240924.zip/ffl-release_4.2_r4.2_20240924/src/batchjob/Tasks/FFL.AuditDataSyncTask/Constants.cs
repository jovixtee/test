﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.FFL.Sync.Common;
using Job.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FFL.DataSyncTask
{
    internal class Constants
    {
        internal static Int32 RunJobCount = 50;
        internal static Int32 OnceCount = 400;
        internal static Int32 PageOnceCount = 80;
        internal static List<DataType>  SyncToIntranetEntities = new List<DataType>() { };
        internal static List<DataType>  SyncToInternetEntities = new List<DataType>() {  DataType.TrackPageViewEntity, DataType.TrackVisitSessionEntity, DataType.TrackVisitUserEntity, DataType.TrackAttachmentDownloadEntity, DataType.ErrorTrackings, DataType.AuditModel};

        public static string DataSourceHeader { get; internal set; } = "X-DataSource";
        public static string CDataSourceDataSync { get; internal set; } = "DataSync";
    }
    public class DocSyncJobDetail : JobDetailDto
    {
        public DocSyncJobDetail(string id, JobState jobState, string title, string comment) : base(id, jobState, comment)
        {
            long utcTicks = DateTime.UtcNow.Ticks;
            StartTime = utcTicks;
            EndTime = utcTicks;
            EntityTitle = title;
        }

        [CustomColumn(DisplayName = "Sync Count", InternalName = "SyncCount", Type = CustomColumnType.String)]
        public int SyncCount { get; set; }
        [CustomColumn(DisplayName = "Entity Title", InternalName = "EntityTitle", Type = CustomColumnType.String)]
        public string EntityTitle { get; set; }
        [CustomColumn(DisplayName = "Start time", InternalName = "StartTime", Type = CustomColumnType.UTCTicks)]
        public long StartTime { get; set; }

        [CustomColumn(DisplayName = "End time", InternalName = "EndTime", Type = CustomColumnType.UTCTicks)]
        public long EndTime { get; set; }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Camps.FFL.Sync.Common
{
    [DataContract]
    public class DataSyncRequest
    {
        [DataMember]
        public List<object> Data { get; set; }
        [DataMember]
        public List<SyncJobReuslt> DataResult { get; set; }
        [DataMember]
        public Dictionary<Guid, List<Guid>> RelativeMedias { get; set; } = new Dictionary<Guid, List<Guid>>();
        [DataMember]
        public Dictionary<Guid, RelatvieEntity> RelativeEntities { get; set; } = new Dictionary<Guid, RelatvieEntity>();
        [DataMember]
        public DataMode DataMode { get; set; } = DataMode.None;
        [DataMember]
        public SyncMode SyncMode { get; set; } = SyncMode.None;
        [DataMember]
        public DataType DataType { get; set; } = DataType.None;
        [DataMember]
        public int SyncJobCount { get; set; } = 500;
        [DataMember]
        public int SyncJobPage { get; set; } = 1;
        [DataMember]
        public string TaskJobId { get; set; }
    }

    [DataContract]
    public class DataSyncResponse
    {
        [DataMember]
        public List<Object> Data { get; set; }
        [DataMember]
        public List<SyncJobReuslt> DataResult { get; set; }
        [DataMember]
        public Dictionary<Guid, List<Guid>> RelativeMedias { get; set; } = new Dictionary<Guid, List<Guid>>();
        [DataMember]
        public Dictionary<Guid, RelatvieEntity> RelativeEntities { get; set; } = new Dictionary<Guid, RelatvieEntity>();
        [DataMember]
        public DataMode DataMode { get; set; } = DataMode.None;
        [DataMember]
        public SyncMode SyncMode { get; set; } = SyncMode.None;
        [DataMember]
        public DataType DataType { get; set; } = DataType.None;
        [DataMember]
        public int SyncJobCount { get; set; } = 500;
        [DataMember]
        public int SyncJobPage { get; set; } = 1;
        [DataMember]
        public string TaskJobId { get; set; }
    }
    [DataContract]
    public class RelatvieEntity
    {
        [DataMember]
        public Dictionary<DataType, List<Object>> Entities { get; set; } = new Dictionary<DataType, List<Object>>();
    }
    [DataContract]
    public class SyncJobReuslt
    {
        [DataMember]
        public Guid Id { get; set; }
        [DataMember]
        public Object OriginData { get; set; }
        [DataMember]
        public SyncItemStatus Status { get; set; }
        [DataMember]
        public DateTimeOffset ModifiedOn { get; set; }
        [DataMember]
        public string ErrorMessage { get; set; }
        [DataMember]
        public bool NeedDelete { get; set; } = false;
    }
    public enum SyncItemStatus : byte
    {
        Successs = 0,
        Failed = 1,
        Conflict = 2,
        DependencynotFound = 3,
        Readonly = 4,
        SkipFailed = 5,
        SkipNotFound = 6
    }
    public enum SyncMode : byte
    {
        None = 0,
        ToInternet = 1,
        ToIntranet = 2
    }
    public enum DataMode : byte
    {
        None = 0,
        ScanData = 1,
        SyncData = 2,
        DeleteData = 3,
        RepairData = 4,
        SyncResult = 5
    }
    public enum DataType : int
    {
        None = 0,
        Activity = 1,
        RotatingBanner = 2,
        MaintenanceBanner = 3,
        TaxonomyEntity = 4,
        TermRelationshipsEntity = 5,
        TermMetaEntity = 6,
        TermEntity = 7,
        TaxonomyMetaEntity = 8,
        Newsletter = 9,
        SiteUser = 10,
        SiteRole = 11,
        UserRole = 12,
        MediaInfo = 13,
        Configuration = 14,
        ViewPage = 15,
        ViewContentPart = 16,
        ViewContentPartField = 17,
        ViewContentField = 18,
        ContentPart = 19,
        ContentField = 20,
        ContentPartField = 21,
        WidgetPermissionMapping = 22,
        ViewPageHistory = 23,
        ViewContentPartHistory = 24,
        ViewContentPartFieldHistory = 25,
        ViewContentFieldHistory = 26,
        WidgetPermissionMappingHistory = 27,
        DocumentEntity = 28,
        DocumentVersionEntity = 29,
        DocumentFolderEntity = 30,
        DocumentRuleEntity = 31,
        Article = 32,
        SiteSettings = 33,
        Event = 34,
        EventDateProvidor = 35,
        EventSubmission = 36,
        UserTrackingEntity = 37,
        Group = 38,
        GroupClaim = 39,
        GroupMembership = 40,
        GroupRole = 41,
        UserLogin = 42,
        UserClaim = 43,
        VolunteerOpportunity = 44,
        VolunteerStory = 45,
        PhotoGalleryModel = 46,
        News = 47,
        NewsletterEmail = 48,
        NewsletterEmailTermRelationship = 49,
        NewsletterEmailOpenRecord = 50,
        NewsletterEmailLinkClickRecord = 51,
        NewsletterEmailHistoryEntity = 52,
        UserGroupInfo = 53,
        Programme = 54,
        ProgrammeInterest = 55,
        ProgrammeProviderRelationship = 56,
        ProgrammeRegion = 57,
        FFLPActivity = 58,
        FFLPArticle = 59,
        FFLPRotatingBanner = 60,
        FFLPGuide = 61,
        FFLPSteps = 62,
        FFLPTips = 63,
        FFLPVideoEntity = 64,
        SchemeBenefit = 65,
        FFLPArticleTermRelationship = 66,
        ActivityTermRelationships = 67,
        ArticleTermRelationships = 68,
        EventTermRelationships = 69,
        NewsletterTermRelationships = 70,
        ProgrammeTermRelationships = 71,
        VolunteerOpportunityTermRelationships = 72,
        FamilyProgramme = 73,
        FamilyProgrammeInterest = 74,
        FamilyProgrammeTermRelationships = 75,
        FamilyProgrammeInterestEmail = 76,
        QuizEntity = 77,
        QuizAnswer = 78,
        QuizQuestion = 79,
        QuizResponse = 80,
        QuizResponseAnswer = 81,
        QuizResponseSection = 82,
        QuizScoreRange = 83,
        QuizSection = 84,
        QuizSectionScoreRange = 85,
        FFLPGroup = 86,
        FFLPVideoGroupRelationshipsEntity = 87,
        FFLPTipsGroupRelationshipsEntity = 88,
        FFLPStepGroupRelationshipsEntity = 89,
        FFLPActivityGroupRelationshipsEntity = 90,
        ErrorTrackings = 91,
        ParentInfo = 92,
        AuditModel = 93,
        QuizProviderRelationship = 94,
        ProgrammesRunSession = 95,
        ProgrammesRun = 96,
        ProgrammesRegistration = 97,
        ProgrammesRegAttendInfo = 98,
        QuizAgreementRelationship = 99,
        PostalCode = 100,
        ProgrammeSettings = 101,
        QuizAgreementRespRelationships = 102,
        PostalCodeTown = 103,
        TrackPageViewEntity = 104,
        TrackVisitSessionEntity = 105,
        TrackVisitUserEntity = 106,
        CourseAssessmentQuestion = 107,
        CourseAssessmentQuestionOptionChoice = 108,
        CourseAssessmentQuestionOptionMapping = 109,
        CourseAssessmentResponseAnswer = 110,
        CourseCertificateTemplate = 111,
        CourseComponentScorm = 112,
        CourseComponent = 113,
        CourseComponentAssessment = 114,
        CourseEntity = 115,
        CourseEnrolment = 116,
        CourseScormCommentFromLMS = 117,
        CourseScormCommentFromLearner = 118,
        CourseScormData = 119,
        CourseScormInteractions = 120,
        CourseScormLearnerPreference = 121,
        CourseSection = 122,
        CourseScormObjectives = 123,
        ModuleProfile = 124,
        ExportReportExtend = 125,
        TrackAttachmentDownloadEntity = 126,
    }
}
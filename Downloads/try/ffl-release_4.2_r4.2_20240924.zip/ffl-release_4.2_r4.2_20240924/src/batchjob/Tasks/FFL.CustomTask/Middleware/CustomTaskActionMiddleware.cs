﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using DataPipeline.Base.Abstraction;
using DataPipeline.Base.Job;
using PipelineJob.Base.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FFL.CustomTask.Middleware
{
    public class CustomActionMiddleware : IDataMiddleware<BulkResult<MappingDataRecord>>
    {
        public CustomActionMiddleware() { }
        public async Task InvokeAsync(DataContext<BulkResult<MappingDataRecord>> context, DataDelegate<BulkResult<MappingDataRecord>> next)
        {
            if (context.Data.Data.Count > 0)
            {
                List<MappingDataRecord> dataList = new();
                foreach (var record in context.Data.Data)
                {
                    Dictionary<string, object> data = new();
                    data.Add("Action", record.__Action.ToString());
                    data = data.Concat(record.Data).ToDictionary(kv => kv.Key, kv => kv.Value);
                    dataList.Add(new MappingDataRecord() { Data = data });
                }
                context.Data.Data = dataList;
            }
            else
            {
                context = new JobDataContext<BulkResult<MappingDataRecord>>("no data to Write file", null, context.ContextServices, context.Features, context.RequestAborted);
            }
            await next.Invoke(context);
        }
    }
}

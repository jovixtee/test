﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using DataPipeline.Base.Job;
using FFL.CustomTask.Middleware;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Npgsql;
using PipelineJob.Base;
using PipelineJob.Base.Mapping;
using PipelineJob.Base.Pipelines;
using Replicator.Interface;
using Replicator.Interface.Model;

namespace FFL.CustomTask
{
    public class CustomRunner : PipelineJobRunner
    {
        public CustomRunner(JobExecutionContext jobContext, IReplicatorsService replicatorsService, CancellationToken cancellationToken, List<ConnectionAdapter> adapters) : base(jobContext, replicatorsService, cancellationToken, adapters)
        {
        }

        public ServiceCollection Services { get; private set; }

        public override void CleanUp()
        {
            try
            {
                Directory.Delete(this.ExeContext.TempFolder, true);
            }
            catch (Exception) { }
        }

        public override void Finish()
        {
        }

        public override void Init()
        {
            this.Services = new ServiceCollection();
            this.Services.UsePipelineJob(this.ExeContext).
                UseBulkPipelineJob<MappingDataRecord>(this.ExeContext);

            this.Services.TryAddSingleton<CustomMappingMiddleware>();
            this.Descriptor = new TableDescriptor("Table_Name");
            this.Descriptor.Columns.Add("Columns1", new ColumnDescriptor("CourseCode", "ntext"));
            this.Descriptor.Columns.Add("Columns2", new ColumnDescriptor("CourseName", "ntext", true));
        }

        public override void Run()
        {
            ExeContext.JobManagerService.UpdateJobProgress(ExeContext.Job.Id, 100);
            ExeContext.JobManagerService.UpdateJobState(ExeContext.Job.Id, Job.Interface.JobState.Finished);
        }

        TableDescriptor Descriptor { get; set; }

        Func<NpgsqlDataReader, MappingDataRecord> Reader = new Func<NpgsqlDataReader, MappingDataRecord>(reader =>
        {
            var data = new MappingDataRecord();

            data.Data.Add("CourseCode", reader.GetString(reader.GetOrdinal("PK")));
            data.Data.Add("MERBanks", reader.GetString(reader.GetOrdinal("MERBanks")));
            data.Data.Add("CourseCatalogue", reader.GetString(reader.GetOrdinal("CourseCatalogue")));
            data.Data.Add("CourseVersions", reader.GetString(reader.GetOrdinal("CourseVersions")));
            data.Data.Add("Modules", reader.GetString(reader.GetOrdinal("Modules")));
            data.Data.Add("CourseIntakes", reader.GetString(reader.GetOrdinal("CourseIntakes")));
            data.Data.Add("Action", reader.GetString(reader.GetOrdinal("Action")));
            data.Data.Add("Modified", reader.GetDateTime(reader.GetOrdinal("Modified")));

            return data;
        });
    }
}

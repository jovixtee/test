﻿using APM.SDK;
using APM.SDK.Messages;
using Job.Interface;
using Microsoft.Extensions.Logging;
using PipelineJob.Base;
using Replicator.Interface;
using Replicator.Interface.Model;

namespace FFL.CommonNotificationEmailTask
{
    public class CommonNotificationEmailRunner : PipelineJobRunner
    {
        private APMClient2 apmClient;
        private CancellationToken cancellationToken;
        private readonly ILogger _logger;
        private string jobId;
        private string jobName;
        const string SERVICEPATH = "api/ProgrammeEmailTaskAdminApi/SendEmailToProgrammeServiceProvider";
        const string SENDSECUREWORDPATH = "api/ExportReportExtendApi/BatchSendingFileSecureWord";

        public CommonNotificationEmailRunner(
            JobExecutionContext jobContext,
            IReplicatorsService replicatorsService,
            CancellationToken cancellationToken,
            List<ConnectionAdapter> adapters) : base(jobContext, replicatorsService, cancellationToken, adapters)
        {
            this.cancellationToken = cancellationToken;
            _logger = jobContext.LoggerFactory.CreateLogger(typeof(CommonNotificationEmailRunner).FullName);
        }
        public override void CleanUp()
        {

        }

        public override void Finish()
        {

        }

        public override void Init()
        {
            jobName = ExeContext.Job.Name;
            _logger.LogWarning($"Initialization for InterestRegistrationEmailRunner: {jobName}");
            try
            {
                apmClient = CreateDocumentService(Adapters[0]);
            }
            catch(Exception ex)
            {
                string errorMsg = $"Failed to initialize apm for InterestRegistrationEmailRunner: {jobName}, error: {ex}";
                UpsertJobDetail(errorMsg, JobState.Failed);
                throw new Exception(errorMsg);
            }
        }

        public override async void Run()
        {
            try
            {
                UpsertJobDetail($"CommonNotification email job: {ExeContext.Job.Id}", JobState.Starting);
                _logger.LogInformation($"Interest registration email start.");
                var apmResponse = apmClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATH, Method = HttpMethod.Post });
                _logger.LogInformation($"Interest registration email end.Is success:{apmResponse.IsSuccess}");

                _logger.LogInformation($"Export report email start.");
                var ExportReportEmail = apmClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SENDSECUREWORDPATH, Method = HttpMethod.Post });
                _logger.LogInformation($"Export report email end.Is success:{ExportReportEmail.IsSuccess}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Interest registration email job failed. {ex}");
                UpsertJobDetail($"Interest registration email job failed: {ExeContext.Job.Id}", JobState.Failed);
            }
        }
        private APMClient2 CreateDocumentService(ConnectionAdapter config)
        {
            var finallyEndpoint = config.ConnectionStr.StartsWith("WebUrl=", StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(7) : config.ConnectionStr;
            finallyEndpoint = finallyEndpoint.TrimEnd('/');
            var authority = config.Parameters["authority"];
            var clientid = config.Parameters["clientid"];
            var secret = config.Parameters["secret"];
            var apmSettings = new APMSettings
            {
                AuthEndpoint = authority,
                ClientId = clientid,
                Secret = secret,
                ServiceEndpoint = finallyEndpoint
            };
            apmSettings.CustomHeaders = new Dictionary<string, string?>();
            return new APMClient2(apmSettings);
        }

        private void UpsertJobDetail(string comment, JobState jobState, bool needRecordJobDetail = true)
        {
            if (jobState == JobState.Exception || jobState == JobState.Failed)
            {
                _logger.LogError("Interest registration email job error: {Comment}", comment);
                ExeContext.JobManagerService.UpdateJobProgress(jobId, 100);
                ExeContext.JobManagerService.UpdateJobState(jobId, jobState);
            }
            else
            {
                _logger.LogInformation("Interest registration email info: {Comment}", comment);
            }

            if (jobState == JobState.Exception || jobState == JobState.Failed || needRecordJobDetail)
            {
                try
                {
                    InterestRegistrationEmailJobDetail jobDetail = new InterestRegistrationEmailJobDetail(jobId, jobState, comment);
                    ExeContext.JobManagerService.UpsertJobDetails(new JobDetailDto[] { jobDetail.Convert2BaseDto() });
                }
                catch (Exception ex)
                {
                    _logger.LogError($"An error occurred while upsertting job detail: {ex}");
                }
            }
        }

        public class InterestRegistrationEmailJobDetail : JobDetailDto
        {
            public InterestRegistrationEmailJobDetail(string id, JobState jobState, string comment) : base(id, jobState, comment)
            {
                long utcTicks = DateTime.UtcNow.Ticks;
                StartTime = utcTicks;
                EndTime = utcTicks;
            }

            [CustomColumn(DisplayName = "Start time", InternalName = "StartTime", Type = CustomColumnType.UTCTicks)]
            public long StartTime { get; set; }

            [CustomColumn(DisplayName = "End time", InternalName = "EndTime", Type = CustomColumnType.UTCTicks)]
            public long EndTime { get; set; }
        }
    }
}

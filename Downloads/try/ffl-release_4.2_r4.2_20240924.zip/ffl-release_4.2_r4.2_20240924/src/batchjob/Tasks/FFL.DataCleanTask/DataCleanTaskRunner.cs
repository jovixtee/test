﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using APM.SDK;
using APM.SDK.Messages;
using APM.SDK.Services;
using Job.Interface;
using Microsoft.Extensions.Logging;
using PipelineJob.Base;
using Replicator.Interface;
using Replicator.Interface.Model;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;

namespace FFL.DataCleanTask
{
    public class DataCleanTaskRunner : PipelineJobRunner
    {
        private APMClient2 _APMClient;
        private CancellationToken CancellationToken { get; set; }
        private readonly ILogger _logger;
        private readonly string jobId;

        const string SERVICEPATH = "api/DocumentCleanApi/DeleteUnnecessaryFiles"; // apm service path

        public DataCleanTaskRunner(           
            JobExecutionContext jobContext,
            IReplicatorsService replicatorsService,
            CancellationToken cancellationToken,
            List<ConnectionAdapter> adapters) : base(jobContext, replicatorsService, cancellationToken, adapters)
        {
            CancellationToken = cancellationToken;
            _logger = jobContext.LoggerFactory.CreateLogger(typeof(DataCleanTaskRunner).FullName);
            jobId = jobContext.Job.Name;
            _logger.LogWarning($"Job id:{jobId}");            
        }
        //private APMClient CreateDocumentService(ConnectionAdapter config)
        //{
        //    return new APMClient(new APMSettings
        //    {
        //        AuthEndpoint = config.Parameters["authority"],
        //        ClientId = config.Parameters["clientid"],
        //        Secret = config.Parameters["secret"],
        //        ServiceEndpoint = config.ConnectionStr.StartsWith("WebUrl=", StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(7) : config.ConnectionStr
        //    });
        //}

        public override void Run()
        {
            _logger.LogInformation($"The data clean job start.");
            try
            {
                UpsertJobDetail($"Start to run the data clean job: {ExeContext.Job.Id}", JobState.Starting);
                var apmResponse = _APMClient.Execute<APMRequest, APMResponse>(new APMRequest { RequestPath = SERVICEPATH, Method = HttpMethod.Get });
                _logger.LogInformation($"{apmResponse}");
                UpsertJobDetail($"Finish to run the data clean job: {ExeContext.Job.Id}", JobState.Finished);
            }
            catch (Exception ex)
            {
                _logger.LogError($"The data clean job failed. {ex}");
                UpsertJobDetail($"The data clean job failed: {ExeContext.Job.Id}", JobState.Failed);
            }
        }

        public override void Init()
        {
            try
            {
                var config = Adapters[0];
                _APMClient = new APMClient2(new APMSettings
                {
                    AuthEndpoint = config.Parameters["authority"],
                    ClientId = config.Parameters["clientid"],
                    Secret = config.Parameters["secret"],
                    ServiceEndpoint = config.ConnectionStr.StartsWith("WebUrl=", StringComparison.InvariantCultureIgnoreCase) ? config.ConnectionStr.Substring(7) : config.ConnectionStr
                });
            }
            catch (Exception ex)
            {
                string errorMsg = $"Failed to initialize apm for data clean job: {ExeContext.Job.Id}, error: {ex}";
                UpsertJobDetail(errorMsg, JobState.Failed);
                throw new Exception(errorMsg);
            }
        }

        public override void CleanUp()
        {

        }

        public override void Finish()
        {
        }

        private void UpsertJobDetail(string comment, JobState jobState, bool needRecordJobDetail = false)
        {
            if (jobState == JobState.Exception)
            {
                _logger.LogError("event error track email job error: {Comment}", comment);
                ExeContext.JobManagerService.UpdateJobProgress(jobId, 100);
                ExeContext.JobManagerService.UpdateJobState(jobId, jobState);
            }
            else
            {
                _logger.LogInformation("event error track email job info: {Comment}", comment);
            }

            if (jobState == JobState.Exception || jobState == JobState.Failed || needRecordJobDetail)
            {
                try
                {
                    DataCleanJobDetail jobDetail = new DataCleanJobDetail(jobId, jobState, comment);
                    ExeContext.JobManagerService.UpsertJobDetails(new JobDetailDto[] { jobDetail.Convert2BaseDto() });
                }
                catch (Exception ex)
                {
                    _logger.LogError($"An error occurred while upsertting job detail: {ex}");
                }
            }
        }
    }
    public class DataCleanJobDetail : JobDetailDto
    {
        public DataCleanJobDetail(string id, JobState jobState, string comment) : base(id, jobState, comment)
        {
            long utcTicks = DateTime.UtcNow.Ticks;
            StartTime = utcTicks;
            EndTime = utcTicks;
        }

        [CustomColumn(DisplayName = "Start time", InternalName = "StartTime", Type = CustomColumnType.UTCTicks)]
        public long StartTime { get; set; }

        [CustomColumn(DisplayName = "End time", InternalName = "EndTime", Type = CustomColumnType.UTCTicks)]
        public long EndTime { get; set; }
    }
}

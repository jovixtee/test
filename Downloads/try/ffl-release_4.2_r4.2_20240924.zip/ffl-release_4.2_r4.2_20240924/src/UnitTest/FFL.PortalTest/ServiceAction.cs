﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.Activities.Core.Commands;
using Camps.Activities.Core.Queries;
using Camps.Activities.EF;
using Camps.Activities.EF.Commands;
using Camps.Activities.EF.MSSQL;
using Camps.Activities.EF.Queries;
using Camps.Alert.Core.Commands;
using Camps.Alert.Core.Queries;
using Camps.Alert.EF;
using Camps.Alert.EF.Commands;
using Camps.Alert.EF.MSSQL;
using Camps.Alert.EF.Queries;
using Camps.Articles.Core.Commands;
using Camps.Articles.Core.Queries;
using Camps.Articles.EF;
using Camps.Articles.EF.Commands;
using Camps.Articles.EF.MSSQL;
using Camps.Articles.EF.Queries;
using Camps.Banner.Core.Commands;
using Camps.Banner.Core.Queries;
using Camps.Banner.Core.Service;
using Camps.Banner.EF;
using Camps.Banner.EF.Commands;
using Camps.Banner.EF.MSSQL;
using Camps.Banner.EF.Queries;
using Camps.CaseDocument.Core.Interface;
using Camps.CaseDocument.EF;
using Camps.CaseDocument.EF.Commands;
using Camps.CaseDocument.EF.MSSQL;
using Camps.CaseDocument.EF.Queries;
using Camps.CaseDocument.Service.EventHandlers;
using Camps.CaseDocument.Service.Helper;
using Camps.CaseDocument.Service.Services;
using Camps.Core.Data.Abstractions;
using Camps.Core.Data.Configurations;
using Camps.Core.Data.Identity;
using Camps.Core.Data.Options;
using Camps.Core.Data.Site;
using Camps.Core.Framework.Components.Messaging;
using Camps.Core.Media;
using Camps.Core.Services.Cache;
using Camps.Core.Services.Configurations;
using Camps.Core.Services.Configurations.Impls;
using Camps.Core.Storage.EF;
using Camps.Core.Storage.EF.MSSQL;
using Camps.Core.Taxonomy.Core.Entities;
using Camps.Core.Taxonomy.Core.Interfaces;
using Camps.Core.Taxonomy.Core.Service;
using Camps.Core.Taxonomy.Core.Service.Interfaces;
using Camps.Core.Taxonomy.EF;
using Camps.Core.Taxonomy.EF.Commands;
using Camps.Core.Taxonomy.EF.MSSQL;
using Camps.Core.Taxonomy.EF.Queries;
using Camps.Core.Taxonomy.Provider.Models;
using Camps.Core.Web.Razor;
using Camps.Events.Core.Commands;
using Camps.Events.Core.Queries;
using Camps.Events.EF;
using Camps.Events.EF.Commands;
using Camps.Events.EF.MSSQL;
using Camps.Events.EF.Queries;
using Camps.FFL.Core.Options;
using Camps.FFL.Core.Services.Validate;
using Camps.FFL.Email.Services;
using Camps.FFLPActivities.EF.MSSQL;
using Camps.FFLPActivities.EF;
using Camps.Messaging.Email;
using Camps.News.Core.Commands;
using Camps.News.Core.Queries;
using Camps.News.EF;
using Camps.News.EF.Commands;
using Camps.News.EF.MSSQL;
using Camps.News.EF.Queries;
using Camps.ViewBuilder.Core;
using Camps.ViewBuilder.Core.Models;
using Camps.ViewBuilder.Core.Models.Interfaces;
using Camps.ViewBuilder.Core.Services;
using Camps.ViewBuilder.EF;
using Camps.ViewBuilder.EF.MSSQL;
using Camps.Web.Activities.ApiController;
using Camps.Web.Activities.ApiService;
using Camps.Web.Activities.Controllers;
using Camps.Web.Activities.Services;
using Camps.Web.Alert.ApiControllers;
using Camps.Web.Alert.Controllers;
using Camps.Web.Alert.Services;
using Camps.Web.Articles.ApiService;
using Camps.Web.Articles.Controllers;
using Camps.Web.Articles.Services;
using Camps.Web.Attachments;
using Camps.Web.Attachments.Services;
using Camps.Web.Attachments.Services.Interfaces;
using Camps.Web.Banner.Controllers;
using Camps.Web.Banner.Services;
using Camps.Web.Events.ApiService;
using Camps.Web.Events.Controllers;
using Camps.Web.Events.Services;
using Camps.Web.FFLPActivities.ApiController;
using Camps.Web.FFLPActivities.ApiService;
using Camps.Web.FFLPActivities.Controllers;
using Camps.Web.FFLPActivities.Services;
using Camps.Web.News.ApiController;
using Camps.Web.News.ApiService;
using Camps.Web.News.Controllers;
using Camps.Web.News.Services;
using CaseDocumentLibrary;
using FFL.PortalTest.DataGenerator;
using FFL.PortalTest.DataGenerator.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Moq;
using Newtonsoft.Json;
using System.Reflection;
using System.Text;
using Camps.FFLPActivities.Core.Commands;
using Camps.FFLPActivities.Core.Queries;
using Camps.FFLPActivities.EF.Commands;
using Camps.FFLPActivities.EF.Queries;
using Camps.Web.FFLPArticles.ApiController;
using Camps.Web.FFLPArticles.Controllers;
using Camps.Web.FFLPArticles.ApiService;
using Camps.FFLPArticles.EF.MSSQL;
using Camps.FFLPArticles.EF;
using Camps.FFLPArticles.Core.Commands;
using Camps.FFLPArticles.Core.Queries;
using Camps.FFLPArticles.EF.Commands;
using Camps.FFLPArticles.EF.Queries;
using Camps.FFLPBanner.EF.MSSQL;
using Camps.Web.FFLPBanner.Controllers;
using Camps.Web.FFLPBanner.Services;
using Camps.FFLPBanner.EF;
using Camps.FFLPBanner.Core.Commands;
using Camps.FFLPBanner.Core.Queries;
using Camps.FFLPBanner.EF.Commands;
using Camps.FFLPBanner.EF.Queries;
using Camps.FFLPBanner.Core.Service;
using Camps.FFL.Attachment.Queries;
using Camps.Guides.EF.MSSQL;
using Camps.Guides.Core.Commands;
using Camps.Guides.Core.Queries;
using Camps.Guides.EF.Commands;
using Camps.Guides.EF.Queries;
using Camps.Guides.EF;
using Camps.Web.Guides.ApiController;
using Camps.Web.Guides.ApiService;
using Camps.Web.Guides.Controllers;
using Camps.Web.Guides.Services;
using Camps.Web.SchemeBenefit.ApiController;
using Camps.Web.FFLPSchemeBenefit.Controllers;
using Camps.Web.SchemeBenefit.Controllers;
using Camps.Web.SchemeBenefit.ApiService;
using Camps.Web.SchemeBenefit.Services;
using Camps.SchemeBenefit.EF.MSSQL;
using Camps.SchemeBenefit.EF;
using Camps.SchemeBenefit.Core.Commands;
using Camps.SchemeBenefit.Core.Queries;
using Camps.SchemeBenefit.EF.Commands;
using Camps.SchemeBenefit.EF.Queries;
using Camps.Web.Activities.Common;
using Camps.Web.Articles.Common;
using Camps.Core.Taxonomy.EF.Actions;
using Camps.Core.Services.Cryptography;

namespace FFL.PortalTest
{
    public static class ServiceAction
    {
        public static void AddDBContext(this IServiceCollection services)
        {
            services.AddDbContext<ActivitiesDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<AlertDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<ArticlesDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<BannerDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<NewsDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<TaxonomyDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<CoreDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<ViewBuilderDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<CaseDocumentDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            //services.AddDbContext<ViewBuilderDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<EventsDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<FFLPActivitiesDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<FFLPArticlesDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<FFLPBannerDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<FFLPGuidesDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
            services.AddDbContext<SchemeBenefitDbContext>(options => options.UseInMemoryDatabase("MSF_FFL"));
        }

        public static void AddCommonServiceAction(this IServiceCollection services, IConfiguration configuration)
        {
            var setting = new SiteSettings();
            setting.Id = new Guid("181b5352-ce4f-4158-9c99-7c11c09c631b");
            services.AddScoped<ISiteSettings, SiteSettings>((provider) => {
                return setting;
            });
            services.AddScoped<SiteContext, SiteContext>((provider) => {
                return new SiteContext(setting);
            });
            services.AddScoped<IUserQueries, UserQueries>();
            services.AddSingleton<ICoreModelMapper, SqlServerCoreModelMapper>();
            services.AddSingleton<ICoreDbContextFactory, CoreDbContextFactory>();

            services.AddScoped<DocumentEvents, DocumentEvents>();
            services.AddScoped<ICaseDocumentStorage, CaseDocumentEFStorage>();
            services.AddScoped<ICaseDocumentsService, CaseDocumentsService>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IDocumentService, DocumentService>();
            services.AddScoped<IFileUploadCacheService, FileUploadCacheService>();
            services.AddScoped<IDocumentExtensionQueries, DocumentExtensionQueries>();
            services.AddScoped<IDocumentExtensionCommands, DocumentExtensionCommands>();

            services.AddScoped<IDocumentQueries, DocumentQueries>();
            services.AddScoped<IDocumentFolderQueries, DocumentFolderQueries>();
            services.AddScoped<IDocumentRuleQueries, DocumentRuleQueries>();
            services.AddScoped<IDocumentCommands, DocumentCommands>();
            services.AddScoped<IDocumentFolderCommands, DocumentFolderCommands>();
            services.AddScoped<IDocumentVersionCommands, DocumentVersionCommands>();
            services.AddScoped<IDocumentVersionQueries, DocumentVersionQueries>();
            services.AddSingleton<ICaseDocumentDbContextFactory, CaseDocumentDbContextFactory>();

            services.Configure<MediaOptions>(configuration.GetSection("MediaOptions"));
            services.AddScoped<IMediaProvider, AWSS3MediaProvider>();
            services.AddScoped<FileSystemZipFile, FileSystemZipFile>();
            services.AddScoped<ISiteMediaService, SiteMediaService>();
            services.AddScoped<IFileSystemFile, FileSystemFile>();
            services.AddScoped<ISiteMediaCommands, SiteMediaCommands>();
            services.AddScoped<ISiteMediaQueries, SiteMediaQueries>();

            services.AddMemoryCache();
            services.AddSingleton<ICacheService, MemoryCacheService>();

            services.AddScoped<PermissionHelper, PermissionHelper>();
            //services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddScoped<IConfigurationService, ConfigurationService>();
            services.AddScoped<IConfigurationQueries, ConfigurationQueries>();
            services.AddScoped<IConfigurationCommands, ConfigurationCommands>();

            services.AddScoped<IViewBuilderMapper, SqlServerViewBuilderMapper>();
            services.AddScoped<IViewPageQueries, ViewPageQueries>();
            services.AddScoped<IViewPageCommands, ViewPageCommands>();
            services.AddScoped<IViewPageHistoryQueries, ViewPageHistoryQueries>();
            services.AddScoped<IViewPageHistoryCommands, ViewPageHistoryCommands>();
            services.AddScoped<IContentPartQueries, ContentPartQueries>();
            services.AddScoped<IContentPartCommands, ContentPartCommands>();
            services.AddScoped<IContentFieldQueries, ContentFieldQueries>();
            services.AddScoped<IContentFieldCommands, ContentFieldCommands>();
            services.AddSingleton<IViewBuilderDbContextFactory, ViewBuilderDbContextFactory>();

            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            //services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddSingleton<SecurityCryptographyService, SecurityCryptographyService>();

            var provider = services.BuildServiceProvider();
            services.AddSingleton<IViewPageCommonService>(provider =>
            {
                return new Mock<ViewPageCommonService>(
                    new Mock<IViewPageQueries>().Object,
                    new Mock<IViewPageCommands>().Object,
                    new Mock<IContentPartQueries>().Object,
                    new Mock<IContentFieldQueries>().Object,
                    new Mock<IViewPageHistoryCommands>().Object,
                    new Mock<IUserQueries>().Object,
                    new Mock<IServiceScopeFactory>().Object,
                    new Mock<ICacheService>().Object,
                    new Mock<IHttpContextAccessor>().Object,
                    new Mock<IContentPartCommands>().Object,
                    provider.GetService<IStringLocalizer<MSSPResources>>(),
                    provider.GetService<IOptions<ViewBuilderOptions>>()
                    ).Object;
            });
            services.TryAddScoped<ViewRenderer>((provider) =>
            {
                return new Mock<ViewRenderer>(
                    new Mock<ICompositeViewEngine>().Object,
                    new Mock<ITempDataProvider>().Object,
                    new Mock<IActionContextAccessor>().Object
                    ).Object;
            });
            services.TryAddScoped<ISmtpOptionsProvider>((p) =>
            {
                return new Mock<SiteSmtpOptionsResolver>(
                    new SiteContext(setting),
                    new Mock<IOptions<SmtpOptions>>().Object
                    ).Object;
            });
        }

        public static void AddActivityServiceAction(this IServiceCollection services)
        {
            services.AddSingleton<ActivitiesController, ActivitiesController>();
            services.AddSingleton<ActivitiesAdminApiController>();
            services.AddSingleton<ActivitiesApiController>();
            services.AddScoped<ActivitiesService, ActivitiesService>();
            services.AddScoped<ApiActivitiesService>();
            services.AddScoped<IActivitiesCommands, ActivitiesCommands>();
            services.AddScoped<IActivitiesQueries, ActivitiesQueries>();
            services.AddSingleton<IActivitiesDbContextFactory, ActivitiesDbContextFactory>();
            services.AddSingleton<IActivitiesMapper, SqlServerActivitiesMapper>();
            services.AddScoped<IActivitiesDbContext, ActivitiesDbContext>();
            services.AddScoped<Camps.Activities.EF.Actions.AddAction>();
            services.AddScoped<ActivityCommon>();
            services.AddShowOnCardTermService<IActivitiesDbContextFactory>();
        }

        public static void AddAlertServiceAction(this IServiceCollection services)
        {
            services.AddSingleton<MaintenanceBannerController>();
            services.AddSingleton<MaintenanceBannerAdminApiController>();
            services.AddSingleton<MaintenanceBannerApiController>();
            services.AddScoped<MaintenanceBannerManager, MaintenanceBannerManager>();
            services.AddScoped<IMaintenanceBannerCommands, MaintenanceBannerCommands>();
            services.AddScoped<IMaintenanceBannerQueries, MaintenanceBannerQueries>();
            services.AddSingleton<IAlertDbContextFactory, AlertDbContextFactory>();
            services.AddSingleton<IAlertMapper, SqlServerAlertMapper>();
            services.AddScoped<IAlertDbContext, AlertDbContext>();
            services.AddScoped<Camps.Alert.EF.Actions.AddAction>();
        }

        public static void AddArticleServiceAction(this IServiceCollection services)
        {
            services.AddSingleton<ArticlesController>();
            services.AddScoped<ArticlesService>();
            services.AddScoped<ApiArticlesService>();
            services.AddScoped<IArticlesCommands, ArticlesCommands>();
            services.AddScoped<IArticlesQueries, ArticlesQueries>();
            services.AddSingleton<IArticlesDbContextFactory, ArticlesDbContextFactory>();
            services.AddSingleton<IArticlesMapper, SqlServerArticlesMapper>();
            services.AddScoped<IArticlesDbContext, ArticlesDbContext>();
            services.AddScoped<Camps.Articles.EF.Actions.AddAction>();
            services.AddScoped<ArticleCommon>();
            services.AddShowOnCardTermService<IArticlesDbContextFactory>();
        }

        public static void AddBannerServiceAction(this IServiceCollection services)
        {
            services.AddSingleton<RotatingBannerController>();
            services.AddScoped<RotatingBannerAdminApiController>();
            services.AddScoped<RotatingBannerApiController>();
            services.AddScoped<RotatingBannerManager, RotatingBannerManager>();
            services.AddSingleton<IBannerDbContextFactory, BannerDbContextFactory>();
            services.AddSingleton<IBannerMapper, SqlServerBannerMapper>();
            services.AddScoped<IBannerDbContext, BannerDbContext>();
            services.AddScoped<IRotatingBannerCommands, RotatingBannerCommands>();
            services.AddScoped<IRotatingBannerQueries, RotatingBannerQueries>();
            services.AddScoped<RotatingBannerService, RotatingBannerService>();
            services.AddScoped<Camps.Banner.EF.Actions.AddAction>();
        }

        public static void AddEventServiceAction(this IServiceCollection services)
        {
            services.AddSingleton<EventsAdminApiController>();
            services.AddSingleton<Camps.WebApi.Events.ApiController.EventsAdminApiController>();
            services.AddSingleton<EventEmailAdminApiController>();
            services.AddSingleton<EventsController>();
            services.AddSingleton<EventSubmissionAdminApiController>();
            services.AddSingleton<EventSubmissionController>();
            services.AddScoped<EventsService>();
            services.AddScoped<EventSubmissionService>();
            services.AddScoped<IEventEmailService, EventEmailService>();
            services.AddSingleton<IEventsMapper, SqlServerEventsMapper>();
            services.AddScoped<IEventsDbContext, EventsDbContext>();
            services.AddSingleton<IEventsDbContextFactory, EventsDbContextFactory>();
            services.AddScoped<EventsApiService, EventsApiService>();
            services.AddScoped<EventSubmissionService>();
            services.AddScoped<ApiEventsSubmissionService, ApiEventsSubmissionService>();
            services.AddScoped<ApiEventsService>();
            services.AddScoped<IEventsCommands, EventsCommands>();
            services.AddScoped<IEventsQueries, EventsQueries>();
            services.AddScoped<IEventSubmissionQueries, EventSubmissionsQueries>();
            services.AddScoped<IEventsSubmittionCommands, EventsSubmissionCommands>();
            services.AddScoped<IRecaptchaService, RecaptchaService>();
            services.AddShowOnCardTermService<IEventsDbContextFactory>();
        }

        public static void AddFFLPActivityServiceAction(this IServiceCollection services)
        {
            services.AddScoped<FFLPActivitiesApiController>();
            services.AddScoped<FFLPActivitiesAdminApiController>();
            services.AddScoped<FFLPActivitiesController>();
            services.AddScoped<FFLPActivitiesService, FFLPActivitiesService>();
            services.AddScoped<ApiFFLPActivitiesService>();
            //services.AddScoped<SecondaryPage>();
            services.AddSingleton<IFFLPActivitiesDbContextFactory, FFLPActivitiesDbContextFactory>();
            services.AddSingleton<IFFLPActivitiesMapper, SqlServerFFLPActivitiesMapper>();
            services.AddScoped<IFFLPActivitiesDbContext, FFLPActivitiesDbContext>();
            services.AddScoped<IFFLPActivitiesCommands, FFLPActivitiesCommands>();
            services.AddScoped<IFFLPActivitiesQueries, FFLPActivitiesQueries>();
        }

        public static void AddFFLPArticlesServiceAction(this IServiceCollection services)
        {
            services.AddScoped<FFLPArticlesApiController>();
            services.AddScoped<FFLPArticlesAdminApiController>();
            services.AddScoped<FFLPArticlesController>();
            services.AddScoped<Camps.Web.FFLPArticles.Services.ArticlesService, Camps.Web.FFLPArticles.Services.ArticlesService>();
            services.AddScoped<ApiFFLPArticlesService>();
            services.AddSingleton<IFFLPArticlesDbContextFactory, FFLPArticlesDbContextFactory>();
            services.AddSingleton<IFFLPArticlesMapper, SqlServerFFLPArticlesMapper>();
            services.AddScoped<IFFLPArticlesDbContext, FFLPArticlesDbContext>();
            services.AddScoped<IFFLPArticlesCommands, FFLPArticlesCommands>();
            services.AddScoped<IFFLPArticlesQueries, FFLPArticlesQueries>();
        }

        public static void AddFFLPBannerServiceAction(this IServiceCollection services)
        {
            services.AddScoped<FFLPRotatingBannerAdminApiController>();
            services.AddScoped<FFLPRotatingBannerApiController>();
            services.AddScoped<FFLPRotatingBannerController>();
            services.AddScoped<FFLPRotatingBannerManager, FFLPRotatingBannerManager>();
            services.AddSingleton<IFFLPBannerDbContextFactory, FFLPBannerDbContextFactory>();
            services.AddSingleton<IFFLPBannerMapper, SqlServerFFLPBannerMapper>();
            services.AddScoped<IFFLPBannerDbContext, FFLPBannerDbContext>();
            services.AddScoped<IFFLPRotatingBannerCommands, FFLPRotatingBannerCommands>();
            services.AddScoped<IFFLPRotatingBannerQueries, FFLPRotatingBannerQueries>();
            services.AddScoped<FFLPRotatingBannerService, FFLPRotatingBannerService>();
        }

        public static void AddFFLPGuidesServiceAction(this IServiceCollection services)
        {
            services.AddScoped<FFLPGuidesApiController>();
            services.AddScoped<FFLPGuidesAdminApiController>();
            services.AddScoped<FFLPGuidesController>();
            services.AddScoped<FFLPGuidesService, FFLPGuidesService>();
            services.AddScoped<ApiFFLPGuidesService>();
            services.AddScoped<IFFLPGuidesCommands, FFLPGuidesCommands>();
            services.AddScoped<IFFLPGuidesQueries, FFLPGuidesQueries>();
            services.AddSingleton<IFFLPGuidesDbContextFactory, FFLPGuidesDbContextFactory>();
            services.AddSingleton<IFFLPGuidesMapper, SqlServerFFLPGuidesMapper>();
            services.AddScoped<IFFLPGuidesDbContext, FFLPGuidesDbContext>();
        }

        public static void AddFFLPSchemeBenefitServiceAction(this IServiceCollection services)
        {
            services.AddScoped<SchemeBenefitApiController>();
            services.AddScoped<SchemeBenefitAdminApiController>();
            services.AddScoped<SchemeBenefitController>();
            services.AddScoped<SchemeBenefitService, SchemeBenefitService>();
            services.AddScoped<ApiSchemeBenefitService>();
            services.AddScoped<ISchemeBenefitCommands, SchemeBenefitCommands>();
            services.AddScoped<ISchemeBenefitQueries, SchemeBenefitQueries>();
            services.AddScoped<ISchemeBenefitMapper, SqlServerSchemeBenefitMapper>();
            services.AddSingleton<ISchemeBenefitDbContextFactory, SchemeBenefitDbContextFactory>();
            services.AddSingleton<ISchemeBenefitMapper, SqlServerSchemeBenefitMapper>();
            services.AddScoped<ISchemeBenefitDbContext, SchemeBenefitDbContext>();
        }

        public static void AddNewsServiceAction(this IServiceCollection services)
        {
            services.AddScoped<NewsApiController>();
            services.AddScoped<NewsController>();
            services.AddScoped<NewsService, NewsService>();
            services.AddScoped<ApiNewsService>();
            services.AddScoped<INewsCommands, NewsCommands>();
            services.AddScoped<INewsQueries, NewsQueries>();
            services.AddScoped<INewsMapper, SqlServerNewsMapper>();
            services.AddSingleton<INewsDbContextFactory, NewsDbContextFactory>();
            services.AddScoped<INewsDbContext, NewsDbContext>();
        }

        public static void AddTaxonomyServiceAction(this IServiceCollection services)
        {
            services.AddScoped<ITermQueries, TermQueries>();
            services.AddScoped<ITermCommands, TermCommands>();
            services.AddScoped<ITaxonomyCache, TaxonomyCache>();
            services.AddScoped<ITaxonomyQueries, TaxonomyQueries>();
            services.AddScoped<ITaxonomyCommands, TaxonomyCommands>();
            services.AddScoped<ITaxonomyCommonService, TaxonomyCommonService>();
            services.AddSingleton<ITaxonomyDbContextFactory, TaxonomyDbContextFactory>();
        }

        public static void InitDatabase(this IServiceCollection services)
        {
            var serviceProvider = services.BuildServiceProvider();
            var _coreDbContext = serviceProvider.GetService<CoreDbContext>();
            //var _viewBuilderDbContext = serviceProvider.GetService<ViewBuilderDbContext>();
            var _caseDocumentDbContext = serviceProvider.GetService<CaseDocumentDbContext>();
            var _taxonomyDbContext = serviceProvider.GetService<TaxonomyDbContext>();

            _coreDbContext.Sites.AddRange(GetStaticData<SiteSettings>("cs_Site.json"));
            _coreDbContext.Roles.AddRange(GetStaticData<SiteRole>("cs_Role.json"));
            _coreDbContext.SaveChanges();

            //_viewBuilderDbContext.ContentParts.AddRange(GetStaticData<ContentPart>("cs_ContentPart.json"));
            //_viewBuilderDbContext.ContentFields.AddRange(GetStaticData<ContentField>("cs_ContentField.json"));
            //_viewBuilderDbContext.ContentPartFields.AddRange(GetStaticData<ContentPartField>("cs_ContentPartField.json"));
            //_viewBuilderDbContext.ViewPages.AddRange(GetStaticData<ViewPage>("cs_SitePage.json"));
            //_viewBuilderDbContext.ViewContentParts.AddRange(GetStaticData<ViewContentPart>("cs_SitePageContentPart.json"));
            //_viewBuilderDbContext.ViewContentFields.AddRange(GetStaticData<ViewContentField>("cs_SitePageContentField.json"));
            //_viewBuilderDbContext.ViewContentPartFields.AddRange(GetStaticData<ViewContentPartField>("cs_SitePageContentPartField.json"));
            //_viewBuilderDbContext.SaveChanges();

            _caseDocumentDbContext.InitCaseDocumentDatabase();

            _taxonomyDbContext.Taxonomies.AddRange(GetStaticData<TaxonomyEntity>("cs_Taxonomy.json"));
            _taxonomyDbContext.TaxonomyMetas.AddRange(GetStaticData<TaxonomyMetaEntity>("cs_TaxonomyMeta.json"));
            _taxonomyDbContext.Terms.AddRange(GetStaticData<TermEntity>("cs_Term.json"));
            _taxonomyDbContext.SaveChanges();
        }

        private static IEnumerable<T> GetStaticData<T>(string fileName)
        {
            using (StreamReader reader = new StreamReader(Path.Combine("data", fileName)))
            {
                var content = reader.ReadToEnd();
                return JsonConvert.DeserializeObject<List<T>>(content);
            }
        }

        public static void AddConfiguration(this IServiceCollection services, IConfiguration config)
        {
            services.Configure<MicroServicesOptions>(config.GetSection("MicroServicesOptions"));
            services.Configure<SiteIdentityOptions>(config.GetSection("SiteIdentityOptions"));
        }

        public static void InitData(this IServiceCollection services)
        {
            var provider = services.BuildServiceProvider();
            var types = Assembly.GetAssembly(typeof(IDataGenerator)).GetTypes().Where(t => t.GetInterfaces().Contains(typeof(IDataGenerator))).ToList();

            foreach (var type in types)
            {
                var instance = Activator.CreateInstance(type);
                var method = type.GetMethod("Execute");
                if (instance != null && method != null)
                {
                    method.Invoke(instance, new object[] { provider });
                }
            }
        }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.Alert.Core.Models;
using Camps.Alert.EF;
using FFL.PortalTest.Common;
using FFL.PortalTest.DataGenerator.Interface;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FFL.PortalTest.DataGenerator
{
    public class AlertDataGenerator : IDataGenerator
    {
        public void Execute(IServiceProvider provider) 
        {
            var _dbContextFactory = provider.GetService<IAlertDbContextFactory>();
            List<MaintenanceBanner> maintenanceBanners = new List<MaintenanceBanner>()
            { 
                new MaintenanceBanner()
                { 
                    Id = Guid.NewGuid(),
                    SiteId = SiteContext.SiteId,
                    Message = "Alert1",
                    Type = "Information",
                    StartTime = DateTime.Now.AddDays(-2),
                    EndTime = DateTime.Now,
                    IsDeleted = false
                },
                new MaintenanceBanner()
                {
                    Id = Guid.Parse("D5D2C09B-A12B-42ED-96FE-7F79112C14B7"),
                    SiteId = SiteContext.SiteId,
                    Message = "Alert2",
                    Type = "Information",
                    StartTime = DateTime.Now.AddDays(-2),
                    EndTime = DateTime.Now,
                    IsDeleted = false
                },
                new MaintenanceBanner()
                {
                    Id = Guid.Parse("787D9721-A954-4232-86C6-7879BB4E9335"),
                    SiteId = SiteContext.SiteId,
                    Message = "Alert2",
                    Type = "Information",
                    StartTime = DateTime.Now.AddDays(-2),
                    EndTime = DateTime.Now,
                    IsDeleted = false
                },
                new MaintenanceBanner()
                {
                    Id = Guid.Parse("FCD02806-94A1-4CDD-BA63-72335C2B1DD2"),
                    SiteId = SiteContext.SiteId,
                    Message = "Alert2",
                    Type = "Information",
                    StartTime = DateTime.Now.AddDays(-2),
                    EndTime = DateTime.Now,
                    IsDeleted = true
                },
            };

            using (var context = _dbContextFactory.CreateContext())
            {
                context.MaintenanceBanners.AddRange(maintenanceBanners);
                context.SaveChangesAsync().Wait();
            }
        }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.Activities.Core.Models.Impls;
using Camps.Activities.EF;
using Camps.Events.EF;
using Camps.Web.Activities.Models;
using FFL.PortalTest.Common;
using Microsoft.Extensions.DependencyInjection;
using Camps.FFL.Core.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FFL.PortalTest.DataGenerator.Interface;

namespace FFL.PortalTest.DataGenerator
{
    public class ActivityDataGenerator : IDataGenerator
    {
        public void Execute(IServiceProvider provider)
        {
            var _dbContextFactory = provider.GetService<IActivitiesDbContextFactory>();

            List<Activity> list = new List<Activity>()
            {
                new Activity()
                {
                    Id = Guid.NewGuid(),
                    SiteId = SiteContext.SiteId,
                    Title = "TestActivity1",
                    ViewPageTemplate = PageTemplate.ActivitiesTemplateA.ToAttributeString(),
                    ViewPageId = Guid.Empty,
                    ViewPageName = "TestActivity1",
                    Status = ActivityStatus.Draft.ToAttributeString(),
                    PriceType = PriceType.Free.ToAttributeString(),
                    StartDate = DateTime.Now.AddDays(-2),
                    EndDate = DateTime.Now,
                    LocationType = (int)LocationType.Online,
                    Featured = true,
                    IsDeleted = false
                }
            };

            using (var context = _dbContextFactory.CreateContext())
            {
                context.Activities.AddRange(list);
                context.SaveChangesAsync().Wait();
            }
        }
    }
}

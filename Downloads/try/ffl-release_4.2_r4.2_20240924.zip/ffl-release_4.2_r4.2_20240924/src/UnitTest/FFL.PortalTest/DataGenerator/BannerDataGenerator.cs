﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.Alert.Core.Models;
using Camps.Alert.EF;
using Camps.Banner.Core.Models;
using Camps.Banner.EF;
using Camps.Web.Banner.ViewModels;
using FFL.PortalTest.Common;
using FFL.PortalTest.DataGenerator.Interface;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FFL.PortalTest.DataGenerator
{
    public class BannerDataGenerator : IDataGenerator
    {
        public void Execute(IServiceProvider provider)
        {
            var _dbContextFactory = provider.GetService<IBannerDbContextFactory>();
            List<RotatingBanner> rotatingBanners = new List<RotatingBanner>()
            {
                new RotatingBanner
                {
                    Id = Guid.Parse("7C82CFE7-9EE0-4E45-967A-FCC8D1106F13"),
                    SiteId = SiteContext.SiteId,
                    Title = "test",
                    ImageLinkType = "External",
                    CreatedBy = Guid.NewGuid(),
                    ModifiedBy = Guid.NewGuid(),
                    SyncStatus = Camps.Core.Data.Abstractions.CSyncStatus.Yes,
                    IsDeleted = false,
                    CreatedUtc = DateTime.UtcNow,
                    ModifiedUtc = DateTime.UtcNow,
                    Status = RotatingBannerStatus.Published.ToString()
                },
                new RotatingBanner
                {
                    Id = Guid.Parse("642F8B4C-8320-415E-8EA7-6FEFB877C343"),
                    SiteId = SiteContext.SiteId,
                    Title = "test01",
                    ImageLinkType = "External",
                    CreatedBy = Guid.NewGuid(),
                    ModifiedBy = Guid.NewGuid(),
                    SyncStatus = Camps.Core.Data.Abstractions.CSyncStatus.Yes,
                    IsDeleted = false,
                    CreatedUtc = DateTime.UtcNow,
                    ModifiedUtc = DateTime.UtcNow,
                    Status = RotatingBannerStatus.Published.ToString()
                },
                new RotatingBanner
                {
                    Id = Guid.Parse("D0DCE857-CE51-41DB-B2E0-325576EEF692"),
                    SiteId = SiteContext.SiteId,
                    Title = "test02",
                    ImageLinkType = "External",
                    CreatedBy = Guid.NewGuid(),
                    ModifiedBy = Guid.NewGuid(),
                    SyncStatus = Camps.Core.Data.Abstractions.CSyncStatus.Yes,
                    IsDeleted = false,
                    CreatedUtc = DateTime.UtcNow,
                    ModifiedUtc = DateTime.UtcNow,
                    Status = RotatingBannerStatus.Published.ToString()
                },
                new RotatingBanner
                {
                    Id = Guid.Parse("833B5853-6977-42A3-BF11-4405761D21E7"),
                    SiteId = SiteContext.SiteId,
                    Title = "test03",
                    ImageLinkType = "External",
                    CreatedBy = Guid.NewGuid(),
                    ModifiedBy = Guid.NewGuid(),
                    SyncStatus = Camps.Core.Data.Abstractions.CSyncStatus.Yes,
                    IsDeleted = false,
                    CreatedUtc = DateTime.UtcNow,
                    ModifiedUtc = DateTime.UtcNow,
                    Status = RotatingBannerStatus.Published.ToString()
                }
            };
            

            using (var context = _dbContextFactory.CreateContext())
            {
                context.RotatingBanners.AddRange(rotatingBanners); ;
                context.SaveChangesAsync().Wait();
            }
        }
    }
}

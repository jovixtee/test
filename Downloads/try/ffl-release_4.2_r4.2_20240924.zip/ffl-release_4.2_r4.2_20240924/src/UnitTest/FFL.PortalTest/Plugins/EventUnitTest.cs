﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using APM.SDK.Messages;
using APM.SDK.Services;
using Camps.Events.Core.Models.Impls;
using Camps.Events.EF;
using Camps.Events.Models.DataModel;
using Camps.Web.Events.Controllers;
using Camps.Web.Events.Services;
using FFL.PortalTest.Common;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit.Extensions.Ordering;

namespace FFL.PortalTest.Plugins
{
    public class EventUnitTest : UnitTestBase
    {
        private readonly EventsAdminApiController _eventAdminApiController;

        public EventUnitTest(
            EventsAdminApiController eventAdminApiController
            ) : base(new List<ControllerBase> { eventAdminApiController })
        {
            _eventAdminApiController = eventAdminApiController;
            MockAPMSdk();
        }

        //[Fact]
        //[Order(1)]
        //public async Task TestGetById()
        //{
        //    var result = await _eventAdminApiController.GetById(Guid.NewGuid());
        //    Assert.NotNull(result);
        //}

        //[Fact]
        //[Order(2)]
        //public async Task TestCheckExist()
        //{
        //    var model = new CheckExistModel()
        //    {
        //        EventId = Guid.NewGuid(),
        //        Title = "Test",
        //        Url = "Test",
        //        ViewId = Guid.NewGuid().ToString()
        //    };

        //    await _eventAdminApiController.CheckExist(model);
        //}

        private void MockAPMSdk()
        {
            EventsService service = GetPrivateField<EventsService>(_eventAdminApiController, "EventsService");
            var mock = new Mock<IEndpointService>();
            var httpContentMock = new Mock<HttpContent>();
            mock.Setup(t => t.ExecuteAsync<APMRequest, APMResponse>(It.IsNotNull<APMRequest>()).Result)
                .Returns(new APMResponse() { Content = httpContentMock.Object });
            MockPrivateField(service, "_client", mock.Object);
        }
    }
}

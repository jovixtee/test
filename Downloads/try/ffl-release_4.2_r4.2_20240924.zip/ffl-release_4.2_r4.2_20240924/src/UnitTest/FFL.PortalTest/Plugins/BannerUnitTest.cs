﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using APM.SDK.Messages;
using APM.SDK.Services;
using Camps.CaseDocument.Core.Models;
using Camps.CaseDocument.Service.Services;
using Camps.Web.Attachments.Model;
using Camps.Web.Attachments.Services;
using Camps.Web.Attachments.Services.Interfaces;
using Camps.Web.Banner.Controllers;
using Camps.Web.Banner.Services;
using Camps.Web.Banner.ViewModels;
using Camps.Web.Events.Services;
using FFL.PortalTest.Common;
using Microsoft.AspNetCore.Http;
using Moq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Xunit.Extensions.Ordering;

namespace FFL.PortalTest.Plugins
{
    public class BannerUnitTest : UnitTestBase
    {
        private readonly RotatingBannerController _rotatingBannerController;
        private readonly RotatingBannerAdminApiController _rotatingBannerAdminApiController;
        private readonly RotatingBannerApiController _rotatingBannerApiController;

        public BannerUnitTest(
            RotatingBannerController rotatingBannerController,
            RotatingBannerAdminApiController rotatingBannerAdminApiController,
            RotatingBannerApiController rotatingBannerApiController
            ) : base(new List<Microsoft.AspNetCore.Mvc.ControllerBase> { rotatingBannerController, rotatingBannerAdminApiController, rotatingBannerApiController })
        {
            _rotatingBannerController = rotatingBannerController;
            _rotatingBannerAdminApiController = rotatingBannerAdminApiController;
            _rotatingBannerApiController = rotatingBannerApiController;
            
        }

        [Fact, Order(1)]
        public async Task TestIndex()
        {
            var result = await _rotatingBannerController.Index(1, 10);
            Assert.NotNull(result);
        }

        [Fact, Order(2)]
        public async Task TestTableList()
        {
            var result = await _rotatingBannerController.TableList(1, 10);
            Assert.NotNull(result);
        }

        [Theory, Order(3)]
        [InlineData("00000000-0000-0000-0000-000000000000")]
        [InlineData("7C82CFE7-9EE0-4E45-967A-FCC8D1106F13")]
        [InlineData("E6B26523-E99F-46BA-97B5-02FC9861B185")]
        public async Task TestFormPartialView02(string id)
        {
            var result = await _rotatingBannerController.FormPartialView(Guid.Parse(id));
            Assert.NotNull(result);
        }

        [Fact, Order(4)]
        public async Task TestCreate()
        {
            MockDocumentSdk();
            var fileMock = new Mock<IFormFile>();
            RotatingBannerViewModel model = new RotatingBannerViewModel()
            { 
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Title = "test",
                ImageLinkType = "External",
                ImageLink = "https://localhost:8000/RotatingBanner",
                File = fileMock.Object,
            };
            var result = await _rotatingBannerAdminApiController.Create(model);
            Assert.NotNull(result);
        }

        [Fact, Order(5)]
        public async Task TestCreate01()
        {
            var fileMock = new Mock<IFormFile>();
            RotatingBannerViewModel model = new RotatingBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Title = "test",
                ImageLinkType = "External",
                ImageLink = "https://localhost:8000/RotatingBanner",
                File = fileMock.Object,
            };
            var result = await _rotatingBannerAdminApiController.Create(model);
            Assert.NotNull(result);
        }

        [Theory, Order(6)]
        [MemberData(nameof(TestData01TestCreateOrUpdate))]
        [MemberData(nameof(TestData02TestCreateOrUpdate))]
        [MemberData(nameof(TestData03TestCreateOrUpdate))]
        [MemberData(nameof(TestData04TestCreateOrUpdate))]
        public async Task TestCreate02(RotatingBannerViewModel model)
        {
            var result = await _rotatingBannerAdminApiController.Create(model);
            Assert.NotNull(result);
        }

        [Fact, Order(7)]
        public async Task TestThumCreate()
        {
            RotatingBannerViewModel model = new RotatingBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Title = "test",
                ImageLinkType = "Internal",
                ImageLink = "https://test:8000/RotatingBanner",
                ImageLinkFooterPath = "test"
            };
            var result = await _rotatingBannerAdminApiController.ThumCreate(model);
            Assert.True(result != Guid.Empty);
        }

        [Fact, Order(8)]
        public async Task TestUpdate()
        {
            RotatingBannerViewModel model = new RotatingBannerViewModel() { Id = Guid.NewGuid() };
            var result = await _rotatingBannerAdminApiController.Update(model);
            Assert.NotNull(result);
        }

        [Fact, Order(9)]
        public async Task TestUpdate01()
        {
            MockDocumentSdk();
            RotatingBannerViewModel model = new RotatingBannerViewModel()
            {
                Id = Guid.Parse("7C82CFE7-9EE0-4E45-967A-FCC8D1106F13"),
                SiteId = SiteContext.SiteId,
                Title = "new title",
                ImageLinkType = "External",
                ImageLink = "https://localhost:8000/RotatingBanner",
                File = new Mock<IFormFile>().Object,
                ImageSourceUrl = "RotatingBanner/fad31526-3563-489a-a61f-320db42725e8/Capture_d8bba4fe-694c-422f-9a2d-7736784e09a4.jpg"
            };
            var result = await _rotatingBannerAdminApiController.Update(model);
            Assert.NotNull(result);
        }

        [Theory, Order(10)]
        [MemberData(nameof(TestData01TestCreateOrUpdate))]
        [MemberData(nameof(TestData02TestCreateOrUpdate))]
        [MemberData(nameof(TestData03TestCreateOrUpdate))]
        [MemberData(nameof(TestData04TestCreateOrUpdate))]
        public async Task TestUpdate02(RotatingBannerViewModel model)
        {
            var result = await _rotatingBannerAdminApiController.Update(model);
            Assert.NotNull(result);
        }

        [Fact, Order(11)]
        public async Task TestDelete()
        {
            var result = await _rotatingBannerAdminApiController.Delete(new List<Guid>() { Guid.Parse("D0DCE857-CE51-41DB-B2E0-325576EEF692"), Guid.Parse("833B5853-6977-42A3-BF11-4405761D21E7") });
            Assert.NotNull(result);
        }

        [Fact, Order(12)]
        public async Task TestDelete01()
        {
            var result = await _rotatingBannerAdminApiController.Delete(new List<Guid>() { Guid.NewGuid() });
            Assert.NotNull(result);
        }

        [Fact, Order(13)]
        public async Task TestGetDataById()
        {
            var result = await _rotatingBannerAdminApiController.GetDataById(Guid.Parse("7C82CFE7-9EE0-4E45-967A-FCC8D1106F13"));
            Assert.NotNull(result);
        }

        [Theory, Order(14)]
        [InlineData("00000000-0000-0000-0000-000000000000")]
        [InlineData("1B49F819-6BE7-43B3-9138-5A807BDAC3CD")]
        public async Task TestGetDataById01(string id)
        {
            var result = await _rotatingBannerAdminApiController.GetDataById(Guid.Parse(id));
            Assert.Null(result);
        }

        [Theory, Order(15)]
        [MemberData(nameof(TestData01TestPublish))]
        [MemberData(nameof(TestData02TestPublish))]
        [MemberData(nameof(TestData03TestPublish))]
        public async Task TestPublish(RotatingBannerPublishModel model)
        {
            var result = await _rotatingBannerAdminApiController.Publish(model);
            Assert.NotNull(result);
        }

        [Fact, Order(16)]
        public async Task TestGetRotatingBannerPublishList()
        { 
            var result = await _rotatingBannerApiController.GetRotatingBannerPublishList();
            Assert.NotNull(result);
        }

        public static IEnumerable<object[]> TestData01TestCreateOrUpdate()
        {
            RotatingBannerViewModel model = new RotatingBannerViewModel()
            {
                Id = Guid.NewGuid(),
                Title = "test title",
                Description = "test description",
                File = new Mock<IFormFile>().Object,
            };
            return new List<object[]> {
                new object[] { model }
            };
        }
        public static IEnumerable<object[]> TestData02TestCreateOrUpdate()
        {
            RotatingBannerViewModel model = new RotatingBannerViewModel()
            { 
                Id = Guid.NewGuid(),
                Title = "test title test title test title test title test title test title " +
                "test title test title test title test title test title test title test title test title",
                File = new Mock<IFormFile>().Object,
                ImageLink = "https://localhost:8000/RotatingBanner"
            };
            return new List<object[]> {
                new object[] { model }
            };
        }
        public static IEnumerable<object[]> TestData03TestCreateOrUpdate()
        {
            RotatingBannerViewModel model = new RotatingBannerViewModel()
            {
                Id = Guid.NewGuid(),
                Title = "test title",
                Description = "test description test description test description test description test " +
                "description test description test description test description test description test " +
                "description test description test description test description test description test " +
                "description test description test description test description test description test " +
                "description test description test description test description test description test " +
                "description test description test description test description test description test ",
                File = new Mock<IFormFile>().Object,
                ImageLink = "https://localhost:8000/RotatingBanner"
            };
            return new List<object[]> {
                new object[] { model }
            };
        }
        public static IEnumerable<object[]> TestData04TestCreateOrUpdate()
        {
            RotatingBannerViewModel model = new RotatingBannerViewModel()
            {
                Id = Guid.NewGuid(),
                Title = "test title",
                Description = "test description",
                File = new Mock<IFormFile>().Object,
                ImageLink = "ftp://RotatingBanner"
            };
            return new List<object[]> {
                new object[] { model }
            };
        }
        public static IEnumerable<object[]> TestData01TestPublish()
        {
            RotatingBannerPublishModel model = new RotatingBannerPublishModel()
            {
                publishIds = new List<Guid>() { Guid.Parse("7C82CFE7-9EE0-4E45-967A-FCC8D1106F13") },
                unPublishIds = new List<Guid>() { Guid.Parse("642F8B4C-8320-415E-8EA7-6FEFB877C343") }
            };
            return new List<object[]> {
                new object[] { model }
            };
        }
        public static IEnumerable<object[]> TestData02TestPublish()
        {
            RotatingBannerPublishModel model = new RotatingBannerPublishModel()
            {
                publishIds = new List<Guid>() { Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid() }
            };
            return new List<object[]> {
                new object[] { model }
            };
        }
        public static IEnumerable<object[]> TestData03TestPublish()
        {
            RotatingBannerPublishModel model = new RotatingBannerPublishModel()
            {
                publishIds = new List<Guid>() { Guid.NewGuid() },
                unPublishIds = new List<Guid>() { Guid.NewGuid() }
            };
            return new List<object[]> {
                new object[] { model }
            };
        }
        private void MockDocumentSdk()
        {
            RotatingBannerManager service = GetPrivateField<RotatingBannerManager>(_rotatingBannerAdminApiController, "_rotatingBannerManager");
            DocumentService docService = GetPrivateField<DocumentService>(service, "_documentService");
            var mock = new Mock<ICaseDocumentsService>();
            mock.Setup(m => m.UploadFile(It.Is<CRMDataModel>(x => x != null), It.Is<IFormFile>(x => x != null), It.Is<UploadOptionsModel>(x => x != null)));
            mock.Setup(m => m.GetFolderFilesByDocType(It.Is<CRMDataModel>(x => x != null), It.Is<string>(x => x != null), It.Is<string>(x => x != null)).Result).Returns(
            new List<FileModel>() {
            new FileModel()
            {
                FileName = "test.jpg",
                CreatedTime = DateTime.UtcNow.Ticks,
                RelativeUrl = "RotatingBanner/78551d5e-cccd-418c-a0c8-d19a262d98db/test_6dfdfb73-eab2-41eb-a7a8-0f3816001f75.jpg"
            }
            });
            MockPrivateField(docService, "documentService", mock.Object);
        }
    }
}

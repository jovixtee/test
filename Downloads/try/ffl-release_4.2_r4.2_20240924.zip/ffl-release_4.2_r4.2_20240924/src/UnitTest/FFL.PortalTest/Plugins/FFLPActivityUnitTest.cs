﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.Web.Alert.ApiControllers;
using Camps.Web.Alert.Controllers;
using Camps.Web.FFLPActivities.ApiController;
using Camps.Web.FFLPActivities.Controllers;
using Camps.Web.FFLPActivities.Models;
using Camps.Web.News.ApiController;
using Camps.Web.News.Models;
using FFL.PortalTest.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit.Extensions.Ordering;

namespace FFL.PortalTest.Plugins
{
    public class FFLPActivityUnitTest : UnitTestBase
    {
        private readonly FFLPActivitiesApiController _fFLPActivitiesApiController;
        private readonly FFLPActivitiesAdminApiController _fFLPActivitiesAdminApiController;
        private readonly FFLPActivitiesController _fFLPActivitiesController;

        public FFLPActivityUnitTest(
            FFLPActivitiesApiController fFLPActivitiesApiController,
            FFLPActivitiesAdminApiController fLPActivitiesAdminApiController,
            FFLPActivitiesController fFLPActivitiesController
            ) : base(new List<Microsoft.AspNetCore.Mvc.ControllerBase> { fFLPActivitiesApiController, fLPActivitiesAdminApiController, fFLPActivitiesController })
        {
            _fFLPActivitiesApiController = fFLPActivitiesApiController;
            _fFLPActivitiesAdminApiController = fLPActivitiesAdminApiController;
            _fFLPActivitiesController = fFLPActivitiesController;
        }

        //[Fact, Order(1)]
        //public async Task TestListData()
        //{
        //    ApiFFLPQueryModel model = new ApiFFLPQueryModel()
        //    {
        //        PageConfig = new Camps.Core.Data.Abstractions.PagingInfo() { CurrentPage = 1 },
        //        Query = new Camps.FFL.Core.QueryModel.CardWebpartQuery() { SearchKeyWord = "test" }

        //    };
        //    var result = await _fFLPActivitiesApiController.ListData(model);
        //    Assert.NotNull(result);
        //}
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.Activities.Core.Models.Impls;
using Camps.Activities.EF;
using Camps.Core.Data.Abstractions;
using Camps.Events.EF.MSSQL.Migrations;
using Camps.FFL.Core.Utilities;
using Camps.Web.Activities.Controllers;
using Camps.Web.Activities.Models;
using FFL.PortalTest.Common;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Moq;

namespace FFL.PortalTest.Plugins
{
    public class ActivitiesUnitTest : UnitTestBase
    {
        private readonly ActivitiesController _activitiesController;
        private readonly ActivitiesAdminApiController _activitiesAdminApiController;
        private readonly IActivitiesDbContextFactory _dbContextFactory;

        public ActivitiesUnitTest(
            ActivitiesController activitiesController,
            ActivitiesAdminApiController activitiesAdminApiController,
            IActivitiesDbContextFactory contextFactory
            ) : base(new List<ControllerBase> { activitiesController , activitiesAdminApiController})
        {
            _activitiesController = activitiesController;
            _activitiesAdminApiController = activitiesAdminApiController;
            _dbContextFactory = contextFactory;
        }

        [Fact]
        public async Task TestCreate()
        {
            var fileMock = new Mock<IFormFile>();
            var attachmentMock = new Mock<IFormFileCollection>();
            var createModel = new ActivityViewModel()
            {
                PageTemplate = PageTemplate.ActivitiesTemplateA,
                Title = "TestActivity",
                Url = "TestActivity",
                ViewPageName = "TestActivity",
                PriceType = PriceType.Paid,
                PaidFrom = 5,
                PaidTo = 15,
                StartDate = DateTime.Now.Date,
                EndDate = DateTime.Now.AddDays(1).Date,
                LocationType = LocationType.Onsite,
                Location = "TestLocation",
                Description = "TestDescription",
                Featured = true,
                TermList = "ab36b74a-1fe7-4e5f-b0c0-411e4f4e1a14,8155c3dc-f2ff-4e40-8d47-98a2d25f5b79",
            };
            var result = await _activitiesAdminApiController.Create(createModel);
            Assert.NotNull(result);
        }

        [Fact]
        public async Task TestTable()
        {
            var result = await _activitiesController.Index(10, 1, Camps.Web.Activities.Models.ActivityStatus.Draft, string.Empty, string.Empty, string.Empty);
            Assert.NotNull(result);
        }
    }
}

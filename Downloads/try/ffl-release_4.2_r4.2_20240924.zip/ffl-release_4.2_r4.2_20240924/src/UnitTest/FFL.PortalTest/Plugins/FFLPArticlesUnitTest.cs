﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.Web.FFLPActivities.ApiController;
using Camps.Web.FFLPActivities.Controllers;
using Camps.Web.FFLPActivities.Models;
using Camps.Web.FFLPArticles.ApiController;
using Camps.Web.FFLPArticles.Controllers;
using Camps.Web.FFLPArticles.Models;
using FFL.PortalTest.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit.Extensions.Ordering;

namespace FFL.PortalTest.Plugins
{
    public class FFLPArticlesUnitTest : UnitTestBase
    {

        private readonly FFLPArticlesApiController _fFLPArticlesApiController;
        private readonly FFLPArticlesAdminApiController _fFLPArticlesAdminApiController;
        private readonly FFLPArticlesController _fFLPArticlesController;

        public FFLPArticlesUnitTest(
                FFLPArticlesApiController fFLPArticlesApiController,
                FFLPArticlesAdminApiController fFLPArticlesAdminApiController,
                FFLPArticlesController fFLPArticlesController
            ) : base(new List<Microsoft.AspNetCore.Mvc.ControllerBase> { fFLPArticlesApiController, fFLPArticlesAdminApiController, fFLPArticlesController })
        {
            _fFLPArticlesApiController = fFLPArticlesApiController;
            _fFLPArticlesAdminApiController = fFLPArticlesAdminApiController;
            _fFLPArticlesController = fFLPArticlesController;
        }

        [Fact, Order(1)]
        public async Task TestListData()
        {
            var result = await _fFLPArticlesApiController.GetArticle("test");
            Assert.NotNull(result);
        }
    }
}

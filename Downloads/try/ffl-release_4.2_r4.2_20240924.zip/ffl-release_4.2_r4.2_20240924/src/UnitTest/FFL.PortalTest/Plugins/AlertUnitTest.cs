﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.Core.Services.Extensions;
using Camps.Web.Alert.ApiControllers;
using Camps.Web.Alert.Controllers;
using Camps.Web.Alert.Services;
using Camps.Web.Alert.ViewModels;
using FFL.PortalTest.Common;
using Microsoft.EntityFrameworkCore.SqlServer.Query.Internal;
using Moq;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Xunit.Extensions.Ordering;

namespace FFL.PortalTest.Plugins
{
    public class AlertUnitTest : UnitTestBase
    {
        private readonly MaintenanceBannerController _maintenanceBannerController;
        private readonly MaintenanceBannerAdminApiController _maintenanceBannerAdminApiController;
        private readonly MaintenanceBannerApiController _maintenanceBannerApiController;

        public AlertUnitTest(
            MaintenanceBannerController maintenanceBannerController,
            MaintenanceBannerAdminApiController maintenanceBannerAdminApiController,
            MaintenanceBannerApiController maintenanceBannerApiController
            ) : base(new List<Microsoft.AspNetCore.Mvc.ControllerBase> { maintenanceBannerController, maintenanceBannerAdminApiController, maintenanceBannerApiController })
        {
            _maintenanceBannerController = maintenanceBannerController;
            _maintenanceBannerAdminApiController = maintenanceBannerAdminApiController;
            _maintenanceBannerApiController = maintenanceBannerApiController;
        }

        [Fact, Order(1)]
        public async Task TestIndex()
        {
            var result = await _maintenanceBannerController.Index(1, 10);
            Assert.NotNull(result);
        }

        [Fact, Order(2)]
        public async Task TestIndexPartial()
        {
            var result = await _maintenanceBannerController.IndexPartial(1, 10);
            Assert.NotNull(result);
        }

        [Fact, Order(3)]
        public void TestCreatePartial()
        {
            var result = _maintenanceBannerController.CreatePartial();
            Assert.NotNull(result);
        }

        [Fact, Order(4)]
        public async Task TestEditPartial()
        {
            var result = await _maintenanceBannerController.EditPartial(Guid.Parse("D5D2C09B-A12B-42ED-96FE-7F79112C14B7"));
            Assert.NotNull(result);
        }

        [Fact, Order(5)]
        public void TestEditPartial01()
        {
            var ex = Assert.ThrowsAsync<Exception>(() => _maintenanceBannerController.EditPartial(Guid.NewGuid()));
            Assert.Contains("One or more errors occurred.", ex.Exception.Message);
        }

        [Fact, Order(6)]
        public async Task TestCreate()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Message = "Alert1",
                Type = "Information",
                EndTime = DateTime.Now,
                IsDisplay = true
            };
            var result = await _maintenanceBannerController.Create(model);
            Assert.NotNull(result);
        }

        [Theory, Order(7)]
        [MemberData(nameof(TestData01TestCreate01))]
        [MemberData(nameof(TestData02TestCreate01))]
        [MemberData(nameof(TestData03TestCreate01))]
        [MemberData(nameof(TestData04TestCreate01))]
        [MemberData(nameof(TestData05TestCreate01))]
        [MemberData(nameof(TestData06TestCreate01))]
        [MemberData(nameof(TestData07TestCreate01))]
        [MemberData(nameof(TestData08TestCreate01))]
        public void TestCreate01(MaintenanceBannerViewModel model)
        {
            var ex = Assert.ThrowsAsync<Exception>(() => _maintenanceBannerController.Create(model));
            Assert.Contains("One or more errors occurred.", ex.Exception.Message);
        }

        [Fact, Order(8)]
        public async Task TestUpdate()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.Parse("D5D2C09B-A12B-42ED-96FE-7F79112C14B7"),
                SiteId = SiteContext.SiteId,
                Message = "Alert",
                Type = "Information",
                EndTime = DateTime.Now,
                IsDisplay = true
            };
            var result = await _maintenanceBannerController.Update(model);
            Assert.NotNull(result);
        }

        [Fact, Order(9)]
        public void TestUpdate01()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.Empty,
                SiteId = SiteContext.SiteId,
                Message = "Alert1",
                Type = "Information",
                StartTime = DateTime.Now.AddDays(1),
                EndTime = DateTime.Now.AddDays(2),
                IsDisplay = false
            };
            var ex = Assert.ThrowsAsync<Exception>(() => _maintenanceBannerController.Update(model));
            Assert.Contains("One or more errors occurred.", ex.Exception.Message);
        }

        [Fact, Order(10)]
        public async Task TestDelete()
        {
            var result = await _maintenanceBannerController.Delete(new List<Guid>() { Guid.Parse("787D9721-A954-4232-86C6-7879BB4E9335") });
            Assert.NotNull(result);
        }

        [Theory, Order(11)]
        [MemberData(nameof(TestData01TestDelete))]
        [MemberData(nameof(TestData02TestDelete))]
        public async Task TestDelete01(List<Guid> ids)
        {
            var result = await _maintenanceBannerController.Delete(ids);
            Assert.NotNull(result);
        }

        [Fact, Order(12)]
        public void TestCreatePartial01()
        {
            var result = _maintenanceBannerAdminApiController.CreatePartial();
            Assert.NotNull(result);
        }

        [Fact, Order(13)]
        public async Task TestEditPartial02()
        {
            var result = await _maintenanceBannerAdminApiController.EditPartial(Guid.Parse("D5D2C09B-A12B-42ED-96FE-7F79112C14B7"));
            Assert.NotNull(result);
        }

        [Fact, Order(14)]
        public void TestEditPartial03()
        {
            var ex = Assert.ThrowsAsync<Exception>(() => _maintenanceBannerAdminApiController.EditPartial(Guid.NewGuid()));
            Assert.Contains("One or more errors occurred.", ex.Exception.Message);
        }

        [Fact, Order(15)]
        public async Task TestGetMaintenanceBanners()
        {
            var result = await _maintenanceBannerApiController.GetMaintenanceBanners();
            Assert.NotNull(result);
        }

        [Fact, Order(16)]
        public async Task TestCreate02()
        {
            var result = await _maintenanceBannerController.Create(null);
            Assert.NotNull(result);
        }

        public static IEnumerable<object[]> TestData01TestCreate01()
        {
            return new List<object[]> {
                new object[] { null }
            };
        }
        public static IEnumerable<object[]> TestData02TestCreate01()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Message = "Alert1",
                EndTime = DateTime.Now,
                IsDisplay = true
            };
            return new List<object[]> {
                new object[] { model }
            };
        }

        public static IEnumerable<object[]> TestData03TestCreate01()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Message = "Alert1",
                Type = "test",
                EndTime = DateTime.Now,
                IsDisplay = true
            };
            return new List<object[]> {
                new object[] { model }
            };
        }

        public static IEnumerable<object[]> TestData04TestCreate01()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Message = "Alert1",
                Type = "Information",
                StartTime = DateTime.Now.AddDays(-2),
                EndTime = DateTime.Now,
                IsDisplay = false
            };
            return new List<object[]> {
                new object[] { model }
            };
        }

        public static IEnumerable<object[]> TestData05TestCreate01()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Message = string.Empty,
                Type = "Information",
                StartTime = DateTime.Now.AddDays(1),
                EndTime = DateTime.Now,
                IsDisplay = false
            };
            return new List<object[]> {
                new object[] { model }
            };
        }
        public static IEnumerable<object[]> TestData06TestCreate01()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Message = "Alert1",
                Type = "Information",
                StartTime = DateTime.MaxValue,
                EndTime = DateTime.Now,
                IsDisplay = false
            };
            return new List<object[]> {
                new object[] { model }
            };
        }

        public static IEnumerable<object[]> TestData07TestCreate01()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Message = "Alert1",
                Type = "Information",
                StartTime = DateTime.Now,
                EndTime = DateTime.MinValue,
                IsDisplay = false
            };
            return new List<object[]> {
                new object[] { model }
            };
        }

        public static IEnumerable<object[]> TestData08TestCreate01()
        {
            MaintenanceBannerViewModel model = new MaintenanceBannerViewModel()
            {
                Id = Guid.NewGuid(),
                SiteId = SiteContext.SiteId,
                Message = "Alert1",
                Type = "Information",
                StartTime = DateTime.Now.AddDays(1),
                EndTime = DateTime.Now,
                IsDisplay = false
            };
            return new List<object[]> {
                new object[] { model }
            };
        }

        public static IEnumerable<object[]> TestData01TestDelete()
        {
            return new List<object[]> {
                new object[] { new List<Guid> { Guid.Parse("FCD02806-94A1-4CDD-BA63-72335C2B1DD2") } }
            };
        }

        public static IEnumerable<object[]> TestData02TestDelete()
        {
            return new List<object[]> {
                new object[] { new List<Guid> { Guid.NewGuid() } }
            };
        }
    }
}

﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using Camps.Core.Web.Controllers;
using IdentityModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Reflection;
using System.Security.Claims;
using System.Security.Principal;

namespace FFL.PortalTest.Common
{
    public abstract class UnitTestBase
    {
        protected UnitTestBase() { }

        protected UnitTestBase(List<ControllerBase> controllers)
        {
            var claims = new List<Claim>()
            {
                new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString())
            };
            var identity = new ClaimsIdentity(claims);
            var claimsPrincipal = new ClaimsPrincipal(identity);
            foreach (var controller in controllers)
            {
                controller.ControllerContext = new ControllerContext();
                controller.ControllerContext.HttpContext = new DefaultHttpContext() { User = claimsPrincipal };
            }
        }

        protected T GetPrivateField<T>(object obj, string field)
        {
            var type = obj.GetType();
            var fieldInfo = type.GetField(field, BindingFlags.NonPublic
                | BindingFlags.Instance
                | BindingFlags.Default
                | BindingFlags.GetField
                );
            if (fieldInfo != null)
            {
                return (T)fieldInfo.GetValue(obj);
            }
            return default(T);
        }

        protected void MockPrivateField(object obj, string fieldName, object mockObj)
        {
            var type = obj.GetType();
            var fieldInfo = type.GetField(fieldName, BindingFlags.NonPublic
                | BindingFlags.Instance
                | BindingFlags.Default
                | BindingFlags.GetField
                );
            if (fieldInfo != null)
            {
                fieldInfo.SetValue(obj, mockObj);
            }
        }
    }

    public static class SiteContext
    {
        public static readonly Guid SiteId = new Guid("181b5352-ce4f-4158-9c99-7c11c09c631b");
    }
}

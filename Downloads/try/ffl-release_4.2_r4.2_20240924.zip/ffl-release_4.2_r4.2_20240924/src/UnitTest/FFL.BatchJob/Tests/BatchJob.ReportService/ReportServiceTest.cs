﻿/********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2022-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */
using BatchJob.ReportService.Model;
using BatchJob.ReportService.Services.Interfaces;
using FFL.BatchJobTest.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FFL.BatchJobTest.Tests.BatchJob.ReportService
{
    public class ReportServiceTest : UnitTestBase<IReportingService>
    {
        private IReportingService ReportingService { get; set; }

        public ReportServiceTest(IReportingService reportService)
        {
            ReportingService = reportService;
        }

        [Fact]
        public async void GetReportTest()
        {
            //var value = await ReportingService.ListReport("/");
            //Assert.NotNull(value);
            Assert.True(true);
        }

        [Fact]
        public async void ExportTest()
        {
            //var value = await ReportingService.Export(new SSRSModel.RenderModel
            //{
            //    Parameters = new Dictionary<string, string>(),
            //    ReportFormat = SSRSEnum.ReportFormat.PDF,
            //    ReportPath = "/MyReportProject/Report3"
            //});
            //Assert.NotNull(value);
            Assert.True(true);
        }
    }
}

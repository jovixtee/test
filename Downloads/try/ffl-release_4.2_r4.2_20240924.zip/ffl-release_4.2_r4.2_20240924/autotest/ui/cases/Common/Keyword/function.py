# import win32con
# import win32gui

def RGB_Convert_To_Hex(rgb):
    str = rgb.strip('rgb(').strip(')')
    lis = str.split(', ')
    r = int(lis[0])
    g = int(lis[1])
    b = int(lis[2])
    color = ('{:02X}' * 3).format(r, g, b)
    color = '#'+color
    return color
# col = RGB_Convert_To_Hex('rgb(161, 112, 14)')
# print(col)

def Get_Date_Format(day):
    import time
    import datetime
    currentDate = datetime.datetime.now()
    date = currentDate + datetime.timedelta(days=day)
    finalDate = date.strftime('%m/%d/%Y')
    return finalDate


def Caculate_Page_Counts(pageText):
    itemCounts = int(pageText.split(': ', 2)[1])
    pageCounts = itemCounts//10+1
    return pageCounts


def Get_Absolute_Path(path):
    rootPath = path.split('Common\\', 2)[0]
    return rootPath


def Get_DateTime_InName():
    import time
    currentTime = time.strftime('%Y%m%d%I', time.localtime(time.time()))
    return currentTime

# def Upload_To_Browser(filepath):  
#     dialog = win32gui.FindWindow(None,"Open")  
#     Comboboxex32 = win32gui.FindWindowEx(dialog, 0, 'Comboboxex32', None)
#     combobox = win32gui.FindWindowEx(Comboboxex32, 0, 'Combobox', None)
#     edit = win32gui.FindWindowEx(combobox, 0, 'Edit', None)
#     button = win32gui.FindWindowEx(dialog, 0, "Button", "Open(&0)")
#     win32gui.SendMessage(edit, win32con.WM_SETTEXT, None, filepath)
#     win32gui.SendMessage(dialog, win32con.WM_COMMAND, 1, button)
   
# def Close_Upload_Dialog():  
#     dialog = win32gui.FindWindow(None,"Open")  
#     win32gui.CloseWindow(dialog)
   


UIAutoTest_Banner_Title_Data = ['AutoTest_Tool_RBanner_Publish01',
                                'AutoTest_Tool_RBanner_PublishAPI_Internal1', 'AutoTest_Tool_RBanner_PublishAPI_External1']
UIAutoTest_Banner_Description_Data = ['Auto Test',
                                      'AutoTest_Tool_Banner_Add_Description03', 'AutoTest_Tool_RBanner_PublishAPI02']
UIAutoTest_Banner_Url_Data = ['https://www.AutoTest_Tool_Banner_Add_Url01.com',
                              'https://www.AutoTest_Tool_Banner_Add_Url02.com',
                              'https://www.AutoTest_Tool_Banner_Add_Url03.com']

FilterType=["Category","Budget","Location","Date Range"]
FilterTypeAll=[" (All)"," (All)"," (All)"," (All)"]
FilterBudget=["FREE","$ (< $10)","$$ ($10 - $30)","$$$ ($30 - $50)","$$$$ (> $50)"]

CategoryItem=["Families"]
CategoryResult=['AUTOTEST-TOOL-EVENT-REGIST2']

BudgetItem=["FREE","$$ ($10 - $30)"]
BudgetResult=["AUTOTEST-TOOL-EVENT-REGIST2"]

LocationItem=["Bedok","Bishan"]
LocationResult=["AUTOTEST-TOOL-EVENT-REGIST2"]

DateItem=["0","0","0","10"] #0 is Current,1 is next month[StartMonth,StartDay,EndMonth,EndDay]
DateResult=["AUTOTEST-TOOL-EVENT-REGIST2"]

SearchKeyword="AUTOTEST-TOOL-EVENT-REGIST2"
ResultEventitle="AUTOTEST-TOOL-EVENT-REGIST2"

SearchKeyword1="AUTOTEST-TOOL-EVENT-REGISTCLOSED2"
ResultEventitle1="AUTOTEST-TOOL-EVENT-REGISTCLOSED2"

SearchKeyword2="AUTOTEST-TOOL-EVENT-FULLYBOOKED2"
ResultEventitle2="AUTOTEST-TOOL-EVENT-FULLYBOOKED2"

AttachName=["UIATUpload.xlsx","UIATUpload.docx"]
FeaturedEventList="AUTOTEST-TOOL-EVENT-REGISTCLOSED2"
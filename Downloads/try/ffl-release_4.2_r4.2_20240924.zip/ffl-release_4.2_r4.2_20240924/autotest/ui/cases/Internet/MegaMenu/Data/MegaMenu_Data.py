MegaMenu_Content_Data = ['About', 'Families for Life',
                         'Learn in', 'Programmes',
                         'Play in', 'Events',
                         'Browse', 'Resources',
                         'Discover', 'Articles & Activities',
                         'Join as', 'Volunteers',
                         'View', 'Made for Families']
MegaMenu_Secondary_Title_Data = ['Programmes',
                                 'Resources',
                                 'Articles & Activities']
MegaMenu_Secondary_Content_Data = ['Family 365', 'Marriage', 'Parenting',
                                   'Pregnancy', 'Newborn', 'Babies', 'Toddlers', 'Young Children', 'Children',
                                   'Activities', 'Articles', 'Occasions']
MegaMenu_Link_Data = ['https://familiesforlife.sg/about-ffl/Pages/default.aspx',
                      'https://familiesforlife.sg/learn-at-a-workshop/Pages/default.aspx',
                      'https://alb-ffl-devezweb-001-1080281820.ap-southeast-1.elb.amazonaws.com/pages/events',
                      # 'https://ffl-qa-portal.sharepointguild.com/pages/events',
                      'https://familiesforlife.sg/parenting/Pages/Home.aspx',
                      # 'https://familiesforlife.sg/join-as-a-volunteer',
                      'https://alb-ffl-devezweb-001-1080281820.ap-southeast-1.elb.amazonaws.com/pages/volunteers',
                      # 'https://ffl-qa-portal.sharepointguild.com/pages/volunteers',
                      'https://www.madeforfamilies.gov.sg/']
MegaMenu_Secondary_Link_Data = ['https://familiesforlife.sg/family-365/Pages/default.aspx',
                                'https://familiesforlife.sg/learn-at-a-workshop/Pages/default.aspx?workshopCategory=Marriage',
                                'https://familiesforlife.sg/learn-at-a-workshop/Pages/default.aspx?workshopCategory=Parenting',
                                'https://familiesforlife.sg/parenting/Pregnancy',
                                'https://familiesforlife.sg/parenting/Newborn',
                                'https://familiesforlife.sg/parenting/Babies',
                                'https://familiesforlife.sg/parenting/Toddlers',
                                'https://familiesforlife.sg/parenting/Young-Children',
                                'https://familiesforlife.sg/parenting/Children',
                                'https://alb-ffl-devezweb-001-1080281820.ap-southeast-1.elb.amazonaws.com/pages/activities',
                                'https://alb-ffl-devezweb-001-1080281820.ap-southeast-1.elb.amazonaws.com/pages/articles',
                                'https://alb-ffl-devezweb-001-1080281820.ap-southeast-1.elb.amazonaws.com/pages/activities?Type=1e3bd8c1-dc3d-40f7-9f76-e23af8f466fc'
                              # 'https://ffl-qa-portal.sharepointguild.com/pages/activities',
                              # 'https://ffl-qa-portal.sharepointguild.com/pages/articles',
                              # 'https://ffl-qa-portal.sharepointguild.com/pages/activities?Type=1e3bd8c1-dc3d-40f7-9f76-e23af8f466fc'
                                ]

FilterType=["Type","Group","Budget","Location","Date Range"]
FilterTypeAll=[" (All)"," (All)"," (All)"," (All)"," (All)"]
FilterBudget=["FREE","$ (< $10)","$$ ($10 - $30)","$$$ ($30 - $50)","$$$$ (> $50)"]
TypeItem=["Games","Cooking"]
TypeResult=["AUTOTEST-TOOL-ACTIVITY-FEATURED-01"]
GroupItem=["Parking","Teenagers"]
GroupResult=["AUTOTEST-TOOL-ACTIVITY-FEATURED-01"]
BudgetItem=["FREE","$$$ ($30 - $50)"]
BudgetResult=["AUTOTEST-TOOL-ACTIVITY-FEATURED-01","AUTOTEST-TOOL-ACTIVITY-FEATURED-FREE-01"]
LocationItem=["Bugis","Chinatown"]
LocationResult=["AUTOTEST-TOOL-ACTIVITY-FEATURED-01","AUTOTEST-TOOL-ACTIVITY-FEATURED-02"]
DateItem=["0","0","1","10"] #0 is Current,1 is next month[StartMonth,StartDay,EndMonth,EndDay]
DateResult=["AUTOTEST-TOOL-ACTIVITY-FEATURED-01"]
SearchKeyword="AUTOTEST-TOOL-ACTIVITY-FEATURED-ATTACH-01"
ResultActTitle="AUTOTEST-TOOL-ACTIVITY-FEATURED-ATTACH-01"
AttachName=["UIATUpload.xlsx","UIATUpload.docx"]
FeaturedActList=["AUTOTEST-TOOL-ACTIVITY-FEATURED-02","AUTOTEST-TOOL-ACTIVITY-FEATURED-03","AUTOTEST-TOOL-ACTIVITY-FEATURED-01"]


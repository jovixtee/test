EventSub_TableTitle = ["", "Title", "Event Organiser", "Email",
                         "Event Category", "Date Submitted", "Status", "Action"]

EventSub_Title_forCreate_Info = ['AutoTest-Tool-EventSubmission-Submitted2']
EventSub_Title_forReject_Info = ['AutoTest-Tool-EventSubmission-Submitted1']

EventSub_Detail_Reject_Dialog_Input_Info = ['UIAutoTest_EventSub_Add_rejectReason']
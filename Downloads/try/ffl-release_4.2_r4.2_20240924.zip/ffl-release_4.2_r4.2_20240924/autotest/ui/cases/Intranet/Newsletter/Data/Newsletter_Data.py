
#Add
Newsletter_New1=["AutoTest_Newsletter_Create01","AutoTest-Newsletter_Create.01@AutoTest.com"]

#Edit
Newsletter_Edit=["AutoTest_Tool_Newsletter03_Edit","AutoTest_Tool-Newsletter_ForEdit.03Edit@UIAT.com","AutoTest_Tool_Newsletter03"]

#Delete
Newsletter_Delete1="AutoTest_Tool_Newsletter04"
Newsletter_MultiDeleteSearch="AutoTest_Tool_Newsletter_MultiDelete"
Newsletter_MultiDelete=["AutoTest_Tool_Newsletter_MultiDelete05","AutoTest_Tool_Newsletter_MultiDelete06"]

#Term
Newsletter_Term_Add=["AutoTest_Newsletter"]

#Table
Newsletter_TableTitle=["", "Full Name", "Email","Interested Topic","Modified on", "Status", "Action"]

#Search,Filter
SearchNewsletter="AutoTest_Tool_Newsletter01"
TermFilterCondition=["AutoTest_Tool_Newsletter"]   #AutoTest_Newsletter
TermFilterObject='AutoTest_Tool_Newsletter01'
StatusFilterActive="Active"   #AutoTest_Newsletter
AtiveObject='AutoTest_Tool_Newsletter01'
StatusFilterInactive="Inactive"
InativeObject='AutoTest_Tool_Newsletter02'
StartTimeRange=0
EndTimeRange=3
DateObject='AutoTest_Tool_Newsletter01'
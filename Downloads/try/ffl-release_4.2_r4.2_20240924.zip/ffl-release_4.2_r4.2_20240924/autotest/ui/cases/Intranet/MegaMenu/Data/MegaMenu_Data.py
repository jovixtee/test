#Add Link  Option:URL,Header,Blank Header; URL:Internal,External; Feature URL:Internal,External
LinkAdd_URL=["AutoTest_URL","URL","Internal","AutoTest_URL","Internal","FURL","FURLDes","Thumbnail.png","AutoTest_URL Upper"]
LinkAdd_Header=["AutoTest_Header","Header","External","http://www.AutoTest.com","External","http://www.AutoTest.com","FURLDes","Thumbnail.png","AutoTest_Header Uppder"]
LinkAdd_BlankHeader=["","Blank Header","External","http://www.AutoTest.com","External","http://www.AutoTest.com","FURLDes","Thumbnail.png"]

#Add SubLink 
SubLinkAdd_URL=["AutoTest_Sub_URL","URL","Internal","AutoTest_URL","AutoTest_Tool_MegaMenu_URL_External01"]
SubLinkAdd_Header=["AutoTest_Sub_Header","Header","External","http://www.AutoTest.com","AutoTest_Tool_MegaMenu_URL_External01"]
SubLinkAdd_BlankHeader=["","Blank Header","External","http://www.AutoTest.com","AutoTest_Tool_MegaMenu_URL_External01"]

#Edit SubLink
SubLinkEdit_URL=["AutoTest_Tool_MegaMenu_Sub_URL_Internal01_Edit","URL","Internal","AutoTest_Tool_MegaMenu_Sub_URL_Internal01","AutoTest_Tool_MegaMenu_URL_External01","AutoTest_Tool_MegaMenu_Sub_URL_Internal01"]
SubLinkEdit_Header=["AutoTest_Tool_MegaMenu_Sub_Header01_Edit","Header","External","http://www.AutoTest.com","AutoTest_Tool_MegaMenu_URL_External01","AutoTest_Tool_MegaMenu_Sub_Header01"]

#Edit Link
LinkEdit_URL=["AutoTest_Tool_URL01_Edit","URL","Internal","AutoTest_URL","Internal","FURL","FURLDes","Thumbnail.png","AutoTest_Tool_URL01 Upper_Edit","AutoTest_Tool_URL01"]
LinkEdit_Header=["AutoTest_Tool_Header01_Edit","Header","External","http://UI.com","External","http://UI.com","FURLDes","Thumbnail.png","AutoTest_Tool_Header01 Uppder_Edit","AutoTest_Tool_Header01"]

#Delete SubLink
SubLinkDelete_URL=["AutoTest_Tool_MegaMenu_URL_External01","AutoTest_Tool_MegaMenu_Sub_URL02"]
SubLinkDelete_Header=["AutoTest_Tool_MegaMenu_URL_External01","AutoTest_Tool_MegaMenu_Sub_Header02"]

#Delete Link
LinkDelete_URL="AutoTest_Tool_MegaMenu_URL_External01"
LinkDelete_Header="AutoTest_Tool_MegaMenu_Header02"

#Move
Move_Sublink=["AutoTest_Tool_MegaMenu_External01","AutoTest_Sub_Header"]
Move_Link="AutoTest_Header"

#ErrorMessage
Mondatory="This field is required."

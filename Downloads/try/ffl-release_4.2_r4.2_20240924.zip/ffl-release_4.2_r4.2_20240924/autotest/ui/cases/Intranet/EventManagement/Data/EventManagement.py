# Table
Event_TableTitle = ["", "Title", "Event Type",
                    "Modified on", "Modified by", "Status", "Action"]

FilterTermEvent = "AutoTest-Tool-Event-Filter2"
FilterTerm = ["Children", "Families"]

FilterStatusEvent = "AutoTest-Tool-Event-Filter2"
FilterStatus = "Publishing"

FilterEventTypeEvent = "AutoTest-Tool-Event-Filter2"
FilterEventType = "Internal"

# Add Template:A,B   Event Organiser:External,Internal   Registration chekbox:select,unselect   Registration Closed Date chekbox:select,unselect
# All Day chekbox:select,unselect    Price:Free,Paid  Online,Onsite    Featured
Add_Event1 = ["AutoTest-Event-A01", "A", "External",
              "https://www.baidu.com", "AutoTest", "12345678@AutoTest.com",  12345678,     # Registration
              0, 1,  "select", "", "",  "", "",                                            # Event Period
              "Paid", "1", "100",                                                          # Price
              "Online", "",                                                                # Location
              "Description", "Thumbnail.png", "Featured"]
Add_Event2 = ["AutoTest-Event-B01", "B", "Internal",
              "select", "https://www.baidu.com",  0, "select",        # Registration
              1, 2,  "unselect", "00", "30",  "23", "30",             # Event Period
              "Paid", "1", "100",                                     # Price
              "Online", "",                                           # Location
              "Description", "Thumbnail.png", "Featured"]

#Term
Add_Term=["Families","Seniors"]

#Upload Files
UploadFiles=["UIATUpload.docx","UIATUpload.xlsx","UIATUpload.pdf"]

#Builder
Builder_Info1=["AutoTest_Event_A01", "description"]
Builder_Info2=["AutoTest_Event_B01", "description"]
Builder_Info3=["AutoTest-Tool-Event-Edit2-update", "description"]

Edit_Event1=["AutoTest-Tool-Event-Edit2-update", "A", "External",
              "https://www.baidu.com", "AutoTest", "12345678@AutoTest.com",  12345678,     # Registration
              0, 1,  "select", "", "",  "", "",                                            # Event Period
              "Paid", "1", "100",                                                          # Price
              "Online", "",                                                                # Location
              "Description", "Thumbnail.png", "Featured", "AutoTest-Tool-Event-Edit2"]

#Publish/Unublish
Publish_Event1="AutoTest-Tool-Event-Draft2"
Unpublish_Event1="AutoTest-Tool-Event-Publish2"

#Delete
Delete_Event1="AutoTest-Tool-Event-Delete3"
MultiDeleteSearch="AutoTest-Tool-Event-Delete"
MultiDelete_Event=["AutoTest-Tool-Event-Delete2","AutoTest-Tool-Event-Delete1"]
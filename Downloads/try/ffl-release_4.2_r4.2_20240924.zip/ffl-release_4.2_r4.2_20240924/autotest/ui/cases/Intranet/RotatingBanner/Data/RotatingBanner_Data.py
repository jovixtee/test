#Add RBanner
RBanner_Add_UIAT=["Thumbnail.png","RBanner_Add_UIAT","Internal","AutoTest_RBanner_Add01","AutoTest_RBanner_Add01_Des"]

#Edit RBanner
RBanner_Edit_UIAT=["Thumbnail.png","AutoTest_Tool_RBanner_Draft01_Edit","External","http://www.AutoTest.com","AutoTest_Tool_RBanner_01_Edit_Des","AutoTest_Tool_RBanner_Draft01"]

#Publish RBanner
RBanner_Pub_UIAT="AutoTest_Tool_RBanner_Draft02"
RBanner_Pub_UIAT1="AutoTest_Tool_RBanner_Draft05"
RBanner_Pub_UIAT2="AutoTest_Tool_RBanner_Draft06"

#UnPublish RBanner
RBanner_UnPub_UIAT="AutoTest_Tool_RBanner_Publish01"

#Delete RBanner
RBanner_Delete_UIAT="AutoTest_Tool_RBanner_Draft03"
RBanner_Delete_UIAT1="AutoTest_Tool_RBanner_Draft04"

# Add and Publish 5 Banners 
RBanner_ForAdd5Banners_1_UIAT = ["Thumbnail.png", "AutoTest_RBanner_ForAdd5Banners_1_UIAT", "Internal", "RBanner_Add_UIAT", "RBanner_Add_UIAT_Des"]
RBanner_Pub_ForAdd5Banners_1_UIAT = "AutoTest_RBanner_ForAdd5Banners_1_UIAT"

RBanner_ForAdd5Banners_2_UIAT = ["Thumbnail.png", "AutoTest_RBanner_ForAdd5Banners_2_UIAT", "Internal", "RBanner_Add_UIAT", "RBanner_Add_UIAT_Des"]
RBanner_Pub_ForAdd5Banners_2_UIAT = "AutoTest_RBanner_ForAdd5Banners_2_UIAT"

RBanner_ForAdd5Banners_3_UIAT = ["Thumbnail.png", "AutoTest_RBanner_ForAdd5Banners_3_UIAT", "Internal", "RBanner_Add_UIAT", "RBanner_Add_UIAT_Des"]
RBanner_Pub_ForAdd5Banners_3_UIAT = "AutoTest_RBanner_ForAdd5Banners_3_UIAT"

RBanner_ForAdd5Banners_4_UIAT = ["Thumbnail.png", "AutoTest_RBanner_ForAdd5Banners_4_UIAT", "Internal", "RBanner_Add_UIAT", "RBanner_Add_UIAT_Des"]
RBanner_Pub_ForAdd5Banners_4_UIAT = "AutoTest_RBanner_ForAdd5Banners_4_UIAT"

RBanner_ForAdd5Banners_5_UIAT = ["Thumbnail.png", "AutoTest_RBanner_ForAdd5Banners_5_UIAT", "Internal", "RBanner_Add_UIAT", "RBanner_Add_UIAT_Des"]
RBanner_Pub_ForAdd5Banners_5_UIAT = "AutoTest_RBanner_ForAdd5Banners_5_UIAT"
#Add Term for Other Module use
TermSet_New1=["AutoTest_TermSet_01","Description"]

#Edit Term
TermSet_Edit1=["AutoTest_Tool_TermSet_02_Edit","Description_Edit","AutoTest_Tool_TermSet_02"]

#Delete Term
TermSet_Delete1="AutoTest_Tool_TermSet_03"

#Add SubTerm
Term_New1=["AutoTest_SubTerm_01","Description","AutoTest_Tool_TermSet_01"]

#Edit SubTerm
Term_Edit1=["AutoTest_Tool_SubTerm_02_Edit","Description_Edit","AutoTest_Tool_TermSet_02","AutoTest_Tool_SubTerm_02"]

#Delete SubTerm
Term_Delete1=["AutoTest_Tool_TermSet_03", "AutoTest_Tool_SubTerm_03"]

#Add 2nd SubTerm
secondSubTerm_New1=["AutoTest_2ndSubTerm_01","Description","AutoTest_Tool_TermSet_01","AutoTest_Tool_SubTerm_01"]

#Edit 2nd SubTerm
secondSubTerm_Edit1=["AutoTest_Tool_2ndSubTerm_02_Edit","Description_Edit","AutoTest_Tool_TermSet_02","AutoTest_Tool_SubTerm_02","AutoTest_Tool_2ndSubTerm_02"]

#Delete 2nd SubTerm
secondSubTerm_Delete1=["AutoTest_Tool_TermSet_03", "AutoTest_Tool_SubTerm_03", "AutoTest_Tool_2ndSubTerm_03"]

#Add Custom Properties
TermSet_Add_CPName=["Module","Background Color","Text Color"]
TermSet_Add_CPValue=["Activities;Article","#F74C20","#F6F6F6"]

Term_CPName=["Background Color","Text Color"]
Term_CPValue=["#F74C20","#F6F6F6"]

#Remove Custom Properties
Term_Remove_CPName=["Module"]

#Mandatory
ErrorMessage="This field is required."
Term_Nul_CPName=["","1"]
Term_Null_CPValue=["1",""]

#TermColorHex
TermColorHex="#FFAABB"
#Add Template:A,B  Price:Free,Paid  Online,Onsite    Featured    AddtoRotatingBanner:UseThumbnail,UpdateImage
Add_Activity1=["AutoTest-Activity-A01","A","Paid","1","100",0,1,"Online","","Description","Thumbnail.png","Featured","AddtoRotatingBanner","UseThumbnail",""]
Add_Activity2=["AutoTest-Activity-B02","B","Free","","",0,1,"Onsite","OnsiteText","Description","Thumbnail.png","","AddtoRotatingBanner","UpdateImage","Thumbnail.png"]

#Upload Files
UploadFiles=["UIATUpload.docx","UIATUpload.xlsx","UIATUpload.pdf"]

#Edit
#Add Template:A,B  Price:Free,Paid  Online,Onsite    Featured    AddtoRotatingBanner:UseThumbnail,UpdateImage
Edit_Activity1=["AutoTest-Tool-Activity-Published2-Edit","B","Paid","1","100",1,2,"Online","","Description","Thumbnail.png","Featured","AddtoRotatingBanner","UseThumbnail","","AutoTest-Tool-Activity-Published2"]

#Term
Add_Term=["Children","Couples"]


#Builder
Builder_Info1="AutoTest-Activity-A01"
Builder_Info2="AutoTest-Activity-B02"
Builder_Info3="AutoTest-Tool-Activity-Published2-Edit"

#Publish/Unublish
Publish_Act1="AutoTest-Tool-Activity-Draft1"
Unpublish_Act1="AutoTest-Tool-Activity-Published3"


#Delete
Delete_Act1="AutoTest-Tool-Activity-Draft2"
MultiDeleteSearch="AutoTest-Tool-Activity-Draft"
MultiDelete_Act=["AutoTest-Tool-Activity-Draft3","AutoTest-Tool-Activity-Draft4"]

#Table
Activity_TableTitle=["", "Title", "Modified on", "Modified by", "Created on", "Created by", "Status", "Action"]

#Filter/Search
FilterStatusActivity="AutoTest-Tool-Activity-Published1"
FilterTermActivity="AutoTest-Tool-Activity-Published1"
SearchActivity="AutoTest-Tool-Activity-Published1"
FilterStatus="Published"
FilterStatusAll="All"
FilterTerm=["Cooking"]
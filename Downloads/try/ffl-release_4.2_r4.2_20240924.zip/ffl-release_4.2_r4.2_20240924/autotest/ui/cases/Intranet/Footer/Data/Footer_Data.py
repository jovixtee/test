#Add Link  Option:URL,Header,Blank Header; URL:Internal,External; Feature URL:Internal,External
LinkAdd_URL=["AutoTest_Footer_Link_URL","URL","Internal","AutoTest_Link_URL"]
LinkAdd_Header=["AutoTest_Footer_Link_Header","Header","External","http://www.AutoTest.com"]
LinkAdd_BlankHeader=["","Blank Header","External","http://www.AutoTest.com"]

#Add SubLink 
SubLinkAdd_URL=["AutoTest_Footer_SubLink_URL","URL","Internal","AutoTest_Link_URL","AutoTest_Tool_Footer_URL_External01"]
SubLinkAdd_Header=["AutoTest_Footer_SubLink_Header","Header","External","http://www.AutoTest.com","AutoTest_Tool_Footer_URL_External01"]
SubLinkAdd_BlankHeader=["","Blank Header","External","http://www.AutoTest.com","AutoTest_Tool_Footer_URL_External01"]

#Edit SubLink
SubLinkEdit_URL=["AutoTest_Tool_Footer_Sub_URL_Internal01_Edit","URL","Internal","AutoTest_Tool_Footer_Sub_URL_Internal01","AutoTest_Tool_Footer_URL_External01","AutoTest_Tool_Footer_Sub_URL_Internal01"]
SubLinkEdit_Header=["AutoTest_Tool_Footer_Sub_Header01_Edit","Header","External","http://www.AutoTest.com","AutoTest_Tool_Footer_URL_External01","AutoTest_Tool_Footer_Sub_Header01"]

#Edit Link
LinkEdit_URL=["AutoTest_Tool_Header01_Edit","URL","Internal","AutoTest_Tool_Footer_Link_URL01","AutoTest_Tool_URL01"]
LinkEdit_Header=["AutoTest_Tool_Header01_Edit","Header","External","http://www.AutoTest.com","AutoTest_Tool_Header01"]

#Delete SubLink
SubLinkDelete_URL=["AutoTest_Tool_Footer_URL_External01","AutoTest_Tool_Footer_Sub_URL02"]
SubLinkDelete_Header=["AutoTest_Tool_Footer_URL_External01","AutoTest_Tool_Footer_Sub_Header02"]

#Delete Link
LinkDelete_URL="AutoTest_Tool_Footer_URL_External01"
LinkDelete_Header="AutoTest_Tool_Footer_Header02"

#Move
Move_Sublink=["AutoTest_Tool_Footer_External01","AutoTest_Sub_Header"]
Move_Link="AutoTest_Header"

#ErrorMessage
Mondatory="This field is required."

#Logo
Footer_Image="Thumbnail.png"
Footer_Title="ffl_logo_AutoTestChange"

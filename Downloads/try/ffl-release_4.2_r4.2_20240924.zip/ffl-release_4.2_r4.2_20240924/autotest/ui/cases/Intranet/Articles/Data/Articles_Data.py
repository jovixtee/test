#Add Template:A,B     Featured    AddtoRotatingBanner:UseThumbnail,UpdateImage
Add_Article1=["AutoTest-Article-A01","A","10","Description","Thumbnail.png","Featured"]
Add_Article2=["AutoTest-Article-B02","B","5","","Thumbnail.png",""]

#Upload Files
UploadFiles=["UIATUpload.docx","UIATUpload.xlsx","UIATUpload.pdf"]

#Edit
#Add Template:A,B  Price:Free,Paid  Online,Onsite    Featured    AddtoRotatingBanner:UseThumbnail,UpdateImage
Edit_Article1=["AutoTest-Tool-Article-02-Edit","B","10","Description Edit","Thumbnail.png","Featured","AutoTest-Tool-Article-02"]

#Term
Add_Term=["Family","Parenting"]

#Builder
Builder_Info1="AutoTest-Article-A01"
Builder_Info2="AutoTest-Article-B02"
Builder_Info3="AutoTest-Tool-Article-02-Edit"

#Publish/Unublish
Publish_Art1="AutoTest-Tool-Article-Draft-01"
Unpublish_Art1="AutoTest-Tool-Article-03"


#Delete
Delete_Art1="AutoTest-Tool-Article-Draft-02"
MultiDeleteSearch="AutoTest-Tool-Article-Draft"
MultiDelete_Act=["AutoTest-Tool-Article-Draft-03","AutoTest-Tool-Article-Draft-04"]

#Table
Article_TableTitle=["", "Title", "Modified on", "Modified by", "Created on", "Created by", "Status", "Action"]

#Filter/Search
FilterStatusArticle="AutoTest-Tool-Article-01"
FilterTermArticle="AutoTest-Tool-Article-01"
SearchArticle="AutoTest-Tool-Article-01"
FilterStatus="Published"
FilterStatusAll="All"
FilterTerm=["Family"]

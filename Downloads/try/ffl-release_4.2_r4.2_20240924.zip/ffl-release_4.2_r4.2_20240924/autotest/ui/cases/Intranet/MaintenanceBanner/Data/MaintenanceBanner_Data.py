# Add  Immediate
MBanner_New_Information = ["AutoTest_MBanner_Add_Information",
                           "Information", "Immediate", "", "10:00", "PM", 1, "11:00", "AM"]
MBanner_New_Alert = ["AutoTest_MBanner_Add_Alert",
                     "Alert", "", 1, "10:00", "PM", 1, "11:00", "PM"]
MBanner_New_Warning = ["AutoTest_MBanner_Add_Warning",
                       "Warning", "Immediate", "", "10:00", "PM", 1, "11:00", "AM"]

# Edit
MBanner_Edit_Information = ["AutoTest_Tool_MBanner_Information01_Edit", "Warning",
                            "Immediate", "", "11:00", "PM", 1, "11:00", "PM", "AutoTest_Tool_MBanner_Information01"]
MBanner_Edit_Alert = ["AutoTest_Tool_MBanner_Alert01_Edit", "Information",
                      "", 1, "11:00", "PM", 2, "11:00", "PM", "AutoTest_Tool_MBanner_Alert01"]
MBanner_Edit_Warning = ["AutoTest_Tool_MBanner_Warning01_Edit", "Alert",
                        "", 1, "11:00", "PM", 2, "11:00", "PM", "AutoTest_Tool_MBanner_Warning01"]

# Delete
MBanner_Delete1 = "AutoTest_Tool_MBanner_Information02"
MBanner_Delete2 = "AutoTest_Tool_MBanner_Alert02"
MBanner_Delete3 = "AutoTest_Tool_MBanner_Warning02"

# Table
MBanner_Table_Column = ["", "Message", "Type",
                        "Start Time", "End Time", "Action"]

# ErrorMessage
Mondatory = "This field is required."
StartEndDate = [0, "Please select a Start Time that is after the Current Time.", "Please select an End Time that is after the Current Time.",
                "Please select a Start Time that is before the End Time."]

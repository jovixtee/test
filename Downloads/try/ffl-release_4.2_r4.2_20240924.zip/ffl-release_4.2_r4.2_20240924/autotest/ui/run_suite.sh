env=$1
Exmodules=(Activities Articles MaintenanceBanner RotatingBanner Search Newsletter)
Inmodules=(Taxonomy Newsletter Activities Articles MaintenanceBanner RotatingBanner MegaMenu Footer PageManagement)
if [ ${env} == "Intranet" ];then
    for i in ${Inmodules[*]}; do
	CMD="robot --output ./autotest/ui/Results/${env}/${i}  --log ./autotest/ui/Results/${env}/${i}.log.html --report ./autotest/ui/Results/${env}/${i}.report.html ./autotest/ui/cases/${env}/${i}/Case"
	echo ${CMD}
	``${CMD}``
    done
else 
    for i in ${Exmodules[*]}; do
	CMD="robot --output ./autotest/ui/Results/${env}/${i}  --log ./autotest/ui/Results/${env}/${i}.log.html --report ./autotest/ui/Results/${env}/${i}.report.html ./autotest/ui/cases/${env}/${i}/Case"
	echo ${CMD}
	``${CMD}``
   done
fi
echo "------Start to Merge Report------"
CMD="rebot --merge --output ./autotest/ui/Results/${env}/Autotest_Result.xml -l ./autotest/ui/Results/${env}/Autotest_Log.html -r ./autotest/ui/Results/${env}/Autotest_Report.html ./autotest/ui/Results/${env}/*.xml"
``${CMD}``


jobid=$1
branch=$2

CMD="node /src/newmanStart.js $jobid $branch 1 https://ffl-dev-wcms.sharepointguild.com/"

echo ${CMD}

``${CMD}``

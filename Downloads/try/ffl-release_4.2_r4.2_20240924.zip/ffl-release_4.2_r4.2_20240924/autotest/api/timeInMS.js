function timeInMS(){
    let now = new Date()
	let day  = (now.toJSON()).split('T')[0]
	let time = (now.toTimeString()).split(' ')[0]
    let milliS = now.getMilliseconds()
    return res = `${day} ${time}.${milliS}`
}
function timeForReport(){
    let now = (new Date()).toJSON()
	let day  = now.split('T')[0]
    let time = now.split('T')[1]

    let timeRes = `${day.replace(/-/g, '')}-${time.split('.')[0].replace(/:/g, '')}`
    return timeRes 
}

module.exports = {
     timeInMS : timeInMS,
     timeForReport:timeForReport
 }

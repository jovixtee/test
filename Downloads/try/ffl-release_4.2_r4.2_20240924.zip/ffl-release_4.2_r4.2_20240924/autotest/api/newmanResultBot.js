const request = require('/usr/local/lib/node_modules/request')
const keys = ['15ee29c2-876d-4690-b152-74716cc8a5b1']

function PushBotMKResult(_content,_wechatkey) {
    console.log('>>> Start pushing msg to wxBot... ')
    var remoteHost = `https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=${_wechatkey}`
    console.log('>>> Start show remotehost ' + remoteHost)
    var _body = {
        "msgtype": "markdown",
        "markdown": {
            "content": _content.toString()
        }
    }

    request({
        url: remoteHost,
        method: 'POST',
        json: true,
        headers: { 'content-type': 'application/json' },
        body: _body
    },
        function (error, response, body) {
            console.log(response.statusCode)
            if (error) {
                console.log(' ............. Push Error ............... ')
                console.log(error)
            }
            else {
                console.log('>>> Push Successful')
                console.log(body)
            }
        })
}

function BuildReport(_result, _startInfo) {
    console.log('>>> Start Building Bot Content ... ')
    
    let res_sta = ''
    if (_result.assertions.failed == 0) {
        res_sta = '[ <font color="info"> SUCCEED </font> ]'
    } else {
        res_sta = '[ <font color="warning"> FAILED </font> ]'
    }

    let ti_header = `## API Test Report [${_startInfo.branch}]() ${res_sta} \n`
    let jobUrl = `https://git.avepoint.net/msfffl/ffl/-/jobs/${_startInfo.jobID}`
    let res_body =
        '> <font color="comment">Project: MSF-FFL </font>\n' +
        `> <font color="comment">Started at: ${new Date(_startInfo.timing.started).toLocaleString()} </font> \n`+
        `> <font color="comment">JobUrl: </font> [${jobUrl}](${jobUrl}) \n` +
        `> <font color="comment">Env: </font> [${_startInfo.Env}]() \r\n`+
        `### [Result Summary]()  <font color='comment'>[${_startInfo.timing.TotalDuration}]</font> \n`+
        '> Test Request: <font color="info">' + _result.requests.total + '</font>, Failed: <font color="warning">' + _result.requests.failed + '</font>\n' +
        '> Test response: <font color="info">' + _result.tests.total + '</font>, Failed: <font color="warning">' + _result.tests.failed + '</font>\n' +
        '> Assertions: <font color="info">' + _result.assertions.total + '</font>, Failed: <font color="warning">' + _result.assertions.failed + '</font>\n'

    let content = ti_header + res_body

    if (_startInfo.isMerge === '1') {
        for (var chatkey in keys) {
            console.log('>>> Start show chatkeys ' + keys[chatkey])
            PushBotMKResult(content,keys[chatkey])
        }  
    } else {
        console.log(content)
    }
}

module.exports = {
    BuildReport: BuildReport
}

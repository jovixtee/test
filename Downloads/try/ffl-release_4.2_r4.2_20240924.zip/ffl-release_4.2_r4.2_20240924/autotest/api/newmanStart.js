const newman = require('/usr/local/lib/node_modules/newman');
const logTime = require('/builds/msfffl/ffl/autotest/api/timeInMS.js')
const report = require('/builds/msfffl/ffl/autotest/api/newmanResultBot.js')

//console.log(process.argv)

let startInfo = {
    jobID : process.argv[2].toString(),
    branch : process.argv[3].toString(),
    isMerge : process.argv[4].toString(),
    htmlReport : `APITest_${logTime.timeForReport()}.html`,
    JsonReport : `APITest_${logTime.timeForReport()}.json`,
    Env: process.argv[5].toString()
}
let runOpt = {
    collection: `/builds/msfffl/ffl/autotest/api/Scripts/FFLAPI.postman_collection.json`,
    reporters : ['htmlextra','cli'],
    environment: '/builds/msfffl/ffl/autotest/api/Environment/FFL_Evn.postman_environment.json',
    //iterationData: '/src/Environment/Smoke/smoke.csv',
    insecure: true,
    reporter : {
        htmlextra: {
            testPaging: true,
            omitHeaders: true,
            showGlobalData: true,
            export: `/builds/msfffl/ffl/autotest/api/report/${startInfo.htmlReport}`,
        },
        cli:{
            export:`/builds/msfffl/ffl/autotest/api/report/${startInfo.JsonReport}`
        }
    }
}

logger(`============================= API Autotest Script Start ===================== `)

console.table(startInfo)
console.table(runOpt)

newman.run({
    collection: `/builds/msfffl/ffl/autotest/api/Scripts/FFLAPI.postman_collection.json`,
    reporters : ['htmlextra','cli'],
    environment: '/builds/msfffl/ffl/autotest/api/Environment/FFL_Evn.postman_environment.json',
    //iterationData: '/src/Environment/Smoke/smoke.csv',
    insecure: true,
    reporter : {
        htmlextra: {
            testPaging: true,
            omitHeaders: true,
            showGlobalData: true,
            export: `/builds/msfffl/ffl/autotest/api/report/${startInfo.htmlReport}`,
        },
        cli:{
            export:`/builds/msfffl/ffl/autotest/api/report/${startInfo.JsonReport}`
        }
    }
}, function (err, summary) {
  if (err) { throw err; }
  console.info('collection run complete!');
  if(err || summary.error){
        logger(`collection run encountered an error: \r\n ${summary.error}`)

    }else{
        logger(`Newman Run Completed !`)

        let timings = summary.run.timings
        let dur =  summary.run.timings.completed - summary.run.timings.started
        dur = `${(dur/1000).toFixed(2)}s`
        timings.TotalDuration = dur

        logger(`================= API result : timing  ==================`)
        console.table(timings)

        logger(`================= API result : stats  ==================`)
        let results = summary.run.stats
        console.table(results)
        startInfo.timing = timings

        report.BuildReport(results, startInfo)

        if(results.assertions.failed == 0){
            logger('Run Passes! Exit Normal ...')
            logger(`Generate Html Report: ${startInfo.htmlReport}`)
            process.exitCode = 0
        }else{
            logger('Run Failed! Exit UnNormal ... ')
            process.exitCode  = 1 
        }
    }
});

function logger(_content){
    let res = `[${logTime.timeInMS()}]: ---> ${_content}`
    return console.log(`\r\n${res}`)
}
